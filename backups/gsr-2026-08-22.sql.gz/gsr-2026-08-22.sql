--
-- PostgreSQL database dump
--

\restrict rRIQJAUAKSgJa4iob9aS9ev1yYbL1Nc6W4LzaOZPZbMvvbjDM4WzTra2ORweGia

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS td_zones_lecture_coordonnateur ON td.zones;
DROP POLICY IF EXISTS td_semaines_lecture_publique ON td.semaines;
DROP POLICY IF EXISTS td_semaines_lecture_coordonnateur ON td.semaines;
DROP POLICY IF EXISTS td_professeurs_lecture_coordonnateur ON td.professeurs;
DROP POLICY IF EXISTS td_postulations_lecture_coordonnateur ON td.postulations;
DROP POLICY IF EXISTS td_matieres_td_lecture_publique ON td.matieres_td;
DROP POLICY IF EXISTS td_matieres_td_lecture_coordonnateur ON td.matieres_td;
DROP POLICY IF EXISTS td_creneaux_lecture_publique ON td.creneaux;
DROP POLICY IF EXISTS td_creneaux_lecture_coordonnateur ON td.creneaux;
DROP POLICY IF EXISTS users_lecture_staff ON public.users;
DROP POLICY IF EXISTS users_lecture_soi_meme ON public.users;
DROP POLICY IF EXISTS user_sites_lecture_soi_meme ON public.user_sites;
DROP POLICY IF EXISTS sites_lecture_staff ON public.sites;
DROP POLICY IF EXISTS sites_lecture_publique ON public.sites;
DROP POLICY IF EXISTS recompenses_acces ON public.recompenses;
DROP POLICY IF EXISTS presences_acces ON public.presences;
DROP POLICY IF EXISTS penalites_reinscription_acces ON public.penalites_reinscription;
DROP POLICY IF EXISTS paiements_supprimes_lecture ON public.paiements_supprimes;
DROP POLICY IF EXISTS paiements_acces ON public.paiements;
DROP POLICY IF EXISTS notifications_acces ON public.notifications;
DROP POLICY IF EXISTS notes_acces ON public.notes;
DROP POLICY IF EXISTS moyennes_semestrielles_acces ON public.moyennes_semestrielles;
DROP POLICY IF EXISTS mois_exoneres_acces ON public.mois_exoneres;
DROP POLICY IF EXISTS matieres_lecture_staff ON public.matieres;
DROP POLICY IF EXISTS log_whatsapp_acces ON public.log_whatsapp;
DROP POLICY IF EXISTS galerie_lecture_publique ON public.galerie;
DROP POLICY IF EXISTS galerie_admin_suppression ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_lecture ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_ajout ON public.galerie_admin;
DROP POLICY IF EXISTS frais_td_lecture_staff ON public.frais_td;
DROP POLICY IF EXISTS eleves_suspendus_acces ON public.eleves_suspendus;
DROP POLICY IF EXISTS eleves_acces ON public.eleves;
DROP POLICY IF EXISTS depenses_annexes_lecture ON public.depenses_annexes;
DROP POLICY IF EXISTS decisions_passage_lecture ON public.decisions_passage;
DROP POLICY IF EXISTS coefficients_lecture_staff ON public.coefficients;
DROP POLICY IF EXISTS classes_lecture_staff ON public.classes;
DROP POLICY IF EXISTS classes_lecture_publique ON public.classes;
DROP POLICY IF EXISTS categories_depenses_lecture_global ON public.categories_depenses;
DROP POLICY IF EXISTS annees_scolaires_lecture_staff ON public.annees_scolaires;
DROP POLICY IF EXISTS actualites_lecture_publique ON public.actualites;
DROP POLICY IF EXISTS actualites_images_lecture_publique ON public.actualites_images;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_zone_id_fkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_matiere_principale_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_professeur_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_semaine_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_paye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_depense_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_admin_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_cloture_par_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_exonere_par_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_envoye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_ajoute_par_fkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_suspendu_par_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_saisi_par_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_categorie_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_nouvelle_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_decide_par_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_classe_suivante_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_actualite_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_cree_par_fkey;
DROP TRIGGER IF EXISTS trg_users_scope_coherence ON public.users;
DROP TRIGGER IF EXISTS trg_unique_annee_en_cours ON public.annees_scolaires;
DROP TRIGGER IF EXISTS trg_frais_td_lock_period ON public.frais_td;
DROP INDEX IF EXISTS public.idx_login_attempts_lookup;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_pkey;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_nom_zone_key;
ALTER TABLE IF EXISTS ONLY td.semaines DROP CONSTRAINT IF EXISTS semaines_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_telephone_key;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_email_key;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_pkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_professeur_id_key;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_pkey;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_nom_matiere_key;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_pkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_date_td_heure_debut_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_initiale_key;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_pkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_key;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_pkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_date_presence_key;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_matiere_type_annee_semestre_key;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_pkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_pkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_pkey;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_code_key;
ALTER TABLE IF EXISTS ONLY public.login_attempts DROP CONSTRAINT IF EXISTS login_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie DROP CONSTRAINT IF EXISTS galerie_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_matricule_key;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_pkey;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_matricule_key;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_pkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_matiere_id_key;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_pkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_nom_classe_site_id_key;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_pkey;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_nom_key;
ALTER TABLE IF EXISTS ONLY public.annees_scolaires DROP CONSTRAINT IF EXISTS annees_scolaires_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_pkey;
ALTER TABLE IF EXISTS td.zones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.semaines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.professeurs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.postulations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.matieres_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.creneaux ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.recompenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.presences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.penalites_reinscription ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements_supprimes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.moyennes_semestrielles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mois_exoneres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matieres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.login_attempts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.log_whatsapp ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie_admin ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.frais_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves_suspendus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.depenses_annexes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.decisions_passage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comptes_parents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.coefficients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories_depenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.annees_scolaires ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS td.zones_id_seq;
DROP TABLE IF EXISTS td.zones;
DROP SEQUENCE IF EXISTS td.semaines_id_seq;
DROP TABLE IF EXISTS td.semaines;
DROP SEQUENCE IF EXISTS td.professeurs_id_seq;
DROP TABLE IF EXISTS td.professeurs;
DROP SEQUENCE IF EXISTS td.postulations_id_seq;
DROP TABLE IF EXISTS td.postulations;
DROP SEQUENCE IF EXISTS td.matieres_td_id_seq;
DROP TABLE IF EXISTS td.matieres_td;
DROP SEQUENCE IF EXISTS td.creneaux_id_seq;
DROP TABLE IF EXISTS td.creneaux;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sites;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.recompenses_id_seq;
DROP TABLE IF EXISTS public.recompenses;
DROP SEQUENCE IF EXISTS public.presences_id_seq;
DROP TABLE IF EXISTS public.presences;
DROP SEQUENCE IF EXISTS public.penalites_reinscription_id_seq;
DROP TABLE IF EXISTS public.penalites_reinscription;
DROP SEQUENCE IF EXISTS public.paiements_supprimes_id_seq;
DROP TABLE IF EXISTS public.paiements_supprimes;
DROP SEQUENCE IF EXISTS public.paiements_id_seq;
DROP TABLE IF EXISTS public.paiements;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notes_id_seq;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.moyennes_semestrielles_id_seq;
DROP TABLE IF EXISTS public.moyennes_semestrielles;
DROP SEQUENCE IF EXISTS public.mois_exoneres_id_seq;
DROP TABLE IF EXISTS public.mois_exoneres;
DROP SEQUENCE IF EXISTS public.matieres_id_seq;
DROP TABLE IF EXISTS public.matieres;
DROP SEQUENCE IF EXISTS public.login_attempts_id_seq;
DROP TABLE IF EXISTS public.login_attempts;
DROP SEQUENCE IF EXISTS public.log_whatsapp_id_seq;
DROP TABLE IF EXISTS public.log_whatsapp;
DROP SEQUENCE IF EXISTS public.galerie_id_seq;
DROP SEQUENCE IF EXISTS public.galerie_admin_id_seq;
DROP TABLE IF EXISTS public.galerie_admin;
DROP TABLE IF EXISTS public.galerie;
DROP SEQUENCE IF EXISTS public.frais_td_id_seq;
DROP TABLE IF EXISTS public.frais_td;
DROP SEQUENCE IF EXISTS public.eleves_suspendus_id_seq;
DROP TABLE IF EXISTS public.eleves_suspendus;
DROP SEQUENCE IF EXISTS public.eleves_id_seq;
DROP TABLE IF EXISTS public.eleves;
DROP SEQUENCE IF EXISTS public.depenses_annexes_id_seq;
DROP TABLE IF EXISTS public.depenses_annexes;
DROP SEQUENCE IF EXISTS public.decisions_passage_id_seq;
DROP TABLE IF EXISTS public.decisions_passage;
DROP SEQUENCE IF EXISTS public.comptes_parents_id_seq;
DROP TABLE IF EXISTS public.comptes_parents;
DROP SEQUENCE IF EXISTS public.coefficients_id_seq;
DROP TABLE IF EXISTS public.coefficients;
DROP SEQUENCE IF EXISTS public.classes_id_seq;
DROP TABLE IF EXISTS public.classes;
DROP SEQUENCE IF EXISTS public.categories_depenses_id_seq;
DROP TABLE IF EXISTS public.categories_depenses;
DROP SEQUENCE IF EXISTS public.annees_scolaires_id_seq;
DROP TABLE IF EXISTS public.annees_scolaires;
DROP SEQUENCE IF EXISTS public.actualites_images_id_seq;
DROP TABLE IF EXISTS public.actualites_images;
DROP SEQUENCE IF EXISTS public.actualites_id_seq;
DROP TABLE IF EXISTS public.actualites;
DROP FUNCTION IF EXISTS td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer);
DROP FUNCTION IF EXISTS public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date);
DROP FUNCTION IF EXISTS public.trg_users_scope_coherence_fn();
DROP FUNCTION IF EXISTS public.trg_unique_annee_en_cours_fn();
DROP FUNCTION IF EXISTS public.trg_frais_td_lock_period_fn();
DROP FUNCTION IF EXISTS public.rls_auto_enable();
DROP FUNCTION IF EXISTS public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]);
DROP SCHEMA IF EXISTS td;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: td; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA td;


--
-- Name: assigner_sites_superviseur(uuid, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  delete from public.user_sites where user_id = p_user_id;
  insert into public.user_sites (user_id, site_id)
  select p_user_id, unnest(p_site_ids);
end;
$$;


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rls_auto_enable() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: trg_frais_td_lock_period_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_frais_td_lock_period_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_debut date;
  v_fin   date;
begin
  select date_debut, date_fin into v_debut, v_fin
  from public.annees_scolaires where statut = 'en_cours';

  if v_debut is not null and current_date between v_debut and v_fin then
    raise exception 'Modification du montant interdite pendant l''année scolaire en cours — uniquement en période de vacances, après l''arbitrage de fin d''année';
  end if;

  return new;
end;
$$;


--
-- Name: trg_unique_annee_en_cours_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_unique_annee_en_cours_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.statut = 'en_cours' and exists (
    select 1 from public.annees_scolaires
    where statut = 'en_cours' and id <> new.id
  ) then
    raise exception 'Une année scolaire est déjà en_cours';
  end if;

  return new;
end;
$$;


--
-- Name: trg_users_scope_coherence_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_users_scope_coherence_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.role in ('chef_site', 'secretaire') and new.site_id is null then
    raise exception 'site_id obligatoire pour le rôle %', new.role;
  end if;

  if new.role in ('coordonnateur','comptable','superviseur') and new.site_id is not null then
    raise exception 'site_id doit être NULL pour le rôle %', new.role;
  end if;

  return new;
end;
$$;


--
-- Name: valider_fin_annee(text, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  -- 1. Créer la nouvelle année scolaire
  insert into public.annees_scolaires (libelle, date_debut, date_fin, statut)
  values (p_nouvelle_libelle, p_nouvelle_date_debut, p_nouvelle_date_fin, 'en_cours');

  -- 2. Clôturer l'ancienne
  update public.annees_scolaires set statut = 'terminee' where statut = 'en_pause';

  -- 3. Appliquer les décisions "passe"
  update public.eleves e
  set classe_id = d.nouvelle_classe_id
  from public.decisions_passage d
  where d.eleve_id = e.id
    and d.decision = 'passe'
    and d.nouvelle_classe_id is not null;

  -- 4. Supprimer définitivement les élèves sortant / encore suspendus
  delete from public.eleves e
  where e.id in (select eleve_id from public.decisions_passage where decision = 'sortant')
     or e.statut = 'suspendu';

  -- 5. Purger les logs applicatifs des élèves désormais absents de `eleves`
  delete from public.log_whatsapp
  where matricule not in (select matricule from public.eleves);

  delete from public.paiements_supprimes
  where matricule not in (select matricule from public.eleves);

  -- 6. Purger la table tampon des décisions
  truncate public.decisions_passage;

exception when others then
  raise;
end;
$$;


--
-- Name: arbitrer_creneau(integer, integer); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  if exists (
    select 1
    from td.postulations p_autre
    join td.creneaux c_autre on c_autre.id = p_autre.creneau_id
    join td.creneaux c_ref on c_ref.id = p_creneau_id
    where p_autre.professeur_id = p_professeur_id
      and p_autre.statut_validation = 'Valide'
      and c_autre.id != p_creneau_id
      and c_autre.date_td = c_ref.date_td
      and c_autre.heure_debut < c_ref.heure_fin
      and c_autre.heure_fin > c_ref.heure_debut
  ) then
    raise exception 'Ce professeur est déjà validé sur un créneau qui chevauche celui-ci.';
  end if;

  update td.postulations set statut_validation = 'Valide'
  where creneau_id = p_creneau_id and professeur_id = p_professeur_id;

  update td.postulations set statut_validation = 'Refuse'
  where creneau_id = p_creneau_id and professeur_id != p_professeur_id
    and statut_validation = 'En attente';

  -- Règle A : vrai chevauchement, pas juste même heure_debut (sql/016).
  update td.postulations
  set statut_validation = 'Refuse'
  where professeur_id = p_professeur_id
    and statut_validation = 'En attente'
    and creneau_id in (
      select c_autre.id
      from td.creneaux c_autre
      join td.creneaux c_ref on c_ref.id = p_creneau_id
      where c_autre.id != p_creneau_id
        and c_autre.date_td = c_ref.date_td
        and c_autre.heure_debut < c_ref.heure_fin
        and c_autre.heure_fin > c_ref.heure_debut
    );

  update td.creneaux set statut_creneau = 'cloture' where id = p_creneau_id;

exception when others then
  raise;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actualites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites (
    id integer NOT NULL,
    titre character varying(200) NOT NULL,
    categorie text NOT NULL,
    extrait text NOT NULL,
    contenu text NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    a_la_une_jusqu_au date,
    date_publication timestamp with time zone DEFAULT now() NOT NULL,
    cree_par uuid,
    CONSTRAINT actualites_categorie_check CHECK ((categorie = ANY (ARRAY['Vie scolaire'::text, 'Événement'::text, 'Réussite'::text, 'Cours'::text, 'Examens/Contrôle'::text]))),
    CONSTRAINT actualites_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publie'::text])))
);


--
-- Name: actualites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_id_seq OWNED BY public.actualites.id;


--
-- Name: actualites_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites_images (
    id integer NOT NULL,
    actualite_id integer NOT NULL,
    storage_path text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL
);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_images_id_seq OWNED BY public.actualites_images.id;


--
-- Name: annees_scolaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.annees_scolaires (
    id integer NOT NULL,
    libelle character varying(10) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'en_cours'::text NOT NULL,
    CONSTRAINT annees_scolaires_statut_check CHECK ((statut = ANY (ARRAY['en_cours'::text, 'en_pause'::text, 'terminee'::text])))
);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.annees_scolaires_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.annees_scolaires_id_seq OWNED BY public.annees_scolaires.id;


--
-- Name: categories_depenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories_depenses (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    systeme boolean DEFAULT false NOT NULL
);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_depenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_depenses_id_seq OWNED BY public.categories_depenses.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id integer NOT NULL,
    nom_classe character varying(50) NOT NULL,
    site_id integer NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    classe_suivante_id integer
);


--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: coefficients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coefficients (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    coefficient numeric(4,2) NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT coefficients_coefficient_check CHECK ((coefficient > (0)::numeric))
);


--
-- Name: coefficients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coefficients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coefficients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coefficients_id_seq OWNED BY public.coefficients.id;


--
-- Name: comptes_parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comptes_parents (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mot_de_passe text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    derniere_connexion timestamp with time zone
);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comptes_parents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comptes_parents_id_seq OWNED BY public.comptes_parents.id;


--
-- Name: decisions_passage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decisions_passage (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    decision text NOT NULL,
    nouvelle_classe_id integer,
    annee_scolaire_id integer NOT NULL,
    date_decision timestamp with time zone DEFAULT now() NOT NULL,
    decide_par uuid NOT NULL,
    CONSTRAINT decisions_passage_decision_check CHECK ((decision = ANY (ARRAY['passe'::text, 'redouble'::text, 'sortant'::text])))
);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.decisions_passage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.decisions_passage_id_seq OWNED BY public.decisions_passage.id;


--
-- Name: depenses_annexes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.depenses_annexes (
    id integer NOT NULL,
    categorie_id integer NOT NULL,
    libelle character varying(255) NOT NULL,
    montant numeric(10,2) NOT NULL,
    date_depense date NOT NULL,
    saisi_par uuid NOT NULL,
    date_saisie timestamp with time zone DEFAULT now() NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.depenses_annexes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.depenses_annexes_id_seq OWNED BY public.depenses_annexes.id;


--
-- Name: eleves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    nom character varying(100) NOT NULL,
    prenoms character varying(150) NOT NULL,
    contact_parent character varying(15),
    classe_id integer NOT NULL,
    college character varying(150) NOT NULL,
    option_m character varying(10),
    statut text DEFAULT 'actif'::text NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL,
    contact_parent_2 character varying(15),
    CONSTRAINT eleves_au_moins_un_contact CHECK (((contact_parent IS NOT NULL) OR (contact_parent_2 IS NOT NULL))),
    CONSTRAINT eleves_statut_check CHECK ((statut = ANY (ARRAY['actif'::text, 'suspendu'::text])))
);


--
-- Name: eleves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_id_seq OWNED BY public.eleves.id;


--
-- Name: eleves_suspendus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves_suspendus (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    site_id integer NOT NULL,
    raison text NOT NULL,
    motif text NOT NULL,
    montant_du integer DEFAULT 0 NOT NULL,
    date_suspension timestamp with time zone DEFAULT now() NOT NULL,
    suspendu_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois_souscription character varying(20),
    CONSTRAINT eleves_suspendus_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[]))),
    CONSTRAINT eleves_suspendus_raison_check CHECK ((raison = ANY (ARRAY['maladie'::text, 'renvoi'::text, 'defaut_paiement'::text, 'autre'::text])))
);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_suspendus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_suspendus_id_seq OWNED BY public.eleves_suspendus.id;


--
-- Name: frais_td; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frais_td (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    montant numeric(10,2) NOT NULL
);


--
-- Name: frais_td_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frais_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frais_td_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frais_td_id_seq OWNED BY public.frais_td.id;


--
-- Name: galerie; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie (
    id integer NOT NULL,
    storage_path text NOT NULL,
    date_insertion timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie_admin (
    id integer NOT NULL,
    storage_path text NOT NULL,
    nom_fichier text NOT NULL,
    taille_octets integer,
    ajoute_par uuid NOT NULL,
    date_ajout timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_admin_id_seq OWNED BY public.galerie_admin.id;


--
-- Name: galerie_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_id_seq OWNED BY public.galerie.id;


--
-- Name: log_whatsapp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_whatsapp (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_restant integer NOT NULL,
    contact_parent character varying(25) NOT NULL,
    envoye_par uuid NOT NULL,
    date_envoi timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_whatsapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_whatsapp_id_seq OWNED BY public.log_whatsapp.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id integer NOT NULL,
    identifiant text NOT NULL,
    portail text NOT NULL,
    reussi boolean NOT NULL,
    ip inet,
    date_tentative timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT login_attempts_portail_check CHECK ((portail = ANY (ARRAY['admin'::text, 'parent'::text, 'td'::text])))
);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_attempts_id_seq OWNED BY public.login_attempts.id;


--
-- Name: matieres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matieres (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL
);


--
-- Name: matieres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matieres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matieres_id_seq OWNED BY public.matieres.id;


--
-- Name: mois_exoneres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mois_exoneres (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    motif text DEFAULT 'Absence totale durant le mois suspendu — dispense du montant dû à la réinscription'::text NOT NULL,
    exonere_par uuid NOT NULL,
    date_exoneration timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mois_exoneres_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mois_exoneres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mois_exoneres_id_seq OWNED BY public.mois_exoneres.id;


--
-- Name: moyennes_semestrielles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.moyennes_semestrielles (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    semestre smallint NOT NULL,
    moyenne_generale numeric(4,2),
    cloture_par uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT moyennes_semestrielles_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2])))
);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.moyennes_semestrielles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.moyennes_semestrielles_id_seq OWNED BY public.moyennes_semestrielles.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    matiere_id integer NOT NULL,
    type_note text NOT NULL,
    valeur numeric(4,2) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    semestre smallint DEFAULT 1 NOT NULL,
    CONSTRAINT notes_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2]))),
    CONSTRAINT notes_type_note_check CHECK ((type_note = ANY (ARRAY['I1'::text, 'I2'::text, 'I3'::text, 'D1'::text, 'D2'::text, 'Ctrl'::text]))),
    CONSTRAINT notes_valeur_check CHECK (((valeur >= (0)::numeric) AND (valeur <= (20)::numeric)))
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    site_id integer NOT NULL,
    contenu text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: paiements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    enregistre_par uuid,
    CONSTRAINT paiements_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[]))),
    CONSTRAINT paiements_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: paiements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_id_seq OWNED BY public.paiements.id;


--
-- Name: paiements_supprimes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements_supprimes (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    admin_id uuid NOT NULL,
    date_suppression timestamp with time zone DEFAULT now() NOT NULL,
    motif text NOT NULL
);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_supprimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_supprimes_id_seq OWNED BY public.paiements_supprimes.id;


--
-- Name: penalites_reinscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.penalites_reinscription (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    montant integer DEFAULT 500 NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    date_paiement date NOT NULL,
    enregistre_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    CONSTRAINT penalites_reinscription_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[])))
);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.penalites_reinscription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.penalites_reinscription_id_seq OWNED BY public.penalites_reinscription.id;


--
-- Name: presences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.presences (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    date_presence date NOT NULL,
    site_id integer NOT NULL,
    classe_id integer NOT NULL,
    present boolean DEFAULT true NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: presences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.presences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: presences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.presences_id_seq OWNED BY public.presences.id;


--
-- Name: recompenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recompenses (
    id integer NOT NULL,
    note_id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois character varying(20) NOT NULL,
    type_gain text NOT NULL,
    montant integer NOT NULL,
    depense_id integer,
    paye_par uuid NOT NULL,
    date_paiement date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recompenses_montant_check CHECK ((montant = ANY (ARRAY[200, 500]))),
    CONSTRAINT recompenses_type_gain_check CHECK ((type_gain = ANY (ARRAY['interro'::text, 'devoir'::text])))
);


--
-- Name: recompenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recompenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recompenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recompenses_id_seq OWNED BY public.recompenses.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    nom_site character varying(100) NOT NULL,
    initiale character(1) NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: user_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sites (
    user_id uuid NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    site_id integer,
    actif boolean DEFAULT true NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text])))
);


--
-- Name: creneaux; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.creneaux (
    id integer NOT NULL,
    semaine_id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    date_td date NOT NULL,
    heure_debut time without time zone NOT NULL,
    heure_fin time without time zone NOT NULL,
    montant_prevu numeric(10,2) DEFAULT 0 NOT NULL,
    statut_creneau text DEFAULT 'brouillon'::text NOT NULL,
    CONSTRAINT creneaux_statut_creneau_check CHECK ((statut_creneau = ANY (ARRAY['brouillon'::text, 'public'::text, 'cloture'::text])))
);


--
-- Name: creneaux_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.creneaux_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: creneaux_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.creneaux_id_seq OWNED BY td.creneaux.id;


--
-- Name: matieres_td; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.matieres_td (
    id integer NOT NULL,
    nom_matiere character varying(100) NOT NULL
);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.matieres_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_td_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.matieres_td_id_seq OWNED BY td.matieres_td.id;


--
-- Name: postulations; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.postulations (
    id integer NOT NULL,
    creneau_id integer NOT NULL,
    professeur_id integer NOT NULL,
    statut_validation text DEFAULT 'En attente'::text NOT NULL,
    date_postulation timestamp with time zone DEFAULT now() NOT NULL,
    motif_retrait text,
    CONSTRAINT postulations_statut_validation_check CHECK ((statut_validation = ANY (ARRAY['En attente'::text, 'Valide'::text, 'Refuse'::text, 'Retiree'::text])))
);


--
-- Name: postulations_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.postulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: postulations_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.postulations_id_seq OWNED BY td.postulations.id;


--
-- Name: professeurs; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.professeurs (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100) NOT NULL,
    telephone character varying(25) NOT NULL,
    email character varying(150) NOT NULL,
    mot_de_passe text NOT NULL,
    zone_id integer NOT NULL,
    matiere_principale_id integer NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: professeurs_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.professeurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professeurs_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.professeurs_id_seq OWNED BY td.professeurs.id;


--
-- Name: semaines; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.semaines (
    id integer NOT NULL,
    libelle character varying(100) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    date_cloture timestamp with time zone,
    CONSTRAINT semaines_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publiee'::text, 'cloturee'::text])))
);


--
-- Name: semaines_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.semaines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semaines_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.semaines_id_seq OWNED BY td.semaines.id;


--
-- Name: zones; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.zones (
    id integer NOT NULL,
    nom_zone character varying(100) NOT NULL
);


--
-- Name: zones_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.zones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zones_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.zones_id_seq OWNED BY td.zones.id;


--
-- Name: actualites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites ALTER COLUMN id SET DEFAULT nextval('public.actualites_id_seq'::regclass);


--
-- Name: actualites_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images ALTER COLUMN id SET DEFAULT nextval('public.actualites_images_id_seq'::regclass);


--
-- Name: annees_scolaires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires ALTER COLUMN id SET DEFAULT nextval('public.annees_scolaires_id_seq'::regclass);


--
-- Name: categories_depenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses ALTER COLUMN id SET DEFAULT nextval('public.categories_depenses_id_seq'::regclass);


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: coefficients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients ALTER COLUMN id SET DEFAULT nextval('public.coefficients_id_seq'::regclass);


--
-- Name: comptes_parents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents ALTER COLUMN id SET DEFAULT nextval('public.comptes_parents_id_seq'::regclass);


--
-- Name: decisions_passage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage ALTER COLUMN id SET DEFAULT nextval('public.decisions_passage_id_seq'::regclass);


--
-- Name: depenses_annexes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes ALTER COLUMN id SET DEFAULT nextval('public.depenses_annexes_id_seq'::regclass);


--
-- Name: eleves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves ALTER COLUMN id SET DEFAULT nextval('public.eleves_id_seq'::regclass);


--
-- Name: eleves_suspendus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus ALTER COLUMN id SET DEFAULT nextval('public.eleves_suspendus_id_seq'::regclass);


--
-- Name: frais_td id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td ALTER COLUMN id SET DEFAULT nextval('public.frais_td_id_seq'::regclass);


--
-- Name: galerie id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie ALTER COLUMN id SET DEFAULT nextval('public.galerie_id_seq'::regclass);


--
-- Name: galerie_admin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin ALTER COLUMN id SET DEFAULT nextval('public.galerie_admin_id_seq'::regclass);


--
-- Name: log_whatsapp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp ALTER COLUMN id SET DEFAULT nextval('public.log_whatsapp_id_seq'::regclass);


--
-- Name: login_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN id SET DEFAULT nextval('public.login_attempts_id_seq'::regclass);


--
-- Name: matieres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres ALTER COLUMN id SET DEFAULT nextval('public.matieres_id_seq'::regclass);


--
-- Name: mois_exoneres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres ALTER COLUMN id SET DEFAULT nextval('public.mois_exoneres_id_seq'::regclass);


--
-- Name: moyennes_semestrielles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles ALTER COLUMN id SET DEFAULT nextval('public.moyennes_semestrielles_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: paiements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements ALTER COLUMN id SET DEFAULT nextval('public.paiements_id_seq'::regclass);


--
-- Name: paiements_supprimes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes ALTER COLUMN id SET DEFAULT nextval('public.paiements_supprimes_id_seq'::regclass);


--
-- Name: penalites_reinscription id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription ALTER COLUMN id SET DEFAULT nextval('public.penalites_reinscription_id_seq'::regclass);


--
-- Name: presences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences ALTER COLUMN id SET DEFAULT nextval('public.presences_id_seq'::regclass);


--
-- Name: recompenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses ALTER COLUMN id SET DEFAULT nextval('public.recompenses_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: creneaux id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux ALTER COLUMN id SET DEFAULT nextval('td.creneaux_id_seq'::regclass);


--
-- Name: matieres_td id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td ALTER COLUMN id SET DEFAULT nextval('td.matieres_td_id_seq'::regclass);


--
-- Name: postulations id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations ALTER COLUMN id SET DEFAULT nextval('td.postulations_id_seq'::regclass);


--
-- Name: professeurs id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs ALTER COLUMN id SET DEFAULT nextval('td.professeurs_id_seq'::regclass);


--
-- Name: semaines id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines ALTER COLUMN id SET DEFAULT nextval('td.semaines_id_seq'::regclass);


--
-- Name: zones id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones ALTER COLUMN id SET DEFAULT nextval('td.zones_id_seq'::regclass);


--
-- Data for Name: actualites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites (id, titre, categorie, extrait, contenu, statut, a_la_une_jusqu_au, date_publication, cree_par) FROM stdin;
1	Démarrage des Cours Intensifs Préparatoires — Édition 2026	Cours	Le GSR lance sa nouvelle édition des Cours Intensifs Préparatoires sur ses 3 sites. Un programme pensé pour combler les lacunes et aborder la suite de l'année en confiance.	Le Groupe Secret de la Réussite ouvre officiellement sa nouvelle édition des Cours Intensifs Préparatoires, sur ses trois sites de Jéricho, Yagbé et Vèdoko. Ce programme, pensé pour la période de vacances, s'adresse à tous les élèves de la 6ème à la Terminale qui souhaitent consolider leurs acquis avant la reprise.\r\n\r\nL'objectif est simple : aborder en douceur les nouvelles notions du programme à venir. Chaque séance s'appuie sur des documents de cours structurés et des évaluations ciblées, pour que chaque élève progresse à son rythme sans se sentir dépassé.\r\n\r\nNos enseignants sont sélectionnés pour leur rigueur et leur pédagogie. Les tarifs, accessibles et adaptés à chaque niveau, sont disponibles en détail sur notre page Tarifs.\r\n\r\nLes places étant limitées sur chaque site, nous invitons les parents à inscrire rapidement leurs enfants en se rendant directement sur l'un de nos trois centres, ou en nous contactant par téléphone pour toute question sur le programme et les horaires.	publie	2026-08-22	2026-08-08 06:48:05.408897+00	\N
2	Démarrage des séances de révision BEPC 2026	Examens/Contrôle	À l'approche des examens, le GSR met en place un dispositif de révision intensif et méthodique dédié aux candidats.	À quelques mois d'une échéance décisive, le Groupe Secret de la Réussite lance ses séances de révision dédiées aux candidats au BEPC 2026. Ce dispositif vise à consolider les acquis sur l'ensemble du programme dans toutes les matières, avec un accent particulier sur les matières fondamentales : Mathématiques, PCT et SVT.\r\n\r\nLe format retenu combine rappels de cours structurés et exercices ciblés chacun suivi d'une correction méthodique en groupe. Cette approche permet à chaque candidat de mesurer précisément ses progrès et d'identifier les points qui demandent encore du travail avant le jour J.\r\n\r\nNos enseignants, habitués aux exigences de l'examen, accompagnent les élèves avec des conseils pratiques de gestion du temps et de méthodologie de rédaction, deux facteurs qui font souvent la différence le jour de l'épreuve.\r\n\r\nLes séances se déroulent sur nos sites de Jéricho et Yagbé, selon un calendrier communiqué aux familles inscrites. Pour rejoindre le dispositif ou obtenir plus d'informations, contactez-nous ou rendez-vous directement sur l'un de nos centres.	publie	\N	2026-08-01 06:48:05.408897+00	\N
3	Séance de Coaching et de Motivation des candidats aux examens 2026	Vie scolaire	Au-delà des révisions académiques, le GSR accompagne aussi ses candidats sur le plan psychologique avec une séance de coaching et de motivation.	La réussite aux examens ne se joue pas uniquement sur les connaissances académiques : la confiance en soi, la gestion du stress et la discipline personnelle jouent un rôle tout aussi déterminant. C'est dans cet esprit que le Groupe Secret de la Réussite a organisé une séance de coaching et de motivation dédiée à ses candidats aux examens 2026.\r\n\r\nAnimée par notre équipe pédagogique, cette rencontre a permis d'aborder des sujets essentiels à l'approche des épreuves : techniques de gestion du stress, organisation efficace du temps de révision, et surtout, comment garder confiance face à la pression des examens.\r\n\r\nLes élèves ont pu échanger librement sur leurs appréhensions et repartir avec des outils concrets pour aborder sereinement les semaines à venir. Cette dimension d'accompagnement humain fait partie intégrante de notre philosophie : préparer nos élèves non seulement académiquement, mais aussi mentalement, à affronter les moments décisifs de leur parcours scolaire.	publie	\N	2026-07-25 06:48:05.408897+00	\N
\.


--
-- Data for Name: actualites_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites_images (id, actualite_id, storage_path, ordre) FROM stdin;
1	1	vitrine/accueil/img_cip.jpg	0
2	2	vitrine/accueil/img_prepa.jpg	0
\.


--
-- Data for Name: annees_scolaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.annees_scolaires (id, libelle, date_debut, date_fin, statut) FROM stdin;
1	2026-2027	2026-10-01	2027-05-31	en_cours
\.


--
-- Data for Name: categories_depenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories_depenses (id, nom, systeme) FROM stdin;
1	Location Site	t
2	Paiement Prof	t
3	Fournitures	t
4	Transport	t
5	Communication	t
6	Maintenance	t
7	Frais bancaires	t
8	Autre	t
9	Récompense	f
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, nom_classe, site_id, ordre, classe_suivante_id) FROM stdin;
12	Terminale D	1	7	\N
16	3ème	2	4	\N
13	6ème	2	1	14
14	5ème	2	2	15
15	4ème	2	3	16
4	3ème A	1	4	\N
17	3ème B	1	4	\N
1	6ème A	1	1	2
20	6ème B	1	1	19
2	5ème A	1	2	3
19	5ème B	1	2	18
3	4ème A	1	3	4
18	4ème B	1	3	17
11	Terminale C	1	7	\N
5	Seconde B	1	5	7
7	Première B	1	6	10
10	Terminale B	1	7	\N
22	3ème C	1	4	\N
8	Première D	1	6	12
6	Seconde C	1	5	24
24	Première C	1	6	11
23	Seconde D	1	5	8
\.


--
-- Data for Name: coefficients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coefficients (id, classe_id, matiere_id, coefficient, updated_at) FROM stdin;
1	1	1	1.00	2026-08-09 22:33:29.272+00
2	1	2	1.00	2026-08-09 22:33:38.434+00
3	1	3	1.00	2026-08-09 22:33:42.435+00
4	1	4	1.00	2026-08-09 22:33:50.941+00
5	1	5	1.00	2026-08-09 22:33:53.754+00
7	1	7	1.00	2026-08-09 22:34:02.071+00
11	20	1	1.00	2026-08-09 22:35:23.232+00
12	20	2	1.00	2026-08-09 22:35:26.587+00
13	20	3	1.00	2026-08-09 22:35:29.64+00
14	20	4	1.00	2026-08-09 22:35:32.733+00
15	20	5	1.00	2026-08-09 22:35:36.384+00
17	20	7	1.00	2026-08-09 22:36:21.475+00
21	2	1	1.00	2026-08-09 22:38:19.883+00
22	2	2	1.00	2026-08-09 22:38:23.389+00
23	2	3	1.00	2026-08-09 22:38:28.759+00
24	2	4	1.00	2026-08-09 22:38:33.558+00
25	2	5	1.00	2026-08-09 22:38:37.453+00
124	22	1	2.00	2026-08-20 21:47:51.364+00
29	2	7	1.00	2026-08-09 22:39:47.027+00
32	19	1	1.00	2026-08-09 22:41:11.023+00
33	19	2	1.00	2026-08-09 22:41:15.097+00
34	19	3	1.00	2026-08-09 22:41:19.274+00
35	19	4	1.00	2026-08-09 22:41:25.689+00
36	19	5	1.00	2026-08-09 22:41:29.795+00
38	19	7	1.00	2026-08-09 22:42:13.316+00
42	13	1	1.00	2026-08-09 22:43:48.04+00
43	13	2	1.00	2026-08-09 22:43:55.083+00
44	13	3	1.00	2026-08-09 22:44:00.208+00
45	13	4	1.00	2026-08-09 22:44:05.903+00
46	13	5	1.00	2026-08-09 22:44:11.06+00
47	13	6	1.00	2026-08-09 22:44:31.404+00
48	13	7	1.00	2026-08-09 22:44:42.046+00
49	13	8	1.00	2026-08-09 22:44:52.513+00
50	13	9	1.00	2026-08-09 22:45:02.407+00
51	13	10	1.00	2026-08-09 22:45:13.351+00
52	14	1	1.00	2026-08-09 22:46:19.228+00
53	14	2	1.00	2026-08-09 22:46:23.192+00
54	14	3	1.00	2026-08-09 22:46:28.257+00
55	14	4	1.00	2026-08-09 22:46:32.856+00
56	14	5	1.00	2026-08-09 22:46:37.237+00
57	14	6	1.00	2026-08-09 22:47:00.854+00
58	14	7	1.00	2026-08-09 22:47:10.978+00
59	14	8	1.00	2026-08-09 22:47:24.397+00
60	14	9	1.00	2026-08-09 22:47:35.053+00
61	14	10	1.00	2026-08-09 22:47:46.279+00
63	3	1	2.00	2026-08-09 22:57:20.66+00
64	3	2	3.00	2026-08-09 22:57:22.919+00
65	3	3	2.00	2026-08-09 22:57:25.385+00
66	3	4	2.00	2026-08-09 22:57:27.442+00
67	3	5	2.00	2026-08-09 22:57:29.779+00
69	3	7	2.00	2026-08-09 22:57:33.838+00
72	3	10	2.00	2026-08-09 22:57:40.597+00
74	1	11	1.00	2026-08-20 20:53:48.029+00
75	20	11	1.00	2026-08-20 20:58:22.005+00
76	2	11	1.00	2026-08-20 21:02:33.637+00
77	19	11	1.00	2026-08-20 21:03:58.459+00
78	3	9	2.00	2026-08-20 21:05:58.431+00
79	3	11	2.00	2026-08-20 21:06:13.081+00
80	18	1	2.00	2026-08-20 21:07:05.907+00
81	18	2	3.00	2026-08-20 21:07:12.194+00
82	18	3	2.00	2026-08-20 21:07:19.585+00
83	18	4	2.00	2026-08-20 21:07:30.287+00
84	18	5	2.00	2026-08-20 21:07:38.124+00
85	18	7	2.00	2026-08-20 21:07:47.063+00
86	18	9	2.00	2026-08-20 21:07:57.975+00
87	18	10	2.00	2026-08-20 21:08:05.342+00
88	18	11	2.00	2026-08-20 21:08:10.38+00
89	4	1	2.00	2026-08-20 21:09:54.018+00
91	4	3	2.00	2026-08-20 21:10:05.73+00
90	4	2	3.00	2026-08-20 21:10:10.801+00
93	4	4	2.00	2026-08-20 21:10:19.65+00
94	4	5	2.00	2026-08-20 21:10:37.474+00
95	4	7	2.00	2026-08-20 21:10:51.068+00
96	4	9	2.00	2026-08-20 21:10:59.718+00
97	4	10	2.00	2026-08-20 21:11:04.992+00
98	4	11	2.00	2026-08-20 21:11:10.35+00
99	17	1	2.00	2026-08-20 21:11:35.157+00
100	17	2	3.00	2026-08-20 21:11:41.091+00
101	17	3	2.00	2026-08-20 21:11:47.24+00
102	17	4	2.00	2026-08-20 21:11:54.935+00
103	17	5	2.00	2026-08-20 21:12:02.594+00
104	17	7	2.00	2026-08-20 21:12:42.877+00
105	17	11	2.00	2026-08-20 21:12:52.309+00
106	17	10	2.00	2026-08-20 21:12:57.798+00
107	17	9	2.00	2026-08-20 21:13:03.305+00
108	5	1	2.00	2026-08-20 21:16:35.619+00
109	5	6	2.00	2026-08-20 21:18:10.993+00
110	5	7	2.00	2026-08-20 21:18:47.551+00
111	5	9	2.00	2026-08-20 21:19:00.825+00
112	5	10	2.00	2026-08-20 21:19:03.931+00
113	5	8	2.00	2026-08-20 21:19:21.803+00
114	5	2	1.00	2026-08-20 21:19:44.393+00
115	5	5	1.00	2026-08-20 21:20:08.798+00
117	6	1	1.00	2026-08-20 21:23:29.97+00
118	6	3	2.00	2026-08-20 21:23:35.617+00
119	6	6	2.00	2026-08-20 21:24:11.632+00
120	6	7	1.00	2026-08-20 21:24:16.308+00
121	6	2	3.00	2026-08-20 21:25:08.492+00
122	6	4	3.00	2026-08-20 21:26:06.809+00
123	6	5	3.00	2026-08-20 21:26:11.502+00
125	22	2	3.00	2026-08-20 21:47:55.724+00
126	22	3	2.00	2026-08-20 21:48:06.475+00
127	22	4	2.00	2026-08-20 21:48:12.505+00
128	22	5	2.00	2026-08-20 21:48:19.214+00
129	22	7	2.00	2026-08-20 21:48:31.284+00
130	22	9	2.00	2026-08-20 21:48:38.832+00
131	22	10	2.00	2026-08-20 21:48:44.799+00
132	22	11	2.00	2026-08-20 21:48:52.642+00
116	5	3	2.00	2026-08-20 21:51:19.858+00
134	23	1	1.00	2026-08-20 22:46:51.427+00
135	23	3	2.00	2026-08-20 22:46:58.666+00
136	23	6	2.00	2026-08-20 22:47:16.311+00
137	23	7	1.00	2026-08-20 22:47:38.451+00
138	23	4	3.00	2026-08-20 22:48:20.759+00
139	23	5	3.00	2026-08-20 22:48:25.28+00
140	23	2	3.00	2026-08-20 22:48:33.194+00
141	8	2	4.00	2026-08-20 22:55:08.233+00
142	8	4	4.00	2026-08-20 22:55:16.977+00
143	8	5	5.00	2026-08-20 22:55:20.283+00
144	8	1	2.00	2026-08-20 22:55:33.318+00
145	8	3	2.00	2026-08-20 22:55:37.662+00
146	8	6	2.00	2026-08-20 22:55:41.973+00
147	8	7	2.00	2026-08-20 22:55:49.107+00
148	24	7	2.00	2026-08-20 22:59:21.262+00
149	24	6	2.00	2026-08-20 22:59:24.671+00
150	24	5	2.00	2026-08-20 22:59:28.71+00
151	24	4	5.00	2026-08-20 22:59:34.997+00
152	24	3	2.00	2026-08-20 22:59:39.451+00
153	24	2	5.00	2026-08-20 22:59:46.135+00
154	24	1	2.00	2026-08-20 22:59:49.919+00
155	7	10	1.00	2026-08-20 23:03:01.782+00
156	7	9	1.00	2026-08-20 23:03:26.481+00
157	7	8	4.00	2026-08-20 23:03:30.625+00
158	7	7	4.00	2026-08-20 23:03:34.118+00
159	7	6	3.00	2026-08-20 23:03:37.839+00
163	7	1	4.00	2026-08-20 23:03:56.335+00
160	7	5	2.00	2026-08-20 23:03:41.992+00
161	7	3	3.00	2026-08-20 23:03:48.955+00
162	7	2	2.00	2026-08-20 23:03:52.106+00
164	12	7	2.00	2026-08-20 23:05:03.142+00
165	12	6	2.00	2026-08-20 23:05:06.21+00
166	12	5	5.00	2026-08-20 23:05:11.855+00
167	12	4	4.00	2026-08-20 23:05:18.934+00
168	12	3	2.00	2026-08-20 23:05:22.5+00
169	12	2	4.00	2026-08-20 23:05:29.37+00
170	12	1	2.00	2026-08-20 23:05:32.335+00
171	11	7	2.00	2026-08-20 23:07:58.54+00
172	11	6	2.00	2026-08-20 23:08:02.077+00
173	11	5	2.00	2026-08-20 23:08:09.04+00
174	11	4	5.00	2026-08-20 23:08:17.229+00
175	11	3	2.00	2026-08-20 23:08:23.15+00
176	11	2	6.00	2026-08-20 23:08:27.895+00
177	11	1	2.00	2026-08-20 23:09:00.712+00
178	10	10	1.00	2026-08-20 23:11:25.359+00
179	10	9	1.00	2026-08-20 23:11:28.377+00
180	10	8	4.00	2026-08-20 23:11:33.319+00
181	10	7	4.00	2026-08-20 23:11:37.508+00
182	10	6	3.00	2026-08-20 23:11:40.834+00
183	10	5	2.00	2026-08-20 23:11:44.256+00
184	10	3	3.00	2026-08-20 23:11:52.313+00
185	10	2	2.00	2026-08-20 23:12:05.25+00
186	10	1	4.00	2026-08-20 23:12:11.515+00
\.


--
-- Data for Name: comptes_parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comptes_parents (id, matricule, mot_de_passe, date_creation, derniere_connexion) FROM stdin;
\.


--
-- Data for Name: decisions_passage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.decisions_passage (id, eleve_id, decision, nouvelle_classe_id, annee_scolaire_id, date_decision, decide_par) FROM stdin;
\.


--
-- Data for Name: depenses_annexes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.depenses_annexes (id, categorie_id, libelle, montant, date_depense, saisi_par, date_saisie, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: eleves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves (id, matricule, nom, prenoms, contact_parent, classe_id, college, option_m, statut, date_inscription, contact_parent_2) FROM stdin;
2	J08261799	GODONOU	Merveille	+2290197456718	20	CEG DANTOKPA	M10	actif	2026-08-13 20:10:03.439013+00	+2290144352378
1	J08262960	AKAKPO	Bertrand	+2290156456755	2	CEG DU LAC	M6	actif	2026-08-13 20:06:56.122825+00	\N
\.


--
-- Data for Name: eleves_suspendus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves_suspendus (id, eleve_id, site_id, raison, motif, montant_du, date_suspension, suspendu_par, annee_scolaire_id, mois_souscription) FROM stdin;
\.


--
-- Data for Name: frais_td; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frais_td (id, classe_id, montant) FROM stdin;
2	13	2000.00
4	14	3000.00
6	15	3000.00
7	4	5000.00
8	16	5000.00
9	5	5000.00
10	6	5000.00
11	7	6000.00
12	8	6000.00
14	10	8000.00
16	12	8000.00
17	17	5000.00
1	1	2500.00
20	20	2500.00
3	2	2500.00
19	19	2500.00
5	3	3500.00
18	18	3500.00
15	11	10000.00
22	22	5000.00
23	23	5000.00
24	24	6000.00
\.


--
-- Data for Name: galerie; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie (id, storage_path, date_insertion) FROM stdin;
\.


--
-- Data for Name: galerie_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie_admin (id, storage_path, nom_fichier, taille_octets, ajoute_par, date_ajout) FROM stdin;
\.


--
-- Data for Name: log_whatsapp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_whatsapp (id, matricule, mois_souscription, montant_restant, contact_parent, envoye_par, date_envoi) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, identifiant, portail, reussi, ip, date_tentative) FROM stdin;
1	jealexhouegbe	admin	t	\N	2026-08-08 09:04:55.328051+00
2	jealexhouegbe	admin	t	\N	2026-08-08 09:39:40.149597+00
3	jealexhouegbe	admin	t	\N	2026-08-08 10:11:21.70487+00
4	jealexhouegbe	admin	t	\N	2026-08-08 17:28:36.86968+00
5	jealexhouegbe	admin	t	\N	2026-08-08 19:50:29.083241+00
6	jealexhouegbe	admin	t	\N	2026-08-08 20:18:37.037356+00
7	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:19:48.89375+00
8	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:20:20.527295+00
9	urielhouegbe	admin	t	\N	2026-08-08 20:21:05.91664+00
10	jealexhouegbe	admin	t	\N	2026-08-09 07:24:15.712276+00
11	jealexhouegbe	admin	t	\N	2026-08-09 17:50:38.07625+00
12	jealexhouegbe	admin	t	\N	2026-08-09 18:04:09.738492+00
13	jealexhouegbe	admin	t	\N	2026-08-09 21:45:01.744606+00
14	jealexhouegbe	admin	t	\N	2026-08-09 22:30:52.951794+00
15	jealexhouegbe	admin	t	\N	2026-08-09 22:51:08.511658+00
16	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:17:04.613553+00
17	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:38:02.296944+00
18	jealexhouegbe	admin	t	\N	2026-08-10 06:54:14.925918+00
19	urielhouegbe	admin	t	\N	2026-08-10 06:54:53.49026+00
20	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-10 14:16:24.752172+00
21	jealexhouegbe	admin	t	\N	2026-08-11 05:15:32.956857+00
22	jealexhouegbe	admin	t	\N	2026-08-11 07:17:09.84883+00
23	jealexhouegbe	admin	t	\N	2026-08-11 14:42:01.560105+00
24	jealexhouegbe 	admin	f	\N	2026-08-11 14:50:28.385101+00
25	jealexhouegbe	admin	t	\N	2026-08-11 14:51:47.881878+00
26	urielhouegbe	admin	t	\N	2026-08-11 22:09:42.773948+00
27	urielhouegbe	admin	t	\N	2026-08-11 22:55:35.577395+00
28	jucalhouegbe	admin	f	\N	2026-08-11 23:47:44.631597+00
29	jealexlhouegbe	admin	f	\N	2026-08-11 23:47:59.101531+00
30	jealexhouegbe	admin	t	\N	2026-08-11 23:48:07.321782+00
31	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:07:07.80926+00
32	jealexhouegbe	admin	t	\N	2026-08-12 00:14:52.139976+00
33	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:14:52.297684+00
34	jealexhouegbe	admin	t	\N	2026-08-12 00:40:28.33475+00
35	jealexhouegbe	admin	t	\N	2026-08-13 06:44:02.687375+00
36	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-13 06:51:51.529595+00
37	urielhouegbe	admin	t	\N	2026-08-13 10:02:55.168658+00
38	urielhouegbe 	admin	f	\N	2026-08-13 10:12:23.387167+00
39	urielhouegbe	admin	t	\N	2026-08-13 10:12:31.147252+00
40	jealexhouegbe	admin	t	\N	2026-08-13 19:58:42.339916+00
41	jealexhouegbe	admin	t	\N	2026-08-13 20:31:27.647073+00
42	urielhouegbe	admin	t	\N	2026-08-14 00:18:35.46862+00
43	urielhouegbe	admin	t	\N	2026-08-15 18:08:50.226733+00
44	jucalhouegbe	admin	f	\N	2026-08-16 16:51:07.068095+00
45	jealexhouegbe	admin	t	\N	2026-08-16 16:51:21.321239+00
46	urielhouegbe	admin	t	\N	2026-08-16 23:14:59.890519+00
47	jealexhouegbe	admin	t	\N	2026-08-17 04:22:29.319416+00
48	urielhouegbe	admin	t	\N	2026-08-17 19:20:15.425783+00
49	jealexhouegbe	admin	f	\N	2026-08-17 19:50:55.965311+00
50	jealexhouegbe	admin	t	\N	2026-08-17 19:51:24.8748+00
51	jealexhouegbe 	admin	f	\N	2026-08-17 19:54:57.472031+00
52	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:11.314247+00
53	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:15.276516+00
54	jealexhouegbe	admin	t	\N	2026-08-17 19:55:32.145075+00
55	urielhouegbe	admin	t	\N	2026-08-18 14:39:31.730354+00
56	urielhouegbe	admin	t	\N	2026-08-18 15:01:39.644185+00
57	jealexhouegbe	admin	t	\N	2026-08-18 18:19:26.597107+00
58	urielhouegbe	admin	t	\N	2026-08-18 18:25:36.774151+00
59	urielhouegbe	admin	t	\N	2026-08-18 19:18:33.026739+00
60	urielhouegbe	admin	t	\N	2026-08-18 19:41:50.997441+00
61	urielhouegbe	admin	t	\N	2026-08-18 19:46:37.319351+00
62	urielhouegbe	admin	t	\N	2026-08-18 20:04:14.497463+00
63	urielhouegbe	admin	t	\N	2026-08-18 20:24:31.820607+00
64	jealexhouegbe	admin	t	\N	2026-08-18 20:57:59.714752+00
65	jealexhouegbe	admin	f	\N	2026-08-18 21:35:02.243166+00
66	jealexhouegbe	admin	t	\N	2026-08-18 21:35:26.978454+00
67	jealexhouegbe	admin	t	\N	2026-08-18 22:15:50.900336+00
68	jealexhouegbe	admin	t	\N	2026-08-18 22:25:22.228939+00
69	jealexhouegbe	admin	t	\N	2026-08-18 22:26:16.772262+00
70	jealexhouegbe	admin	f	\N	2026-08-20 20:51:38.231956+00
71	jealexhouegbe	admin	t	\N	2026-08-20 20:52:02.9463+00
72	jealexhouegbe	admin	t	\N	2026-08-20 22:40:52.726733+00
73	jealexhouegbe	admin	t	\N	2026-08-21 05:34:05.517187+00
\.


--
-- Data for Name: matieres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matieres (id, nom, code, ordre, actif) FROM stdin;
1	Francais	FR	1	t
2	Mathematiques	MATHS	2	t
3	Anglais	ANG	3	t
5	SVT	SVT	5	t
6	Philosophie	PHILO	6	t
7	Histoire-Geographie	HG	7	t
8	Economie	ECO	8	t
9	Espagnol	ESP	9	t
10	Allemand	ALL	10	t
11	Com. Ecrite	COM_ECRITE	11	t
4	PCT	PCT	4	t
\.


--
-- Data for Name: mois_exoneres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mois_exoneres (id, eleve_id, mois_souscription, annee_scolaire_id, motif, exonere_par, date_exoneration) FROM stdin;
\.


--
-- Data for Name: moyennes_semestrielles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.moyennes_semestrielles (id, eleve_id, annee_scolaire_id, semestre, moyenne_generale, cloture_par, updated_at) FROM stdin;
1	2	1	2	\N	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-08-17 04:30:04.97269+00
2	1	1	2	\N	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-08-17 04:30:04.97269+00
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, eleve_id, matiere_id, type_note, valeur, annee_scolaire_id, updated_at, semestre) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, site_id, contenu, lu, date_creation) FROM stdin;
\.


--
-- Data for Name: paiements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements (id, eleve_id, mois_souscription, montant_paye, date_paiement, mode_paiement, annee_scolaire_id, enregistre_par) FROM stdin;
\.


--
-- Data for Name: paiements_supprimes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements_supprimes (id, matricule, mois_souscription, montant_paye, date_paiement, mode_paiement, admin_id, date_suppression, motif) FROM stdin;
\.


--
-- Data for Name: penalites_reinscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.penalites_reinscription (id, eleve_id, montant, mode_paiement, date_paiement, enregistre_par, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: presences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.presences (id, eleve_id, date_presence, site_id, classe_id, present, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: recompenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recompenses (id, note_id, eleve_id, annee_scolaire_id, mois, type_gain, montant, depense_id, paye_par, date_paiement, created_at) FROM stdin;
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, nom_site, initiale) FROM stdin;
1	Jéricho	J
2	Yagbé	Y
\.


--
-- Data for Name: user_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sites (user_id, site_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, role, site_id, actif) FROM stdin;
55899634-2a3d-4d0c-a169-c883ddd3b72f	jealexhouegbe	jucaljealexhouegbe@gmail.com	coordonnateur	\N	t
7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	urielhouegbe	urielaxelhouegbe@gmail.com	comptable	\N	t
\.


--
-- Data for Name: creneaux; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.creneaux (id, semaine_id, classe_id, matiere_id, date_td, heure_debut, heure_fin, montant_prevu, statut_creneau) FROM stdin;
3	4	20	3	2026-10-10	08:00:00	10:00:00	3000.00	cloture
4	4	18	1	2026-10-10	10:30:00	12:30:00	3000.00	cloture
5	5	20	7	2026-10-14	10:00:00	12:00:00	2000.00	cloture
6	5	18	4	2026-10-14	10:00:00	12:00:00	3000.00	cloture
\.


--
-- Data for Name: matieres_td; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.matieres_td (id, nom_matiere) FROM stdin;
1	Francais
2	Mathematiques
3	Anglais
5	SVT
6	Philosophie
7	Histoire-Geographie
8	Economie
9	Espagnol
10	Allemand
11	Communication écrite
4	PCT
\.


--
-- Data for Name: postulations; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.postulations (id, creneau_id, professeur_id, statut_validation, date_postulation, motif_retrait) FROM stdin;
3	3	1	Valide	2026-08-12 00:37:45.857256+00	\N
5	6	1	Refuse	2026-08-13 06:52:27.566445+00	\N
4	5	1	Retiree	2026-08-13 06:52:19.155386+00	Maladie
\.


--
-- Data for Name: professeurs; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.professeurs (id, nom, prenom, telephone, email, mot_de_passe, zone_id, matiere_principale_id, actif, date_inscription) FROM stdin;
1	HOUEGBE	Uriel	0169974527	urielaxelhouegbe@gmail.com	$2b$10$kTFT24SIP1kiTHh.450jdepLCViUKeP/iN8GqsSu7snvTAROKciG.	1	2	t	2026-08-09 23:16:20.976307+00
\.


--
-- Data for Name: semaines; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.semaines (id, libelle, date_debut, date_fin, statut, date_creation, date_cloture) FROM stdin;
4	Semaine 1	2026-10-05	2026-10-11	cloturee	2026-08-12 00:27:06.382828+00	2026-08-12 00:45:18.88+00
5	Semaine 2	2026-10-12	2026-10-18	cloturee	2026-08-13 06:46:47.446567+00	2026-08-13 07:10:14.833+00
\.


--
-- Data for Name: zones; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.zones (id, nom_zone) FROM stdin;
1	Jéricho
2	Yagbé
3	Vèdoko
\.


--
-- Name: actualites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_id_seq', 3, true);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_images_id_seq', 3, true);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.annees_scolaires_id_seq', 1, true);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_depenses_id_seq', 10, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.classes_id_seq', 24, true);


--
-- Name: coefficients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.coefficients_id_seq', 186, true);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comptes_parents_id_seq', 1, false);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.decisions_passage_id_seq', 2, true);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.depenses_annexes_id_seq', 1, false);


--
-- Name: eleves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_id_seq', 2, true);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_suspendus_id_seq', 1, false);


--
-- Name: frais_td_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frais_td_id_seq', 24, true);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_admin_id_seq', 1, true);


--
-- Name: galerie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_id_seq', 1, false);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_whatsapp_id_seq', 1, false);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_attempts_id_seq', 73, true);


--
-- Name: matieres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matieres_id_seq', 11, true);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mois_exoneres_id_seq', 1, false);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.moyennes_semestrielles_id_seq', 2, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: paiements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_id_seq', 1, false);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_supprimes_id_seq', 1, false);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.penalites_reinscription_id_seq', 1, false);


--
-- Name: presences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.presences_id_seq', 1, false);


--
-- Name: recompenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recompenses_id_seq', 1, false);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 2, true);


--
-- Name: creneaux_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.creneaux_id_seq', 6, true);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.matieres_td_id_seq', 11, true);


--
-- Name: postulations_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.postulations_id_seq', 5, true);


--
-- Name: professeurs_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.professeurs_id_seq', 1, true);


--
-- Name: semaines_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.semaines_id_seq', 5, true);


--
-- Name: zones_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.zones_id_seq', 3, true);


--
-- Name: actualites_images actualites_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_pkey PRIMARY KEY (id);


--
-- Name: actualites actualites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_pkey PRIMARY KEY (id);


--
-- Name: annees_scolaires annees_scolaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires
    ADD CONSTRAINT annees_scolaires_pkey PRIMARY KEY (id);


--
-- Name: categories_depenses categories_depenses_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_nom_key UNIQUE (nom);


--
-- Name: categories_depenses categories_depenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_pkey PRIMARY KEY (id);


--
-- Name: classes classes_nom_classe_site_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_nom_classe_site_id_key UNIQUE (nom_classe, site_id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: coefficients coefficients_classe_id_matiere_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_matiere_id_key UNIQUE (classe_id, matiere_id);


--
-- Name: coefficients coefficients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_pkey PRIMARY KEY (id);


--
-- Name: comptes_parents comptes_parents_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_matricule_key UNIQUE (matricule);


--
-- Name: comptes_parents comptes_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_pkey PRIMARY KEY (id);


--
-- Name: decisions_passage decisions_passage_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_key UNIQUE (eleve_id);


--
-- Name: decisions_passage decisions_passage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_pkey PRIMARY KEY (id);


--
-- Name: depenses_annexes depenses_annexes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_pkey PRIMARY KEY (id);


--
-- Name: eleves eleves_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_matricule_key UNIQUE (matricule);


--
-- Name: eleves eleves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_pkey PRIMARY KEY (id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_key UNIQUE (eleve_id);


--
-- Name: eleves_suspendus eleves_suspendus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_pkey PRIMARY KEY (id);


--
-- Name: frais_td frais_td_classe_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_key UNIQUE (classe_id);


--
-- Name: frais_td frais_td_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_pkey PRIMARY KEY (id);


--
-- Name: galerie_admin galerie_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_pkey PRIMARY KEY (id);


--
-- Name: galerie galerie_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie
    ADD CONSTRAINT galerie_pkey PRIMARY KEY (id);


--
-- Name: log_whatsapp log_whatsapp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: matieres matieres_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_code_key UNIQUE (code);


--
-- Name: matieres matieres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_pkey PRIMARY KEY (id);


--
-- Name: mois_exoneres mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key UNIQUE (eleve_id, mois_souscription, annee_scolaire_id);


--
-- Name: mois_exoneres mois_exoneres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_pkey PRIMARY KEY (id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key UNIQUE (eleve_id, annee_scolaire_id, semestre);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_pkey PRIMARY KEY (id);


--
-- Name: notes notes_eleve_matiere_type_annee_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_matiere_type_annee_semestre_key UNIQUE (eleve_id, matiere_id, type_note, annee_scolaire_id, semestre);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: paiements paiements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_pkey PRIMARY KEY (id);


--
-- Name: paiements_supprimes paiements_supprimes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_pkey PRIMARY KEY (id);


--
-- Name: penalites_reinscription penalites_reinscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_pkey PRIMARY KEY (id);


--
-- Name: presences presences_eleve_id_date_presence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_date_presence_key UNIQUE (eleve_id, date_presence);


--
-- Name: presences presences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_pkey PRIMARY KEY (id);


--
-- Name: recompenses recompenses_note_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_key UNIQUE (note_id);


--
-- Name: recompenses recompenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_pkey PRIMARY KEY (id);


--
-- Name: sites sites_initiale_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_initiale_key UNIQUE (initiale);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: user_sites user_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_pkey PRIMARY KEY (user_id, site_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: creneaux creneaux_classe_id_date_td_heure_debut_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_date_td_heure_debut_key UNIQUE (classe_id, date_td, heure_debut);


--
-- Name: creneaux creneaux_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_pkey PRIMARY KEY (id);


--
-- Name: matieres_td matieres_td_nom_matiere_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_nom_matiere_key UNIQUE (nom_matiere);


--
-- Name: matieres_td matieres_td_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_pkey PRIMARY KEY (id);


--
-- Name: postulations postulations_creneau_id_professeur_id_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_professeur_id_key UNIQUE (creneau_id, professeur_id);


--
-- Name: postulations postulations_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_email_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_email_key UNIQUE (email);


--
-- Name: professeurs professeurs_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_telephone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_telephone_key UNIQUE (telephone);


--
-- Name: semaines semaines_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines
    ADD CONSTRAINT semaines_pkey PRIMARY KEY (id);


--
-- Name: zones zones_nom_zone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_nom_zone_key UNIQUE (nom_zone);


--
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id);


--
-- Name: idx_login_attempts_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_attempts_lookup ON public.login_attempts USING btree (identifiant, portail, date_tentative);


--
-- Name: frais_td trg_frais_td_lock_period; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_frais_td_lock_period BEFORE UPDATE OF montant ON public.frais_td FOR EACH ROW EXECUTE FUNCTION public.trg_frais_td_lock_period_fn();


--
-- Name: annees_scolaires trg_unique_annee_en_cours; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_unique_annee_en_cours BEFORE INSERT OR UPDATE ON public.annees_scolaires FOR EACH ROW EXECUTE FUNCTION public.trg_unique_annee_en_cours_fn();


--
-- Name: users trg_users_scope_coherence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_scope_coherence BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.trg_users_scope_coherence_fn();


--
-- Name: actualites actualites_cree_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_cree_par_fkey FOREIGN KEY (cree_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: actualites_images actualites_images_actualite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_actualite_id_fkey FOREIGN KEY (actualite_id) REFERENCES public.actualites(id) ON DELETE CASCADE;


--
-- Name: classes classes_classe_suivante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_classe_suivante_id_fkey FOREIGN KEY (classe_suivante_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: classes classes_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: decisions_passage decisions_passage_decide_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_decide_par_fkey FOREIGN KEY (decide_par) REFERENCES public.users(id);


--
-- Name: decisions_passage decisions_passage_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_nouvelle_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_nouvelle_classe_id_fkey FOREIGN KEY (nouvelle_classe_id) REFERENCES public.classes(id);


--
-- Name: depenses_annexes depenses_annexes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_categorie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_categorie_id_fkey FOREIGN KEY (categorie_id) REFERENCES public.categories_depenses(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_saisi_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_saisi_par_fkey FOREIGN KEY (saisi_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: eleves eleves_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_suspendu_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_suspendu_par_fkey FOREIGN KEY (suspendu_par) REFERENCES public.users(id);


--
-- Name: frais_td frais_td_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: galerie_admin galerie_admin_ajoute_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_ajoute_par_fkey FOREIGN KEY (ajoute_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: log_whatsapp log_whatsapp_envoye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_envoye_par_fkey FOREIGN KEY (envoye_par) REFERENCES public.users(id);


--
-- Name: mois_exoneres mois_exoneres_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_exonere_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_exonere_par_fkey FOREIGN KEY (exonere_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: moyennes_semestrielles moyennes_semestrielles_cloture_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_cloture_par_fkey FOREIGN KEY (cloture_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: notes notes_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: paiements_supprimes paiements_supprimes_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: penalites_reinscription penalites_reinscription_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id);


--
-- Name: presences presences_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: presences presences_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: presences presences_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: presences presences_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_depense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_depense_id_fkey FOREIGN KEY (depense_id) REFERENCES public.depenses_annexes(id) ON DELETE SET NULL;


--
-- Name: recompenses recompenses_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_paye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_paye_par_fkey FOREIGN KEY (paye_par) REFERENCES public.users(id);


--
-- Name: user_sites user_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: user_sites user_sites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users users_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: creneaux creneaux_classe_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_matiere_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_semaine_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_semaine_id_fkey FOREIGN KEY (semaine_id) REFERENCES td.semaines(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_creneau_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_fkey FOREIGN KEY (creneau_id) REFERENCES td.creneaux(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_professeur_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_professeur_id_fkey FOREIGN KEY (professeur_id) REFERENCES td.professeurs(id) ON DELETE CASCADE;


--
-- Name: professeurs professeurs_matiere_principale_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_matiere_principale_id_fkey FOREIGN KEY (matiere_principale_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: professeurs professeurs_zone_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES td.zones(id) ON DELETE RESTRICT;


--
-- Name: actualites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites_images ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images actualites_images_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_images_lecture_publique ON public.actualites_images FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.actualites a
  WHERE ((a.id = actualites_images.actualite_id) AND (a.statut = 'publie'::text)))));


--
-- Name: actualites actualites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_lecture_publique ON public.actualites FOR SELECT USING ((statut = 'publie'::text));


--
-- Name: annees_scolaires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.annees_scolaires ENABLE ROW LEVEL SECURITY;

--
-- Name: annees_scolaires annees_scolaires_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY annees_scolaires_lecture_staff ON public.annees_scolaires FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: categories_depenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.categories_depenses ENABLE ROW LEVEL SECURITY;

--
-- Name: categories_depenses categories_depenses_lecture_global; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY categories_depenses_lecture_global ON public.categories_depenses FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: classes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;

--
-- Name: classes classes_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_publique ON public.classes FOR SELECT TO anon USING (true);


--
-- Name: classes classes_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_staff ON public.classes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: coefficients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coefficients ENABLE ROW LEVEL SECURITY;

--
-- Name: coefficients coefficients_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY coefficients_lecture_staff ON public.coefficients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: comptes_parents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.comptes_parents ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decisions_passage ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage decisions_passage_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY decisions_passage_lecture ON public.decisions_passage FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: depenses_annexes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.depenses_annexes ENABLE ROW LEVEL SECURITY;

--
-- Name: depenses_annexes depenses_annexes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY depenses_annexes_lecture ON public.depenses_annexes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: eleves; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves eleves_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_acces ON public.eleves USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM (public.user_sites us
             JOIN public.classes c ON ((c.id = eleves.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM public.classes c
          WHERE ((c.id = eleves.classe_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: eleves_suspendus; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves_suspendus ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves_suspendus eleves_suspendus_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_suspendus_acces ON public.eleves_suspendus USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = eleves_suspendus.site_id))))))))));


--
-- Name: frais_td; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.frais_td ENABLE ROW LEVEL SECURITY;

--
-- Name: frais_td frais_td_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY frais_td_lecture_staff ON public.frais_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: galerie; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie_admin ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin galerie_admin_ajout; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_ajout ON public.galerie_admin FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_lecture ON public.galerie_admin FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_suppression; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_suppression ON public.galerie_admin FOR DELETE USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text])) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (galerie_admin.ajoute_par = auth.uid())))))));


--
-- Name: galerie galerie_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_lecture_publique ON public.galerie FOR SELECT USING (true);


--
-- Name: log_whatsapp; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.log_whatsapp ENABLE ROW LEVEL SECURITY;

--
-- Name: log_whatsapp log_whatsapp_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY log_whatsapp_acces ON public.log_whatsapp FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON (((e.matricule)::text = (log_whatsapp.matricule)::text)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: login_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.matieres ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres matieres_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY matieres_lecture_staff ON public.matieres FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: mois_exoneres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mois_exoneres ENABLE ROW LEVEL SECURITY;

--
-- Name: mois_exoneres mois_exoneres_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mois_exoneres_acces ON public.mois_exoneres USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = mois_exoneres.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: moyennes_semestrielles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.moyennes_semestrielles ENABLE ROW LEVEL SECURITY;

--
-- Name: moyennes_semestrielles moyennes_semestrielles_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY moyennes_semestrielles_acces ON public.moyennes_semestrielles USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = moyennes_semestrielles.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = moyennes_semestrielles.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: notes notes_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notes_acces ON public.notes USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = notes.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = notes.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_acces ON public.notifications FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = notifications.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = notifications.site_id)))))));


--
-- Name: paiements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements paiements_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_acces ON public.paiements USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = paiements.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: paiements_supprimes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements_supprimes ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements_supprimes paiements_supprimes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_supprimes_lecture ON public.paiements_supprimes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: penalites_reinscription; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.penalites_reinscription ENABLE ROW LEVEL SECURITY;

--
-- Name: penalites_reinscription penalites_reinscription_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY penalites_reinscription_acces ON public.penalites_reinscription USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = penalites_reinscription.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: presences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.presences ENABLE ROW LEVEL SECURITY;

--
-- Name: presences presences_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY presences_acces ON public.presences USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = presences.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = presences.site_id)))))));


--
-- Name: recompenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recompenses ENABLE ROW LEVEL SECURITY;

--
-- Name: recompenses recompenses_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY recompenses_acces ON public.recompenses USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = recompenses.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: sites sites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_publique ON public.sites FOR SELECT TO anon USING (true);


--
-- Name: sites sites_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_staff ON public.sites FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: user_sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_sites ENABLE ROW LEVEL SECURITY;

--
-- Name: user_sites user_sites_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_sites_lecture_soi_meme ON public.user_sites FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_soi_meme ON public.users FOR SELECT USING ((id = auth.uid()));


--
-- Name: users users_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_staff ON public.users FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: creneaux; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.creneaux ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres_td; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.matieres_td ENABLE ROW LEVEL SECURITY;

--
-- Name: postulations; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.postulations ENABLE ROW LEVEL SECURITY;

--
-- Name: professeurs; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.professeurs ENABLE ROW LEVEL SECURITY;

--
-- Name: semaines; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.semaines ENABLE ROW LEVEL SECURITY;

--
-- Name: creneaux td_creneaux_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_coordonnateur ON td.creneaux FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: creneaux td_creneaux_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_publique ON td.creneaux FOR SELECT TO anon USING (((statut_creneau = ANY (ARRAY['public'::text, 'cloture'::text])) AND (EXISTS ( SELECT 1
   FROM td.semaines s
  WHERE ((s.id = creneaux.semaine_id) AND (s.statut = 'publiee'::text))))));


--
-- Name: matieres_td td_matieres_td_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_coordonnateur ON td.matieres_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: matieres_td td_matieres_td_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_publique ON td.matieres_td FOR SELECT TO anon USING (true);


--
-- Name: postulations td_postulations_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_postulations_lecture_coordonnateur ON td.postulations FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: professeurs td_professeurs_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_professeurs_lecture_coordonnateur ON td.professeurs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_coordonnateur ON td.semaines FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_publique ON td.semaines FOR SELECT TO anon USING ((statut = 'publiee'::text));


--
-- Name: zones td_zones_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_zones_lecture_coordonnateur ON td.zones FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: zones; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.zones ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict rRIQJAUAKSgJa4iob9aS9ev1yYbL1Nc6W4LzaOZPZbMvvbjDM4WzTra2ORweGia


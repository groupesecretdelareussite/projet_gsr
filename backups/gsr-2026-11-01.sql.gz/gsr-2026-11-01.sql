--
-- PostgreSQL database dump
--

\restrict t2zpMM0CAX9uKD9k9o8bw2FbOz5tmyWr3WnZ0EVA8RPvdTwgzyiYa5qsVme8IS5

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg26.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS td_zones_lecture_coordonnateur ON td.zones;
DROP POLICY IF EXISTS td_semaines_lecture_publique ON td.semaines;
DROP POLICY IF EXISTS td_semaines_lecture_coordonnateur ON td.semaines;
DROP POLICY IF EXISTS td_professeurs_lecture_coordonnateur ON td.professeurs;
DROP POLICY IF EXISTS td_postulations_lecture_coordonnateur ON td.postulations;
DROP POLICY IF EXISTS td_matieres_td_lecture_publique ON td.matieres_td;
DROP POLICY IF EXISTS td_matieres_td_lecture_coordonnateur ON td.matieres_td;
DROP POLICY IF EXISTS td_demandes_retrait_lecture_coordonnateur ON td.demandes_retrait;
DROP POLICY IF EXISTS td_creneaux_lecture_publique ON td.creneaux;
DROP POLICY IF EXISTS td_creneaux_lecture_coordonnateur ON td.creneaux;
DROP POLICY IF EXISTS users_lecture_staff ON public.users;
DROP POLICY IF EXISTS users_lecture_soi_meme ON public.users;
DROP POLICY IF EXISTS user_sites_lecture_soi_meme ON public.user_sites;
DROP POLICY IF EXISTS sites_lecture_staff ON public.sites;
DROP POLICY IF EXISTS sites_lecture_publique ON public.sites;
DROP POLICY IF EXISTS recompenses_acces ON public.recompenses;
DROP POLICY IF EXISTS presences_acces ON public.presences;
DROP POLICY IF EXISTS penalites_reinscription_acces ON public.penalites_reinscription;
DROP POLICY IF EXISTS paiements_supprimes_lecture ON public.paiements_supprimes;
DROP POLICY IF EXISTS paiements_acces ON public.paiements;
DROP POLICY IF EXISTS notifications_acces ON public.notifications;
DROP POLICY IF EXISTS notes_acces ON public.notes;
DROP POLICY IF EXISTS moyennes_semestrielles_acces ON public.moyennes_semestrielles;
DROP POLICY IF EXISTS mois_exoneres_acces ON public.mois_exoneres;
DROP POLICY IF EXISTS mfa_backup_codes_lecture_soi ON public.mfa_backup_codes;
DROP POLICY IF EXISTS matieres_lecture_staff ON public.matieres;
DROP POLICY IF EXISTS log_whatsapp_acces ON public.log_whatsapp;
DROP POLICY IF EXISTS galerie_lecture_publique ON public.galerie;
DROP POLICY IF EXISTS galerie_admin_suppression ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_lecture ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_ajout ON public.galerie_admin;
DROP POLICY IF EXISTS frais_td_lecture_staff ON public.frais_td;
DROP POLICY IF EXISTS eleves_suspendus_acces ON public.eleves_suspendus;
DROP POLICY IF EXISTS eleves_exonerations_lecture ON public.eleves_exonerations;
DROP POLICY IF EXISTS eleves_exonerations_ecriture ON public.eleves_exonerations;
DROP POLICY IF EXISTS eleves_acces ON public.eleves;
DROP POLICY IF EXISTS depenses_annexes_lecture ON public.depenses_annexes;
DROP POLICY IF EXISTS decisions_passage_lecture ON public.decisions_passage;
DROP POLICY IF EXISTS coefficients_lecture_staff ON public.coefficients;
DROP POLICY IF EXISTS classes_lecture_staff ON public.classes;
DROP POLICY IF EXISTS classes_lecture_publique ON public.classes;
DROP POLICY IF EXISTS categories_depenses_lecture_global ON public.categories_depenses;
DROP POLICY IF EXISTS annees_scolaires_lecture_staff ON public.annees_scolaires;
DROP POLICY IF EXISTS actualites_lecture_publique ON public.actualites;
DROP POLICY IF EXISTS actualites_images_lecture_publique ON public.actualites_images;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_zone_id_fkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_matiere_principale_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_professeur_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_fkey;
ALTER TABLE IF EXISTS ONLY td.demandes_retrait DROP CONSTRAINT IF EXISTS demandes_retrait_rejete_par_fkey;
ALTER TABLE IF EXISTS ONLY td.demandes_retrait DROP CONSTRAINT IF EXISTS demandes_retrait_professeur_id_fkey;
ALTER TABLE IF EXISTS ONLY td.demandes_retrait DROP CONSTRAINT IF EXISTS demandes_retrait_paye_par_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_semaine_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_paye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_depense_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_admin_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_cloture_par_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_exonere_par_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mfa_backup_codes DROP CONSTRAINT IF EXISTS mfa_backup_codes_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_envoye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_ajoute_par_fkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_suspendu_par_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_accorde_par_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_saisi_par_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_categorie_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_nouvelle_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_decide_par_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_classe_suivante_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_actualite_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_cree_par_fkey;
DROP TRIGGER IF EXISTS trg_check_max_postulations ON td.postulations;
DROP TRIGGER IF EXISTS trg_users_scope_coherence ON public.users;
DROP TRIGGER IF EXISTS trg_unique_annee_en_cours ON public.annees_scolaires;
DROP TRIGGER IF EXISTS trg_frais_td_lock_period ON public.frais_td;
DROP INDEX IF EXISTS td.idx_retrait_prof_mois_actif;
DROP INDEX IF EXISTS td.idx_professeurs_valide;
DROP INDEX IF EXISTS td.idx_professeurs_reset_token_hash;
DROP INDEX IF EXISTS td.idx_demandes_retrait_statut;
DROP INDEX IF EXISTS td.idx_demandes_retrait_prof;
DROP INDEX IF EXISTS td.idx_demandes_retrait_mois;
DROP INDEX IF EXISTS td.idx_demandes_retrait_code;
DROP INDEX IF EXISTS public.idx_mfa_backup_codes_user;
DROP INDEX IF EXISTS public.idx_login_attempts_lookup;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_pkey;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_nom_zone_key;
ALTER TABLE IF EXISTS ONLY td.semaines DROP CONSTRAINT IF EXISTS semaines_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_telephone_key;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_email_key;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_pkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_professeur_id_key;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_pkey;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_nom_matiere_key;
ALTER TABLE IF EXISTS ONLY td.demandes_retrait DROP CONSTRAINT IF EXISTS demandes_retrait_pkey;
ALTER TABLE IF EXISTS ONLY td.demandes_retrait DROP CONSTRAINT IF EXISTS demandes_retrait_code_demande_key;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_pkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_date_td_heure_debut_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_initiale_key;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_pkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_key;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_pkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_date_presence_key;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_matiere_type_annee_semestre_key;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_pkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_pkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key;
ALTER TABLE IF EXISTS ONLY public.mfa_backup_codes DROP CONSTRAINT IF EXISTS mfa_backup_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_pkey;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_code_key;
ALTER TABLE IF EXISTS ONLY public.login_attempts DROP CONSTRAINT IF EXISTS login_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie DROP CONSTRAINT IF EXISTS galerie_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_matricule_key;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_eleve_id_annee_scolaire_id_key;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_pkey;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_matricule_key;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_pkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_matiere_id_key;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_pkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_nom_classe_site_id_key;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_pkey;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_nom_key;
ALTER TABLE IF EXISTS ONLY public.annees_scolaires DROP CONSTRAINT IF EXISTS annees_scolaires_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_pkey;
ALTER TABLE IF EXISTS td.zones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.semaines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.professeurs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.postulations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.matieres_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.demandes_retrait ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.creneaux ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.recompenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.presences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.penalites_reinscription ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements_supprimes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.moyennes_semestrielles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mois_exoneres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mfa_backup_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matieres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.login_attempts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.log_whatsapp ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie_admin ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.frais_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves_suspendus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves_exonerations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.depenses_annexes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.decisions_passage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comptes_parents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.coefficients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories_depenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.annees_scolaires ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS td.zones_id_seq;
DROP TABLE IF EXISTS td.zones;
DROP SEQUENCE IF EXISTS td.semaines_id_seq;
DROP TABLE IF EXISTS td.semaines;
DROP SEQUENCE IF EXISTS td.professeurs_id_seq;
DROP TABLE IF EXISTS td.professeurs;
DROP SEQUENCE IF EXISTS td.postulations_id_seq;
DROP TABLE IF EXISTS td.postulations;
DROP SEQUENCE IF EXISTS td.matieres_td_id_seq;
DROP TABLE IF EXISTS td.matieres_td;
DROP SEQUENCE IF EXISTS td.demandes_retrait_id_seq;
DROP TABLE IF EXISTS td.demandes_retrait;
DROP SEQUENCE IF EXISTS td.creneaux_id_seq;
DROP TABLE IF EXISTS td.creneaux;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sites;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.recompenses_id_seq;
DROP TABLE IF EXISTS public.recompenses;
DROP SEQUENCE IF EXISTS public.presences_id_seq;
DROP TABLE IF EXISTS public.presences;
DROP SEQUENCE IF EXISTS public.penalites_reinscription_id_seq;
DROP TABLE IF EXISTS public.penalites_reinscription;
DROP SEQUENCE IF EXISTS public.paiements_supprimes_id_seq;
DROP TABLE IF EXISTS public.paiements_supprimes;
DROP SEQUENCE IF EXISTS public.paiements_id_seq;
DROP TABLE IF EXISTS public.paiements;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notes_id_seq;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.moyennes_semestrielles_id_seq;
DROP TABLE IF EXISTS public.moyennes_semestrielles;
DROP SEQUENCE IF EXISTS public.mois_exoneres_id_seq;
DROP TABLE IF EXISTS public.mois_exoneres;
DROP SEQUENCE IF EXISTS public.mfa_backup_codes_id_seq;
DROP TABLE IF EXISTS public.mfa_backup_codes;
DROP SEQUENCE IF EXISTS public.matieres_id_seq;
DROP TABLE IF EXISTS public.matieres;
DROP SEQUENCE IF EXISTS public.login_attempts_id_seq;
DROP TABLE IF EXISTS public.login_attempts;
DROP SEQUENCE IF EXISTS public.log_whatsapp_id_seq;
DROP TABLE IF EXISTS public.log_whatsapp;
DROP SEQUENCE IF EXISTS public.galerie_id_seq;
DROP SEQUENCE IF EXISTS public.galerie_admin_id_seq;
DROP TABLE IF EXISTS public.galerie_admin;
DROP TABLE IF EXISTS public.galerie;
DROP SEQUENCE IF EXISTS public.frais_td_id_seq;
DROP TABLE IF EXISTS public.frais_td;
DROP SEQUENCE IF EXISTS public.eleves_suspendus_id_seq;
DROP TABLE IF EXISTS public.eleves_suspendus;
DROP SEQUENCE IF EXISTS public.eleves_id_seq;
DROP SEQUENCE IF EXISTS public.eleves_exonerations_id_seq;
DROP TABLE IF EXISTS public.eleves_exonerations;
DROP TABLE IF EXISTS public.eleves;
DROP SEQUENCE IF EXISTS public.depenses_annexes_id_seq;
DROP TABLE IF EXISTS public.depenses_annexes;
DROP SEQUENCE IF EXISTS public.decisions_passage_id_seq;
DROP TABLE IF EXISTS public.decisions_passage;
DROP SEQUENCE IF EXISTS public.comptes_parents_id_seq;
DROP TABLE IF EXISTS public.comptes_parents;
DROP SEQUENCE IF EXISTS public.coefficients_id_seq;
DROP TABLE IF EXISTS public.coefficients;
DROP SEQUENCE IF EXISTS public.classes_id_seq;
DROP TABLE IF EXISTS public.classes;
DROP SEQUENCE IF EXISTS public.categories_depenses_id_seq;
DROP TABLE IF EXISTS public.categories_depenses;
DROP SEQUENCE IF EXISTS public.annees_scolaires_id_seq;
DROP TABLE IF EXISTS public.annees_scolaires;
DROP SEQUENCE IF EXISTS public.actualites_images_id_seq;
DROP TABLE IF EXISTS public.actualites_images;
DROP SEQUENCE IF EXISTS public.actualites_id_seq;
DROP TABLE IF EXISTS public.actualites;
DROP FUNCTION IF EXISTS td.check_max_postulations();
DROP FUNCTION IF EXISTS td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer);
DROP FUNCTION IF EXISTS td.affecter_directement_creneau(p_creneau_id integer, p_professeur_id integer);
DROP FUNCTION IF EXISTS public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date);
DROP FUNCTION IF EXISTS public.trg_users_scope_coherence_fn();
DROP FUNCTION IF EXISTS public.trg_unique_annee_en_cours_fn();
DROP FUNCTION IF EXISTS public.trg_frais_td_lock_period_fn();
DROP FUNCTION IF EXISTS public.rls_auto_enable();
DROP FUNCTION IF EXISTS public.resolve_staff_email(p_username text);
DROP FUNCTION IF EXISTS public.enregistrer_paiement_atomique(p_eleve_id integer, p_mois_souscription text, p_montant_paye numeric, p_date_paiement date, p_mode_paiement text, p_enregistre_par uuid);
DROP FUNCTION IF EXISTS public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]);
DROP SCHEMA IF EXISTS td;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: td; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA td;


--
-- Name: assigner_sites_superviseur(uuid, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  DELETE FROM public.user_sites WHERE user_id = p_user_id;
  INSERT INTO public.user_sites (user_id, site_id)
  SELECT p_user_id, unnest(p_site_ids);
END;
$$;


--
-- Name: enregistrer_paiement_atomique(integer, text, numeric, date, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enregistrer_paiement_atomique(p_eleve_id integer, p_mois_souscription text, p_montant_paye numeric, p_date_paiement date, p_mode_paiement text, p_enregistre_par uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_classe_id integer;
  v_statut text;
  v_college text;
  v_montant_frais numeric;
  v_annee_id integer;
  v_annee_libelle text;
  v_exo_motif text;
  v_total_deja_paye numeric;
  v_reste numeric;
  v_nouveau_paiement_id integer;
  v_total_apres numeric;
  v_reste_apres numeric;
BEGIN
  -- 1. Verrouiller la ligne de l'élève pour sérialiser tout paiement sur cet élève
  SELECT classe_id, statut, college INTO v_classe_id, v_statut, v_college
  FROM public.eleves
  WHERE id = p_eleve_id
  FOR UPDATE;

  IF NOT FOUND OR v_statut <> 'actif' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Élève introuvable ou suspendu');
  END IF;

  -- 2. Récupérer l'année scolaire en cours
  SELECT id, libelle INTO v_annee_id, v_annee_libelle
  FROM public.annees_scolaires
  WHERE statut = 'en_cours'
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Aucune année scolaire en cours');
  END IF;

  -- 3. Vérifier les frais TD configurés
  SELECT montant INTO v_montant_frais
  FROM public.frais_td
  WHERE classe_id = v_classe_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Aucun montant de frais TD configuré pour cette classe');
  END IF;

  -- 4. Vérifier exonération
  SELECT motif INTO v_exo_motif
  FROM public.mois_exoneres
  WHERE eleve_id = p_eleve_id
    AND mois_souscription = p_mois_souscription
    AND annee_scolaire_id = v_annee_id;

  IF FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Ce mois est exonéré ou déjà pris en charge (' || v_exo_motif || '). Aucun paiement requis.');
  END IF;

  -- 5. Calculer le total déjà payé
  SELECT COALESCE(SUM(montant_paye), 0) INTO v_total_deja_paye
  FROM public.paiements
  WHERE eleve_id = p_eleve_id
    AND mois_souscription = p_mois_souscription
    AND annee_scolaire_id = v_annee_id;

  v_reste := GREATEST(0, v_montant_frais - v_total_deja_paye);

  IF p_montant_paye > v_reste THEN
    RETURN jsonb_build_object('success', false, 'error', 'Le montant dépasse le reste dû (' || v_reste || ' F)');
  END IF;

  -- 6. Insérer le paiement avec la variable correcte v_annee_id
  INSERT INTO public.paiements (
    eleve_id,
    mois_souscription,
    montant_paye,
    date_paiement,
    mode_paiement,
    annee_scolaire_id,
    enregistre_par
  ) VALUES (
    p_eleve_id,
    p_mois_souscription,
    p_montant_paye,
    p_date_paiement,
    p_mode_paiement,
    v_annee_id,
    p_enregistre_par
  ) RETURNING id INTO v_nouveau_paiement_id;

  v_total_apres := v_total_deja_paye + p_montant_paye;
  v_reste_apres := GREATEST(0, v_montant_frais - v_total_apres);

  RETURN jsonb_build_object(
    'success', true,
    'last_paiement_id', v_nouveau_paiement_id,
    'reste_apres_paiement', v_reste_apres,
    'montant_attendu', v_montant_frais,
    'college', v_college,
    'annee_libelle', v_annee_libelle,
    'annee_id', v_annee_id
  );
END;
$$;


--
-- Name: resolve_staff_email(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_staff_email(p_username text) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  RETURN (SELECT email FROM public.users WHERE username = p_username AND actif = true LIMIT 1);
END;
$$;


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rls_auto_enable() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: trg_frais_td_lock_period_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_frais_td_lock_period_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_debut date;
  v_fin   date;
begin
  select date_debut, date_fin into v_debut, v_fin
  from public.annees_scolaires where statut = 'en_cours';

  if v_debut is not null and current_date between v_debut and v_fin then
    raise exception 'Modification du montant interdite pendant l''année scolaire en cours — uniquement en période de vacances, après l''arbitrage de fin d''année';
  end if;

  return new;
end;
$$;


--
-- Name: trg_unique_annee_en_cours_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_unique_annee_en_cours_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.statut = 'en_cours' and exists (
    select 1 from public.annees_scolaires
    where statut = 'en_cours' and id <> new.id
  ) then
    raise exception 'Une année scolaire est déjà en_cours';
  end if;

  return new;
end;
$$;


--
-- Name: trg_users_scope_coherence_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_users_scope_coherence_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.role in ('chef_site', 'secretaire') and new.site_id is null then
    raise exception 'site_id obligatoire pour le rôle %', new.role;
  end if;

  if new.role in ('coordonnateur','comptable','superviseur') and new.site_id is not null then
    raise exception 'site_id doit être NULL pour le rôle %', new.role;
  end if;

  return new;
end;
$$;


--
-- Name: valider_fin_annee(text, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  -- 1. Créer la nouvelle année scolaire
  INSERT INTO public.annees_scolaires (libelle, date_debut, date_fin, statut)
  VALUES (p_nouvelle_libelle, p_nouvelle_date_debut, p_nouvelle_date_fin, 'en_cours');

  -- 2. Clôturer l'ancienne
  UPDATE public.annees_scolaires SET statut = 'terminee' WHERE statut = 'en_pause';

  -- 3. Appliquer les décisions "passe"
  UPDATE public.eleves e
  SET classe_id = d.nouvelle_classe_id
  FROM public.decisions_passage d
  WHERE d.eleve_id = e.id
    AND d.decision = 'passe'
    AND d.nouvelle_classe_id IS NOT NULL;

  -- 4. Supprimer définitivement les élèves sortant / encore suspendus
  DELETE FROM public.eleves e
  WHERE e.id IN (SELECT eleve_id FROM public.decisions_passage WHERE decision = 'sortant')
     OR e.statut = 'suspendu';

  -- 5. Purger les logs applicatifs des élèves désormais absents de `eleves`
  DELETE FROM public.log_whatsapp
  WHERE matricule NOT IN (SELECT matricule FROM public.eleves);

  DELETE FROM public.paiements_supprimes
  WHERE matricule NOT IN (SELECT matricule FROM public.eleves);

  -- 6. Purger la table tampon des décisions
  TRUNCATE public.decisions_passage;

  -- 7. Récompenses de fin d'année
  UPDATE public.recompenses_fin_annee
  SET date_distribution = now()
  WHERE annee_scolaire_id IN (
    SELECT id FROM public.annees_scolaires WHERE statut = 'terminee'
  )
  AND date_distribution IS NULL;

EXCEPTION WHEN OTHERS THEN
  RAISE;
END;
$$;


--
-- Name: affecter_directement_creneau(integer, integer); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.affecter_directement_creneau(p_creneau_id integer, p_professeur_id integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'td', 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM td.creneaux WHERE id = p_creneau_id AND statut_creneau = 'public'
  ) THEN
    RAISE EXCEPTION 'Ce créneau n''est plus ouvert aux candidatures ou à l''affectation.';
  END IF;

  -- Garde anti-chevauchement
  IF EXISTS (
    SELECT 1
    FROM td.postulations p_autre
    JOIN td.creneaux c_autre ON c_autre.id = p_autre.creneau_id
    JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
    WHERE p_autre.professeur_id = p_professeur_id
      AND p_autre.statut_validation = 'Valide'
      AND c_autre.id != p_creneau_id
      AND c_autre.date_td = c_ref.date_td
      AND c_autre.heure_debut < c_ref.heure_fin
      AND c_autre.heure_fin > c_ref.heure_debut
  ) THEN
    RAISE EXCEPTION 'Ce professeur est déjà validé sur un créneau qui chevauche celui-ci.';
  END IF;

  -- 1. Insérer ou mettre à jour la postulation du professeur choisi à "Valide"
  INSERT INTO td.postulations (creneau_id, professeur_id, statut_validation)
  VALUES (p_creneau_id, p_professeur_id, 'Valide')
  ON CONFLICT (creneau_id, professeur_id)
  DO UPDATE SET statut_validation = 'Valide';

  -- 2. Refuser les autres candidatures en attente sur ce créneau
  UPDATE td.postulations
  SET statut_validation = 'Refuse'
  WHERE creneau_id = p_creneau_id
    AND professeur_id != p_professeur_id
    AND statut_validation = 'En attente';

  -- 3. Règle A : Refuser les autres candidatures en attente de ce même professeur sur les créneaux chevauchants
  UPDATE td.postulations
  SET statut_validation = 'Refuse'
  WHERE professeur_id = p_professeur_id
    AND statut_validation = 'En attente'
    AND creneau_id IN (
      SELECT c_autre.id
      FROM td.creneaux c_autre
      JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
      WHERE c_autre.id != p_creneau_id
        AND c_autre.date_td = c_ref.date_td
        AND c_autre.heure_debut < c_ref.heure_fin
        AND c_autre.heure_fin > c_ref.heure_debut
    );

  -- 4. Clôturer le créneau
  UPDATE td.creneaux SET statut_creneau = 'cloture' WHERE id = p_creneau_id;

EXCEPTION WHEN OTHERS THEN
  RAISE;
END;
$$;


--
-- Name: arbitrer_creneau(integer, integer); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'td', 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM td.postulations p_autre
    JOIN td.creneaux c_autre ON c_autre.id = p_autre.creneau_id
    JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
    WHERE p_autre.professeur_id = p_professeur_id
      AND p_autre.statut_validation = 'Valide'
      AND c_autre.id != p_creneau_id
      AND c_autre.date_td = c_ref.date_td
      AND c_autre.heure_debut < c_ref.heure_fin
      AND c_autre.heure_fin > c_ref.heure_debut
  ) THEN
    RAISE EXCEPTION 'Ce professeur est déjà validé sur un créneau qui chevauche celui-ci.';
  END IF;

  UPDATE td.postulations SET statut_validation = 'Valide'
  WHERE creneau_id = p_creneau_id AND professeur_id = p_professeur_id;

  UPDATE td.postulations SET statut_validation = 'Refuse'
  WHERE creneau_id = p_creneau_id AND professeur_id != p_professeur_id
    AND statut_validation = 'En attente';

  -- Règle A : vrai chevauchement
  UPDATE td.postulations
  SET statut_validation = 'Refuse'
  WHERE professeur_id = p_professeur_id
    AND statut_validation = 'En attente'
    AND creneau_id IN (
      SELECT c_autre.id
      FROM td.creneaux c_autre
      JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
      WHERE c_autre.id != p_creneau_id
        AND c_autre.date_td = c_ref.date_td
        AND c_autre.heure_debut < c_ref.heure_fin
        AND c_autre.heure_fin > c_ref.heure_debut
    );

  UPDATE td.creneaux SET statut_creneau = 'cloture' WHERE id = p_creneau_id;

EXCEPTION WHEN OTHERS THEN
  RAISE;
END;
$$;


--
-- Name: check_max_postulations(); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.check_max_postulations() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_count integer;
begin
  if NEW.statut_validation = 'En attente' then
    select count(*) into v_count
    from td.postulations
    where creneau_id = NEW.creneau_id
      and statut_validation = 'En attente'
      and id != coalesce(NEW.id, 0);

    if v_count >= 3 then
      raise exception 'Ce créneau a déjà atteint le nombre maximal de candidatures (3).'
        using errcode = '23514';
    end if;
  end if;
  return NEW;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actualites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites (
    id integer NOT NULL,
    titre character varying(200) NOT NULL,
    categorie text NOT NULL,
    extrait text NOT NULL,
    contenu text NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    a_la_une_jusqu_au date,
    date_publication timestamp with time zone DEFAULT now() NOT NULL,
    cree_par uuid,
    CONSTRAINT actualites_categorie_check CHECK ((categorie = ANY (ARRAY['Vie scolaire'::text, 'Événement'::text, 'Réussite'::text, 'Cours'::text, 'Examens/Contrôle'::text]))),
    CONSTRAINT actualites_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publie'::text])))
);


--
-- Name: actualites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_id_seq OWNED BY public.actualites.id;


--
-- Name: actualites_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites_images (
    id integer NOT NULL,
    actualite_id integer NOT NULL,
    storage_path text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL
);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_images_id_seq OWNED BY public.actualites_images.id;


--
-- Name: annees_scolaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.annees_scolaires (
    id integer NOT NULL,
    libelle character varying(10) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'en_cours'::text NOT NULL,
    CONSTRAINT annees_scolaires_statut_check CHECK ((statut = ANY (ARRAY['en_cours'::text, 'en_pause'::text, 'terminee'::text])))
);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.annees_scolaires_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.annees_scolaires_id_seq OWNED BY public.annees_scolaires.id;


--
-- Name: categories_depenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories_depenses (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    systeme boolean DEFAULT false NOT NULL
);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_depenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_depenses_id_seq OWNED BY public.categories_depenses.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id integer NOT NULL,
    nom_classe character varying(50) NOT NULL,
    site_id integer NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    classe_suivante_id integer
);


--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: coefficients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coefficients (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    coefficient numeric(4,2) NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT coefficients_coefficient_check CHECK ((coefficient > (0)::numeric))
);


--
-- Name: coefficients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coefficients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coefficients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coefficients_id_seq OWNED BY public.coefficients.id;


--
-- Name: comptes_parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comptes_parents (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mot_de_passe text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    derniere_connexion timestamp with time zone
);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comptes_parents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comptes_parents_id_seq OWNED BY public.comptes_parents.id;


--
-- Name: decisions_passage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decisions_passage (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    decision text NOT NULL,
    nouvelle_classe_id integer,
    annee_scolaire_id integer NOT NULL,
    date_decision timestamp with time zone DEFAULT now() NOT NULL,
    decide_par uuid NOT NULL,
    CONSTRAINT decisions_passage_decision_check CHECK ((decision = ANY (ARRAY['passe'::text, 'redouble'::text, 'sortant'::text])))
);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.decisions_passage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.decisions_passage_id_seq OWNED BY public.decisions_passage.id;


--
-- Name: depenses_annexes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.depenses_annexes (
    id integer NOT NULL,
    categorie_id integer NOT NULL,
    libelle character varying(255) NOT NULL,
    montant numeric(10,2) NOT NULL,
    date_depense date NOT NULL,
    saisi_par uuid NOT NULL,
    date_saisie timestamp with time zone DEFAULT now() NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.depenses_annexes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.depenses_annexes_id_seq OWNED BY public.depenses_annexes.id;


--
-- Name: eleves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    nom character varying(100) NOT NULL,
    prenoms character varying(150) NOT NULL,
    contact_parent character varying(15),
    classe_id integer NOT NULL,
    college character varying(150) NOT NULL,
    option_m character varying(10),
    statut text DEFAULT 'actif'::text NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL,
    contact_parent_2 character varying(15),
    CONSTRAINT eleves_au_moins_un_contact CHECK (((contact_parent IS NOT NULL) OR (contact_parent_2 IS NOT NULL))),
    CONSTRAINT eleves_statut_check CHECK ((statut = ANY (ARRAY['actif'::text, 'suspendu'::text])))
);


--
-- Name: eleves_exonerations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves_exonerations (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    type_exoneration text NOT NULL,
    nombre_mois integer NOT NULL,
    mois_couverts text[] NOT NULL,
    motif text NOT NULL,
    accorde_par uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT eleves_exonerations_nombre_mois_check CHECK (((nombre_mois >= 1) AND (nombre_mois <= 8))),
    CONSTRAINT eleves_exonerations_type_exoneration_check CHECK ((type_exoneration = ANY (ARRAY['permanente'::text, 'bourse'::text])))
);


--
-- Name: eleves_exonerations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_exonerations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_exonerations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_exonerations_id_seq OWNED BY public.eleves_exonerations.id;


--
-- Name: eleves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_id_seq OWNED BY public.eleves.id;


--
-- Name: eleves_suspendus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves_suspendus (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    site_id integer NOT NULL,
    raison text NOT NULL,
    motif text NOT NULL,
    montant_du integer DEFAULT 0 NOT NULL,
    date_suspension timestamp with time zone DEFAULT now() NOT NULL,
    suspendu_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois_souscription character varying(20),
    CONSTRAINT eleves_suspendus_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[]))),
    CONSTRAINT eleves_suspendus_raison_check CHECK ((raison = ANY (ARRAY['maladie'::text, 'renvoi'::text, 'defaut_paiement'::text, 'autre'::text])))
);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_suspendus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_suspendus_id_seq OWNED BY public.eleves_suspendus.id;


--
-- Name: frais_td; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frais_td (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    montant numeric(10,2) NOT NULL
);


--
-- Name: frais_td_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frais_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frais_td_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frais_td_id_seq OWNED BY public.frais_td.id;


--
-- Name: galerie; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie (
    id integer NOT NULL,
    storage_path text NOT NULL,
    date_insertion timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie_admin (
    id integer NOT NULL,
    storage_path text NOT NULL,
    nom_fichier text NOT NULL,
    taille_octets integer,
    ajoute_par uuid NOT NULL,
    date_ajout timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_admin_id_seq OWNED BY public.galerie_admin.id;


--
-- Name: galerie_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_id_seq OWNED BY public.galerie.id;


--
-- Name: log_whatsapp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_whatsapp (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_restant integer NOT NULL,
    contact_parent character varying(25) NOT NULL,
    envoye_par uuid NOT NULL,
    date_envoi timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_whatsapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_whatsapp_id_seq OWNED BY public.log_whatsapp.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id integer NOT NULL,
    identifiant text NOT NULL,
    portail text NOT NULL,
    reussi boolean NOT NULL,
    ip inet,
    date_tentative timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT login_attempts_portail_check CHECK ((portail = ANY (ARRAY['admin'::text, 'parent'::text, 'td'::text])))
);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_attempts_id_seq OWNED BY public.login_attempts.id;


--
-- Name: matieres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matieres (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL
);


--
-- Name: matieres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matieres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matieres_id_seq OWNED BY public.matieres.id;


--
-- Name: mfa_backup_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mfa_backup_codes (
    id integer NOT NULL,
    user_id uuid NOT NULL,
    code_hash text NOT NULL,
    utilise boolean DEFAULT false NOT NULL,
    utilise_le timestamp with time zone,
    cree_le timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mfa_backup_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mfa_backup_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mfa_backup_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mfa_backup_codes_id_seq OWNED BY public.mfa_backup_codes.id;


--
-- Name: mois_exoneres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mois_exoneres (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    motif text DEFAULT 'Absence totale durant le mois suspendu — dispense du montant dû à la réinscription'::text NOT NULL,
    exonere_par uuid NOT NULL,
    date_exoneration timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mois_exoneres_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mois_exoneres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mois_exoneres_id_seq OWNED BY public.mois_exoneres.id;


--
-- Name: moyennes_semestrielles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.moyennes_semestrielles (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    semestre smallint NOT NULL,
    moyenne_generale numeric(4,2),
    cloture_par uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT moyennes_semestrielles_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2])))
);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.moyennes_semestrielles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.moyennes_semestrielles_id_seq OWNED BY public.moyennes_semestrielles.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    matiere_id integer NOT NULL,
    type_note text NOT NULL,
    valeur numeric(4,2) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    semestre smallint DEFAULT 1 NOT NULL,
    CONSTRAINT notes_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2]))),
    CONSTRAINT notes_type_note_check CHECK ((type_note = ANY (ARRAY['I1'::text, 'I2'::text, 'I3'::text, 'D1'::text, 'D2'::text, 'Ctrl'::text]))),
    CONSTRAINT notes_valeur_check CHECK (((valeur >= (0)::numeric) AND (valeur <= (20)::numeric)))
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    site_id integer NOT NULL,
    contenu text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    roles_cibles text[]
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: paiements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    enregistre_par uuid,
    CONSTRAINT paiements_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[]))),
    CONSTRAINT paiements_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: paiements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_id_seq OWNED BY public.paiements.id;


--
-- Name: paiements_supprimes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements_supprimes (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    admin_id uuid NOT NULL,
    date_suppression timestamp with time zone DEFAULT now() NOT NULL,
    motif text NOT NULL
);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_supprimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_supprimes_id_seq OWNED BY public.paiements_supprimes.id;


--
-- Name: penalites_reinscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.penalites_reinscription (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    montant integer DEFAULT 500 NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    date_paiement date NOT NULL,
    enregistre_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    CONSTRAINT penalites_reinscription_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[])))
);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.penalites_reinscription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.penalites_reinscription_id_seq OWNED BY public.penalites_reinscription.id;


--
-- Name: presences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.presences (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    date_presence date NOT NULL,
    site_id integer NOT NULL,
    classe_id integer NOT NULL,
    present boolean DEFAULT true NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: presences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.presences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: presences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.presences_id_seq OWNED BY public.presences.id;


--
-- Name: recompenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recompenses (
    id integer NOT NULL,
    note_id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois character varying(20) NOT NULL,
    type_gain text NOT NULL,
    montant integer NOT NULL,
    depense_id integer,
    paye_par uuid NOT NULL,
    date_paiement date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recompenses_montant_check CHECK ((montant = ANY (ARRAY[200, 500]))),
    CONSTRAINT recompenses_type_gain_check CHECK ((type_gain = ANY (ARRAY['interro'::text, 'devoir'::text])))
);


--
-- Name: recompenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recompenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recompenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recompenses_id_seq OWNED BY public.recompenses.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    nom_site character varying(100) NOT NULL,
    initiale character(1) NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: user_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sites (
    user_id uuid NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    site_id integer,
    actif boolean DEFAULT true NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text])))
);


--
-- Name: creneaux; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.creneaux (
    id integer NOT NULL,
    semaine_id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    date_td date NOT NULL,
    heure_debut time without time zone NOT NULL,
    heure_fin time without time zone NOT NULL,
    montant_prevu numeric(10,2) DEFAULT 0 NOT NULL,
    statut_creneau text DEFAULT 'brouillon'::text NOT NULL,
    CONSTRAINT creneaux_statut_creneau_check CHECK ((statut_creneau = ANY (ARRAY['brouillon'::text, 'public'::text, 'cloture'::text])))
);


--
-- Name: creneaux_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.creneaux_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: creneaux_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.creneaux_id_seq OWNED BY td.creneaux.id;


--
-- Name: demandes_retrait; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.demandes_retrait (
    id integer NOT NULL,
    code_demande character varying(30) NOT NULL,
    professeur_id integer NOT NULL,
    mois character varying(7) NOT NULL,
    montant_demande numeric(10,2) NOT NULL,
    reseau_momo text NOT NULL,
    numero_momo character varying(25) NOT NULL,
    statut text DEFAULT 'en_attente'::text NOT NULL,
    date_demande timestamp with time zone DEFAULT now() NOT NULL,
    ip_demande text,
    date_paiement timestamp with time zone,
    paye_par uuid,
    reference_paiement text,
    commentaire_admin text,
    date_rejet timestamp with time zone,
    rejete_par uuid,
    CONSTRAINT demandes_retrait_montant_demande_check CHECK ((montant_demande >= (5000)::numeric)),
    CONSTRAINT demandes_retrait_reseau_momo_check CHECK ((reseau_momo = ANY (ARRAY['mtn'::text, 'moov'::text, 'celtis'::text]))),
    CONSTRAINT demandes_retrait_statut_check CHECK ((statut = ANY (ARRAY['en_attente'::text, 'paye'::text, 'rejete'::text])))
);


--
-- Name: demandes_retrait_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.demandes_retrait_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: demandes_retrait_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.demandes_retrait_id_seq OWNED BY td.demandes_retrait.id;


--
-- Name: matieres_td; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.matieres_td (
    id integer NOT NULL,
    nom_matiere character varying(100) NOT NULL
);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.matieres_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_td_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.matieres_td_id_seq OWNED BY td.matieres_td.id;


--
-- Name: postulations; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.postulations (
    id integer NOT NULL,
    creneau_id integer NOT NULL,
    professeur_id integer NOT NULL,
    statut_validation text DEFAULT 'En attente'::text NOT NULL,
    date_postulation timestamp with time zone DEFAULT now() NOT NULL,
    motif_retrait text,
    CONSTRAINT postulations_statut_validation_check CHECK ((statut_validation = ANY (ARRAY['En attente'::text, 'Valide'::text, 'Refuse'::text, 'Retiree'::text])))
);


--
-- Name: postulations_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.postulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: postulations_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.postulations_id_seq OWNED BY td.postulations.id;


--
-- Name: professeurs; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.professeurs (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100) NOT NULL,
    telephone character varying(25) NOT NULL,
    email character varying(150) NOT NULL,
    mot_de_passe text NOT NULL,
    zone_id integer NOT NULL,
    matiere_principale_id integer NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL,
    valide boolean DEFAULT true NOT NULL,
    reset_token_hash text,
    reset_token_expires_at timestamp with time zone
);


--
-- Name: professeurs_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.professeurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professeurs_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.professeurs_id_seq OWNED BY td.professeurs.id;


--
-- Name: semaines; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.semaines (
    id integer NOT NULL,
    libelle character varying(100) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    date_cloture timestamp with time zone,
    CONSTRAINT semaines_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publiee'::text, 'cloturee'::text])))
);


--
-- Name: semaines_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.semaines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semaines_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.semaines_id_seq OWNED BY td.semaines.id;


--
-- Name: zones; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.zones (
    id integer NOT NULL,
    nom_zone character varying(100) NOT NULL
);


--
-- Name: zones_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.zones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zones_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.zones_id_seq OWNED BY td.zones.id;


--
-- Name: actualites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites ALTER COLUMN id SET DEFAULT nextval('public.actualites_id_seq'::regclass);


--
-- Name: actualites_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images ALTER COLUMN id SET DEFAULT nextval('public.actualites_images_id_seq'::regclass);


--
-- Name: annees_scolaires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires ALTER COLUMN id SET DEFAULT nextval('public.annees_scolaires_id_seq'::regclass);


--
-- Name: categories_depenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses ALTER COLUMN id SET DEFAULT nextval('public.categories_depenses_id_seq'::regclass);


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: coefficients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients ALTER COLUMN id SET DEFAULT nextval('public.coefficients_id_seq'::regclass);


--
-- Name: comptes_parents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents ALTER COLUMN id SET DEFAULT nextval('public.comptes_parents_id_seq'::regclass);


--
-- Name: decisions_passage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage ALTER COLUMN id SET DEFAULT nextval('public.decisions_passage_id_seq'::regclass);


--
-- Name: depenses_annexes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes ALTER COLUMN id SET DEFAULT nextval('public.depenses_annexes_id_seq'::regclass);


--
-- Name: eleves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves ALTER COLUMN id SET DEFAULT nextval('public.eleves_id_seq'::regclass);


--
-- Name: eleves_exonerations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations ALTER COLUMN id SET DEFAULT nextval('public.eleves_exonerations_id_seq'::regclass);


--
-- Name: eleves_suspendus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus ALTER COLUMN id SET DEFAULT nextval('public.eleves_suspendus_id_seq'::regclass);


--
-- Name: frais_td id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td ALTER COLUMN id SET DEFAULT nextval('public.frais_td_id_seq'::regclass);


--
-- Name: galerie id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie ALTER COLUMN id SET DEFAULT nextval('public.galerie_id_seq'::regclass);


--
-- Name: galerie_admin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin ALTER COLUMN id SET DEFAULT nextval('public.galerie_admin_id_seq'::regclass);


--
-- Name: log_whatsapp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp ALTER COLUMN id SET DEFAULT nextval('public.log_whatsapp_id_seq'::regclass);


--
-- Name: login_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN id SET DEFAULT nextval('public.login_attempts_id_seq'::regclass);


--
-- Name: matieres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres ALTER COLUMN id SET DEFAULT nextval('public.matieres_id_seq'::regclass);


--
-- Name: mfa_backup_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_backup_codes ALTER COLUMN id SET DEFAULT nextval('public.mfa_backup_codes_id_seq'::regclass);


--
-- Name: mois_exoneres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres ALTER COLUMN id SET DEFAULT nextval('public.mois_exoneres_id_seq'::regclass);


--
-- Name: moyennes_semestrielles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles ALTER COLUMN id SET DEFAULT nextval('public.moyennes_semestrielles_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: paiements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements ALTER COLUMN id SET DEFAULT nextval('public.paiements_id_seq'::regclass);


--
-- Name: paiements_supprimes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes ALTER COLUMN id SET DEFAULT nextval('public.paiements_supprimes_id_seq'::regclass);


--
-- Name: penalites_reinscription id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription ALTER COLUMN id SET DEFAULT nextval('public.penalites_reinscription_id_seq'::regclass);


--
-- Name: presences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences ALTER COLUMN id SET DEFAULT nextval('public.presences_id_seq'::regclass);


--
-- Name: recompenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses ALTER COLUMN id SET DEFAULT nextval('public.recompenses_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: creneaux id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux ALTER COLUMN id SET DEFAULT nextval('td.creneaux_id_seq'::regclass);


--
-- Name: demandes_retrait id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.demandes_retrait ALTER COLUMN id SET DEFAULT nextval('td.demandes_retrait_id_seq'::regclass);


--
-- Name: matieres_td id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td ALTER COLUMN id SET DEFAULT nextval('td.matieres_td_id_seq'::regclass);


--
-- Name: postulations id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations ALTER COLUMN id SET DEFAULT nextval('td.postulations_id_seq'::regclass);


--
-- Name: professeurs id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs ALTER COLUMN id SET DEFAULT nextval('td.professeurs_id_seq'::regclass);


--
-- Name: semaines id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines ALTER COLUMN id SET DEFAULT nextval('td.semaines_id_seq'::regclass);


--
-- Name: zones id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones ALTER COLUMN id SET DEFAULT nextval('td.zones_id_seq'::regclass);


--
-- Data for Name: actualites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites (id, titre, categorie, extrait, contenu, statut, a_la_une_jusqu_au, date_publication, cree_par) FROM stdin;
1	Démarrage des Cours Intensifs Préparatoires — Édition 2026	Cours	Le GSR lance sa nouvelle édition des Cours Intensifs Préparatoires sur ses 3 sites. Un programme pensé pour combler les lacunes et aborder la suite de l'année en confiance.	Le Groupe Secret de la Réussite ouvre officiellement sa nouvelle édition des Cours Intensifs Préparatoires, sur ses trois sites de Jéricho, Yagbé et Vèdoko. Ce programme, pensé pour la période de vacances, s'adresse à tous les élèves de la 6ème à la Terminale qui souhaitent consolider leurs acquis avant la reprise.\r\n\r\nL'objectif est simple : aborder en douceur les nouvelles notions du programme à venir. Chaque séance s'appuie sur des documents de cours structurés et des évaluations ciblées, pour que chaque élève progresse à son rythme sans se sentir dépassé.\r\n\r\nNos enseignants sont sélectionnés pour leur rigueur et leur pédagogie. Les tarifs, accessibles et adaptés à chaque niveau, sont disponibles en détail sur notre page Tarifs.\r\n\r\nLes places étant limitées sur chaque site, nous invitons les parents à inscrire rapidement leurs enfants en se rendant directement sur l'un de nos trois centres, ou en nous contactant par téléphone pour toute question sur le programme et les horaires.	publie	2026-08-22	2026-08-08 06:48:05.408897+00	\N
2	Démarrage des séances de révision BEPC 2026	Examens/Contrôle	À l'approche des examens, le GSR met en place un dispositif de révision intensif et méthodique dédié aux candidats.	À quelques mois d'une échéance décisive, le Groupe Secret de la Réussite lance ses séances de révision dédiées aux candidats au BEPC 2026. Ce dispositif vise à consolider les acquis sur l'ensemble du programme dans toutes les matières, avec un accent particulier sur les matières fondamentales : Mathématiques, PCT et SVT.\r\n\r\nLe format retenu combine rappels de cours structurés et exercices ciblés chacun suivi d'une correction méthodique en groupe. Cette approche permet à chaque candidat de mesurer précisément ses progrès et d'identifier les points qui demandent encore du travail avant le jour J.\r\n\r\nNos enseignants, habitués aux exigences de l'examen, accompagnent les élèves avec des conseils pratiques de gestion du temps et de méthodologie de rédaction, deux facteurs qui font souvent la différence le jour de l'épreuve.\r\n\r\nLes séances se déroulent sur nos sites de Jéricho et Yagbé, selon un calendrier communiqué aux familles inscrites. Pour rejoindre le dispositif ou obtenir plus d'informations, contactez-nous ou rendez-vous directement sur l'un de nos centres.	publie	\N	2026-08-01 06:48:05.408897+00	\N
3	Séance de Coaching et de Motivation des candidats aux examens 2026	Vie scolaire	Au-delà des révisions académiques, le GSR accompagne aussi ses candidats sur le plan psychologique avec une séance de coaching et de motivation.	La réussite aux examens ne se joue pas uniquement sur les connaissances académiques : la confiance en soi, la gestion du stress et la discipline personnelle jouent un rôle tout aussi déterminant. C'est dans cet esprit que le Groupe Secret de la Réussite a organisé une séance de coaching et de motivation dédiée à ses candidats aux examens 2026.\r\n\r\nAnimée par notre équipe pédagogique, cette rencontre a permis d'aborder des sujets essentiels à l'approche des épreuves : techniques de gestion du stress, organisation efficace du temps de révision, et surtout, comment garder confiance face à la pression des examens.\r\n\r\nLes élèves ont pu échanger librement sur leurs appréhensions et repartir avec des outils concrets pour aborder sereinement les semaines à venir. Cette dimension d'accompagnement humain fait partie intégrante de notre philosophie : préparer nos élèves non seulement académiquement, mais aussi mentalement, à affronter les moments décisifs de leur parcours scolaire.	publie	\N	2026-07-25 06:48:05.408897+00	\N
\.


--
-- Data for Name: actualites_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites_images (id, actualite_id, storage_path, ordre) FROM stdin;
1	1	vitrine/accueil/img_cip.jpg	0
2	2	vitrine/accueil/img_prepa.jpg	0
\.


--
-- Data for Name: annees_scolaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.annees_scolaires (id, libelle, date_debut, date_fin, statut) FROM stdin;
1	2026-2027	2026-10-01	2027-05-31	en_cours
\.


--
-- Data for Name: categories_depenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories_depenses (id, nom, systeme) FROM stdin;
1	Location Site	t
2	Paiement Prof	t
3	Fournitures	t
4	Transport	t
5	Communication	t
6	Maintenance	t
7	Frais bancaires	t
8	Autre	t
9	Récompense	f
11	Entretien	f
12	Salaire coordonnateur	f
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, nom_classe, site_id, ordre, classe_suivante_id) FROM stdin;
12	Terminale D	1	7	\N
13	6ème	2	1	14
15	4ème	2	3	16
4	3ème A	1	4	\N
17	3ème B	1	4	\N
1	6ème A	1	1	2
20	6ème B	1	1	19
2	5ème A	1	2	3
19	5ème B	1	2	18
11	Terminale C	1	7	\N
7	Première B	1	6	10
10	Terminale B	1	7	\N
22	3ème C	1	4	\N
8	Première D	1	6	12
6	Seconde C	1	5	24
24	Première C	1	6	11
23	Seconde D	1	5	8
14	5ème	2	2	15
16	3ème	2	4	\N
26	3ème D	1	4	\N
25	4ème C	1	3	26
18	4ème B	1	3	22
3	4ème A	1	3	17
27	5ème C	1	2	25
28	6ème C	1	1	27
5	Seconde B	1	5	7
\.


--
-- Data for Name: coefficients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coefficients (id, classe_id, matiere_id, coefficient, updated_at) FROM stdin;
1	1	1	1.00	2026-08-09 22:33:29.272+00
2	1	2	1.00	2026-08-09 22:33:38.434+00
3	1	3	1.00	2026-08-09 22:33:42.435+00
4	1	4	1.00	2026-08-09 22:33:50.941+00
5	1	5	1.00	2026-08-09 22:33:53.754+00
7	1	7	1.00	2026-08-09 22:34:02.071+00
11	20	1	1.00	2026-08-09 22:35:23.232+00
12	20	2	1.00	2026-08-09 22:35:26.587+00
13	20	3	1.00	2026-08-09 22:35:29.64+00
14	20	4	1.00	2026-08-09 22:35:32.733+00
15	20	5	1.00	2026-08-09 22:35:36.384+00
17	20	7	1.00	2026-08-09 22:36:21.475+00
21	2	1	1.00	2026-08-09 22:38:19.883+00
22	2	2	1.00	2026-08-09 22:38:23.389+00
23	2	3	1.00	2026-08-09 22:38:28.759+00
24	2	4	1.00	2026-08-09 22:38:33.558+00
25	2	5	1.00	2026-08-09 22:38:37.453+00
124	22	1	2.00	2026-08-20 21:47:51.364+00
29	2	7	1.00	2026-08-09 22:39:47.027+00
32	19	1	1.00	2026-08-09 22:41:11.023+00
33	19	2	1.00	2026-08-09 22:41:15.097+00
34	19	3	1.00	2026-08-09 22:41:19.274+00
35	19	4	1.00	2026-08-09 22:41:25.689+00
36	19	5	1.00	2026-08-09 22:41:29.795+00
38	19	7	1.00	2026-08-09 22:42:13.316+00
42	13	1	1.00	2026-08-09 22:43:48.04+00
43	13	2	1.00	2026-08-09 22:43:55.083+00
44	13	3	1.00	2026-08-09 22:44:00.208+00
45	13	4	1.00	2026-08-09 22:44:05.903+00
46	13	5	1.00	2026-08-09 22:44:11.06+00
47	13	6	1.00	2026-08-09 22:44:31.404+00
48	13	7	1.00	2026-08-09 22:44:42.046+00
49	13	8	1.00	2026-08-09 22:44:52.513+00
50	13	9	1.00	2026-08-09 22:45:02.407+00
51	13	10	1.00	2026-08-09 22:45:13.351+00
52	14	1	1.00	2026-08-09 22:46:19.228+00
53	14	2	1.00	2026-08-09 22:46:23.192+00
54	14	3	1.00	2026-08-09 22:46:28.257+00
55	14	4	1.00	2026-08-09 22:46:32.856+00
56	14	5	1.00	2026-08-09 22:46:37.237+00
57	14	6	1.00	2026-08-09 22:47:00.854+00
58	14	7	1.00	2026-08-09 22:47:10.978+00
59	14	8	1.00	2026-08-09 22:47:24.397+00
60	14	9	1.00	2026-08-09 22:47:35.053+00
61	14	10	1.00	2026-08-09 22:47:46.279+00
63	3	1	2.00	2026-08-09 22:57:20.66+00
64	3	2	3.00	2026-08-09 22:57:22.919+00
65	3	3	2.00	2026-08-09 22:57:25.385+00
66	3	4	2.00	2026-08-09 22:57:27.442+00
67	3	5	2.00	2026-08-09 22:57:29.779+00
69	3	7	2.00	2026-08-09 22:57:33.838+00
72	3	10	2.00	2026-08-09 22:57:40.597+00
74	1	11	1.00	2026-08-20 20:53:48.029+00
75	20	11	1.00	2026-08-20 20:58:22.005+00
76	2	11	1.00	2026-08-20 21:02:33.637+00
77	19	11	1.00	2026-08-20 21:03:58.459+00
78	3	9	2.00	2026-08-20 21:05:58.431+00
79	3	11	2.00	2026-08-20 21:06:13.081+00
80	18	1	2.00	2026-08-20 21:07:05.907+00
81	18	2	3.00	2026-08-20 21:07:12.194+00
82	18	3	2.00	2026-08-20 21:07:19.585+00
83	18	4	2.00	2026-08-20 21:07:30.287+00
84	18	5	2.00	2026-08-20 21:07:38.124+00
85	18	7	2.00	2026-08-20 21:07:47.063+00
86	18	9	2.00	2026-08-20 21:07:57.975+00
87	18	10	2.00	2026-08-20 21:08:05.342+00
88	18	11	2.00	2026-08-20 21:08:10.38+00
89	4	1	2.00	2026-08-20 21:09:54.018+00
91	4	3	2.00	2026-08-20 21:10:05.73+00
90	4	2	3.00	2026-08-20 21:10:10.801+00
93	4	4	2.00	2026-08-20 21:10:19.65+00
94	4	5	2.00	2026-08-20 21:10:37.474+00
95	4	7	2.00	2026-08-20 21:10:51.068+00
96	4	9	2.00	2026-08-20 21:10:59.718+00
97	4	10	2.00	2026-08-20 21:11:04.992+00
98	4	11	2.00	2026-08-20 21:11:10.35+00
99	17	1	2.00	2026-08-20 21:11:35.157+00
100	17	2	3.00	2026-08-20 21:11:41.091+00
101	17	3	2.00	2026-08-20 21:11:47.24+00
102	17	4	2.00	2026-08-20 21:11:54.935+00
103	17	5	2.00	2026-08-20 21:12:02.594+00
104	17	7	2.00	2026-08-20 21:12:42.877+00
105	17	11	2.00	2026-08-20 21:12:52.309+00
106	17	10	2.00	2026-08-20 21:12:57.798+00
107	17	9	2.00	2026-08-20 21:13:03.305+00
108	5	1	2.00	2026-08-20 21:16:35.619+00
109	5	6	2.00	2026-08-20 21:18:10.993+00
110	5	7	2.00	2026-08-20 21:18:47.551+00
111	5	9	2.00	2026-08-20 21:19:00.825+00
112	5	10	2.00	2026-08-20 21:19:03.931+00
113	5	8	2.00	2026-08-20 21:19:21.803+00
114	5	2	1.00	2026-08-20 21:19:44.393+00
115	5	5	1.00	2026-08-20 21:20:08.798+00
117	6	1	1.00	2026-08-20 21:23:29.97+00
118	6	3	2.00	2026-08-20 21:23:35.617+00
119	6	6	2.00	2026-08-20 21:24:11.632+00
120	6	7	1.00	2026-08-20 21:24:16.308+00
121	6	2	3.00	2026-08-20 21:25:08.492+00
122	6	4	3.00	2026-08-20 21:26:06.809+00
123	6	5	3.00	2026-08-20 21:26:11.502+00
125	22	2	3.00	2026-08-20 21:47:55.724+00
126	22	3	2.00	2026-08-20 21:48:06.475+00
127	22	4	2.00	2026-08-20 21:48:12.505+00
128	22	5	2.00	2026-08-20 21:48:19.214+00
129	22	7	2.00	2026-08-20 21:48:31.284+00
130	22	9	2.00	2026-08-20 21:48:38.832+00
131	22	10	2.00	2026-08-20 21:48:44.799+00
132	22	11	2.00	2026-08-20 21:48:52.642+00
116	5	3	2.00	2026-08-20 21:51:19.858+00
134	23	1	1.00	2026-08-20 22:46:51.427+00
135	23	3	2.00	2026-08-20 22:46:58.666+00
136	23	6	2.00	2026-08-20 22:47:16.311+00
137	23	7	1.00	2026-08-20 22:47:38.451+00
138	23	4	3.00	2026-08-20 22:48:20.759+00
139	23	5	3.00	2026-08-20 22:48:25.28+00
140	23	2	3.00	2026-08-20 22:48:33.194+00
141	8	2	4.00	2026-08-20 22:55:08.233+00
142	8	4	4.00	2026-08-20 22:55:16.977+00
143	8	5	5.00	2026-08-20 22:55:20.283+00
144	8	1	2.00	2026-08-20 22:55:33.318+00
145	8	3	2.00	2026-08-20 22:55:37.662+00
146	8	6	2.00	2026-08-20 22:55:41.973+00
147	8	7	2.00	2026-08-20 22:55:49.107+00
148	24	7	2.00	2026-08-20 22:59:21.262+00
149	24	6	2.00	2026-08-20 22:59:24.671+00
150	24	5	2.00	2026-08-20 22:59:28.71+00
151	24	4	5.00	2026-08-20 22:59:34.997+00
152	24	3	2.00	2026-08-20 22:59:39.451+00
153	24	2	5.00	2026-08-20 22:59:46.135+00
154	24	1	2.00	2026-08-20 22:59:49.919+00
155	7	10	1.00	2026-08-20 23:03:01.782+00
156	7	9	1.00	2026-08-20 23:03:26.481+00
157	7	8	4.00	2026-08-20 23:03:30.625+00
158	7	7	4.00	2026-08-20 23:03:34.118+00
159	7	6	3.00	2026-08-20 23:03:37.839+00
163	7	1	4.00	2026-08-20 23:03:56.335+00
160	7	5	2.00	2026-08-20 23:03:41.992+00
161	7	3	3.00	2026-08-20 23:03:48.955+00
162	7	2	2.00	2026-08-20 23:03:52.106+00
164	12	7	2.00	2026-08-20 23:05:03.142+00
165	12	6	2.00	2026-08-20 23:05:06.21+00
166	12	5	5.00	2026-08-20 23:05:11.855+00
167	12	4	4.00	2026-08-20 23:05:18.934+00
168	12	3	2.00	2026-08-20 23:05:22.5+00
169	12	2	4.00	2026-08-20 23:05:29.37+00
170	12	1	2.00	2026-08-20 23:05:32.335+00
171	11	7	2.00	2026-08-20 23:07:58.54+00
172	11	6	2.00	2026-08-20 23:08:02.077+00
173	11	5	2.00	2026-08-20 23:08:09.04+00
174	11	4	5.00	2026-08-20 23:08:17.229+00
175	11	3	2.00	2026-08-20 23:08:23.15+00
176	11	2	6.00	2026-08-20 23:08:27.895+00
177	11	1	2.00	2026-08-20 23:09:00.712+00
178	10	10	1.00	2026-08-20 23:11:25.359+00
179	10	9	1.00	2026-08-20 23:11:28.377+00
180	10	8	4.00	2026-08-20 23:11:33.319+00
181	10	7	4.00	2026-08-20 23:11:37.508+00
182	10	6	3.00	2026-08-20 23:11:40.834+00
183	10	5	2.00	2026-08-20 23:11:44.256+00
184	10	3	3.00	2026-08-20 23:11:52.313+00
185	10	2	2.00	2026-08-20 23:12:05.25+00
186	10	1	4.00	2026-08-20 23:12:11.515+00
\.


--
-- Data for Name: comptes_parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comptes_parents (id, matricule, mot_de_passe, date_creation, derniere_connexion) FROM stdin;
\.


--
-- Data for Name: decisions_passage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.decisions_passage (id, eleve_id, decision, nouvelle_classe_id, annee_scolaire_id, date_decision, decide_par) FROM stdin;
\.


--
-- Data for Name: depenses_annexes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.depenses_annexes (id, categorie_id, libelle, montant, date_depense, saisi_par, date_saisie, annee_scolaire_id) FROM stdin;
1	3	Papier Ram (1 Carton)	11000.00	2026-09-18	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:27:28.478041+00	1
5	8	Lampe torche (2)	6000.00	2026-09-25	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:47:04.831226+00	1
6	5	Affiche Publicitaire Grand format (2)	7200.00	2026-09-12	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:49:07.695571+00	1
7	1	Frais de site Jéricho mois d'Octobre 2026	130000.00	2026-09-30	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 11:34:43.970864+00	1
3	11	Balayage du 25 Septembre 2026	9000.00	2026-09-25	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:44:00.680196+00	1
2	11	Balayage du 18 Septembre 2026	7000.00	2026-09-18	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:31:48.482039+00	1
8	11	Balayage du 02 et du 04 Octobre 2026	13600.00	2026-10-04	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 11:39:54.479131+00	1
9	3	Papier Ram (2 paquets) + craie (1 boîte)	6200.00	2026-10-02	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 12:22:42.01093+00	1
4	5	Forfait appel Celtiis	10000.00	2026-09-14	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:45:00.359199+00	1
10	5	Forfait appel Celtis	5000.00	2026-10-06	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-07 07:45:26.690655+00	1
12	8	Lampe torche (3)	9000.00	2026-10-07	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 12:06:30.325447+00	1
13	3	Imprimante kyocera blanc noir 	53500.00	2026-10-08	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 13:15:39.693425+00	1
11	11	Balayage du 07 au 09 Octobre 2026	12000.00	2026-10-09	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 05:55:13.834101+00	1
15	3	Papier Ram ( 1 carton) + craie (1 boîte)	12500.00	2026-10-09	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-10 02:12:34.798356+00	1
18	7	Ouverture de compte bancaire Atlantique Banque et premier dépôt 	10000.00	2026-10-12	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 09:57:10.155096+00	1
26	3	Tablette professionnelle 	160000.00	2026-10-15	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 15:19:19.845746+00	1
16	11	Balayage du 14 au 18 Octobre 2026	15000.00	2026-10-18	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 03:47:20.880833+00	1
29	3	Papier Ram (1 carton)	11000.00	2026-10-16	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 16:24:30.01844+00	1
30	12	Salaire Septembre 2026	200000.00	2026-09-30	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 16:28:21.155365+00	1
28	8	Achat de vin à offrir à l'administration Yagbé 	19000.00	2026-10-23	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 16:20:57.508552+00	1
33	3	Achat d'un lot d'instruments de Mathématiques 	5000.00	2026-10-23	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-23 22:13:47.8324+00	1
27	3	Tee-shirt 	87000.00	2026-10-23	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 15:28:26.185272+00	1
35	1	Frais de site Yagbé mois d'Octobre 2026	40000.00	2026-10-23	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-23 22:21:13.562278+00	1
34	11	Balayage du 21 au 25 Octobre 2026	13000.00	2026-10-25	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-23 22:15:41.977469+00	1
32	8	Prise en charge 50% paiement Octobre retardataires 	81250.00	2026-10-25	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 16:34:23.364934+00	1
31	12	Avance sur salaire Octobre 2026	100000.00	2026-10-25	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 16:29:17.540177+00	1
36	3	Papier Ram (1 carton)	12000.00	2026-10-28	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-28 13:50:21.296913+00	1
37	3	Achat de portable à touche 	5000.00	2026-10-27	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 12:12:17.011704+00	1
38	11	Balayage du 28 au 31 Octobre 2026	2500.00	2026-10-28	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 12:13:24.694722+00	1
39	2	Paiement émoluments Septembre 2026	146400.00	2026-10-29	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 21:53:16.627474+00	1
40	2	Frais de transaction des émoluments 	950.00	2026-10-29	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 21:56:34.933853+00	1
41	5	Forfait appel Celtiis	5000.00	2026-10-28	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 22:03:27.169892+00	1
\.


--
-- Data for Name: eleves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves (id, matricule, nom, prenoms, contact_parent, classe_id, college, option_m, statut, date_inscription, contact_parent_2) FROM stdin;
1269	Y10265031	HOUSSOU	Gemima	+2290197592760	14	CEG YAGBE	\N	actif	2026-10-20 00:08:41.229871+00	\N
69	J08269764	HONFOGA	Juliette	+2290197338328	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:55.537954+00	\N
1294	Y10269651	SALIOU	Fridaous	+2290166031250	14	CEG YAGBE	\N	actif	2026-10-25 14:48:29.573885+00	\N
1232	J10262511	LALA-AKAMBI	Habib	+2290167077894	18	CEG DANTOKPA	M1	suspendu	2026-10-18 06:11:55.687151+00	+2290147663978
11	J08267444	BOUSSARI	Aemane	+2290197832325	1	CEG DU LAC	\N	actif	2026-08-25 20:08:16.849956+00	\N
1257	J10265396	ADJASSA	Gracia	\N	18	CEG DU LAC	\N	suspendu	2026-10-18 10:04:49.150163+00	+2290196388460
62	J08262797	HOUESSINON	Océane	+2290195192360	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:51.955924+00	\N
41	J08268546	AFFO	Régina	+2290197618574	1	CEG DANTOKPA	M2	suspendu	2026-08-25 20:08:40.957883+00	\N
5	J08268267	AHOTON	Aristide	+2290199245666	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:13.202517+00	\N
7	J08267548	ALI KPONOU	Barnabé	+2290149231863	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:14.629668+00	\N
8	J08263106	AMOUSSOU	Angéline Tété	+2290147001102	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:15.145837+00	\N
10	J08264473	BONOU	Andréa	+2290167569601	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:16.409862+00	\N
12	J08268911	DANNOUDO	Belvine	+2290197149708	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:17.309641+00	\N
15	J08261500	DEGBO	Abel	+2290169008428	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:23.804393+00	\N
16	J08264569	DJOHA	Fridaouce	+2290144989378	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:24.29167+00	\N
21	J08264212	HASSANE	Abdoul Razack	+2290196124155	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:28.782043+00	\N
26	J08264348	HOUNGBO	Kafui Belle	+2290161958178	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:33.099597+00	\N
29	J08269137	KOUKPAKI	Habiguel	+2290147104032	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:34.966879+00	\N
34	J08267043	TOSSAVI	Eurielle	+2290196145763	1	CEG DU LAC	\N	actif	2026-08-25 20:08:37.573351+00	\N
30	J08267246	KPLAKOTCHA	Bignon Pascaline	+2290197161718	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:35.393318+00	\N
37	J08265784	ZANNOU	Charles	+2290197833912	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:38.913405+00	\N
42	J08268517	AGOSSOU	Diane Christiane	+2290197860677	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:41.492241+00	\N
43	J08263823	AHEHEHINNOU	Princesse	+2290143979537	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:42.640039+00	\N
48	J08267893	ALLOSSE	Merveil	+2290166027811	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:45.350018+00	\N
57	J08268114	DENAKPO	Samuel	+2290196009792	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:49.731717+00	\N
64	J08269872	HOUNDO	Urbain	+2290163357881	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:53.094261+00	\N
66	J08262719	HOUNGA	Romuald	+2290157606352	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:54.143593+00	\N
68	J08264253	HOUNNOU	Rachelle Fèmi	+2290140577316	1	CEG DU LAC	\N	suspendu	2026-08-25 20:08:55.004408+00	\N
49	J08264584	AWAZE	Rosalie	+2290197939840	1	CEG DU LAC	\N	actif	2026-08-25 20:08:45.778327+00	\N
32	J08269042	SIMENOU	M. Jérôme	+2290166098259	20	CEG DU LAC	\N	suspendu	2026-08-25 20:08:36.525755+00	\N
51	J08269366	BALA	Nabil	+2290140357078	1	CEG DU LAC	\N	actif	2026-08-25 20:08:46.59036+00	\N
52	J08262516	BOUKARI	Majoie	+2290196915692	1	CEG DU LAC	\N	actif	2026-08-25 20:08:47.016333+00	\N
53	J08262940	CHOGOLOU	Naomie	+2290195319539	1	CEG DU LAC	\N	actif	2026-08-25 20:08:47.65703+00	\N
1299	Y11268619	DO-REGO	Jasucri	+2290196371580	16	CEG YAGBE	\N	actif	2026-11-01 08:01:20.014052+00	\N
55	J08265035	DAGA	Ella	+2290157527662	1	CEG DU LAC	\N	actif	2026-08-25 20:08:48.755396+00	\N
56	J08267543	DELE	Astride	+2290196144429	1	CEG DU LAC	\N	actif	2026-08-25 20:08:49.188918+00	\N
58	J08268391	DOUDJI	Thierry	+2290166237408	1	CEG DU LAC	\N	actif	2026-08-25 20:08:50.188168+00	\N
19	J08264361	GODONOU	Gloria Merveille	+2290197328732	1	CEG DU LAC	\N	actif	2026-08-25 20:08:26.430749+00	+2290164785458
71	J08268667	KEITA	Aminata	+2290197314371	1	CEG DU LAC	\N	actif	2026-08-25 20:08:57.16069+00	\N
1295	Y10261485	SAIZONOU	Falonne	+2290197520238	15	CEG YAGBE	\N	actif	2026-10-25 14:54:04.270276+00	\N
77	J08265783	KPODJI	Néhémie	+2290167221243	1	CEG DU LAC	\N	actif	2026-08-25 20:09:04.385038+00	\N
1270	Y10266847	BISSIRIOU	Fatiath	+2290196415033	15	CEG YAGBE	\N	suspendu	2026-10-20 06:24:43.205799+00	\N
84	J08264180	TCHEWENOU	Arsène	+2290166035605	1	CEG DU LAC	\N	suspendu	2026-08-25 20:09:10.199278+00	\N
1233	J10267278	ASSOCLE	Gaëlle	+2290197380691	18	CEG DU LAC	M5	suspendu	2026-10-18 06:12:41.918725+00	\N
1258	Y10265282	MONTCHO	Atma	+2290199198080	16	CEG YAGBE	\N	actif	2026-10-18 10:11:14.640707+00	\N
72	J08267215	KODJO	Abdiel	+2290197984238	1	CEG DU LAC	\N	actif	2026-08-25 20:08:57.791864+00	\N
1296	Y10269215	YAOTCHA	Grâce	+2290197815798	14	CEG YAGBE	\N	actif	2026-10-25 15:31:15.442597+00	\N
78	J08268262	OKE	Henriette	+2290197442195	1	CEG DU LAC	\N	actif	2026-08-25 20:09:05.120007+00	\N
81	J08268561	RADJI	Raoudath	+2290196789444	1	CEG DU LAC	\N	actif	2026-08-25 20:09:07.022291+00	\N
1271	J10268229	ARIORI	Parfaite	+2290155417438	12	CEG DU LAC	\N	suspendu	2026-10-21 22:35:56.618972+00	+2290166765135
1234	J10263340	TCHIBOZO	Nadia	+2290163750858	2	LA RÉFÉRENCE	M3	suspendu	2026-10-18 06:44:43.936383+00	\N
87	J08264552	HOUNGBO	Delphin	+2290196688515	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:08.675427+00	\N
1259	Y10267810	SAVI	Fatima	+2290197218152	14	CEG YAGBE	\N	actif	2026-10-18 10:26:36.468945+00	\N
95	J08269363	ADOUNVO	Jennifer	+2290197594007	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:13.188926+00	\N
96	J08263763	AGBODJINOU	Mariale	+2290167663696	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:13.647296+00	\N
97	J08268080	AGOSSOU	Emmanuella Théodora	+2290197055133	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:14.205934+00	\N
103	J08267273	AMADOU	Yasmine	+2290154066389	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:18.87951+00	\N
113	J08264655	FANOU	Daniel	+2290197476899	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:35.193329+00	\N
127	J08264575	KONGNON	Délia	+2290197735776	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:48.490539+00	\N
135	J08269085	NOUHOU	Abdoul Malick	+2290153544001	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:52.848805+00	\N
137	J08265347	OSSE	Rodiath	+2290196214481	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:54.922733+00	\N
141	J08265266	TCHOUTCHOU	Julien	+2290197640248	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:57.638412+00	\N
142	J08268635	VODOUNON	Abigael	+2290161473452	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:58.139998+00	\N
120	J08262823	HONFO	Irène	+2290197278334	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:42.182296+00	\N
143	J08262675	VOITAN	Mirabelle	+2290191122266	20	CEG DU LAC	\N	suspendu	2026-08-25 20:15:59.165779+00	\N
111	J08265923	DEDEWANOU	Antoine Karl	+2290166035959	20	CEG DU LAC	\N	actif	2026-08-25 20:15:30.321026+00	\N
115	J08268220	GANTIN	Sandrine	+2290166752832	20	CEG DU LAC	\N	actif	2026-08-25 20:15:37.004969+00	\N
116	J08265269	GANTIN	Jean Marie Vianney	+2290166752832	20	CEG DU LAC	\N	actif	2026-08-25 20:15:38.133241+00	\N
128	J08265578	KOUNNI	Ferdinand	+2290161714247	20	CEG DU LAC	\N	actif	2026-08-25 20:15:49.298866+00	\N
100	J08269537	AHOUSSINOU	Ariane	+2290197419771	20	CEG OKOUN SEME	\N	actif	2026-08-25 20:15:16.172653+00	\N
133	J08265910	MOUSSA	Souraimou	+2290196097248	1	CEG DU LAC	\N	actif	2026-08-25 20:15:51.779213+00	\N
101	J08267211	AHOUSSINOU	Trésora	+2290197419771	20	CEG OKOUN SEME	\N	actif	2026-08-25 20:15:16.629155+00	\N
153	J08266287	AKPO	Mirabelle	+2290197312358	2	CEG DU LAC	\N	actif	2026-08-25 20:17:57.307348+00	\N
1297	Y10265957	DONDJA	Zakiath	+2290166384725	15	CEG YAGBE	\N	actif	2026-10-29 11:51:07.019062+00	\N
1235	J10264969	BOUBAKAR	Youssouf	+2290197335840	2	CEG DU LAC	M6	actif	2026-10-18 06:48:03.788749+00	\N
157	J08266313	COUMASSOU	Prince	+2290197080003	2	CEG DU LAC	M3	actif	2026-08-25 20:17:59.305607+00	\N
167	J08262389	HINVI	Ziad	+2290197037460	2	CEG DU LAC	\N	actif	2026-08-25 20:18:09.138801+00	\N
177	J08265692	MOUSSA	Housna	+2290197349831	2	CEG STE RITA	M2	actif	2026-08-25 20:18:14.80965+00	\N
1272	J10265237	OLAGUNJU	Mariame	+2290152245274	12	CEG DU LAC	\N	suspendu	2026-10-21 22:38:20.554585+00	+2290196591441
151	J08265785	AGOSSOU	Victorine	+2290167476339	2	CEG DU LAC	\N	suspendu	2026-08-25 20:17:55.946261+00	\N
1260	Y10267586	YAOTCHAMAGAN	Emmanuella	+2290140751632	14	CEG YAGBE	\N	actif	2026-10-18 10:30:31.87573+00	\N
165	J08261302	GNANMLIN	Miracle	+2290190467078	2	CEG DU LAC	\N	suspendu	2026-08-25 20:18:08.05419+00	\N
173	J08269254	KOULIHO	Esther	+2290197255177	2	CEG DU LAC	\N	suspendu	2026-08-25 20:18:12.453726+00	\N
187	J08267645	YEDIYETON	Bénoit	+2290161997615	2	CEG DU LAC	\N	suspendu	2026-08-25 20:18:27.07848+00	\N
189	J08266477	ZOUMENOU	Kenneth	+2290166767937	2	LA RÉFÉRENCE	\N	actif	2026-08-25 20:18:28.651564+00	\N
148	J08261306	AGLI	Marie Grâce	+2290196727958	2	CEG DU LAC	\N	actif	2026-08-25 20:17:54.508992+00	\N
168	J08265768	HOUETCHOU	Boris	+2290166765769	2	CEG DU LAC	\N	suspendu	2026-08-25 20:18:09.536271+00	\N
1273	J10268828	KOUMALIN	Mariam	+2290166118314	20	CEG DANTOKPA	\N	actif	2026-10-25 08:00:29.938533+00	\N
164	J08266507	GBAMMADO	Marie Guillaumine	+2290197226046	2	CEG DU LAC	\N	actif	2026-08-25 20:18:07.439743+00	\N
166	J08266025	GOUNFLE	Fréjuste	+2290169685526	2	CEG DU LAC	\N	actif	2026-08-25 20:18:08.705773+00	\N
178	J08261650	NANDANAN	Harvey	+2290166759633	2	CEG DU LAC	\N	actif	2026-08-25 20:18:15.636598+00	\N
209	J08266177	GOUGBE	Yvette	+2290167258787	19	CEG DU LAC	M4	actif	2026-08-25 20:21:21.38959+00	\N
186	J08267188	TOSSA	Kasmi	+2290145408425	2	CEG DU LAC	\N	actif	2026-08-25 20:18:25.753843+00	\N
196	J08263082	AHOUHENOU	Trésor	+2290148501864	19	CEG DU LAC	M8	suspendu	2026-08-25 20:21:10.794834+00	\N
224	J08262449	SAGBO	Exaucé	+2290197779418	19	CEG ZOGBO	M1	actif	2026-08-25 20:21:28.438895+00	\N
193	J08263232	AGOGNON	Légende	+2290166775177	19	CEG DU LAC	M2	actif	2026-08-25 20:21:09.043323+00	\N
232	J08269533	YEVO EDO	Bénédicte	+2290191311563	19	CEG DU LAC	M1	suspendu	2026-08-25 20:21:32.964158+00	\N
206	J08269627	DOSSOU	Urielle Alfreda	+2290166889076	19	CEG DU LAC	\N	actif	2026-08-25 20:21:19.96175+00	\N
152	J08269605	AHISSOU	Exaucé	+2290197826116	2	CEG DU LAC	M3	suspendu	2026-08-25 20:17:56.653392+00	\N
215	J08265764	KODJO	Abimaël	+2290197984238	19	SAINT MICHEL	M2	actif	2026-08-25 20:21:24.190851+00	\N
200	J08263509	BOTON FATCHE	Etienne	+2290165566653	19	CEG DU LAC	M8	actif	2026-08-25 20:21:13.991351+00	\N
184	J08265037	SOUNOUVO	Exaucé Nadège	+2290190182835	2	CEG DU LAC	M3	suspendu	2026-08-25 20:18:22.432022+00	\N
1236	J10263275	HOUETO	Sédrique	+2290152487706	19	CEG DU LAC	M1	actif	2026-10-18 06:53:11.79963+00	\N
158	J08269052	DANSI-GAH	Sèdjro Assuerus	+2290197261814	2	CEG DANTOKPA	M3	suspendu	2026-08-25 20:17:59.923184+00	\N
174	J08267855	KPIKPONSOUHOU	Chérif	+2290157369995	2	CEG DANTOKPA	M4	suspendu	2026-08-25 20:18:12.914535+00	\N
195	J08268059	AGUE	Dolorès	+2290169473256	2	CEG DU LAC	\N	suspendu	2026-08-25 20:21:10.326029+00	\N
226	J08265047	SOTON	Williams	+2290169193199	19	CEG DU LAC	\N	actif	2026-08-25 20:21:29.285542+00	\N
190	J08269360	ADJIWANOU	Gérade	+2290195506360	19	CEG DU LAC	M10	actif	2026-08-25 20:21:06.754093+00	\N
203	J08266148	DEGBOGBAHOUN	Aldonie	+2290196315585	19	CEG DU LAC	M1	actif	2026-08-25 20:21:17.358207+00	\N
221	J08263831	NOUVOESSI	Fortuné T.	+2290197084300	19	CEG DU LAC	M4	actif	2026-08-25 20:21:26.941801+00	\N
207	J08264321	GANHOUNOUTO	Marie Thérèse	+2290196125479	19	CEG DU LAC	M3	actif	2026-08-25 20:21:20.392061+00	\N
201	J08263520	DAGA	Rosalma	+2290157527662	19	CEG STE RITA	M5	actif	2026-08-25 20:21:15.344264+00	\N
222	J08263037	OLAWUMI	Anne marie	+2290151517544	19	CEG DU LAC	\N	actif	2026-08-25 20:21:27.591132+00	\N
156	J08262999	AYONOU	Samuel	+2290166901887	2	CEG DU LAC	M7	actif	2026-08-25 20:17:58.840807+00	\N
150	J08262276	AGOSSOU	Lorice	+2290197860677	2	CEG DU LAC	\N	suspendu	2026-08-25 20:17:55.462522+00	\N
1261	J10269732	ADOUVO	Gertrude	+2290166247402	3	CEG DU LAC	\N	suspendu	2026-10-18 19:31:44.416832+00	\N
162	J08268276	DOSSA	Ifè Edwige M.	+2290196610899	2	CEG DU LAC	\N	suspendu	2026-08-25 20:18:04.591692+00	\N
1298	J10262824	AKITOBY	Sergine	+2290195818270	18	CEG DU LAC	\N	suspendu	2026-10-31 06:12:32.957264+00	\N
176	J08267340	MIGNONTODE	Flora	+2290197217601	2	CEG DU LAC	\N	suspendu	2026-08-25 20:18:13.815287+00	\N
188	J08262689	YESSOUFOU	Ambidath	+2290196757912	2	CEG DU LAC	\N	suspendu	2026-08-25 20:18:28.21583+00	\N
216	J08268081	KOUTON	Dorcas Mahugnon	+2290155414875	19	CEG DU LAC	M4	suspendu	2026-08-25 20:21:24.669724+00	\N
194	J08263499	AGOSSOU	Victoria	+2290167476339	19	CEG DU LAC	\N	suspendu	2026-08-25 20:21:09.554304+00	\N
198	J08264964	ARIORI	Sagesse	+2290197893687	19	CEG DU LAC	M6	suspendu	2026-08-25 20:21:11.762538+00	\N
214	J08263025	IBRAHIM	Mohamed	+2290153547976	19	CEG DU LAC	M4	suspendu	2026-08-25 20:21:23.746714+00	\N
208	J08261310	GLELE	David Junior	+2290167077126	19	CEG DU LAC	M3	suspendu	2026-08-25 20:21:20.883773+00	\N
204	J08265241	DJIGBE	Bernadin	+2290147278964	19	CEG DU LAC	M10	suspendu	2026-08-25 20:21:18.399457+00	\N
202	J08266547	DA SILVA	Peace Joy	+2290197379738	19	CEG STE RITA	M7	suspendu	2026-08-25 20:21:16.923281+00	\N
191	J08264547	AGBO ZINSOU	Anick	+2290166011707	19	CEG DU LAC	M1	suspendu	2026-08-25 20:21:08.054005+00	\N
231	J08267962	YESSOUFOU	Himayath	+2290157577890	19	CEG DU LAC	M3	suspendu	2026-08-25 20:21:32.536467+00	\N
227	J08262359	SOUNOUVO	Ezéchiel	+2290166119513	19	CEG DANTOKPA	\N	suspendu	2026-08-25 20:21:29.705505+00	\N
218	J08265895	MEGOTIN	Inecia Gloria	+2290197610834	19	CEG STE RITA	M4	suspendu	2026-08-25 20:21:25.725845+00	\N
238	J08267099	AKPO	Judith	+2290197312358	3	CEG DU LAC	\N	actif	2026-08-25 20:23:13.382645+00	\N
1274	J10266304	ADEDOKOUN	Mohamed	+2290196172941	1	CEG DU LAC	\N	actif	2026-10-25 08:21:27.234429+00	\N
244	J08269502	CHOGOLOU	Merveille	+2290197998135	3	CEG DU LAC	\N	actif	2026-08-25 20:23:16.398331+00	\N
251	J08266975	HINVI	Imtinane	+2290157594918	3	CEG DU LAC	\N	actif	2026-08-25 20:23:20.444147+00	\N
242	J08262629	BAHOUNON	Zéphaniah	+2290197072759	3	CEG STE RITA	\N	suspendu	2026-08-25 20:23:15.398769+00	\N
1237	J10262267	GORY-SYLLA	Amadou	+2290164348971	19	CEG DU LAC	M4	suspendu	2026-10-18 06:55:28.312506+00	\N
257	J08265274	AKPLAGBE	Surprise	+2290196720577	3	CEG DU LAC	\N	suspendu	2026-08-25 20:23:26.13395+00	\N
1262	J10268158	MASSARI	Adnane	\N	18	CEG DANTOKPA	\N	actif	2026-10-18 19:34:29.690983+00	+2290196417616
263	J08267347	GNONLONFOUN	Amour	+2290166696627	3	CEG STE RITA	\N	suspendu	2026-08-25 20:23:28.696394+00	\N
269	J08263201	KODJO	Merveille	+2290148879069	3	CEG DANTOKPA	\N	suspendu	2026-08-25 20:23:31.44012+00	\N
255	J08263921	AFO	Fabienne	+2290196849044	18	CEG DU LAC	\N	suspendu	2026-08-25 20:23:25.206681+00	\N
276	J08261766	SEWADE	Anne Marie	+2290197127769	3	CEG DU LAC	\N	actif	2026-08-25 20:23:34.709415+00	\N
1275	J10268699	ADEDOKOUN	Moustekimat	+2290196172941	1	CEG DU LAC	\N	actif	2026-10-25 08:24:06.935829+00	\N
241	J08266621	BAGBONON	Thérèse	+2290197294636	3	CEG DU LAC	\N	actif	2026-08-25 20:23:15.00794+00	\N
243	J08262739	CHOGOLOU	Daniel	+2290197998135	3	CEG GBEGAMEY	\N	actif	2026-08-25 20:23:15.951138+00	\N
245	J08261829	CODJOVI	Warren	+2290196532358	3	CEG DU LAC	\N	actif	2026-08-25 20:23:16.862292+00	\N
247	J08264514	DANSI	Inès	+2290153291153	3	CEG DU LAC	\N	actif	2026-08-25 20:23:17.72742+00	\N
1263	J10265128	FADEHI	Bernadette	+2290197031011	8	CEG DANTOKPA	\N	actif	2026-10-18 19:38:25.61665+00	+2290141572808
252	J08264241	KOLI	Jamal	+2290197839250	3	CEG DU LAC	\N	actif	2026-08-25 20:23:21.743552+00	\N
287	J08267451	AHOKPE	Odile	+2290197253091	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:09.147118+00	\N
1238	J10264256	HOUNSOU	Adéline	+2290197029777	19	CEG STE RITA	M3	suspendu	2026-10-18 06:58:50.636707+00	\N
272	J08262068	NOUDAMESSI	Esther	+2290199303063	3	CEG DU LAC	\N	suspendu	2026-08-25 20:23:32.792163+00	\N
275	J08267091	SEDJAME	Fifamè	+2290195030593	3	CEG STE RITA	\N	suspendu	2026-08-25 20:23:34.281538+00	\N
264	J08266200	HOUNTONDJI	Josué	+2290150390481	3	CEG DU LAC	\N	actif	2026-08-25 20:23:29.112226+00	\N
284	J08262750	ADJINAKOU	Dénise	+2290196516030	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:07.768867+00	\N
285	J08265741	AGOGNON	Ericaelle	+2290196463831	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:08.223234+00	\N
270	J08261928	KOUDJANNANGNI	Favour	+2290196720577	3	CEG DU LAC	\N	actif	2026-08-25 20:23:31.909157+00	\N
286	J08267659	AHLONSOU	Gloria	+2290197538418	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:08.679252+00	\N
293	J08261299	FRANCISCO	Géovani Bignon	+2290197984238	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:12.270564+00	\N
294	J08262991	HOUENOU	Lorindo	+2290161020067	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:12.680398+00	\N
288	J08266640	AHOUANGBO	Francois	+2290168004959	18	CEG FIYEGNON	\N	actif	2026-08-25 20:25:09.570642+00	\N
303	J08264739	SAGBO	Madoché	+2290196749687	18	CEG DANTOKPA	\N	suspendu	2026-08-25 20:25:18.566774+00	\N
290	J08264353	ATSEFONYA	Komlavi Dieu donné	+2290169366200	18	CEG DU LAC	\N	actif	2026-08-25 20:25:10.68848+00	\N
305	J08267841	AGOSSOU	Damienne	+2290147992417	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:20.224754+00	\N
306	J08264502	AHISSOU	Marcolino	+2290197826116	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:20.819693+00	\N
295	J08263957	HOUETO	Ruth	+2290163395788	18	CEG DU LAC	\N	actif	2026-08-25 20:25:13.114509+00	\N
309	J08266858	CHEMITAN	Widad	+2290197069624	18	CEG STE RITA	\N	suspendu	2026-08-25 20:25:22.670713+00	\N
310	J08266360	GNONLONFOUN	Emmanuella	+2290195665249	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:23.085322+00	\N
312	J08265474	GOUSSANOU	Fanelle	+2290197992570	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:23.925831+00	\N
317	J08266763	YESSOUFOU	Ihssane	+2290197670868	18	CEG DU LAC	\N	suspendu	2026-08-25 20:25:26.162121+00	\N
300	J08266895	OKE	Narcisse	+2290197442195	18	CEG DU LAC	\N	actif	2026-08-25 20:25:15.642398+00	\N
322	J08265442	ATEKPO	Modérand	+2290195879022	4	CEG DU LAC	\N	suspendu	2026-08-25 22:14:34.962607+00	\N
302	J08266620	RADJI	Rokibath	+2290196789444	18	CEG DANTOKPA	\N	actif	2026-08-25 20:25:16.96529+00	\N
262	J08262658	GANKOU	Nelda	+2290195425289	18	CEG DU LAC	\N	suspendu	2026-08-25 20:23:28.26659+00	\N
307	J08264556	AWAZE	Mathias	+2290197939840	18	CEG DU LAC	\N	actif	2026-08-25 20:25:21.278402+00	\N
281	J08266134	ZANNOU	Géraldo	+2290161089001	18	CEG STE RITA	\N	suspendu	2026-08-25 20:23:36.820695+00	\N
313	J08267475	HOUNNOU	Chakirath	+2290148159571	18	CEG DU LAC	\N	actif	2026-08-25 20:25:24.538587+00	\N
314	J08261428	HOUNTONDJI	Josephine	+2290150390481	18	CEG DU LAC	\N	actif	2026-08-25 20:25:24.939314+00	\N
318	J08263702	ZOUMENOU	Mystère	+2290166767937	18	LA RÉFÉRENCE	\N	actif	2026-08-25 20:25:26.599413+00	\N
323	J08264998	CISSE	Salif	+2290152240511	4	CEG DANTOKPA	\N	actif	2026-08-25 22:14:35.569304+00	\N
324	J08261460	DADJO	Ramatou	+2290161240573	4	COURONNE DE DIEU	\N	actif	2026-08-25 22:14:36.351809+00	\N
326	J08262414	KPODJI	Joseph	+2290167221243	4	CEG STE RITA	\N	actif	2026-08-25 22:14:37.371621+00	\N
328	J08268729	SOKE	Yésid	+2290197389466	4	CEG DU LAC	\N	actif	2026-08-25 22:14:38.542672+00	\N
279	J08269120	TCHIAKPE	Exaucée	+2290197909012	18	CEG STE RITA	\N	actif	2026-08-25 20:23:35.93473+00	\N
330	J08261722	ZOHOU	Mickel Ange	+2290194747461	4	CEG DU LAC	\N	actif	2026-08-25 22:14:39.354596+00	\N
332	J08265015	ATINKPINDA	Tatiana	+2290169690372	4	CEG DU LAC	\N	actif	2026-08-25 22:14:40.509959+00	\N
333	J08262238	SALAOU	Hamza	+2290162080013	4	CEG DU LAC	\N	actif	2026-08-25 22:14:40.909561+00	\N
334	J08263491	TOGNI	Iniestar	+2290197722297	4	CEG DU LAC	\N	actif	2026-08-25 22:14:41.316381+00	\N
1276	J10262912	ABDOULAYE	Balkissa	+2290159230649	1	CEG DU LAC	\N	actif	2026-10-25 08:33:09.767434+00	\N
337	J08264620	ADANDE	Bénicia	+2290197130866	17	CEG DU LAC	\N	actif	2026-08-25 22:15:07.674864+00	\N
384	J08264426	YESSOUFOU	Karimath	+2290196847244	22	CEG DU LAC	\N	suspendu	2026-08-25 22:15:30.954944+00	\N
1264	Y10264163	HOGNANFODE	Majoie	+2290196449207	15	CEG YAGBE	\N	actif	2026-10-18 21:44:47.607552+00	\N
335	J08263933	ABENI	Edith	+2290197214548	17	CEG DU LAC	\N	suspendu	2026-08-25 22:15:06.275484+00	\N
1239	J10263379	MEDJOGBE	Léonie	+2290191109350	19	CEG DU LAC	M4	suspendu	2026-10-18 07:00:57.893385+00	+2290147482828
345	J08265827	AHOUANHIDE	Godwin Adonai	+2290196138109	17	CEG STE RITA	\N	actif	2026-08-25 22:15:12.218918+00	\N
347	J08267095	AKIOLA	Célestine	+2290197180553	17	CEG DU LAC	\N	actif	2026-08-25 22:15:13.100231+00	\N
339	J08267295	ADANNOU	Sheerine	+2290194665662	17	CEG STE RITA	\N	suspendu	2026-08-25 22:15:09.270972+00	\N
344	J08269195	AHOGBO	Mariette	+2290166568060	17	CEG DU LAC	\N	suspendu	2026-08-25 22:15:11.841235+00	\N
346	J08263176	AKINOCHO	Joseph	+2290166450317	17	CEG DU LAC	\N	suspendu	2026-08-25 22:15:12.643017+00	\N
348	J08269135	AMOUSSOU	Floriane	+2290197910617	17	CEG DU LAC	\N	suspendu	2026-08-25 22:15:13.503796+00	\N
361	J08261528	GAYET	Miracle	+2290196883610	17	CEG DU LAC	\N	suspendu	2026-08-25 22:15:19.795282+00	\N
385	J08268467	ZANNOU	Ghislain	+2290197833912	17	CEG DU LAC	\N	suspendu	2026-08-25 22:15:31.551663+00	\N
355	J08269209	CAKPO SOGOE	Fadel	+2290197931064	17	CEG DU LAC	\N	actif	2026-08-25 22:15:17.325973+00	\N
396	J08262113	AGOSSOU	Ange	+2290197215500	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:45.775241+00	\N
397	J08263684	AGOSSOU	Eunice	+2290197215500	17	CEG DU LAC	\N	suspendu	2026-08-25 22:22:46.193486+00	\N
358	J08265789	DIOGO	Jacques	+2290166027220	17	CEG STE RITA	\N	actif	2026-08-25 22:15:18.58232+00	\N
364	J08263005	HOUETCHOU	Précieux	+2290166765769	17	CEG DU LAC	\N	actif	2026-08-25 22:15:21.166729+00	\N
365	J08264067	HOUNGBE	Ezéchias	+2290196411710	17	CEG STE RITA	\N	actif	2026-08-25 22:15:21.560194+00	\N
369	J08268631	KAKINI	Déborah	+2290161943189	17	CEG DU LAC	\N	actif	2026-08-25 22:15:23.628899+00	\N
371	J08266455	KOUMA	Léonce	+2290196285600	17	CEG DU LAC	\N	actif	2026-08-25 22:15:24.503603+00	\N
375	J08268070	OMIALE	Faouziyath	+2290190301261	17	CEG DU LAC	\N	actif	2026-08-25 22:15:26.158239+00	\N
379	J08265055	SEWA	Epiphane	+2290197473838	17	CEG DU LAC	\N	actif	2026-08-25 22:15:28.183219+00	\N
380	J08267322	SEWADE	Crépin	+2290140641890	17	CEG DU LAC	\N	actif	2026-08-25 22:15:28.789136+00	\N
381	J08263179	SOUNOUVOU	Julienne	+2290195461198	17	CEG DU LAC	\N	actif	2026-08-25 22:15:29.58494+00	\N
389	J08261792	ADEYEMON	Inès	+2290140124702	22	CEG DU LAC	\N	actif	2026-08-25 22:22:42.699436+00	\N
391	J08269560	ADOHOUNGBO	Faribelle	+2290197080258	22	CEG DU LAC	\N	actif	2026-08-25 22:22:43.751236+00	\N
395	J08265555	AGOGNON	Dolorès	+2290162795215	22	CEG DU LAC	\N	actif	2026-08-25 22:22:45.389891+00	\N
1277	J10265787	BATCHO	Carlos	+2290197942994	20	CEG DU LAC	\N	actif	2026-10-25 08:40:53.854119+00	\N
464	J08266158	AHOGBO	Dieu donné	+2290166568060	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:47.628794+00	\N
399	J08261595	AHLONSOU	Francois	+2290149230522	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:47.014544+00	\N
407	J08263103	BANDJE	Israel	+2290197020336	22	CEG DU LAC	\N	actif	2026-08-25 22:22:50.668507+00	\N
1265	J10262258	HOUSSA	Samuel	+2290197188094	12	CEG DU LAC	\N	actif	2026-10-19 14:52:52.395471+00	\N
410	J08262150	DAGA	Carmelle	+2290157527662	22	CEG STE RITA	\N	actif	2026-08-25 22:22:52.231827+00	\N
1240	J10268623	MEDJOGBE	Anita	+2290191109350	19	CEG DU LAC	M10	suspendu	2026-10-18 07:02:14.080446+00	+2290147482828
401	J08265072	AKANDJONAN	Belmond	+2290190312616	22	CEG DANTOKPA	\N	suspendu	2026-08-25 22:22:47.80973+00	\N
402	J08266577	AKOUETE	Eugénio	+2290147657093	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:48.625943+00	\N
403	J08267662	AMOUSSOU	Fanette	+2290147001102	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:49.05639+00	\N
415	J08266783	DOUROSSIMI	Rodiath	+2290144070871	22	CEG DU LAC	\N	actif	2026-08-25 22:22:54.245664+00	\N
404	J08266028	AMOUSSOU	Nicolette	+2290144025280	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:49.482707+00	\N
418	J08266487	GBAMMADO MARIE GRÂCE	Marie Grâce	+2290197226046	22	CEG DU LAC	\N	actif	2026-08-25 22:22:55.483515+00	\N
419	J08266029	GNANSOUNOU IRÈNE	Irène	+2290196564684	22	CEG DANTOKPA	\N	actif	2026-08-25 22:22:56.12035+00	\N
409	J08264946	CHANGOTADE	Landry	+2290148454819	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:51.67579+00	\N
421	J08264165	HINVI DAMILOLA	Damilola	+2290197063773	22	CEG DU LAC	\N	actif	2026-08-25 22:22:56.944847+00	\N
423	J08265706	HOUADJETO	Emilio	+2290148152298	22	CEG DU LAC	\N	actif	2026-08-25 22:22:57.773133+00	\N
422	J08266089	HONFO AICHATH	Aichath	+2290197731084	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:57.338877+00	\N
425	J08268377	HOUENOU	Jean Véronique	+2290166856732	22	CEG DU LAC	\N	suspendu	2026-08-25 22:22:58.606343+00	\N
443	J08263375	TOSSOU	Conforte	+2290161243265	22	CEG DU LAC	\N	suspendu	2026-08-25 22:23:06.609899+00	\N
447	J08264316	ADELEYE	Fulbert	+2290155845758	24	CEG DU LAC	\N	suspendu	2026-08-25 22:30:18.537005+00	\N
450	J08266270	DOVI	Edwige	+2290197445773	24	CEG DU LAC	\N	suspendu	2026-08-25 22:30:20.055139+00	\N
452	J08264476	FASSINOU	Odette	+2290197552156	24	CEG DU LAC	\N	suspendu	2026-08-25 22:30:21.358943+00	\N
454	J08266085	KANA	Emmanuella	+2290195154337	24	CEG DU LAC	\N	suspendu	2026-08-25 22:30:22.501925+00	\N
432	J08265265	KOUAKANOU	Jeannette	+2290197313260	22	CEG DU LAC	\N	actif	2026-08-25 22:23:01.636137+00	\N
462	J08262094	ADJASSOHO	Conceptine	+2290199000351	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:46.801766+00	\N
434	J08265130	KOUYONOU	Damienne	+2290150390481	22	CEG DU LAC	\N	actif	2026-08-25 22:23:02.44536+00	\N
463	J08268263	AGOSSOU	Immaculée	+2290169038875	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:47.208753+00	\N
451	J08268703	DOVONON	Samuel	+2290156453316	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:20.869457+00	\N
449	J08262509	AKLO	Ezéchiel	+2290197955076	24	CEG DU LAC	\N	actif	2026-08-25 22:30:19.65303+00	\N
416	J08263905	EZOUNKATON	Merveille	+2290148969037	17	CEG DU LAC	\N	suspendu	2026-08-25 22:22:54.641527+00	\N
456	J08262538	NICOUE	Faith	+2290190467081	24	CEG DU LAC	\N	actif	2026-08-25 22:30:23.416348+00	\N
457	J08265627	NICOUE	Love	+2290190467081	24	CEG DU LAC	\N	actif	2026-08-25 22:30:23.816738+00	\N
458	J08262386	SALAOU	Ismael	+2290196085957	24	CEG DU LAC	\N	actif	2026-08-25 22:30:24.237185+00	\N
459	J08262634	ADEKPODJOU	Fatima	+2290195198341	8	CEG DU LAC	\N	actif	2026-08-25 22:30:45.23724+00	\N
468	J08263858	ASSANI	Moussa	+2290190620865	8	CEG DU LAC	\N	actif	2026-08-25 22:30:49.319854+00	\N
1266	Y10265856	LAURIANO	Yazid	+2290151896465	14	CEG YAGBE	\N	actif	2026-10-19 15:28:45.576972+00	\N
1278	J10262835	GREGNON	Damien	+2290148106125	2	CEG DU LAC	\N	actif	2026-10-25 08:58:40.122767+00	\N
474	J08269687	GNONLONFOUN	Rose Kèmi	+2290166696627	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:52.367575+00	\N
478	J08265611	KINTCHIMON	Charbelle	+2290197984354	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:54.006119+00	\N
485	J08263278	RADJI	Nadiath	+2290196789444	8	CEG DANTOKPA	\N	actif	2026-08-25 22:30:57.087489+00	\N
487	J08264683	TOGNIFODE	Alain	+2290147278514	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.091731+00	\N
489	J08264427	ZANNOU	Félix	+2290197337122	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.920784+00	\N
470	J08265218	BOUKARI	Mira	+2290196915692	23	CEG STE RITA	\N	actif	2026-08-25 22:30:50.110871+00	\N
1241	J10268789	HOUNGBEME	Jean-Claude	+2290165110880	19	CEG DU LAC	M6	suspendu	2026-10-18 07:04:07.944937+00	+2290144366131
467	J08268338	AMOUZOUN	David	+2290141819742	8	CEG DU LAC	\N	actif	2026-08-25 22:30:48.884874+00	\N
469	J08266759	AZANKPO	Prisca	+2290197942377	8	CEG DU LAC	\N	actif	2026-08-25 22:30:49.715617+00	\N
471	J08262314	DAGA	Clémence	+2290157527662	8	CEG DU LAC	\N	actif	2026-08-25 22:30:50.549347+00	\N
1242	J10266937	AIVODJI	Bernice	+2290154178550	1	CEG DU LAC	\N	actif	2026-10-18 07:20:10.85204+00	\N
1267	Y10267838	ADANHONDJI	Marc	+2290154608022	16	CEG YAGBE	\N	actif	2026-10-19 15:32:42.755161+00	\N
480	J08268591	KOUDEGNAN	Rodolpho	+2290161419976	8	CEG DU LAC	\N	actif	2026-08-25 22:30:54.948426+00	\N
1279	J10263272	SOWANOU	Amadine Bénie	+2290197844461	2	CEG DU LAC	\N	actif	2026-10-25 09:08:21.255164+00	\N
488	J08267145	ZANNOU	Jacqueline	+2290197337122	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.505002+00	\N
490	J08261386	AHOWEKOUN	Noel	+2290192715933	11	CEG DU LAC	\N	actif	2026-08-25 22:37:59.330365+00	\N
491	J08262060	DOSSA	Immaculée	+2290197288140	11	CEG DU LAC	\N	actif	2026-08-25 22:37:59.736211+00	\N
492	J08265127	DOSSOU	Fourier	+2290197176633	11	CEG DU LAC	\N	actif	2026-08-25 22:38:00.346514+00	\N
475	J08263238	HOLOEYI	Félicien	+2290153815647	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:52.795631+00	\N
494	J08261345	LOHOUNME	Emmanuella	+2290166418569	11	CEG DU LAC	\N	actif	2026-08-25 22:38:01.124003+00	\N
482	J08264009	OGOULOLA	Léa	+2290191404508	8	CEG DU LAC	\N	suspendu	2026-08-25 22:30:55.778228+00	\N
486	J08269335	SEDJAME	Néhémie	+2290195030593	8	CEG STE RITA	\N	suspendu	2026-08-25 22:30:57.484661+00	\N
497	J08269513	ZONON	Roberta	+2290151797551	11	CEG DU LAC	\N	actif	2026-08-25 22:38:02.617364+00	\N
500	J08265110	AGOSSOU	Nicodème	+2290167476339	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:23.378496+00	\N
499	J08269228	AGBOSSODJAN	Esther	+2290144973242	12	CEG DU LAC	\N	actif	2026-08-25 22:38:22.992179+00	\N
501	J08261475	AHOWEKOUN	Alice	+2290161312823	12	CEG DU LAC	\N	actif	2026-08-25 22:38:23.767259+00	\N
502	J08263495	AKOUEGNINOU	Ernest	+2290197384806	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.150997+00	\N
504	J08265797	AZOUASSI	Rose	+2290194666556	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.930368+00	\N
503	J08262331	AVANDE	Mauriace	+2290152240745	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:24.544978+00	\N
507	J08265608	ATEKPO	Néoland	+2290152706991	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:26.854616+00	\N
509	J08263602	DENAKPO	Charles	+2290196970092	12	CEG DU LAC	\N	actif	2026-08-25 22:38:27.660258+00	\N
508	J08268464	D'ALMEIDA	Merveille Ifè	+2290196577824	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:27.25613+00	\N
514	J08268157	HOUNTO ADA	Francis	+2290195666328	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:29.643545+00	\N
518	J08266137	MARCOS	Mariano	+2290197839801	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:31.185714+00	\N
526	J08263060	ZANNOU	Foeube	+2290166526102	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:34.40601+00	\N
515	J08266463	HOUNTONDJI	Espérancia	+2290197511214	12	CEG DU LAC	\N	actif	2026-08-25 22:38:30.024495+00	\N
528	J08263934	ZANNOU	Julien	+2290197833912	12	CEG DU LAC	\N	suspendu	2026-08-25 22:38:35.200743+00	\N
519	J08269471	OKE	Raoul	+2290197442195	12	CEG DU LAC	\N	actif	2026-08-25 22:38:31.568051+00	\N
521	J08262030	OMIALE	Ziyadath	+2290190301261	12	CEG DU LAC	\N	actif	2026-08-25 22:38:32.405764+00	\N
523	J08262095	ROUFAI	Fahimath	+2290197264392	12	CEG DU LAC	\N	actif	2026-08-25 22:38:33.197533+00	\N
529	Y08268030	ADANHONDJI	Osias	+2290140783317	13	CEG YAGBE	\N	actif	2026-08-26 05:06:26.656279+00	\N
530	Y08267130	AGOSSA	Osée	+2290197127693	13	CEG YAGBE	\N	actif	2026-08-26 05:06:27.46423+00	\N
534	Y08264031	BANKOLE	Alida	+2290197428276	13	CEG YAGBE	\N	actif	2026-08-26 05:06:30.070493+00	\N
539	Y08267893	HOUANGNI	Elohim Merveille	+2290196006677	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.014741+00	\N
540	Y08267733	HOUESSOU	Isabelle	+2290196580930	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.426934+00	\N
545	Y08267634	KITOYI	Bilal	+2290152605104	13	CEG YAGBE	\N	actif	2026-08-26 05:06:35.538708+00	\N
548	Y08263608	MAIGA	Halimata	+2290162396051	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.072067+00	\N
549	Y08262435	MAIGA	Zoulaiha	+2290162396061	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.587933+00	\N
553	Y08263248	TINVOEYI	Merveille De Dieu	+2290152091308	13	CEG YAGBE	\N	actif	2026-08-26 05:06:39.346589+00	\N
1243	J10268172	GBAGUIDI	Mariella	+2290154239050	1	CEG DU LAC	\N	actif	2026-10-18 07:25:29.788542+00	\N
1268	Y10268355	AKALA	Dariath	+2290167007819	16	CEG YAGBE	\N	actif	2026-10-19 15:37:47.191281+00	\N
1280	J10266481	HOUSSOU	Asser	+2290197183449	2	CEG DANTOKPA	\N	actif	2026-10-25 09:12:18.7327+00	\N
550	Y08261421	MASSE	Thomadêsse	+2290165440636	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.983233+00	\N
552	Y08264124	OUABI	Romdonne	+2290197771856	13	CEG YAGBE	\N	actif	2026-08-26 05:06:38.753534+00	\N
557	Y08266946	ADJAGNISSOUDE	Ruth	+2290197189342	14	CEG YAGBE	\N	actif	2026-08-26 05:08:48.817662+00	\N
558	Y08267185	AGBEDJA	Miracle	+2290191383610	14	CEG YAGBE	\N	actif	2026-08-26 05:08:49.3923+00	\N
559	Y08266216	ATEMENOU	Hilary	+2290169261498	14	CEG YAGBE	\N	actif	2026-08-26 05:08:49.843058+00	\N
560	Y08264433	BADAROU	Mohamed	+2290197694392	14	CEG YAGBE	\N	actif	2026-08-26 05:08:50.217537+00	\N
563	Y08267529	DARAMANI	Amir	+2290141266053	14	CEG YAGBE	\N	actif	2026-08-26 05:08:51.426197+00	\N
564	Y08267630	DOSSOU	Marie Irène	+2290197720161	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.045119+00	\N
565	Y08263713	ESSOUM	Esther Ruth	+2290197885232	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.443953+00	\N
567	Y08266460	HOUNDENOU	Jeannette	+2290197334020	14	CEG YAGBE	\N	actif	2026-08-26 05:08:53.402274+00	\N
570	Y08266338	KAKA	Jilichricia	+2290166152655	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.611625+00	\N
571	Y08268089	KEKE	Florent	+2290197679887	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.980536+00	\N
572	Y08265874	KOTIN	Didier	+2290166020333	14	CEG YAGBE	\N	actif	2026-08-26 05:08:55.400035+00	\N
573	Y08268197	KPANGON	Célione	+2290166692043	14	CEG YAGBE	\N	actif	2026-08-26 05:08:55.773243+00	\N
575	Y08262460	MASSE	Wilfried	+2290165440636	14	CEG YAGBE	\N	actif	2026-08-26 05:08:56.914813+00	\N
580	Y08262710	TOGBE	Mohamed	+2290196359815	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.05091+00	\N
581	Y08265533	TOGBE	Obérique	+2290167665433	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.46022+00	\N
582	Y08268680	YAYA OYE	Soubedatou	+2290169003643	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.849627+00	\N
585	Y08264813	ADANHONDJI	Daniella	+2290197935230	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.226044+00	\N
587	Y08268530	AGOSSA	Edna Inès	+2290197599452	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.986855+00	\N
588	Y08261806	AGOSSA	Obed	+2290197127693	15	CEG YAGBE	\N	actif	2026-08-26 05:09:22.390946+00	\N
590	Y08262204	AKAKPO	Isabelle	+2290196445487	15	CEG YAGBE	\N	actif	2026-08-26 05:09:23.153873+00	\N
594	Y08263842	BADAROU	Yékini	+2290197247234	15	CEG YAGBE	\N	actif	2026-08-26 05:09:24.727583+00	\N
595	Y08268402	BAKPE	Jacques	+2290190525828	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.107306+00	\N
596	Y08267020	BAMIGBADE	Otniel	+2290197641417	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.485235+00	\N
597	Y08267520	BANKOLE	David	+2290197428276	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.856608+00	\N
599	Y08269579	DANSOU	Laurence	+2290166831544	15	CEG YAGBE	\N	actif	2026-08-26 05:09:26.646412+00	\N
600	Y08267701	DOSSOU	Bénédicte	+2290196580930	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.037992+00	\N
601	Y08266899	DOSSOU	Immaculée	+2290196953652	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.418849+00	\N
602	Y08267161	GANDONOU	Loïs	+2290165406987	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.809298+00	\N
604	Y08267580	HODOMIHOU	Cécile	+2290166657478	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.582105+00	\N
605	Y08268521	HODOMIHOU	Jeanne	+2290166657478	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.954878+00	\N
606	Y08262979	HOLLARD	Emmanuel	+2290195407566	15	CEG YAGBE	\N	actif	2026-08-26 05:09:29.343262+00	\N
607	Y08266426	HOSSOU	Marcelle	+2290196810679	15	CEG YAGBE	\N	actif	2026-08-26 05:09:29.729414+00	\N
608	Y08262889	HOSSOU	Paterne	+2290196810679	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.10539+00	\N
609	Y08266545	HOUESSOU	Belforeste	+2290196371580	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.499214+00	\N
610	Y08269826	HOUETCHOEZON	Didier	+2290191040567	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.883123+00	\N
611	Y08265099	HOUNDENOU	Emilienne	+2290197334020	15	CEG YAGBE	\N	actif	2026-08-26 05:09:31.269025+00	\N
614	Y08269245	HOUNKPATIN	Constance	+2290197573580	15	CEG YAGBE	\N	actif	2026-08-26 05:09:32.438881+00	\N
615	Y08266634	HOUNKPATIN	Ornella	+2290197762900	15	CEG YAGBE	\N	actif	2026-08-26 05:09:33.025573+00	\N
618	Y08266275	LOGBO	Siméon	+2290167763931	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.208577+00	\N
568	Y08265256	HOUNGBO	Mardoché	+2290197066005	14	CEG YAGBE	\N	suspendu	2026-08-26 05:08:53.78932+00	\N
621	Y08262090	MISSIKPODE	Malaleel	+2290197345620	15	CEG YAGBE	\N	actif	2026-08-26 05:09:35.333118+00	\N
623	Y08268733	OLOUKPEDE	Floriane	+2290163103710	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.146702+00	\N
624	Y08262868	SAGBOHAN	Divine	+2290166285000	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.552985+00	\N
574	Y08266990	MASSE	Victoire	+2290165440636	13	CEG YAGBE	\N	actif	2026-08-26 05:08:56.155059+00	\N
598	Y08263174	BANKOLE	Noel	+2290197428276	14	CEG YAGBE	\N	actif	2026-08-26 05:09:26.254907+00	\N
583	Y08264402	ADAMON	Assande	+2290196431908	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:20.465725+00	\N
589	Y08268677	AHLONSOU	Synthiche	+2290196296213	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:22.771404+00	\N
591	Y08267993	AKOGOUN	Zékiath	+2290193902690	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:23.552739+00	\N
603	Y08264249	GNAMBODE	Bénédicte	+2290155438512	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:28.195939+00	\N
612	Y08269420	HOUNDETON	Silvia	+2290144763739	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:31.656278+00	\N
616	Y08264713	KOUKOUI	Mariette	+2290197294746	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:33.422391+00	\N
619	Y08268871	LOKO	Carolle	+2290196005511	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:34.583446+00	\N
622	Y08262014	OGOUTCHI	Oré Oluwa Merveille	+2290166376314	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:35.75142+00	\N
625	Y08262554	SALAKO	Mariano	+2290161824028	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.936539+00	\N
631	Y08269477	YESSOUFOU	Sodirath	+2290197482674	15	CEG YAGBE	\N	actif	2026-08-26 05:09:39.261892+00	\N
633	Y08262231	ZANNOU	Kauis	+2290197480937	15	CEG YAGBE	\N	actif	2026-08-26 05:09:40.019524+00	\N
1281	J10266122	KINHONON	Valentine	+2290166181547	24	CEG DANTOKPA	\N	actif	2026-10-25 09:19:06.907513+00	\N
627	Y08262955	SOSSOU	Ruth	+2290196534513	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:37.712014+00	\N
1244	J10261984	AVODAGBE	Emmanuella	+2290140725143	1	CEG DU LAC	M7	suspendu	2026-10-18 07:27:07.959069+00	+2290197196457
626	Y08264700	SOMASSE	Sonia	+2290197540636	15	CEG YAGBE	\N	actif	2026-08-26 05:09:37.327035+00	\N
628	Y08262947	SOUMANOU	Yousra	+2290197062518	15	CEG YAGBE	\N	actif	2026-08-26 05:09:38.10923+00	\N
689	J08265649	CODJIA	Joinès	+2290197148281	19	CEG DU LAC	M4	actif	2026-08-31 14:20:56.80596+00	\N
634	Y08265856	ABOKI	Daniel	+2290197073508	16	CEG YAGBE	\N	actif	2026-08-26 05:10:19.759651+00	\N
637	Y08264406	ADJAGNISSOUDE	Parfait	+2290167248075	16	CEG YAGBE	\N	actif	2026-08-26 05:10:20.919054+00	\N
640	Y08265492	ASSOCLE	Doris	+2290166829586	16	CEG YAGBE	\N	actif	2026-08-26 05:10:22.083622+00	\N
641	Y08268688	ATCHADE	Grâce	+2290196154376	16	CEG YAGBE	\N	actif	2026-08-26 05:10:22.663731+00	\N
642	Y08267443	AWOUSSA	Dénise	+2290197818921	16	CEG YAGBE	\N	actif	2026-08-26 05:10:23.044425+00	\N
643	Y08264430	AZANGBE	Céline	+2290197738516	16	CEG YAGBE	\N	actif	2026-08-26 05:10:23.461833+00	\N
644	Y08263904	DANTODJI	Amos	+2290197681137	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.057591+00	\N
645	Y08263449	DANTON	Emmanuella	+2290140739385	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.450314+00	\N
648	Y08261899	ESSOUM	Ozias	+2290197885232	16	CEG YAGBE	\N	actif	2026-08-26 05:10:25.634746+00	\N
649	Y08265374	GOGAN	Gloria	+2290197033746	16	CEG YAGBE	\N	actif	2026-08-26 05:10:26.221361+00	\N
650	Y08267681	GOGAN	Paul	+2290197033746	16	CEG YAGBE	\N	actif	2026-08-26 05:10:26.617392+00	\N
654	Y08263427	KABORE	Mohamed	+2290196530180	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.149791+00	\N
655	Y08266853	KOUTON	Franck	+2290197138284	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.532337+00	\N
656	Y08269124	KOUTON	Francky	+2290197138284	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.980225+00	\N
658	Y08264191	MASSE	Thomas	+2290165440636	16	CEG YAGBE	\N	actif	2026-08-26 05:10:29.760361+00	\N
660	Y08265561	NOUMON	Lauriane	+2290197120315	16	CEG YAGBE	\N	actif	2026-08-26 05:10:30.573136+00	\N
663	Y08266220	SOSSOU	Ornella	+2290153503224	16	CEG YAGBE	\N	actif	2026-08-26 05:10:31.756167+00	\N
664	Y08266563	TAIWO	Tayé	+2290196794716	16	CEG YAGBE	\N	actif	2026-08-26 05:10:32.128494+00	\N
1245	J10261596	TCHINAN	Lionel	+2290197017581	1	CEG DU LAC	M4	actif	2026-10-18 07:28:22.261717+00	+2290197692968
1282	J10262212	HOUNVO	Styve Junior	+2290197876278	6	CEG DU LAC	\N	actif	2026-10-25 09:48:13.933648+00	\N
630	Y08263533	TOLOFON	Eben Ezer	+2290190030696	15	CEG YAGBE	\N	suspendu	2026-08-26 05:09:38.889136+00	\N
636	Y08261739	ADJAGNISSOUDE	Jérémie	+2290196667584	16	CEG YAGBE	\N	suspendu	2026-08-26 05:10:20.531336+00	\N
639	Y08261253	AKON	Junior	+2290196475434	16	CEG YAGBE	\N	suspendu	2026-08-26 05:10:21.697789+00	\N
651	Y08264481	HESSANON	Marie Noel	+2290196003555	16	CEG YAGBE	\N	suspendu	2026-08-26 05:10:27.003884+00	\N
653	Y08265469	HOUNMENOU	Odile	+2290197647346	16	CEG YAGBE	\N	suspendu	2026-08-26 05:10:27.773135+00	\N
662	Y08263046	SETON	Innocent	+2290196569446	16	CEG YAGBE	\N	suspendu	2026-08-26 05:10:31.353165+00	\N
682	J08268280	VITCHOEDO	Clémence	+2290197073687	20	CEG DU LAC	\N	suspendu	2026-08-31 13:58:41.399693+00	\N
687	J08268256	OLAITAN	Chefiou	+2290196094508	19	FRANCO ARABE	\N	suspendu	2026-08-31 14:18:03.940363+00	\N
688	J08265135	HOUNTONDJI	Gaspard	+2290196041927	2	CEG DU LAC	\N	suspendu	2026-08-31 14:19:45.732143+00	\N
1283	J10262584	GOHOUNGO	Delicia	+2290196413833	18	CS KENNEDY	\N	actif	2026-10-25 09:55:02.684792+00	\N
701	J08269518	HOUNGBEMEY	Emmanuella	+2290197987888	18	CEG DU LAC	\N	actif	2026-08-31 14:51:34.909784+00	\N
1246	J10268410	METOZOUNVE	Bernadin	\N	1	CEG DANTOKPA	M3	suspendu	2026-10-18 07:29:43.328802+00	+2290146908526
708	J08265739	ADJASSOHO	Bernard	+2290194268533	17	CEG DU LAC	\N	suspendu	2026-08-31 15:27:49.347844+00	\N
717	J08267578	OLAITAN	Kêphil	+2290196828789	17	CEG DU LAC	\N	suspendu	2026-08-31 15:37:15.192742+00	\N
732	J08265891	AFFO	Roukayath	+2290197498175	8	CEG DU LAC	\N	suspendu	2026-08-31 16:28:30.48894+00	\N
734	J08267751	AKPOTINKPE	Jacqueline	+2290142551336	8	CEG DU LAC	\N	suspendu	2026-08-31 16:30:48.156048+00	\N
728	J08268681	OLAITAN	Rafiath	+2290192174585	3	FRANCO ARABE	\N	suspendu	2026-08-31 16:16:55.202282+00	\N
739	J08264199	MAIGA	Fadie	+2290198076741	24	CEG DU LAC	\N	suspendu	2026-08-31 16:40:22.399744+00	\N
710	J08267282	AHIDE	Dimitri Enguerran	+2290151901775	17	CEG DU LAC	\N	actif	2026-08-31 15:29:51.245757+00	\N
729	J08268324	ONELECHI	Chiamaka	+2290196982815	22	CEG DU LAC	\N	actif	2026-08-31 16:17:36.947357+00	\N
733	J08269857	AFOUFOU	Raymond	+2290197181891	8	COLLÈGE LA RÉFÉRENCE	\N	actif	2026-08-31 16:29:57.843769+00	\N
737	J08263156	BALA	Aboubacar	+2290140357078	8	CEG DU LAC	\N	actif	2026-08-31 16:38:12.069562+00	\N
742	J08268663	MIGNANWANDE	Gloria	+2290197036135	8	CEG DU LAC	\N	actif	2026-08-31 16:43:39.129423+00	\N
746	J08263975	ADOHOUNGBO	Lynce	+2290197080258	12	CEG DU LAC	\N	actif	2026-08-31 16:56:28.481538+00	\N
750	J08268630	GUELIFO	Isidore	+2290197866174	12	CEG DU LAC	\N	actif	2026-08-31 17:00:05.272406+00	\N
753	J08262890	LOKONON	Danick	+2290197762788	12	CEG DU LAC	\N	actif	2026-08-31 17:04:38.129159+00	\N
1284	J10268074	AHOUANDJINOU	Ulrich	+2290151340182	18	CEG DANTOKPA	\N	actif	2026-10-25 09:56:57.744317+00	\N
1247	J10267394	FAGBITE	Pascal	+2290195798056	20	CEG DU LAC	\N	suspendu	2026-10-18 08:37:35.786979+00	\N
784	J09265900	ADAHE	Gisèle	+2290195588948	20	CEG DU LAC	\N	suspendu	2026-09-02 19:08:40.626923+00	\N
1285	J10263226	KITI	Elodie	+2290196470058	18	CEG STE RITA	\N	actif	2026-10-25 09:58:24.212983+00	\N
1248	J10262301	KANVI	Edwige	\N	20	CEG DU LAC	\N	suspendu	2026-10-18 08:40:42.991141+00	+2290162664461
1286	J10263845	AMANDA	Espoir	+2290140143526	23	CEG DU LAC	\N	actif	2026-10-25 10:06:26.524419+00	\N
1249	J10262773	TCHINAN	Cédric	+2290166821400	20	CEG STE RITA	\N	actif	2026-10-18 08:42:05.657352+00	\N
815	J09268212	DEDJI	Maximilienne	+2290162129301	20	CEG DU LAC	\N	actif	2026-09-02 19:08:55.63603+00	\N
1287	J10264662	HOUSSOU	Grâce	+2290195743225	3	CEG DU LAC	\N	actif	2026-10-25 10:22:21.438496+00	\N
872	J09262610	FALOLA	Roselin	+2290197146599	2	CEG DU LAC	M7	actif	2026-09-14 11:49:12.747193+00	\N
880	J09263199	ALLAGBE	Josué Boris	+2290197601477	5	CEG STE RITA	\N	suspendu	2026-09-17 22:19:05.676706+00	\N
1250	J10261475	FOHOU	Confirmé	+2290167066737	6	CEG DU LAC	\N	actif	2026-10-18 09:17:13.553906+00	+2290190624187
852	J09265772	DJOSSOU	Assanath	+2290151123040	8	CEG DU LAC	\N	suspendu	2026-09-14 10:44:42.72106+00	\N
883	J09268409	LOKONON	Anaëlle	+2290197762788	17	CEG DU LAC	\N	suspendu	2026-09-19 01:01:25.112038+00	\N
762	J09267751	ESSOU	Valentine	+2290197276399	1	CEG DU LAC	\N	suspendu	2026-09-02 19:08:30.39158+00	\N
828	J09262629	HOUNGA	Abigaelle	+2290197734530	20	CEG DU LAC	\N	suspendu	2026-09-02 19:09:01.095153+00	\N
837	J09263882	TITO	Daniel	+2290196874193	20	CEG DU LAC	\N	actif	2026-09-12 19:19:16.043039+00	\N
838	Y09263372	SOUNOUVOU	Michel	+2290151255990	13	CEG YAGBE	\N	actif	2026-09-12 19:27:08.35551+00	\N
840	J09261410	QUENUM	David	+2290197397395	20	CEG DU LAC	\N	actif	2026-09-12 19:38:09.527734+00	\N
841	J09267209	AGOUNDO	Princesse	+2290162591227	20	CEG DU LAC	\N	actif	2026-09-12 19:41:58.566468+00	\N
842	Y09267327	DENAKPO	Prince André	+2290197118590	13	CEG YAGBE	\N	actif	2026-09-12 19:54:42.812334+00	\N
820	J09264613	LOKOSSOU	Exaucée	+2290196007792	20	CEG DU LAC	\N	actif	2026-09-02 19:08:57.739639+00	\N
843	Y09264628	AGOSSOU	Mariela	+2290165440636	13	CEG YAGBE	\N	actif	2026-09-12 20:05:27.793934+00	\N
844	J09261290	DAGBA	Othniella	+2290195810335	20	CEG DU LAC	\N	actif	2026-09-12 20:13:58.19492+00	\N
845	J09262759	ASSOGBA	Gaël	+2290197456393	8	CEG STE RITA	\N	actif	2026-09-12 20:32:23.352374+00	\N
846	J09264839	QUENUM	Précieux	+2290197397395	3	CEG STE RITA	\N	actif	2026-09-12 20:39:17.483913+00	\N
847	J09267055	AGOUNDO	Exaucé	+2290162591227	17	CEG DU LAC	\N	actif	2026-09-12 21:05:33.232988+00	\N
848	J09263304	CHOGOLOU	Junior	+2290195319539	23	CEG DANTOKPA	\N	actif	2026-09-12 21:15:05.284985+00	\N
849	J09264707	LANLENOU	Justin	+2290197172092	3	CEG DU LAC	\N	actif	2026-09-12 21:21:43.226122+00	\N
850	Y09263780	MEDEKO	Samétane	+2290197867177	14	CEG YAGBE	\N	actif	2026-09-12 21:24:38.149321+00	\N
851	J09261864	DAGBA	Hermance	+2290195810335	23	CEG STE RITA	\N	actif	2026-09-12 21:26:17.312251+00	\N
853	J09267715	NIANDOU	Mohamed	+2290191392646	8	CEG DU LAC	\N	actif	2026-09-14 10:51:41.683738+00	\N
855	J09264479	AZONSI	Miracle	+2290197191212	23	CEG DANTOKPA	\N	actif	2026-09-14 11:07:08.375256+00	\N
858	Y09261367	ASSOCLE	Esther	+2290196356528	13	CEG YAGBE	\N	actif	2026-09-14 11:32:40.95348+00	\N
862	Y09264799	LOKO	Cyr	+2290152147964	15	CEG YAGBE	\N	actif	2026-09-14 11:36:45.332492+00	\N
864	Y09269856	AMOUSSOU	Junior	+2290147853120	16	CEG YAGBE	\N	actif	2026-09-14 11:38:43.400765+00	\N
866	Y09265856	DOSSOU	Bernadin	+2290152177036	16	CEG YAGBE	\N	actif	2026-09-14 11:41:02.522304+00	\N
871	J09264448	FALOLA	Rodrigue	\N	23	CEG DU LAC	\N	actif	2026-09-14 11:48:23.3918+00	+2290197146599
873	J09267412	TOKPANOU	Bérenger	+2290195866169	1	CEG STE RITA	\N	actif	2026-09-14 12:03:27.604821+00	\N
874	J09268021	YESSOUFOU	Fathihiyath	+2290196095575	18	CEG DANTOKPA	\N	actif	2026-09-14 12:08:15.642552+00	\N
875	J09261819	AVOCE	Estella	+2290196386603	8	CEG DU LAC	\N	actif	2026-09-16 21:49:02.826014+00	\N
876	J09264484	GANHOUNOUTO	Miracle	+2290195533360	20	CEG STE RITA	\N	actif	2026-09-16 22:04:09.429384+00	\N
877	J09268939	GANHOUNOUTO	Emma	+2290195533360	5	CEG STE RITA	\N	actif	2026-09-16 22:05:01.072277+00	\N
878	J09265398	BALA	Faouziyath	+2290140357078	6	CEG DU LAC	\N	actif	2026-09-16 22:12:35.466017+00	\N
879	J09265604	ANATO	Gracia	+2290197267378	17	CEG STE RITA	\N	actif	2026-09-17 14:47:11.013051+00	\N
881	J09267623	YESSOUFOU	Farhane	+2290196095575	8	CEG DANTOKPA	\N	actif	2026-09-19 00:33:50.091546+00	\N
884	J09264856	ABLADON	Sylvano	+2290197657850	17	CEG DU LAC	\N	actif	2026-09-19 01:07:15.285341+00	\N
885	J09265762	ABLADON	Abelline	+2290197657850	2	CEG DU LAC	\N	actif	2026-09-19 01:14:39.214789+00	\N
886	J09265908	SEWA	Marie Lyne	+2290197473838	1	CEG DU LAC	\N	actif	2026-09-20 07:49:36.492955+00	\N
887	J09268034	AVLOKO	Farahane Mohamed	+2290166920827	1	CEG GBEGAMEY	\N	actif	2026-09-20 09:03:11.669221+00	\N
888	J09262081	BOCCO	Angélique	\N	1	CEG DU LAC	\N	actif	2026-09-20 10:27:53.030517+00	+2290197796471
870	J09261873	FALOLA	Gloria	+2290197146599	5	CEG DU LAC	\N	actif	2026-09-14 11:47:26.125112+00	\N
859	Y09263520	AWOUNOU	Emmanuella	+2290197415823	15	CEG YAGBE	\N	actif	2026-09-14 11:34:57.362975+00	\N
882	J09265700	GBEDO	Alex Sého	+2290197120811	20	CEG STE RITA	\N	actif	2026-09-19 00:43:50.033618+00	\N
839	J09263404	AGBOESSI	Marie Lumière	+2290196913075	20	COLLEGE STE CÉCILE	\N	actif	2026-09-12 19:33:06.185915+00	\N
889	J09266361	ZOTOGBE	Presley	+2290197681951	20	CEG DU LAC	\N	actif	2026-09-20 11:18:45.278531+00	\N
895	J09264171	GANDONOU	Jaï-Christ	+2290197745255	2	CEG DU LAC	\N	actif	2026-09-20 11:58:12.943978+00	+2290147353783
902	J09263051	HOUNSOU	Sélim Hamdrim	+2290197596533	3	CEG STE RITA	\N	actif	2026-09-20 12:22:35.561284+00	+2290143242625
903	J09264447	AVLOKO	Fadilath	+2290166920827	3	CEG GBEGAMEY	\N	actif	2026-09-20 12:24:14.584627+00	\N
904	J09266209	KPETOTON	Dorcas	+2290196310287	3	CEG DU LAC	\N	actif	2026-09-20 12:26:00.472763+00	\N
907	J09269168	DEDJAN	Ronel	+2290197271667	3	CEG DANTOKPA	\N	actif	2026-09-20 12:33:35.748944+00	\N
1288	J10264000	BATCHO	Cassandre	+2290197942994	18	CEG DU LAC	\N	actif	2026-10-25 10:32:51.085231+00	\N
1251	J10269871	EDJROSSE	Merveil	+2290196335383	6	CEG DU LAC	\N	actif	2026-10-18 09:18:16.787549+00	+2290198821835
913	J09262617	AHOWEKOUN	Gloria Lydie	+2290196621644	23	CEG DU LAC	\N	actif	2026-09-20 13:00:05.598163+00	+2290147982057
914	J09261251	AKAKPOVI	Daria	+2290195341070	23	CEG DU LAC	\N	actif	2026-09-20 13:11:08.690634+00	+2290196119393
915	J09262765	GANDONOU	Jirince	+2290197745255	23	CEG DU LAC	\N	actif	2026-09-20 13:12:28.599+00	+2290147353783
916	J09262521	KPEHOUNTON	Augustin	+2290167555423	23	CEG LE NOKOUE	\N	actif	2026-09-20 13:14:06.905264+00	\N
917	J09264268	ZOTOGBE	Philomey	+2290197681951	8	CEG DU LAC	\N	actif	2026-09-20 13:15:38.036665+00	\N
919	J09267586	HOUNGNISSI	Victoire	\N	8	CEG DU LAC	\N	actif	2026-09-20 13:18:44.239329+00	+2290197283985
906	J09261874	SODOHOUNSI	Roberte	+2290196881398	3	CEG DANTOKPA	\N	actif	2026-09-20 12:32:03.444313+00	\N
923	J09267416	DEDEWANOU	Chancelle	+2290166035959	23	CEG DANTOKPA	\N	actif	2026-09-20 13:34:22.670149+00	\N
926	J09263314	HOUNSOUKPE	Adrien	+2290194940807	6	CEG DU LAC	\N	actif	2026-09-20 13:39:11.255048+00	\N
927	J09263981	HINVI	Rayane	+2290197037460	23	CEG DU LAC	\N	actif	2026-09-20 13:40:08.745562+00	\N
929	J09262762	GBESSI-SEWA	Prisca	+2290197558787	3	CEG DU LAC	\N	actif	2026-09-20 13:42:15.88935+00	\N
930	J09266774	ADEROMOU	Victorine	+2290197071411	3	CEG DU LAC	\N	actif	2026-09-20 13:43:24.647044+00	\N
933	Y09263625	ADJANOHOUN	Brice	+2290165192802	16	CEG SURU LÉRÉ	\N	suspendu	2026-09-20 14:39:59.42149+00	\N
934	Y09265129	NOUWE	Styve	+2290197199375	16	CEG YAGBE	\N	actif	2026-09-20 15:46:19.708624+00	\N
935	Y09269264	MAHUGBE	Emmanuelle	+2290167560380	13	CEG YAGBE	\N	actif	2026-09-20 18:27:57.477441+00	\N
936	Y09263279	MISSIKPODE	Celestine	+2290197345620	13	CEG YAGBE	\N	actif	2026-09-20 18:30:35.331496+00	\N
937	Y09263321	NOUWE	Brice	+2290197199375	15	CEG YAGBE	\N	actif	2026-09-20 18:36:47.432952+00	\N
938	Y09262008	ZANNOU	Dakshi	+2290152111412	15	CEG YAGBE	\N	actif	2026-09-20 18:40:07.059908+00	\N
940	Y09263383	MIDINGOYI	Fidélia	+2290197749119	15	CEG YAGBE	\N	actif	2026-09-20 18:47:16.868291+00	\N
941	Y09268165	BONOU	Charlotte	\N	16	CEG YAGBE	\N	actif	2026-09-20 18:52:09.647193+00	+2290161245720
942	Y09267396	HOUNKPATIN	Even-Ezer	+2290197812323	16	CEG YAGBE	\N	actif	2026-09-20 18:53:37.38977+00	\N
943	Y09266329	MEZONLIN	Anne	+2290197752366	16	CEG YAGBE	\N	actif	2026-09-20 18:55:41.065412+00	\N
946	Y09263356	AMOUSSOU	Maximiene	+2290166224816	15	CEG YAGBE	\N	actif	2026-09-20 19:06:51.280471+00	\N
947	Y09269126	DANSOU	Géovani	+2290197118312	14	CEG YAGBE	\N	actif	2026-09-20 19:08:17.279629+00	\N
948	Y09261632	KPOBLI	Melchior	+2290140527323	14	CEG YAGBE	\N	actif	2026-09-20 19:11:31.748315+00	\N
949	Y09269206	AGONVI	Prince	+2290197811988	15	CEG YAGBE	\N	actif	2026-09-20 19:12:50.251827+00	\N
954	J09261584	ESSOU	Joseph	+2290197276399	17	CEG DANTOKPA	\N	suspendu	2026-09-20 20:01:46.96751+00	+2290161014286
952	J09264825	METEHOUE	Emmaüs	+2290167072405	17	CEG DU LAC	\N	actif	2026-09-20 19:52:55.587007+00	\N
953	J09269042	TOGNIFODE	Florence	+2290167080147	17	CEG DU LAC	\N	actif	2026-09-20 19:57:35.280492+00	\N
911	J09261990	DAGA	Camelia	\N	22	CEG STE RITA	\N	actif	2026-09-20 12:56:21.240862+00	+2290157527662
898	J09263770	OGOUBIYI	Nanyimanth	+2290197080216	19	CEG DU LAC	M1	suspendu	2026-09-20 12:11:28.461317+00	\N
951	J09268002	OLORIY	Shania	+2290141312012	8	CEG STE RITA	\N	actif	2026-09-20 19:51:21.593373+00	\N
925	J09266868	DANSI-GAH	Godwin	+2290197261814	6	CEG DANTOKPA	M3	suspendu	2026-09-20 13:37:28.4925+00	\N
896	J09264702	ACCROMBESSI	Robert	+2290197603711	2	CS LA RÉFÉRENCE	M3	actif	2026-09-20 12:00:06.884261+00	\N
620	Y08266252	MAHUGBE	Alki	+2290167560380	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.965797+00	\N
890	J09268322	HOUNTONDJI	Faoziath Aminath	+2290167703637	20	CEG DU LAC	\N	suspendu	2026-09-20 11:29:24.571259+00	\N
891	J09269107	HOUNTONDJI	Affissou	+2290167703637	20	CEG DU LAC	\N	suspendu	2026-09-20 11:30:58.441488+00	\N
892	J09265561	ADDY	Prince	\N	20	CEG DU LAC	\N	suspendu	2026-09-20 11:32:54.087636+00	+2290152240723
893	J09268851	WIGNANON	Phanuel	+2290141808865	20	CEG DU LAC	\N	suspendu	2026-09-20 11:34:36.246688+00	\N
894	J09266244	YABI	Chérifath	+2290147519987	2	CEG STE RITA	\N	suspendu	2026-09-20 11:55:32.735017+00	+2290197193836
900	J09262749	FADELE	Prince	+2290166731515	3	CEG DU LAC	\N	suspendu	2026-09-20 12:15:58.024381+00	+2290144970296
901	J09263905	DEGBOGBAHOUN	Samuel	\N	3	CEG DU LAC	\N	suspendu	2026-09-20 12:19:47.232992+00	+2290147079808
905	J09262320	AGUIDA	Raphaëlla	+2290197540087	3	CEG DANTOKPA	\N	suspendu	2026-09-20 12:29:58.726682+00	\N
908	J09265217	ADEGBINDIN	Sodic	+2290197190362	3	CEG DU LAC	\N	suspendu	2026-09-20 12:35:51.833631+00	\N
910	J09263774	TOLEFO	Marie Félicité	+2290196201911	18	CEG DU LAC	\N	suspendu	2026-09-20 12:53:58.607935+00	\N
918	J09268232	KPEHOUNTON	Auguste	+2290167555423	8	CEG LE NOKOUE	\N	suspendu	2026-09-20 13:16:51.468242+00	\N
920	J09269442	HOLO	Doris	+2290197733551	8	CEG DU LAC	\N	suspendu	2026-09-20 13:20:34.193844+00	\N
921	J09267044	BOUKARI	Bakiath	+2290196915692	7	CEG DU LAC	\N	suspendu	2026-09-20 13:22:12.935919+00	\N
924	J09268180	SEKPONNA	Noëlie	+2290197011503	6	CEG DU LAC	\N	suspendu	2026-09-20 13:35:21.542828+00	\N
928	J09267263	DEGUENONVO	Estelle	+2290197011503	3	CEG DU LAC	\N	suspendu	2026-09-20 13:41:22.063265+00	\N
931	J09262619	ALLAGBE	Espoir	+2290197601477	3	CEG STE RITA	\N	suspendu	2026-09-20 13:46:50.42332+00	\N
897	J09265173	ADELOU	Michel Alix	+2290197403766	19	CEG DU LAC	M11	suspendu	2026-09-20 12:01:50.728376+00	+2290193718383
939	Y09264387	ATINDEYETIN	David	+2290197470749	16	CEG YAGBE	\N	suspendu	2026-09-20 18:45:11.621148+00	\N
899	J09267347	KOUNOUHO	Florentin	+2290151698954	19	CEG DU LAC	M4	suspendu	2026-09-20 12:12:58.345854+00	\N
932	J09263043	METOZOUNVE	Fati	+2290166583294	19	CEG DU LAC	M10	suspendu	2026-09-20 13:48:36.851794+00	\N
1252	J10264074	AKPATA	Philomène	+2290195237539	7	CEG DU LAC	\N	actif	2026-10-18 09:26:37.620946+00	\N
958	Y09265713	GANDONOU	Janvier	+2290197214957	16	CEG YAGBE	\N	actif	2026-09-21 10:50:20.873989+00	\N
959	J09263137	HOUESSOU	Christy Belvie Ligth	+2290194997203	1	CEG DU LAC	\N	actif	2026-09-22 07:50:13.218212+00	\N
961	J09266436	AGBOTON	Oluwa Fèmi	+2290197379922	7	CEG DU LAC	\N	actif	2026-09-24 00:52:41.064933+00	\N
971	J09266751	TCHIAKPE	Stella	+2290167613034	5	CEG STE RITA	\N	actif	2026-09-26 09:14:22.126411+00	\N
1289	J10261405	GNONLONFOUN	Pascaline	+2290140518136	22	CEG DU LAC	\N	actif	2026-10-25 13:41:58.177878+00	\N
972	J09264202	TOGBEME	Jonathan	+2290192261790	6	CEG DU LAC	\N	actif	2026-09-26 09:18:06.55338+00	\N
974	J09265408	HOUNGBE	Ouzziel	+2290196299052	23	CEG DU LAC	\N	actif	2026-09-26 09:23:08.510768+00	\N
977	J09265137	WHANNOU	Jeannine	+2290166168106	8	CEG DU LAC	\N	actif	2026-09-27 05:39:24.470869+00	\N
981	Y09262152	BOGNON	Emmanuel	+2290140128403	16	CEG YAGBE	\N	suspendu	2026-09-27 12:41:07.39478+00	+2290161103570
982	Y09264911	ABOUBAKAR	Mohamed	+2290197774065	15	CEG YAGBE	\N	actif	2026-09-27 18:32:16.399938+00	\N
983	Y09261642	GOGAN	Pierre	+2290197033746	14	CEG YAGBE	\N	actif	2026-09-27 18:35:28.96427+00	\N
984	Y09269253	SANNI	Nouhbath	+2290197086906	16	CEG YAGBE	\N	actif	2026-09-27 18:37:45.310909+00	\N
987	Y09263324	ADJAGNISSOUDE	Daniella	+2290197749436	14	CEG YAGBE	\N	actif	2026-09-27 19:09:50.40969+00	\N
988	Y09267690	ADJANOHOUN	Cyr Baudoin	+2290197034835	13	CEG YAGBE	\N	actif	2026-09-27 19:15:29.028975+00	\N
989	Y09263073	DJIBRIL MORIBA	Aliou	+2290197026002	15	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:17:10.523784+00	\N
990	Y09261426	DJIBRIL MORIBA	Grâce	+2290197026002	16	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:18:50.742938+00	\N
991	Y09264529	ADAMOU	Neyla	+2290197026002	13	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:21:52.60205+00	\N
1011	J09268139	SODOHOUNSI	Raymond	+2290196881398	19	CEG DU LAC	M2	actif	2026-09-27 20:35:18.737788+00	\N
993	Y09266282	LOKOSSOU	Ivenne	+2290197153537	15	CEG YAGBE	\N	actif	2026-09-27 19:25:58.022503+00	\N
994	Y09263722	FONTECLOUNON	Généreux	+2290167119605	13	CEG YAGBE	\N	actif	2026-09-27 19:29:18.588484+00	\N
995	Y09263297	FONTECLOUNON	Heureux	+2290167119605	13	CEG YAGBE	\N	actif	2026-09-27 19:30:49.192221+00	\N
996	Y09263643	ACAKPO	Lumière	+2290128511180	16	CEG YAGBE	\N	actif	2026-09-27 19:32:46.190466+00	\N
997	Y09267654	ADJAGNISSODE	Yvens	+2290197516128	16	CEG YAGBE	\N	actif	2026-09-27 19:34:04.937795+00	\N
998	Y09263367	DOSSOU KOKO	Georges	+2290168952225	16	CEG YAGBE	\N	actif	2026-09-27 19:36:33.84486+00	\N
999	Y09265552	BOKO	Askel	+2290162226218	14	CEG YAGBE	\N	actif	2026-09-27 19:37:33.910231+00	\N
1000	Y09262769	ALASSANE	Rayane	+2290167484906	16	CEG YAGBE	\N	actif	2026-09-27 19:43:41.655393+00	\N
1001	Y09265886	SOULE ADOWA	Aïda	+2290197864013	13	CEG YAGBE	\N	actif	2026-09-27 19:49:32.92598+00	\N
1002	Y09264101	SOULE ADOWA	Akil	+2290197864013	15	CEG YAGBE	\N	actif	2026-09-27 19:51:29.435173+00	\N
1004	J09261327	CAPO-CHICHI	Elysée Eléna Nathalie	+2290195667655	22	CEG DU LAC	\N	actif	2026-09-27 19:56:11.949775+00	+2290195231828
1005	J09269266	HOUNKPEVI	Natacha	+2290167613034	22	CEG STE RITA	\N	actif	2026-09-27 19:58:42.628709+00	\N
1006	J09268823	KPETOTON	Amour	+2290166262724	22	CEG DU LAC	\N	actif	2026-09-27 20:17:54.452802+00	+2290147280801
1007	J09264796	BIO-GABA	Isaac	+2290166365518	4	CEG DU LAC	\N	actif	2026-09-27 20:19:58.962012+00	\N
1012	J09269532	ALI	Zeynab	+2290196232591	8	CS LA PAIX	\N	actif	2026-09-27 20:38:07.881525+00	+2290144497544
1014	J09261974	TOSSE	Joyce	+2290197602223	3	CEG DU LAC	\N	actif	2026-09-27 20:52:52.348446+00	+2290143955156
1017	J09264829	HOUESSOU	Majoie	+2290141804563	3	CEG DU LAC	\N	actif	2026-09-27 20:58:59.538165+00	\N
1019	J09267985	GNONLONSOU	Eunice	+2290197906041	3	CEG DU LAC	\N	actif	2026-09-27 21:02:10.727492+00	\N
960	J09263830	AYITE	Lucie Sarra	+2290196313654	22	CEG STE RITA	\N	actif	2026-09-24 00:37:04.675846+00	\N
965	J09269237	TOZO	Aser	+2290197013309	17	CEG DU LAC	\N	actif	2026-09-25 12:10:38.896771+00	\N
966	J09264452	DAASSI	Freud	+2290197262346	19	CEG DU LAC	M3	suspendu	2026-09-26 03:24:28.439725+00	\N
967	J09265092	HAMIDU	Haruna	+2290197262346	19	CEG DU LAC	M3	suspendu	2026-09-26 03:25:29.98266+00	\N
980	J09267083	AMOUZOUN	Occens	+2290169781377	19	CEG ZOGBO	M1	actif	2026-09-27 07:12:35.176459+00	\N
1009	J09265272	DEDO	Divine	+2290197441431	19	CEG DU LAC	M1	suspendu	2026-09-27 20:27:02.691218+00	\N
976	J09264607	TODJINOU	Océane	+2290197267528	19	CEG DANTOKPA	M2	suspendu	2026-09-26 15:02:30.364051+00	\N
1010	J09268331	DOSSEH	Vicentia	+2290141907995	19	CEG DU LAC	M6	suspendu	2026-09-27 20:31:30.480887+00	+2290163960279
808	J09264941	AHISSOU	Jean Eudes	+2290197061112	20	CEG DU LAC	\N	suspendu	2026-09-02 19:08:52.202838+00	\N
956	J09268472	BAOLA	Faosath	+2290163346290	10	CEG DU LAC	\N	suspendu	2026-09-20 20:07:41.817731+00	+2290197467939
962	J09262370	GANNEYEDO	Merveille	+2290166852390	18	CEG DU LAC	\N	suspendu	2026-09-24 07:38:50.500755+00	\N
968	J09262693	DAASSI	Armandine	+2290197262346	3	CEG DU LAC	\N	suspendu	2026-09-26 03:27:26.648978+00	\N
970	J09266458	TCHEHOUNDJE	Rolande	+2290140460674	20	CEG DU LAC	\N	suspendu	2026-09-26 09:08:26.971484+00	\N
973	J09266457	KOUDJANNAGNI	Lydie	+2290196720577	6	CEG DU LAC	\N	suspendu	2026-09-26 09:19:27.522887+00	\N
975	J09267221	SEKPONNA	Merveille	+2290197011503	3	CEG DU LAC	\N	suspendu	2026-09-26 09:47:41.779537+00	\N
979	Y09263504	OGOUHOLA	Expédit	+2290197888932	15	CEG YAGBE	\N	suspendu	2026-09-27 06:01:09.718019+00	\N
964	J09266223	ADANNOU	Lucienne	+2290141565967	19	CEG DU LAC	M5	suspendu	2026-09-24 22:19:26.023908+00	\N
985	Y09263913	OGOUDJOBI	Aurelie	+2290197290380	15	CEG YAGBE	\N	suspendu	2026-09-27 19:01:14.580982+00	\N
1003	Y09267411	MAMA	Imourane	+2290166558966	16	CEG YAGBE	\N	suspendu	2026-09-27 19:54:06.778818+00	\N
1008	J09268895	ALAO	Faoziath	+2290197639005	22	CEG DANTOKPA	\N	suspendu	2026-09-27 20:23:43.806203+00	\N
1013	J09268975	MASSESSI	Mathilde	+2290195247806	8	CEG STE RITA	\N	suspendu	2026-09-27 20:39:56.808814+00	+2290169744470
1015	J09266481	GLO	Esméralda	+2290197538080	3	CEG DANTOKPA	\N	suspendu	2026-09-27 20:53:50.454952+00	\N
1016	J09262191	ALANHOUHEDO	Pélagie	+2290152693008	3	CEG DANTOKPA	\N	suspendu	2026-09-27 20:56:20.194376+00	\N
1018	J09269689	ADJASSOHO	Ossénath	+2290195397467	3	CEG DU LAC	\N	suspendu	2026-09-27 21:00:46.385601+00	+2290196577131
969	J09268778	DJOGBE	Sègla Anicette	+2290167514889	1	CEG DU LAC	\N	suspendu	2026-09-26 08:34:57.293366+00	\N
1021	J09266145	GBEHI	Samuel	+2290197029240	3	CEG DU LAC	\N	actif	2026-09-27 21:04:42.76989+00	+2290167359474
1022	J09264980	HOUSSA	Elisabeth	+2290166866574	3	CEG DU LAC	\N	actif	2026-09-27 21:06:40.663727+00	+2290163201738
1023	J09264808	KPETOTON	Celestine	+2290166262724	3	CEG DU LAC	\N	actif	2026-09-27 21:08:19.810437+00	+2290147280801
1024	J09268745	BOTON FATCHE	Bignon Merveille	+2290199594615	3	CEG DU LAC	\N	actif	2026-09-27 21:09:37.803444+00	+2290197743882
1290	Y10269486	DJIMA	Abdel-Manan	+2290167672017	16	CEG YAGBE	\N	actif	2026-10-25 14:29:51.89127+00	\N
1027	J09265590	GOUHOUENOU	Osiniel	+2290197029674	20	CEG DU LAC	\N	actif	2026-09-27 21:42:42.241991+00	\N
1029	J09266908	DAMBIOKOU	Augustin	+2290166575867	3	CEG DU LAC	\N	actif	2026-09-27 21:45:33.107168+00	\N
1033	J09263198	MADADANNI	Leslie	+2290197043360	3	CEG STE RITA	M5	actif	2026-09-27 21:51:16.102972+00	\N
1039	J09269869	GNANGNON	Mariella	+2290197547207	3	CEG GBEGAMEY	M9	actif	2026-09-27 22:05:48.485038+00	\N
1049	J09261792	TOKINHO	Ebénézer	+2290196145763	19	CEG DU LAC	M5	actif	2026-09-27 22:20:57.440752+00	\N
1036	J09263820	YETIN	Aliou	+2290196741698	3	CEG DU LAC	M9	actif	2026-09-27 22:00:31.498596+00	\N
1046	J09262506	ACCROMBESSI	Donald	+2290163737144	8	CEG DU LAC	\N	actif	2026-09-27 22:16:17.954547+00	\N
1047	J09268568	ASSILAMEHOU	Charley	+2290197575294	8	CEG DU LAC	\N	actif	2026-09-27 22:17:37.097718+00	\N
1048	J09264407	GBENONCHI	Pablo	+2290197963160	8	CEG DU LAC	\N	actif	2026-09-27 22:18:50.057203+00	\N
1050	J09262673	AGBENOMBA	Divine	+2290195440830	22	CEG DU LAC	\N	actif	2026-09-27 22:32:25.542384+00	\N
1051	J09269111	AVOCEVOU	Christelle	+2290162597511	22	CEG DANTOKPA	\N	actif	2026-09-27 22:34:05.808435+00	\N
1052	J09262744	AKANNI	Assanath	+2290166077537	22	CEG DU LAC	\N	actif	2026-09-27 22:37:27.511544+00	\N
1053	J09261470	DANGBENON	Ignance	+2290196799502	22	CEG DU LAC	\N	actif	2026-09-27 22:38:24.531636+00	\N
1054	J09268707	AHLONSOU	Ametiste	+2290197631315	22	CEG DU LAC	\N	actif	2026-09-27 22:39:24.47414+00	\N
1055	J09265287	GANSA	Shalom	+2290152236985	22	CEG DU LAC	\N	actif	2026-09-27 22:40:40.525517+00	\N
1057	J09269640	SEDE	Abigaëlle	+2290195677493	22	CEG DANTOKPA	\N	actif	2026-09-27 22:43:23.265959+00	\N
1058	J09264352	SEDE	Josias	+2290195677493	22	CEG DANTOKPA	\N	actif	2026-09-27 22:44:13.691004+00	\N
1059	J09266065	DJOSSOU	Gwladys	+2290197742685	22	CEG DU LAC	\N	actif	2026-09-27 22:45:24.453904+00	\N
1060	J09266793	SOLEVO	Ikhlos	+2290197574124	5	CEG DU LAC	\N	actif	2026-09-27 22:51:52.596631+00	\N
1063	J10269394	AKPLOGAN	Aristide	+2290162129301	8	CEG DU LAC	\N	actif	2026-10-01 12:08:38.957554+00	\N
1064	J10263417	HOUNGBO	Aurel	+2290161550156	18	CEG DU LAC	\N	actif	2026-10-01 12:15:03.876203+00	\N
1065	J10264247	IDRISSOU	Yasmine	+2290190391603	22	CEG STE RITA	\N	actif	2026-10-02 09:02:43.444127+00	\N
1066	Y10267503	NOUNAGNON	Marie Christelle	+2290166997929	15	CEG YAGBE	\N	actif	2026-10-02 12:48:09.879146+00	\N
1061	J09269783	TCHINAN	Sévérine	+2290165566201	19	CEG DU LAC	M4	suspendu	2026-09-29 22:57:21.844445+00	\N
1253	J10262016	ADJABAHOUN	Débora	+2290196049662	24	CEG DANTOKPA	\N	actif	2026-10-18 09:34:32.118915+00	\N
1045	J09265505	HOUNMENOU	Aurel	+2290161215023	19	CEG DANTOKPA	M1	suspendu	2026-09-27 22:14:37.69211+00	\N
1043	J09262714	AKELE	Jean-Baptiste	+2290197370155	19	CEG DANTOKPA	M1	suspendu	2026-09-27 22:11:50.372462+00	\N
1028	J09263217	AHOUSSINOU	Doriane	+2290197419771	3	CEG OKOUN SEME	\N	actif	2026-09-27 21:44:08.121517+00	\N
1068	J10263181	KPADONOU	Miracle	+2290197962188	22	CEG DU LAC	\N	suspendu	2026-10-04 05:57:15.829476+00	\N
1020	J09266004	WIKON	Mariam	+2290167729007	3	CEG DANTOKPA	\N	suspendu	2026-09-27 21:03:29.828699+00	+2290144601210
1025	J09262141	HOUESSOU	Salomé	+2290141804563	20	CEG DU LAC	\N	suspendu	2026-09-27 21:16:16.239533+00	\N
1069	J10268826	ADI	Océane	+2290197580293	22	CEG DU LAC	\N	suspendu	2026-10-04 06:00:10.073302+00	\N
1076	J10266781	HOUNKANRIN	Estelle	\N	22	CEG DU LAC	\N	suspendu	2026-10-04 06:24:51.306566+00	+2290197804182
1072	J10265879	ANAGOKE	José	+2290197554314	22	CEG DU LAC	\N	actif	2026-10-04 06:08:59.162948+00	+2290140362931
1074	J10263302	WOLLO	Emilienne	+2290197564409	12	CEG DU LAC	\N	actif	2026-10-04 06:18:53.560587+00	\N
1075	J10263264	OGOULOLA	Divine	+2290197885464	22	CEG DU LAC	\N	actif	2026-10-04 06:22:21.663762+00	+2290194435444
1080	Y10266570	TOTCHOEDO	Boris	+2290149141962	13	CEG YAGBE	\N	actif	2026-10-04 10:24:02.079955+00	\N
1082	Y10268123	BONOU	Chabel	\N	13	CEG YAGBE	\N	actif	2026-10-04 10:40:10.113366+00	+2290147270077
1030	J09265584	MEDJOGBE	Fifamè	+2290195434989	3	CEG DU LAC	\N	suspendu	2026-09-27 21:46:50.436653+00	\N
1031	J09261983	AKELE	Christian	+2290197370155	3	CEG DANTOKPA	\N	suspendu	2026-09-27 21:48:30.536205+00	+2290144824461
1032	J09261744	HOUETO	Yasmine	+2290166816794	3	CEG DU LAC	\N	suspendu	2026-09-27 21:50:11.924469+00	\N
1034	J09269399	MONLIGUI	Dorcas	+2290144818881	3	CEG DU LAC	M6	suspendu	2026-09-27 21:57:54.096684+00	\N
1035	J09267041	AZANKPO	Elisée	+2290197942377	3	CEG DU LAC	M4	suspendu	2026-09-27 21:59:04.628251+00	\N
1037	J09262488	KPOVIESSI	Victorine	+2290197930411	3	CEG DU LAC	M5	suspendu	2026-09-27 22:01:56.518758+00	\N
1038	J09266260	MEDJOGBE	Exaucée	+2290195434986	3	CEG DU LAC	\N	suspendu	2026-09-27 22:03:12.590959+00	\N
1040	J09268731	KPETOTON	Saturnin	+2290197334739	3	CEG DU LAC	M10	suspendu	2026-09-27 22:07:25.636661+00	\N
1042	J09266924	LOUMINGOU	Grâce	+2290161746084	3	CEG DU LAC	M3	suspendu	2026-09-27 22:10:25.738755+00	\N
1056	J09264136	TOGNIFODE	Vlad	+2290197008629	22	CEG DU LAC	\N	suspendu	2026-09-27 22:41:39.408467+00	\N
1062	J09266463	SETOME	Basilia	+2290165566201	20	CEG DU LAC	\N	suspendu	2026-09-29 22:58:13.778737+00	\N
1071	J10268288	KOUEVI	Mélissa	+2290161626638	22	CEG DU LAC	\N	suspendu	2026-10-04 06:05:48.270807+00	\N
1073	J10266226	METOZOUNVE	Eunice	+2290146908526	22	CEG DANTOKPA	\N	suspendu	2026-10-04 06:12:06.803687+00	\N
1070	J10267811	TOSSOU	Bernadine	+2290199988253	22	CEG DANTOKPA	\N	suspendu	2026-10-04 06:03:17.426507+00	+2290149502013
1077	J10266544	GBENONMEDJI	Dorcas	+2290195767557	12	CEG STE RITA	\N	suspendu	2026-10-04 06:26:48.590091+00	+2290169297820
1078	Y10265475	TAIROU	Mohamed Fridaous	+2290167781926	13	CEG YAGBE	\N	suspendu	2026-10-04 10:20:14.907328+00	\N
1079	Y10263424	BOLO	Naomie	+2290167341484	13	CEG SURU LÉRÉ	\N	suspendu	2026-10-04 10:21:49.282624+00	\N
1081	Y10268452	FADEYI	Donaldine	+2290196807537	13	CEG YAGBE	\N	suspendu	2026-10-04 10:38:51.153853+00	\N
1041	J09262968	SAGBO	Esther	+2290151828951	3	CEG STE RITA	M4	suspendu	2026-09-27 22:09:00.081479+00	\N
1086	Y10262115	ABOUBAKAR	Fatimatou	+2290194616120	14	CEG YAGBE	\N	actif	2026-10-04 10:46:11.969984+00	+2290197023536
1088	Y10262569	CISSE	Prunelle	+2290196468398	15	CEG YAGBE	\N	actif	2026-10-04 10:48:02.43763+00	\N
1089	Y10262364	BONOU	Anne Marie	+2290161245720	15	CEG YAGBE	\N	actif	2026-10-04 10:48:59.134205+00	\N
1090	Y10265441	AKADIRY	Foudlath	+2290167159970	15	CEG YAGBE	\N	actif	2026-10-04 10:50:00.446561+00	\N
1091	Y10267039	ADEBIYI	Antoinette	+2290196093516	15	CEG YAGBE	\N	actif	2026-10-04 10:50:52.463195+00	\N
1092	Y10268615	CAKPO-CHICHI	Mickaela	+2290196086169	15	CEG YAGBE	\N	actif	2026-10-04 10:51:59.701066+00	\N
1093	Y10266141	MOUSTAPHA	Soumaiya	+2290197995990	15	CEG YAGBE	\N	actif	2026-10-04 10:53:08.64887+00	\N
1099	Y10263761	AKADIRY	Mahmoudath	+2290167159970	16	CEG YAGBE	\N	actif	2026-10-04 11:40:55.216682+00	\N
1103	J10263647	NASSARAH	Evrard	+2290164672825	20	CEG DU LAC	\N	actif	2026-10-04 12:36:01.534147+00	\N
1104	J10268764	NASSARAH	Bénit	+2290197639709	20	CEG DU LAC	\N	actif	2026-10-04 12:36:41.501423+00	\N
1105	J10263846	AFADJRO	Mario	+2290197556909	8	CEG DU LAC	\N	actif	2026-10-04 14:31:44.280834+00	\N
1106	J10268245	SALAVI	Josué	+2290197270887	8	CEG DU LAC	\N	actif	2026-10-04 14:34:39.217936+00	\N
1108	J10267753	MEKPO	Rotild	+2290197556075	24	CEG DANTOKPA	\N	actif	2026-10-04 14:52:20.784386+00	\N
1254	J10268479	AHOUANDJE	Alexie	+2290196969449	8	CEG STE RITA	\N	actif	2026-10-18 09:36:21.404279+00	\N
1291	Y10264533	ALAGBO	Emmanuella	+2290153899353	13	CEG YAGBE	\N	actif	2026-10-25 14:32:09.381119+00	\N
1113	J10263137	GODONOU	Belvida	+2290164785458	18	CEG DU LAC	\N	actif	2026-10-04 15:00:35.864763+00	\N
1114	J10265847	GODONOU	Géovania	+2290164785458	18	CEG DANTOKPA	\N	actif	2026-10-04 15:01:44.54752+00	\N
1115	J10268399	MOUTAIROU	Romziath	+2290196550970	18	CEG DU LAC	\N	actif	2026-10-04 15:04:02.964999+00	\N
1117	J10261246	AGONYE	Jesutin Marlène	+2290196720577	18	CEG DU LAC	\N	actif	2026-10-04 15:06:04.884714+00	\N
1120	J10268116	DEGBO	Yannick	+2290197250573	18	CEG DU LAC	\N	actif	2026-10-04 15:10:14.057704+00	+2290194747363
1125	J10261869	TOYIGBE	Frédéric	+2290196811574	2	LA RÉFÉRENCE	\N	actif	2026-10-04 15:20:11.708495+00	\N
1128	J10263555	AGBOZE	Messi	+2290197692968	20	CEG DU LAC	\N	actif	2026-10-04 15:24:13.39993+00	+2290147949090
1124	J10267652	SALAVI	Prince	+2290197270887	19	CEG DANTOKPA	M4	actif	2026-10-04 15:18:39.088774+00	\N
1130	J10266955	SALAVI	Gloire de Dieu	+2290197270887	20	CEG DU LAC	\N	actif	2026-10-04 15:26:56.239159+00	\N
1132	J10261772	ALAO	Olouwa Kèmi	+2290197639005	20	CEG DANTOKPA	\N	actif	2026-10-04 15:33:43.096533+00	\N
1133	J10261900	DJOTCHOU	Samuel Akouègnon	+2290197286137	1	CEG DU LAC	\N	actif	2026-10-04 15:37:25.248818+00	\N
1026	J09266010	MOIDE	Fènou Jériel Antonio	+2290195667655	20	CEG DU LAC	\N	actif	2026-09-27 21:18:37.381728+00	+2290195231828
1121	J10265210	NEVICE	Prunelle	\N	19	CEG DU LAC	M1	suspendu	2026-10-04 15:11:19.375209+00	+2290197717516
992	Y09269649	DOHOUIN	Buscotin	+2290197026002	16	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:23:47.516422+00	\N
1122	J10266462	TOÏGBE	Valentine	+2290194309419	19	LA RÉFÉRENCE	M3	actif	2026-10-04 15:13:00.24133+00	\N
1138	J10269348	HOUNSINOU	Emmanuella	+2290161881005	17	CEG STE RITA	\N	actif	2026-10-08 06:10:49.929962+00	\N
1083	Y10264683	HOUANGNI	Fériol	\N	14	CEG YAGBE	\N	suspendu	2026-10-04 10:41:46.79794+00	+2290147270077
1084	Y10266361	HOUNSA	Othniel	+2290196806998	14	CEG YAGBE	\N	suspendu	2026-10-04 10:43:06.919648+00	\N
1085	Y10264760	SAIZONOU	Lumen	+2290165412242	14	COLLÈGE LUCIE VERONE	\N	suspendu	2026-10-04 10:44:43.184568+00	\N
1087	Y10266598	DJIMA	Raoudath	\N	14	CEG YAGBE	\N	suspendu	2026-10-04 10:47:09.581004+00	+2290167536958
1094	Y10262246	HINTEGNI	Georjinio	+2290166045121	15	CEG YAGBE	\N	suspendu	2026-10-04 10:54:22.801225+00	\N
1095	Y10265483	OKPEICHA	Wadoud	+2290197442037	15	CEG YAGBE	\N	suspendu	2026-10-04 10:55:09.170153+00	\N
1097	Y10261711	ODOUNHARO	Antoine	+2290197513291	16	CEG YAGBE	\N	suspendu	2026-10-04 11:04:06.728328+00	\N
1100	Y10266810	ABOUBAKAR	Youssouf	+2290194616120	16	CEG YAGBE	\N	suspendu	2026-10-04 11:41:54.945938+00	+2290197023536
1101	Y10264902	OLOUKPEDE	Charbel	+2290191648674	16	CEG YAGBE	\N	suspendu	2026-10-04 11:42:37.33559+00	\N
1102	Y10262263	TIKO	Océane	+2290197553671	16	CEG YAGBE	\N	suspendu	2026-10-04 11:43:25.889816+00	\N
1107	J10268851	ASSOGBA	Ariel	+2290197031698	8	CEG DU LAC	\N	suspendu	2026-10-04 14:49:16.319381+00	\N
1109	J10267800	ADJIWANOU	Emmanuella	+2290195506360	7	CEG DU LAC	\N	suspendu	2026-10-04 14:54:12.535029+00	\N
1112	J10268435	SOGLO	Jordan	+2290197538080	22	CEG DANTOKPA	\N	suspendu	2026-10-04 14:59:11.842846+00	+2290197849559
1116	J10263085	AGBOOLA	Saobane	+2290141859959	18	CEG DU LAC	\N	suspendu	2026-10-04 15:04:57.634161+00	\N
1118	J10266199	KPADONOU	Jacques	\N	18	CEG DU LAC	\N	suspendu	2026-10-04 15:07:22.346287+00	+2290147282237
1127	J10261340	ASSOGBA	Christelle	\N	2	CEG STE RITA	\N	suspendu	2026-10-04 15:22:19.149512+00	+2290196432768
1131	J10264408	DEDJILA	Marigine	+2290161806373	20	CEG DANTOKPA	\N	suspendu	2026-10-04 15:30:12.363645+00	\N
1134	J10268019	HOUETO	Yanis	+2290166973747	8	CEG DU LAC	\N	suspendu	2026-10-04 19:50:08.814101+00	\N
1135	J10265203	DEGBO	Aubin	+2290169008428	18	CEG DU LAC	\N	suspendu	2026-10-05 00:18:10.674401+00	+2290191405028
1119	J10263248	KOUASSI	Shalom	+2290197779479	3	CEG DU LAC	\N	suspendu	2026-10-04 15:08:56.517844+00	+2290199516860
1136	J10261938	AHOUANVOEGBLA	Aurore	\N	8	CEG DU LAC	\N	suspendu	2026-10-05 00:42:37.037912+00	+2290147877997
1123	J10261977	N'SOYENOU	Abigaëlle	+2290197092940	19	CEG DU LAC	M6	suspendu	2026-10-04 15:15:15.479364+00	+2290148758037
1126	J10268944	BOTON FATCHE	Honoré	+2290199594615	2	CEG DU LAC	M4	suspendu	2026-10-04 15:21:16.425693+00	\N
1140	J10262787	ADANZOUNNON	Irène	+2290167734945	20	CEG DU LAC	\N	suspendu	2026-10-08 22:40:23.376613+00	\N
1255	J10265441	GOGAN	Rosepère	+2290196046320	8	CEG DANTOKPA	\N	actif	2026-10-18 09:38:04.209239+00	+2290141763990
1169	J10261355	HOUNMENOU	Isaïe	+2290196424807	19	CEG DU LAC	\N	suspendu	2026-10-13 05:35:33.279851+00	\N
1292	Y10263844	AÏNAGNON	Maria	+2290196344918	13	CED	\N	actif	2026-10-25 14:35:57.128642+00	\N
1174	J10265661	SENOU	Ella	+2290157341326	18	COLLÈGE KENNEDY	\N	suspendu	2026-10-13 05:43:39.755305+00	\N
1146	J10266527	ATORO	Failylath	+2290195809121	2	CEG DU LAC	\N	suspendu	2026-10-09 00:58:30.187341+00	\N
912	J09268877	WIGNANON	Jéssica	+2290141808865	17	CEG DU LAC	\N	suspendu	2026-09-20 12:58:12.218711+00	+2290197168495
1170	J10261305	LOKO	Etienne	+2290197567917	2	CEG DU LAC	M7	suspendu	2026-10-13 05:36:29.184616+00	\N
1151	J10267429	KPATINVO	Jean Marc	+2290196344395	2	CEG DU LAC	\N	suspendu	2026-10-09 02:34:50.348689+00	\N
1153	J10267059	OKATTA	Esta	+2290161551004	2	CEG DU LAC	\N	suspendu	2026-10-09 02:36:32.158437+00	\N
1167	J10262020	HOUNKPE	Romaric	+2290197388574	20	CEG DANTOKPA	\N	suspendu	2026-10-13 05:32:07.243493+00	\N
1168	J10267511	DJEKETE	Arafath	+2290197176477	20	CEG DU LAC	\N	suspendu	2026-10-13 05:33:46.332323+00	\N
1175	J10265240	DADIDJE	Esther	+2290167047604	18	CEG DU LAC	\N	suspendu	2026-10-13 05:45:09.869803+00	\N
1176	J10262938	LOKO	Centhia	+2290151805554	18	CEG DU LAC	\N	suspendu	2026-10-13 05:46:25.866439+00	+2290140602786
1177	J10263720	TANKPINOU	Exaucé	+2290141275703	18	CEG DU LAC	\N	suspendu	2026-10-13 05:47:51.835639+00	+2290197631493
1180	J10263021	KOGODE	Charbel	\N	6	CEG DU LAC	\N	suspendu	2026-10-13 05:55:08.394437+00	+2290197786888
1137	J10265005	SENOU	Virgile	+2290191639607	17	CEG DU LAC	\N	actif	2026-10-08 05:58:44.508347+00	\N
1163	Y10265070	DOSSA	Miracle	+2290195818133	16	CEG YAGBE	\N	actif	2026-10-09 23:22:16.272408+00	\N
1164	J10265922	SAGBO	Marie Madeleine	+2290197124578	20	CEG DU LAC	\N	actif	2026-10-10 01:14:43.458373+00	\N
1179	J10264799	KOSSOUKINI	Anne Marie	+2290197733277	18	CEG DANTOKPA	\N	suspendu	2026-10-13 05:53:16.090497+00	\N
1182	J10267705	GANKOU	Perrine	+2290195425289	23	CEG DU LAC	\N	suspendu	2026-10-13 07:47:01.166648+00	\N
1171	J10264102	AKPLOGAN	Harmonie	+2290151079615	18	CEG DANTOKPA	\N	actif	2026-10-13 05:38:15.790928+00	\N
1172	J10263367	KANONTIN	Grâce Divine	+2290147463030	18	CEG AKPAKPA CENTRE	\N	actif	2026-10-13 05:39:56.476123+00	+2290166665050
1173	J10262976	AMOUSSA	Rahimath	+2290197284809	18	CEG DU LAC	\N	actif	2026-10-13 05:41:00.337751+00	\N
1178	J10261458	HOUNGBE	Tryphose	+2290196299052	18	CEG DU LAC	\N	actif	2026-10-13 05:51:40.295572+00	\N
1184	J10261252	ADJOVI	Fleurette	+2290152280439	23	CEG DU LAC	\N	suspendu	2026-10-13 07:48:24.08648+00	\N
1181	J10265289	ATINSOUNON	Junior	+2290197327208	22	CEG DU LAC	\N	actif	2026-10-13 07:39:16.458728+00	\N
1190	Y10268666	VIVO	Jeanne	+2290197035303	13	CEG YAGBE	\N	actif	2026-10-13 08:02:44.17741+00	\N
1196	Y10267418	SAVI	Malick	+2290141980704	14	COLLÈGE LA GRACE	\N	suspendu	2026-10-13 08:13:54.452871+00	\N
1192	Y10267727	IBRAHIM	Mouttaha	+2290193522842	15	CEG YAGBE	\N	actif	2026-10-13 08:08:28.817418+00	\N
1195	Y10264337	OLOUKPEDE	Eden	+2290141395300	13	CEG YAGBE	\N	actif	2026-10-13 08:12:08.989151+00	\N
1198	Y10266780	ADANVOESSI	Ezeckiel	+2290162378300	14	CEG YAGBE	\N	actif	2026-10-13 08:16:16.698967+00	\N
1202	Y10269367	OTEKPOLA	Israël	+2290167244552	15	CEG YAGBE	\N	actif	2026-10-13 08:26:16.112394+00	\N
1205	Y10267745	KOUSSEMOU	Dayab	+2290196268858	16	CEG YAGBE	\N	actif	2026-10-13 08:31:01.181039+00	\N
1206	Y10266226	GBADAMOWSSI	Souliath	+2290195358062	16	CEG YAGBE	\N	actif	2026-10-13 08:32:53.556008+00	\N
1207	Y10266321	DAH-DOSSOU	Mathieu	+2290196588307	15	CEG YAGBE	\N	actif	2026-10-13 08:33:50.474161+00	\N
1209	Y10265890	DEHONOU	Charlène	+2290190950946	15	CEG YAGBE	\N	actif	2026-10-13 08:38:15.181453+00	\N
1210	Y10269396	HOUNSA	Esther	+2290141919329	14	CEG YAGBE	\N	actif	2026-10-13 08:41:14.47505+00	\N
1183	J10269553	ADJASSOHO	Osseni	+2290147989742	23	CEG DU LAC	\N	suspendu	2026-10-13 07:47:38.958875+00	\N
1185	J10263209	METEHOUE	Gracia	+2290167072405	24	CEG DU LAC	\N	suspendu	2026-10-13 07:50:17.725141+00	\N
1186	J10266071	SEZONDJI-SOTIN	Nelly	+2290159125964	8	CEG DU LAC	\N	suspendu	2026-10-13 07:54:38.86231+00	\N
1187	J10269600	GBEKPO	Anselme	\N	8	CEG DU LAC	\N	suspendu	2026-10-13 07:55:34.996813+00	+2290165171120
1188	J10265391	ALLOSSE	Marie-Polycarpe	+2290197224871	8	CEG STE RITA	\N	suspendu	2026-10-13 07:57:10.987997+00	\N
1189	Y10267392	KANGNIDE	Firmine	+2290197913165	13	CEG YAGBE	\N	suspendu	2026-10-13 08:00:32.228777+00	\N
543	Y08268529	KANGNIDE	Bénoit	+2290197913165	13	CEG YAGBE	\N	suspendu	2026-08-26 05:06:34.586662+00	\N
1191	Y10266663	AGBANRIN	Ebenezer	+2290197879696	16	CEG YAGBE	\N	suspendu	2026-10-13 08:03:34.317471+00	\N
1193	Y10266284	AMADOU	Sahidatou	+2290151782422	13	CEG YAGBE	\N	suspendu	2026-10-13 08:09:21.879717+00	\N
1197	Y10261874	AYENA	Immaculée	+2290197695103	16	CEG YAGBE	\N	suspendu	2026-10-13 08:14:50.324993+00	\N
1199	Y10264752	DJIDONOU	Josias	+2290197896860	14	CEG YAGBE	\N	suspendu	2026-10-13 08:17:24.966115+00	\N
1200	Y10262022	LIADI	Kismath	+2290191357360	13	CEG YAGBE	\N	suspendu	2026-10-13 08:18:22.709452+00	\N
1201	Y10266603	GNANIH	Christelle	+2290195471964	16	CEG YAGBE	\N	suspendu	2026-10-13 08:25:07.299349+00	\N
1203	Y10267679	HOUNWANOU	Osnelle	+2290166954788	15	CEG YAGBE	\N	suspendu	2026-10-13 08:27:16.795763+00	\N
1204	Y10264471	OUMAROU	Mouna	+2290197988552	16	CEG YAGBE	\N	suspendu	2026-10-13 08:30:09.995281+00	\N
1208	Y10264716	ADOYATON	Rubène	+2290198459539	15	CEG YAGBE	\N	suspendu	2026-10-13 08:36:16.706803+00	\N
1216	Y10269041	GUENANON	Bernard	+2290197925298	15	CEG YAGBE	\N	actif	2026-10-13 08:55:45.629321+00	\N
1217	Y10267085	VIVO	Epiphanie	+2290197035303	15	CEG YAGBE	\N	actif	2026-10-13 09:02:15.702059+00	\N
1218	Y10263795	MAROUFOU	Houdalah	+2290197992161	15	CEG SURU LÉRÉ	\N	actif	2026-10-13 09:08:46.003994+00	\N
1221	J10269406	KINDOMISSI	Sylvestre	+2290155209199	12	CEG DU LAC	\N	actif	2026-10-15 03:05:37.755492+00	\N
1228	J10267589	TCHOKOTI	Mélène	+2290166821400	18	CEG STE RITA	M8	actif	2026-10-18 06:05:58.292012+00	\N
1229	J10269028	ASSANI	Michkath	+2290166838650	18	CEG GBEGAMEY	M2	actif	2026-10-18 06:08:10.668006+00	\N
1226	J10265611	KPANKOUN	Sègla Sergio	\N	13	CEG YAGBE	\N	actif	2026-10-16 23:05:45.214976+00	+2290196768832
1293	Y10267908	KOUNNOU	King	+2290197286942	15	CEG YAGBE	\N	actif	2026-10-25 14:45:07.269527+00	\N
1211	Y10268172	CHAGANOU	Esther	+2290166834182	14	CEG YAGBE	\N	suspendu	2026-10-13 08:45:51.428482+00	\N
1212	Y10263750	KOUDOGBO	Prophétie	+2290167299021	15	CEG YAGBE	\N	suspendu	2026-10-13 08:47:22.379692+00	\N
1213	Y10267800	EDOKPA	Sarah	+2290197891770	14	CEG YAGBE	\N	suspendu	2026-10-13 08:48:12.398576+00	\N
1214	Y10262691	AKPA-GANGBE	Junior	+2290197350050	16	CEG YAGBE	\N	suspendu	2026-10-13 08:49:08.159233+00	\N
1215	Y10268466	LOKO	Jérémie	+2290147482395	16	CEG YAGBE	\N	suspendu	2026-10-13 08:50:36.579432+00	\N
1219	J10267793	NOUATIN	Pascal	+2290166307014	18	CEG DANTOKPA	\N	suspendu	2026-10-14 06:17:08.370529+00	\N
1220	J10268192	NOUATIN	Nestor	+2290166307014	18	CEG DANTOKPA	\N	suspendu	2026-10-14 06:17:50.593565+00	\N
1223	J10268351	N'SOYENOU	Jean de Dieu	+2290197616102	20	CEG DU LAC	\N	suspendu	2026-10-15 17:42:36.898815+00	\N
1224	J10264209	ZOUNDJI	Inès	\N	2	CEG DU LAC	\N	suspendu	2026-10-15 23:23:29.757512+00	+2290143799412
1225	J10262006	KPADONOU	Prudence	+2290196200266	22	CEG DU LAC	\N	suspendu	2026-10-16 00:08:03.901833+00	+2290192603200
1230	J10267888	HAMONDJI	Samson	+2290143719480	18	CEG DU LAC	M2	suspendu	2026-10-18 06:09:15.023433+00	\N
1231	J10264241	KEITA	Fanta	+2290197905389	18	CEG DU LAC	M12	suspendu	2026-10-18 06:10:35.188228+00	\N
1256	J10263892	KABADE	Géraude	+2290145287197	22	CEG DU LAC	\N	suspendu	2026-10-18 09:53:48.034866+00	\N
1227	J10262532	TOGNIMASSOU	Divine	+2290195117111	3	CEG DU LAC	M4	suspendu	2026-10-18 06:03:10.665229+00	+2290196274737
\.


--
-- Data for Name: eleves_exonerations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves_exonerations (id, eleve_id, annee_scolaire_id, type_exoneration, nombre_mois, mois_couverts, motif, accorde_par, created_at) FROM stdin;
1	467	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:40.951304+00
2	55	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:53.825667+00
3	209	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.054336+00
4	243	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:45.857556+00
5	334	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.697448+00
6	457	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.536282+00
7	487	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:47.806154+00
8	497	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:23.898365+00
9	501	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.603225+00
10	58	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:30:19.679793+00
11	164	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:04.872328+00
12	270	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:46.743438+00
14	456	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:01.344125+00
15	480	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:44.019351+00
16	490	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:26.327911+00
17	502	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:58.667355+00
19	193	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:36:32.882999+00
21	449	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:24.606245+00
22	469	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:51.06393+00
23	491	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:19.228814+00
24	509	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:59.342987+00
25	980	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.372664+00
26	549	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.110041+00
27	530	1	bourse	2	{Fevrier,Mars}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:46:03.496344+00
29	560	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.599569+00
30	564	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:37.67204+00
31	570	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:06.900455+00
32	625	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.523186+00
33	862	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:51:08.523286+00
34	620	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:21.313798+00
35	650	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.293738+00
38	328	1	bourse	1	{Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:55:12.254336+00
39	288	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:44.425682+00
40	618	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.376929+00
41	609	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:10.326461+00
42	1273	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:13:47.78073+00
43	1274	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:29:39.881625+00
44	1275	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:30:07.916153+00
45	1276	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:35:40.941246+00
46	1277	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:41:34.497305+00
47	1278	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:09:35.582276+00
48	1279	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:10:52.725466+00
49	1280	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:12:54.228333+00
50	1281	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:42:14.065019+00
51	1282	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:48:46.400224+00
52	1285	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:01:09.088138+00
53	1284	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:02:34.683605+00
54	1283	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:03:19.288985+00
55	1235	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:15:26.089873+00
56	1286	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:16:16.36784+00
57	1287	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:22:52.373293+00
58	1289	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 13:42:30.869272+00
59	1290	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 14:30:23.592675+00
60	1292	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 14:37:32.838652+00
61	1258	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:37.765294+00
62	1288	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-28 14:01:53.388618+00
63	1297	1	bourse	1	{Octobre}	Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 11:52:05.970521+00
\.


--
-- Data for Name: eleves_suspendus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves_suspendus (id, eleve_id, site_id, raison, motif, montant_du, date_suspension, suspendu_par, annee_scolaire_id, mois_souscription) FROM stdin;
1	1232	1	defaut_paiement	Defaut de paiement — 1750 F restants pour le mois de Octobre	1750	2026-11-01 00:03:51.193429+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
2	1257	1	defaut_paiement	Defaut de paiement — 1750 F restants pour le mois de Octobre	1750	2026-11-01 00:03:51.964515+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
3	62	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:52.88932+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
4	41	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:53.834482+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
5	5	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:54.396422+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
6	7	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:55.338862+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
7	8	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:56.081237+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
8	10	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:57.012481+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
9	12	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:57.564752+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
10	15	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:58.277262+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
11	16	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:58.823199+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
12	21	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:03:59.556142+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
13	26	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:00.273658+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
14	29	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:00.629535+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
15	30	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:01.172094+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
16	37	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:01.721023+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
17	42	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:02.648841+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
18	43	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:03.624164+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
19	48	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:04.364885+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
20	57	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:05.131594+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
21	64	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:04:05.657579+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
22	66	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:06.210835+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
23	68	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:06.749061+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
24	69	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:07.481885+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
25	32	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:08.01132+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
26	1270	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:08.566144+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
27	84	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:08.980498+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
28	1233	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:04:09.317025+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
29	1271	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:04:10.045611+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
30	1234	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:04:10.603752+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
31	87	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:11.173067+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
32	95	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:11.507209+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
33	96	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:12.072403+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
34	97	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:12.597155+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
35	103	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:13.164989+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
36	113	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:13.718994+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
37	127	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:14.262961+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
38	135	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:14.602357+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
39	137	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:15.141469+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
40	141	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:15.671222+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
41	142	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:16.009673+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
42	120	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:16.562216+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
43	143	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:16.908398+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
44	1272	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:04:17.250105+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
45	151	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:17.798828+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
46	165	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:18.553653+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
47	173	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:18.889888+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
48	187	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:19.224518+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
49	150	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:19.579925+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
50	1261	1	defaut_paiement	Defaut de paiement — 750 F restants pour le mois de Octobre	750	2026-11-01 00:04:19.919054+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
51	162	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:04:20.283246+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
52	168	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:20.826271+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
53	1298	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:21.175345+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
54	176	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:21.51699+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
55	188	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:21.870978+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
56	216	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:04:22.222941+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
57	194	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:22.575519+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
58	198	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:22.920762+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
59	214	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:23.26535+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
60	208	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:23.628922+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
61	204	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:24.184522+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
62	202	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:24.53826+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
63	191	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:25.111521+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
64	231	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:25.456095+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
65	227	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:25.815853+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
66	218	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:26.15199+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
67	196	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:26.513391+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
68	232	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:27.059862+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
69	152	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:27.432656+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
70	184	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:27.807204+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
71	158	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:28.355133+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
72	174	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:28.686016+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
73	195	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:29.033668+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
74	242	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:29.367121+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
75	1237	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:04:29.731236+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
76	257	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:30.072391+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
77	263	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:30.444664+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
78	269	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:30.974324+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
79	255	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:31.312293+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
80	1238	1	defaut_paiement	Defaut de paiement — 250 F restants pour le mois de Octobre	250	2026-11-01 00:04:31.650454+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
81	272	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:32.001775+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
82	275	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:04:32.351386+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
83	284	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:32.701194+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
84	285	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:04:33.044895+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
85	286	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:04:33.387138+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
86	293	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:33.729178+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
87	294	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:04:34.079491+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
88	303	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:34.412296+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
89	305	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:34.768834+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
90	306	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:35.33881+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
91	309	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:35.682188+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
92	310	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:36.286722+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
93	312	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:36.6296+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
94	317	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:37.159932+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
95	322	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:37.502973+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
96	262	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:37.865526+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
97	281	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:04:38.218608+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
98	287	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:04:38.556691+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
99	384	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:04:38.906539+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
100	335	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:39.468355+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
101	1239	1	defaut_paiement	Defaut de paiement — 250 F restants pour le mois de Octobre	250	2026-11-01 00:04:39.839175+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
102	339	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:40.19851+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
103	344	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:40.544495+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
104	346	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:40.882569+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
105	348	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:41.246923+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
106	361	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:41.592626+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
107	385	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:04:41.943819+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
108	396	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:42.28939+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
109	397	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:42.640263+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
110	399	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:43.003938+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
111	1240	1	defaut_paiement	Defaut de paiement — 250 F restants pour le mois de Octobre	250	2026-11-01 00:04:43.343571+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
112	401	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:43.694322+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
113	402	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:44.062456+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
114	403	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:44.428189+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
115	404	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:44.777487+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
116	409	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:45.126996+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
117	422	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:45.681037+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
118	425	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:46.030334+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
119	443	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:46.388448+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
120	447	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:47.100547+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
121	450	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:47.448212+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
122	452	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:47.793967+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
123	454	1	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:04:48.157196+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
124	462	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:48.578777+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
125	463	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:48.968502+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
126	464	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:49.325523+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
127	451	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:49.681431+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
128	416	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:04:50.027951+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
129	474	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:50.393262+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
130	478	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:50.747753+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
131	1241	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:04:51.096413+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
132	475	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:51.444658+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
133	482	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:04:51.789464+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
134	486	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:52.144469+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
135	500	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-11-01 00:04:52.491844+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
136	503	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-11-01 00:04:52.847721+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
137	507	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-11-01 00:04:53.21315+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
138	508	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-11-01 00:04:53.549531+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
139	514	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-11-01 00:04:53.912631+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
140	518	1	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:04:54.268215+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
141	526	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:54.624769+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
142	528	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:55.080104+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
143	568	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:04:55.426771+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
144	583	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:55.781007+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
145	589	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:56.126781+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
146	591	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:56.484095+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
147	603	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:56.823969+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
148	612	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:57.169509+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
149	616	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:57.528595+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
150	619	2	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:04:57.868001+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
151	622	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:58.220938+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
152	627	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:58.582243+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
153	1244	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:04:58.91912+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
154	630	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:04:59.265521+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
155	636	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:04:59.629998+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
156	639	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:04:59.978376+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
157	651	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:00.377852+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
158	653	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:00.73826+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
159	662	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:01.09507+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
161	682	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:01.834608+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
162	687	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:02.185144+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
163	688	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:02.555172+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
164	1246	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:05:02.969825+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
165	708	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:03.333752+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
166	717	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:03.695853+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
167	732	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:04.049057+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
168	734	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:04.414025+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
169	728	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:04.791756+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
170	739	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:05.151963+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
171	1247	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:05:05.514437+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
172	784	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:05.872265+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
173	1248	1	defaut_paiement	Defaut de paiement — 1250 F restants pour le mois de Octobre	1250	2026-11-01 00:05:06.221425+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
174	880	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:06.57036+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
175	852	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:05:06.926325+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
176	883	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:07.265372+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
177	762	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:07.6248+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
178	828	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:07.984107+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
179	890	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:08.359553+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
180	891	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:08.709652+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
181	892	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:09.057357+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
182	893	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:09.410048+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
183	894	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:09.76176+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
184	900	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:10.115842+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
185	901	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:10.487436+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
186	905	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:10.855288+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
187	908	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:11.222192+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
188	910	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:11.566486+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
189	918	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:11.922042+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
190	920	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:12.266654+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
191	921	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:05:12.86617+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
192	924	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:13.22458+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
193	928	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:13.57394+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
194	931	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:13.915291+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
195	897	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:14.468602+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
196	933	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:15.008638+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
197	939	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:15.775401+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
198	899	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:16.329979+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
199	954	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:16.691582+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
200	932	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:17.040545+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
201	898	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:17.406696+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
202	925	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:17.758586+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
203	808	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:18.114383+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
204	956	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-11-01 00:05:18.676483+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
205	962	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:19.038591+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
206	968	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:19.405232+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
207	970	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:19.945865+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
208	973	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:20.296196+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
209	975	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:20.644909+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
210	979	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:21.002019+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
211	964	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:21.384846+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
212	981	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:21.961266+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
213	985	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:22.31767+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
214	1003	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:22.666619+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
215	1008	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:23.033191+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
216	1013	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:23.375157+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
217	1015	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:23.916762+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
218	1016	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:24.26905+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
219	1018	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:24.753795+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
220	969	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:25.092812+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
221	966	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:25.440137+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
222	967	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:25.779252+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
223	1009	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:26.13072+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
224	976	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:26.47535+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
225	1010	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:26.824691+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
226	1020	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:27.203783+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
227	1025	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:27.556513+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
228	1030	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:27.908303+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
229	1031	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:28.278399+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
230	1032	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:28.634879+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
231	1034	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:28.995593+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
232	1035	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:29.352433+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
233	1037	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:29.708378+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
234	1038	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:30.055034+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
235	1040	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:30.407471+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
236	1042	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:30.749943+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
237	1056	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:31.100547+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
238	1062	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:31.45112+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
239	1061	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:31.81188+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
240	1045	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:32.15273+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
241	1043	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:32.507993+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
242	1068	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:33.063311+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
243	1071	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:33.418208+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
244	1073	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:33.760052+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
245	1070	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:34.110644+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
246	1069	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:34.47951+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
247	1076	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:34.898415+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
248	1077	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:35.229387+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
249	1078	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:35.560557+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
250	1079	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:35.903018+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
251	1081	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:36.243341+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
252	1041	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:36.582319+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
253	1083	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:36.93652+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
254	1084	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:37.286257+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
255	1085	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:37.63271+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
256	1087	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:37.972859+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
257	1094	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:38.338656+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
258	1095	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:38.673456+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
259	1097	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:39.034937+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
260	1100	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:39.379534+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
261	1101	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:39.748606+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
262	1102	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:40.085858+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
263	1107	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:05:40.442468+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
264	1109	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:05:40.77604+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
265	1112	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:41.124754+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
266	1116	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:41.477473+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
267	1118	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:41.810221+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
268	1127	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:42.184177+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
269	1131	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:42.551636+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
270	1134	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-11-01 00:05:42.891712+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
271	1135	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:43.239978+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
272	1119	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:43.583113+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
273	1136	1	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:43.918971+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
274	1121	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:44.267136+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
275	1123	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:44.603524+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
276	1126	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:44.947608+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
277	1140	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:45.292323+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
278	1146	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:45.632934+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
279	912	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:45.964887+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
280	1170	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:46.302721+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
281	1151	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:46.650706+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
282	1153	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:46.995198+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
283	1167	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:47.371377+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
284	1168	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:47.703405+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
285	1169	1	defaut_paiement	Defaut de paiement — 500 F restants pour le mois de Octobre	500	2026-11-01 00:05:48.0692+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
286	1174	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:48.413247+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
287	1175	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:48.76542+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
288	1176	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:49.303333+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
289	1177	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:49.637664+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
290	1180	1	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:49.973368+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
291	1179	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:50.317967+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
292	1182	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:50.681141+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
293	1183	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:51.017669+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
294	1184	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-11-01 00:05:51.350289+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
295	1185	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:05:51.69598+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
296	1186	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-11-01 00:05:52.052303+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
297	1187	1	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:52.40278+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
298	1188	1	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:52.737748+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
299	1189	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:53.086132+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
300	543	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:53.42972+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
301	1191	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:53.78574+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
302	1193	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:54.11557+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
303	1196	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:54.476333+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
304	1197	2	defaut_paiement	Defaut de paiement — 1500 F restants pour le mois de Octobre	1500	2026-11-01 00:05:54.817937+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
305	1199	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:55.156003+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
306	1200	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:55.524844+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
307	1201	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:55.86711+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
308	1203	2	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:56.203207+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
309	1204	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:56.54521+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
310	1208	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:56.891104+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
311	1211	2	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:05:57.233664+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
312	1212	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:57.576134+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
313	1213	2	defaut_paiement	Defaut de paiement — 1000 F restants pour le mois de Octobre	1000	2026-11-01 00:05:57.915222+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
314	1214	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:58.250734+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
315	1215	2	defaut_paiement	Defaut de paiement — 4000 F restants pour le mois de Octobre	4000	2026-11-01 00:05:58.598183+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
316	1219	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:58.933369+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
317	1220	1	defaut_paiement	Defaut de paiement — 3500 F restants pour le mois de Octobre	3500	2026-11-01 00:05:59.269925+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
318	1223	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:59.602613+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
319	1224	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:05:59.948237+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
320	1225	1	defaut_paiement	Defaut de paiement — 2000 F restants pour le mois de Octobre	2000	2026-11-01 00:06:00.301285+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
321	1230	1	defaut_paiement	Defaut de paiement — 1750 F restants pour le mois de Octobre	1750	2026-11-01 00:06:00.651982+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
322	1231	1	defaut_paiement	Defaut de paiement — 250 F restants pour le mois de Octobre	250	2026-11-01 00:06:00.982542+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
323	1256	1	defaut_paiement	Defaut de paiement — 2500 F restants pour le mois de Octobre	2500	2026-11-01 00:06:01.349861+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
324	1227	1	defaut_paiement	Defaut de paiement — 1750 F restants pour le mois de Octobre	1750	2026-11-01 00:06:01.698057+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	1	Octobre
\.


--
-- Data for Name: frais_td; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frais_td (id, classe_id, montant) FROM stdin;
2	13	2000.00
6	15	3000.00
7	4	5000.00
9	5	5000.00
10	6	5000.00
11	7	6000.00
12	8	6000.00
14	10	8000.00
16	12	8000.00
17	17	5000.00
1	1	2500.00
20	20	2500.00
3	2	2500.00
19	19	2500.00
5	3	3500.00
18	18	3500.00
15	11	10000.00
22	22	5000.00
23	23	5000.00
24	24	6000.00
4	14	2000.00
8	16	4000.00
25	25	3500.00
26	26	5000.00
27	27	2500.00
28	28	2500.00
\.


--
-- Data for Name: galerie; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie (id, storage_path, date_insertion) FROM stdin;
\.


--
-- Data for Name: galerie_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie_admin (id, storage_path, nom_fichier, taille_octets, ajoute_par, date_ajout) FROM stdin;
\.


--
-- Data for Name: log_whatsapp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_whatsapp (id, matricule, mois_souscription, montant_restant, contact_parent, envoye_par, date_envoi) FROM stdin;
1	J08263933	Octobre	5000	+2290197214548	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-10-16 06:26:17.361674+00
2	Y10266810	Octobre	2000	+2290194616120	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:16:55.10093+00
3	Y08264402	Octobre	3000	+2290196431908	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:19:00.05478+00
4	Y10266780	Octobre	2000	+2290162378300	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:19:51.533353+00
5	Y09267654	Octobre	4000	+2290197516128	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:20:39.646094+00
6	Y09263324	Octobre	1000	+2290197749436	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:20:51.679688+00
7	Y09263324	Octobre	1000	+2290197749436	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:24:40.291442+00
8	Y09263324	Octobre	1000	+2290197749436	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:26:51.599468+00
9	Y08261739	Octobre	1000	+2290196667584	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:27:17.621274+00
10	Y09263625	Octobre	4000	+2290165192802	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:27:39.114018+00
11	Y09267690	Octobre	2000	+2290197034835	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:27:58.679631+00
12	Y10264716	Octobre	2000	+2290198459539	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:28:23.370136+00
13	Y10266663	Octobre	4000	+2290197879696	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:28:44.487655+00
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, identifiant, portail, reussi, ip, date_tentative) FROM stdin;
1	jealexhouegbe	admin	t	\N	2026-08-08 09:04:55.328051+00
2	jealexhouegbe	admin	t	\N	2026-08-08 09:39:40.149597+00
3	jealexhouegbe	admin	t	\N	2026-08-08 10:11:21.70487+00
4	jealexhouegbe	admin	t	\N	2026-08-08 17:28:36.86968+00
5	jealexhouegbe	admin	t	\N	2026-08-08 19:50:29.083241+00
6	jealexhouegbe	admin	t	\N	2026-08-08 20:18:37.037356+00
7	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:19:48.89375+00
8	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:20:20.527295+00
9	urielhouegbe	admin	t	\N	2026-08-08 20:21:05.91664+00
10	jealexhouegbe	admin	t	\N	2026-08-09 07:24:15.712276+00
11	jealexhouegbe	admin	t	\N	2026-08-09 17:50:38.07625+00
12	jealexhouegbe	admin	t	\N	2026-08-09 18:04:09.738492+00
13	jealexhouegbe	admin	t	\N	2026-08-09 21:45:01.744606+00
14	jealexhouegbe	admin	t	\N	2026-08-09 22:30:52.951794+00
15	jealexhouegbe	admin	t	\N	2026-08-09 22:51:08.511658+00
16	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:17:04.613553+00
17	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:38:02.296944+00
18	jealexhouegbe	admin	t	\N	2026-08-10 06:54:14.925918+00
19	urielhouegbe	admin	t	\N	2026-08-10 06:54:53.49026+00
20	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-10 14:16:24.752172+00
21	jealexhouegbe	admin	t	\N	2026-08-11 05:15:32.956857+00
22	jealexhouegbe	admin	t	\N	2026-08-11 07:17:09.84883+00
23	jealexhouegbe	admin	t	\N	2026-08-11 14:42:01.560105+00
24	jealexhouegbe 	admin	f	\N	2026-08-11 14:50:28.385101+00
25	jealexhouegbe	admin	t	\N	2026-08-11 14:51:47.881878+00
26	urielhouegbe	admin	t	\N	2026-08-11 22:09:42.773948+00
27	urielhouegbe	admin	t	\N	2026-08-11 22:55:35.577395+00
28	jucalhouegbe	admin	f	\N	2026-08-11 23:47:44.631597+00
29	jealexlhouegbe	admin	f	\N	2026-08-11 23:47:59.101531+00
30	jealexhouegbe	admin	t	\N	2026-08-11 23:48:07.321782+00
31	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:07:07.80926+00
32	jealexhouegbe	admin	t	\N	2026-08-12 00:14:52.139976+00
33	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:14:52.297684+00
34	jealexhouegbe	admin	t	\N	2026-08-12 00:40:28.33475+00
35	jealexhouegbe	admin	t	\N	2026-08-13 06:44:02.687375+00
36	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-13 06:51:51.529595+00
37	urielhouegbe	admin	t	\N	2026-08-13 10:02:55.168658+00
38	urielhouegbe 	admin	f	\N	2026-08-13 10:12:23.387167+00
39	urielhouegbe	admin	t	\N	2026-08-13 10:12:31.147252+00
40	jealexhouegbe	admin	t	\N	2026-08-13 19:58:42.339916+00
41	jealexhouegbe	admin	t	\N	2026-08-13 20:31:27.647073+00
42	urielhouegbe	admin	t	\N	2026-08-14 00:18:35.46862+00
43	urielhouegbe	admin	t	\N	2026-08-15 18:08:50.226733+00
44	jucalhouegbe	admin	f	\N	2026-08-16 16:51:07.068095+00
45	jealexhouegbe	admin	t	\N	2026-08-16 16:51:21.321239+00
46	urielhouegbe	admin	t	\N	2026-08-16 23:14:59.890519+00
47	jealexhouegbe	admin	t	\N	2026-08-17 04:22:29.319416+00
48	urielhouegbe	admin	t	\N	2026-08-17 19:20:15.425783+00
49	jealexhouegbe	admin	f	\N	2026-08-17 19:50:55.965311+00
50	jealexhouegbe	admin	t	\N	2026-08-17 19:51:24.8748+00
51	jealexhouegbe 	admin	f	\N	2026-08-17 19:54:57.472031+00
52	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:11.314247+00
53	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:15.276516+00
54	jealexhouegbe	admin	t	\N	2026-08-17 19:55:32.145075+00
55	urielhouegbe	admin	t	\N	2026-08-18 14:39:31.730354+00
56	urielhouegbe	admin	t	\N	2026-08-18 15:01:39.644185+00
57	jealexhouegbe	admin	t	\N	2026-08-18 18:19:26.597107+00
58	urielhouegbe	admin	t	\N	2026-08-18 18:25:36.774151+00
59	urielhouegbe	admin	t	\N	2026-08-18 19:18:33.026739+00
60	urielhouegbe	admin	t	\N	2026-08-18 19:41:50.997441+00
61	urielhouegbe	admin	t	\N	2026-08-18 19:46:37.319351+00
62	urielhouegbe	admin	t	\N	2026-08-18 20:04:14.497463+00
63	urielhouegbe	admin	t	\N	2026-08-18 20:24:31.820607+00
64	jealexhouegbe	admin	t	\N	2026-08-18 20:57:59.714752+00
65	jealexhouegbe	admin	f	\N	2026-08-18 21:35:02.243166+00
66	jealexhouegbe	admin	t	\N	2026-08-18 21:35:26.978454+00
67	jealexhouegbe	admin	t	\N	2026-08-18 22:15:50.900336+00
68	jealexhouegbe	admin	t	\N	2026-08-18 22:25:22.228939+00
69	jealexhouegbe	admin	t	\N	2026-08-18 22:26:16.772262+00
70	jealexhouegbe	admin	f	\N	2026-08-20 20:51:38.231956+00
71	jealexhouegbe	admin	t	\N	2026-08-20 20:52:02.9463+00
72	jealexhouegbe	admin	t	\N	2026-08-20 22:40:52.726733+00
73	jealexhouegbe	admin	t	\N	2026-08-21 05:34:05.517187+00
74	jealexhouegbe	admin	t	\N	2026-08-24 08:05:32.234437+00
75	jealexhouegbe	admin	t	\N	2026-08-24 09:27:48.297251+00
76	sylvestregblagodo@gmail.com	td	f	\N	2026-08-24 21:19:59.614399+00
77	jealexhouegbe	admin	t	\N	2026-08-24 23:51:25.967698+00
78	louislucnou@gmail.com	td	f	\N	2026-08-25 11:10:13.546533+00
79	jealexhouegbe	admin	t	\N	2026-08-25 14:17:27.114846+00
80	piomedesse@gmail.com	td	f	\N	2026-08-25 17:34:32.465617+00
81	jealexhouegbe	admin	t	\N	2026-08-25 19:58:21.76755+00
82	jealexhouegbe	admin	t	\N	2026-08-25 20:04:35.214424+00
83	jealexhouegbe	admin	t	\N	2026-08-25 21:59:07.881512+00
84	jealexhouegbe	admin	t	\N	2026-08-25 22:28:27.334899+00
85	jealexhouegbe	admin	t	\N	2026-08-26 05:04:34.848327+00
86	jealexhouegbe	admin	t	\N	2026-08-26 05:25:00.305425+00
87	urielhouegbe	admin	t	\N	2026-08-26 05:26:07.905145+00
88	urielhouegbe	admin	t	\N	2026-08-26 05:33:11.71263+00
89	urielhouegbe	admin	t	\N	2026-08-26 06:39:47.176169+00
90	urielhouegbe	admin	t	\N	2026-08-26 06:45:04.452508+00
91	jealexhouegbe	admin	t	\N	2026-08-26 06:47:20.684668+00
92	jealexhouegbe	admin	t	\N	2026-08-26 07:29:32.628906+00
93	urielhouegbe	admin	t	\N	2026-08-26 07:34:42.59047+00
94	jealexhouegbe	admin	t	\N	2026-08-26 07:39:09.898096+00
95	jealexhouegbe	admin	t	\N	2026-08-26 19:22:10.541005+00
96	urielhouegbe	admin	t	\N	2026-08-26 19:22:17.499147+00
97	jealexhouegbe	admin	t	\N	2026-08-26 19:54:34.621802+00
98	djossoudavid19@gmail.com	td	f	\N	2026-08-27 06:27:52.0945+00
99	kegnidedavid70@gmail.com	td	f	\N	2026-08-27 22:49:29.236976+00
100	kegnidedavid70@gmail.com	td	f	\N	2026-08-27 22:49:38.098546+00
101	romaricadjovi12@gmail.com	td	f	\N	2026-08-29 09:58:17.030525+00
102	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:49:15.325666+00
103	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:49:28.24588+00
104	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:49:54.500969+00
105	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:50:34.492743+00
106	jeremieabidegbekponou@gmail.com	td	f	\N	2026-08-29 17:13:15.658474+00
107	amankpemodeste761@gmail.com	td	f	\N	2026-08-30 10:39:33.94497+00
108	amankpemodeste761@gmail.com	td	f	\N	2026-08-30 10:42:06.962371+00
109	jealexhouegbe	admin	t	\N	2026-08-30 14:51:26.502628+00
110	jealexhouegbe	admin	t	\N	2026-08-30 19:27:17.776124+00
111	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-30 19:35:14.075465+00
112	jealexhouegbe	admin	t	\N	2026-08-31 13:18:30.424268+00
113	jealexhouegbe	admin	t	\N	2026-08-31 16:07:13.248466+00
114	jealexhouegbe	admin	t	\N	2026-09-01 06:06:12.389123+00
115	jealexhouegbe	admin	t	\N	2026-09-02 18:47:56.174114+00
116	jealexhouegbe	admin	t	\N	2026-09-02 19:29:34.855369+00
117	jealexhouegbe 	admin	f	\N	2026-09-04 16:31:13.600098+00
118	jealexhouegbe	admin	t	\N	2026-09-04 16:31:22.231021+00
119	aurelgodfrid2@gmail.com	td	f	\N	2026-09-06 06:42:49.650185+00
120	jealexhouegbe	admin	t	\N	2026-09-06 14:34:13.904069+00
121	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-06 14:56:40.768797+00
122	djossoudavid19@gmail.com	admin	f	\N	2026-09-06 18:21:29.002743+00
123	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-06 22:11:20.431377+00
124	jealexhouegbe	admin	t	\N	2026-09-06 22:14:59.418656+00
125	jealexhouegbe	admin	t	\N	2026-09-06 22:25:24.857657+00
126	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 07:19:05.70145+00
127	jealexhouegbe	admin	t	\N	2026-09-07 08:20:11.259871+00
128	jealexhouegbe 	admin	f	\N	2026-09-07 08:48:30.552839+00
129	jealexhouegb	admin	f	\N	2026-09-07 08:49:32.716556+00
130	jealexhouegbe	admin	t	\N	2026-09-07 08:49:51.984579+00
131	jealexhouegbe	admin	t	\N	2026-09-07 09:24:54.821277+00
132	jealexhouegbe	admin	t	\N	2026-09-07 14:46:34.476593+00
133	arnaudzadji066@gmail.com	td	f	\N	2026-09-07 15:10:49.322012+00
134	arnaudzadji066@gmail.com	td	f	\N	2026-09-07 15:11:18.080867+00
135	jealexhouegbe	admin	t	\N	2026-09-07 15:19:58.379888+00
136	charliehounkanrin@gmail.com	td	f	\N	2026-09-07 15:32:15.363749+00
137	charliehounkanrin@gmail.com	td	f	\N	2026-09-07 15:32:57.573718+00
138	arnaudzadji066@gmail.com	td	t	\N	2026-09-07 15:33:41.236706+00
139	jealexhouegbe 	admin	f	\N	2026-09-07 15:36:16.05189+00
140	jealexhouegbe	admin	t	\N	2026-09-07 15:36:22.55051+00
141	piomedesse@gmail.com	td	f	\N	2026-09-07 15:38:39.896874+00
142	piomedesse@gmail.com	td	f	\N	2026-09-07 15:39:11.520009+00
143	piomedesse@gmail.com	td	f	\N	2026-09-07 15:39:23.83405+00
144	charliehounkanrin@gmail.com	td	t	\N	2026-09-07 15:39:51.365342+00
145	piomedesse@gmail.com	td	f	\N	2026-09-07 15:41:32.965879+00
146	piomedesse@gmail.com	td	f	\N	2026-09-07 15:41:46.742573+00
147	louislucnou@gmail.com	td	f	\N	2026-09-07 15:47:59.108894+00
148	louislucnou@gmail.com	td	t	\N	2026-09-07 15:48:39.009296+00
149	florenthinnou@gmail.com	td	t	\N	2026-09-07 16:09:29.057582+00
150	leopoldchangodele@gmail.com	td	f	\N	2026-09-07 16:10:00.772591+00
151	leopoldchangodele@gmail.com	td	f	\N	2026-09-07 16:10:06.887534+00
152	leopoldchangodele@gmail.com	td	f	\N	2026-09-07 16:10:31.059911+00
153	leopoldchangodele@gmail.com	td	t	\N	2026-09-07 16:12:24.653371+00
154	fauxence1994@gmail.com	td	t	\N	2026-09-07 16:27:29.592543+00
155	zoutounnouf@gmail.com	td	t	\N	2026-09-07 16:28:22.898891+00
156	mawougnongael91@gmail.com	td	f	\N	2026-09-07 16:34:21.561919+00
157	mawougnongael91@gmail.com	td	t	\N	2026-09-07 16:35:55.051974+00
158	sagbowilliam@gmail.com	td	f	\N	2026-09-07 16:40:05.869304+00
159	sagbowilliam@gmail.com	admin	f	\N	2026-09-07 16:40:19.433993+00
160	angekarson1@gmail.com	td	f	\N	2026-09-07 16:41:17.5689+00
161	angekarson1@gmail.com	td	f	\N	2026-09-07 16:41:27.620185+00
162	mawougnongael91@gmail.com	td	t	\N	2026-09-07 16:41:42.129007+00
163	angekarson1@gmail.com	td	f	\N	2026-09-07 16:41:45.438386+00
164	angekarson1@gmail.com	td	f	\N	2026-09-07 16:42:06.956887+00
165	sagbowilliam@gmail.com	admin	f	\N	2026-09-07 16:49:22.192363+00
166	sagbowilliam@gmail.com	admin	f	\N	2026-09-07 16:49:25.107283+00
167	charliehounkanrin@gmail.com	td	t	\N	2026-09-07 16:54:34.107492+00
168	ricoferno@gmail.com	td	t	\N	2026-09-07 16:56:57.741793+00
169	ghics2000@yahoo.fr	td	f	\N	2026-09-07 16:59:38.362339+00
170	ghics2000@yahoo.fr	td	t	\N	2026-09-07 17:04:46.043919+00
171	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:15:38.951332+00
172	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:16:16.795912+00
173	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:18:31.914911+00
174	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:18:35.682994+00
175	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:18:45.150071+00
176	ferdinandagossou03@gmail.com	td	f	\N	2026-09-07 19:32:36.746486+00
177	jealexhouegbe	admin	t	\N	2026-09-07 19:44:16.99934+00
178	ferdinandagossou03@gmail.com	td	t	\N	2026-09-07 19:55:28.983056+00
179	carlosbokononhoui@gmail.com	td	t	\N	2026-09-07 20:02:40.49141+00
180	augustinnoutahi@gmail.com	td	f	\N	2026-09-07 20:10:47.493278+00
181	enagnonaugustinnoutahi@gmail.com	td	f	\N	2026-09-07 20:17:12.319047+00
182	enagnonaugustinnoutahi@gmail.com	td	f	\N	2026-09-07 20:17:48.352146+00
183	enagnonaugustinnoutahi@gmail.com	td	t	\N	2026-09-07 20:21:31.44175+00
184	faroukaremou5@gmail.com	td	f	\N	2026-09-07 21:00:14.734822+00
185	amankpemodeste761@gmail.com	td	f	\N	2026-09-07 21:08:00.066227+00
186	amankpemodeste761@gmail.com	td	t	\N	2026-09-07 21:09:57.790002+00
187	faroukaremou5@gmail.com	td	t	\N	2026-09-07 21:11:18.848169+00
188	jealexhouegbe	admin	t	\N	2026-09-07 21:32:40.499189+00
189	jealexhouegbe	admin	t	\N	2026-09-07 22:24:39.123957+00
190	jealexhouegbe	admin	t	\N	2026-09-07 22:26:26.261929+00
191	akakpoenock00@gmail.com	td	t	\N	2026-09-08 07:45:59.700265+00
192	charliehounkanrin@gmail.com	td	t	\N	2026-09-08 15:04:31.393706+00
193	jealexhouegbe	admin	t	\N	2026-09-08 16:57:23.884135+00
194	aurelgodfrid2@gmail.com	td	t	\N	2026-09-08 17:00:00.644839+00
195	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:16:44.818061+00
196	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:16:52.669302+00
197	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:17:05.670902+00
198	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:17:08.723116+00
199	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:17:50.524738+00
200	aurelgodfrid2@gmail.com	td	t	\N	2026-09-08 17:20:55.367207+00
201	sahopaulh@gmail.com	td	f	\N	2026-09-08 17:39:03.871025+00
202	sahopaulh@gmail.com	td	f	\N	2026-09-08 17:39:37.920437+00
203	sahopaulh@gmail.com	td	f	\N	2026-09-08 17:39:56.194002+00
204	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-08 17:43:04.339291+00
205	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-08 17:46:41.32014+00
206	romaricadjovi12@gmail.com	td	f	\N	2026-09-08 17:49:15.692794+00
207	romaricadjovi12@gmail.com	td	f	\N	2026-09-08 17:50:34.501488+00
208	romaricadjovi12@gmail.com	td	t	\N	2026-09-08 17:50:52.981519+00
209	magbondejerome@gmail.com	td	t	\N	2026-09-08 17:59:41.430013+00
210	simkiki30@gmail.com	td	f	\N	2026-09-08 18:13:39.62656+00
211	simkiki30@gmail.com	td	f	\N	2026-09-08 18:15:20.13368+00
212	simkiki30@gmail.com	td	f	\N	2026-09-08 18:16:16.870798+00
213	simkiki30@gmail.com	td	f	\N	2026-09-08 18:16:27.361542+00
214	simkiki30@gmail.com	td	f	\N	2026-09-08 18:17:06.197495+00
215	simkiki30@gmail.com	admin	f	\N	2026-09-08 18:17:23.833101+00
216	hounkponouhorus@gmail.com	td	t	\N	2026-09-08 18:17:35.516017+00
217	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:29:23.843159+00
218	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:29:47.07518+00
219	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:29:54.72863+00
220	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:30:12.477541+00
221	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:31:43.053269+00
222	armelnou@gmail.com	td	f	\N	2026-09-08 18:36:56.302358+00
223	armelnou@gmail.com	td	f	\N	2026-09-08 18:39:26.315209+00
224	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:54:35.838524+00
225	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:54:40.346182+00
226	avocevouemmanuel5@gmail.com	td	f	\N	2026-09-08 19:29:15.226242+00
227	avocevouemmanuel5@gmail.com	td	f	\N	2026-09-08 19:29:19.409738+00
228	avocevouemmanuel5@gmail.com	td	f	\N	2026-09-08 19:29:23.093843+00
229	jealexhouegbe	admin	t	\N	2026-09-08 19:45:56.129496+00
230	leondomessi04@gmail.com	td	f	\N	2026-09-08 21:08:40.258439+00
231	dansoumika8@gmail.com	td	f	\N	2026-09-08 21:38:48.23217+00
232	dansoumika8@gmail.com	td	f	\N	2026-09-08 21:38:57.148777+00
233	dansoumika8@gmail.com	admin	f	\N	2026-09-08 21:39:31.557871+00
234	dansoumika8@gmail.com	td	f	\N	2026-09-08 21:39:46.724113+00
235	jealexhouegbe	admin	t	\N	2026-09-08 21:47:52.463031+00
236	armelnou@gmail.com	td	t	\N	2026-09-08 22:14:06.00525+00
237	merveilleahounhosse54@gmail.com	td	f	\N	2026-09-08 22:25:52.672299+00
238	merveilleahounhosse54@gmail.com	td	f	\N	2026-09-08 22:25:56.175885+00
239	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-08 22:26:48.945064+00
240	jealexhouegbe	admin	t	\N	2026-09-08 22:30:09.289323+00
241	jealexhouegbe	admin	t	\N	2026-09-08 22:52:19.34283+00
242	urielhouegbe	admin	t	\N	2026-09-08 23:11:07.788843+00
243	urielhouegbe	admin	t	\N	2026-09-08 23:19:03.20489+00
244	djossougermain0@gmail.com	td	f	\N	2026-09-09 06:06:59.794509+00
245	djossougermain0@gmail.com	td	f	\N	2026-09-09 06:08:13.159685+00
246	djossougermain0@gmail.com	admin	f	\N	2026-09-09 06:08:28.498005+00
247	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:51:23.743759+00
248	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:51:47.921389+00
249	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:51:52.103425+00
250	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:52:00.293561+00
251	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:52:12.493077+00
252	kouamitode@gmail.com	td	f	\N	2026-09-09 10:34:55.250854+00
253	kouamitode@gmail.com	td	f	\N	2026-09-09 10:35:04.24174+00
254	kouamitode@gmail.com	td	f	\N	2026-09-09 10:35:22.752607+00
255	kouamitode@gmail.com	td	f	\N	2026-09-09 10:35:37.942858+00
256	kouamitode@gmail.com	td	f	\N	2026-09-09 10:36:02.048456+00
257	charliehounkanrin@gmail.com	td	t	\N	2026-09-09 10:53:24.239277+00
258	devtesteur	admin	f	\N	2026-09-09 11:31:51.354306+00
259	devtesteur	admin	f	\N	2026-09-09 11:34:50.312325+00
260	devtesteur	admin	f	\N	2026-09-09 11:34:54.929069+00
261	devtesteur	admin	f	\N	2026-09-09 11:35:08.553843+00
262	devtesteur	admin	f	\N	2026-09-09 11:35:12.499136+00
263	devtesteur	admin	f	\N	2026-09-09 11:50:44.816197+00
264	admin	admin	f	\N	2026-09-09 11:51:00.386029+00
265	kouamitode@gmail.com	td	f	\N	2026-09-09 11:58:50.981479+00
266	maurienakouamitode@gmail.com	td	f	\N	2026-09-09 11:59:06.397397+00
267	kouamitode@gmail.com	td	f	\N	2026-09-09 12:00:51.097231+00
268	kouamitode@gmail.com	td	f	\N	2026-09-09 12:06:33.329401+00
269	jealexhouegbe	admin	t	\N	2026-09-09 12:14:28.441223+00
270	kouamitode@gmail.com	td	t	\N	2026-09-09 12:56:58.651341+00
271	urielhouegbe	admin	f	\N	2026-09-09 13:47:46.124369+00
272	urielhouegbe	admin	t	\N	2026-09-09 13:47:52.546863+00
273	jealexhouegbe	admin	t	\N	2026-09-09 14:19:25.970401+00
274	marianototin@gmail.com	td	f	\N	2026-09-09 15:02:11.282244+00
275	jealexhouegbe	admin	t	\N	2026-09-09 21:38:53.460259+00
276	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:15:51.041988+00
277	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:16:06.396019+00
278	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:17:16.093318+00
279	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:17:23.019062+00
280	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:17:26.490953+00
281	jealexhouegbe	admin	t	\N	2026-09-09 23:06:43.284138+00
282	jealexhouegbe	admin	t	\N	2026-09-10 04:42:41.325301+00
283	doskice@gmail.com	td	t	\N	2026-09-10 07:06:28.733203+00
284	jealexhouegbe	admin	t	\N	2026-09-11 09:24:14.722432+00
285	marianototin@gmail.com	td	t	\N	2026-09-11 10:37:46.184679+00
286	jealexhouegbe	admin	t	\N	2026-09-11 13:36:36.378006+00
287	urielhouegbe	admin	t	\N	2026-09-11 20:46:22.031152+00
288	jealexhouegbe	admin	t	\N	2026-09-11 21:12:40.316401+00
289	ferdinandagossou03@gmail.com	td	t	\N	2026-09-11 21:53:10.882861+00
290	jealexhouegbe	admin	t	\N	2026-09-11 21:55:52.370143+00
291	dkobahubert@gmail.com	td	t	\N	2026-09-11 22:59:56.564455+00
292	jealexhouegbe	admin	t	\N	2026-09-12 05:12:25.396241+00
293	jealexhouegbe	admin	t	\N	2026-09-12 07:45:33.760722+00
294	akakpoenock00@gmail.com	td	t	\N	2026-09-12 12:21:42.254294+00
295	charliehounkanrin@gmail.com	td	t	\N	2026-09-12 14:24:54.988704+00
296	jealexhouegbe	admin	t	\N	2026-09-12 16:15:34.441634+00
297	jealexhouegbe	admin	t	\N	2026-09-12 19:05:34.549037+00
298	jealexhouegbe	admin	t	\N	2026-09-12 20:04:08.867703+00
299	akakpoenock00@gmail.com	td	t	\N	2026-09-12 20:56:56.561324+00
300	jealexhouegbe	admin	t	\N	2026-09-12 21:04:23.479221+00
301	jealexhouegbe	admin	t	\N	2026-09-13 11:32:09.03945+00
302	jealexhouegbe	admin	t	\N	2026-09-13 13:03:41.064231+00
303	jealexhouegbe	admin	t	\N	2026-09-13 13:52:54.192683+00
304	jealexhouegbe	admin	t	\N	2026-09-13 14:26:06.236833+00
305	urielhouegbe	admin	t	\N	2026-09-13 15:56:07.699482+00
306	jealexhouegbe 	admin	f	\N	2026-09-13 16:26:05.307147+00
307	jealexhouegbe	admin	t	\N	2026-09-13 16:26:12.988548+00
308	jealexhouegbe 	admin	f	\N	2026-09-13 16:31:28.726433+00
309	jealexhouegbe	admin	t	\N	2026-09-13 16:31:36.489244+00
310	yetbaginn 	admin	f	\N	2026-09-13 16:35:06.743305+00
311	yetohoubago@gmail.com 	admin	f	\N	2026-09-13 16:35:30.116141+00
312	yetbaginn	admin	t	\N	2026-09-13 16:36:06.738423+00
313	jealexhouegbe	admin	t	\N	2026-09-13 16:36:56.725496+00
314	quenumparfait	admin	t	\N	2026-09-13 16:39:10.703296+00
315	yetbaginn	admin	t	\N	2026-09-13 16:39:53.692152+00
316	urielhouegbe	admin	t	\N	2026-09-13 16:41:44.983548+00
317	jealexhouegbe	admin	t	\N	2026-09-13 17:19:15.534746+00
318	urielhouegbe	admin	t	\N	2026-09-13 17:47:17.148192+00
319	jealexhouegbe	admin	t	\N	2026-09-13 17:47:19.098982+00
320	quenumparfait	admin	t	\N	2026-09-13 18:12:32.918547+00
321	quenumparfait	admin	t	\N	2026-09-13 18:16:38.374148+00
322	jealexhhouegbe	admin	f	\N	2026-09-13 20:02:32.822467+00
323	jealexhouegbe	admin	t	\N	2026-09-13 20:02:42.177757+00
324	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 20:30:35.311249+00
325	akakpoenock00@gmail.com	td	t	\N	2026-09-13 20:31:59.348786+00
326	mawougnongael91@gmail.com	td	t	\N	2026-09-13 20:33:06.080854+00
327	dkobahubert@gmail.com	td	t	\N	2026-09-13 20:33:42.268853+00
328	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 20:33:46.977433+00
329	aremouramziath@gmail.com	td	t	\N	2026-09-13 20:33:53.58636+00
330	degnonfrederics@gmail.com	td	t	\N	2026-09-13 20:35:11.689687+00
331	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 20:36:49.682391+00
332	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 20:41:12.730103+00
333	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 20:41:50.100314+00
334	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 20:42:24.201952+00
335	jucalhouegbe 	admin	f	\N	2026-09-13 20:45:27.687242+00
336	jucalhouegbe	admin	f	\N	2026-09-13 20:45:32.605097+00
337	jealexhouegbe	admin	t	\N	2026-09-13 20:45:50.82161+00
338	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 20:48:37.891842+00
339	aremouramziath@gmail.com	td	t	\N	2026-09-13 20:48:48.084567+00
340	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 21:07:01.327269+00
341	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 21:17:20.380237+00
342	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 21:18:15.281163+00
343	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 21:18:44.821227+00
344	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 21:41:56.968681+00
345	jealexhouegbe	admin	t	\N	2026-09-13 22:13:40.523994+00
346	jealexhouegbe	admin	t	\N	2026-09-14 02:27:36.209712+00
347	jealexhouegbe	admin	t	\N	2026-09-14 02:44:26.157679+00
348	jealexhouegbe	admin	t	\N	2026-09-14 02:49:47.585415+00
349	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 03:36:26.922808+00
350	jealexhouegbe	admin	t	\N	2026-09-14 06:22:12.335793+00
351	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 06:39:22.198635+00
352	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 06:44:36.316497+00
353	jealexhouegbe	admin	t	\N	2026-09-14 07:12:49.929187+00
354	aremouramziath@gmail.com	td	t	\N	2026-09-14 07:52:19.105004+00
355	faroukaremou5@gmail.com	td	t	\N	2026-09-14 07:54:04.214891+00
356	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 07:55:36.012683+00
357	akakpoenock00@gmail.com	td	t	\N	2026-09-14 07:56:35.097174+00
358	degnonfrederics@gmail.com	td	t	\N	2026-09-14 08:08:44.527587+00
359	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-14 08:19:18.429385+00
360	jealexhouegbe	admin	t	\N	2026-09-14 08:19:21.415706+00
361	carlosbokononhoui@gmail.com	td	t	\N	2026-09-14 08:23:11.992365+00
362	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-14 08:45:21.075536+00
363	florenthinnou@gmail.com	td	t	\N	2026-09-14 09:13:52.516397+00
364	mawougnongael91@gmail.com	td	t	\N	2026-09-14 10:13:28.644776+00
365	jealexhouegbe	admin	t	\N	2026-09-14 10:33:43.965177+00
366	jealexhouegbe	admin	t	\N	2026-09-14 10:38:18.2797+00
367	jealexhouegbe	admin	t	\N	2026-09-14 11:08:14.266565+00
368	jeremieabidegbekponou@gmail.com	td	f	\N	2026-09-14 12:01:35.712231+00
369	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-14 12:01:47.619401+00
370	quenumparfait	admin	f	\N	2026-09-14 12:01:50.036028+00
371	quenumparfait	admin	f	\N	2026-09-14 12:02:01.822162+00
372	quenumparfait	admin	f	\N	2026-09-14 12:02:13.043869+00
373	quenumparfait	admin	f	\N	2026-09-14 12:02:34.742982+00
374	faroukaremou5@gmail.com	td	t	\N	2026-09-14 12:21:03.294228+00
375	mawougnongael91@gmail.com	td	t	\N	2026-09-14 12:47:27.90147+00
376	aldolalumiere80@gmail.com	td	t	\N	2026-09-14 13:55:15.614228+00
377	jealexhouegbe	admin	t	\N	2026-09-14 15:02:06.658439+00
378	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 15:34:58.056752+00
379	dkobahubert@gmail.com	td	t	\N	2026-09-14 15:53:19.769044+00
380	dkobahubert@gmail.com	td	t	\N	2026-09-14 15:53:56.356312+00
381	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 16:48:16.378835+00
382	degnonfrederics@gmail.com	td	t	\N	2026-09-14 16:57:53.587037+00
383	degnonfrederics@gmail.com	td	t	\N	2026-09-14 16:58:59.135653+00
384	leopoldchangodele@gmail.com	td	t	\N	2026-09-14 17:00:41.548585+00
385	quenumparfait	admin	f	\N	2026-09-14 17:03:20.880275+00
386	quenumparfait	admin	f	\N	2026-09-14 17:04:05.021938+00
387	leopoldchangodele@gmail.com	td	t	\N	2026-09-14 17:05:14.402555+00
388	piomedesse@gmail.com	td	t	\N	2026-09-14 17:09:33.380343+00
389	faroukaremou5@gmail.com	td	t	\N	2026-09-14 17:13:25.125716+00
390	jealexhouegbe	admin	t	\N	2026-09-14 17:24:52.534823+00
391	degnonfrederics@gmail.com	td	f	\N	2026-09-14 18:15:21.955912+00
392	degnonfrederics@gmail.com	td	t	\N	2026-09-14 18:15:45.97897+00
393	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 19:16:54.251058+00
394	aldolalumiere80@gmail.com	td	t	\N	2026-09-14 19:59:18.513296+00
395	degnonfrederics@gmail.com	td	f	\N	2026-09-14 20:07:43.54482+00
396	degnonfrederics@gmail.com	td	t	\N	2026-09-14 20:08:12.950217+00
397	jealexhouegbe	admin	t	\N	2026-09-14 20:08:59.916574+00
398	akakpoenock00@gmail.com	td	t	\N	2026-09-14 20:25:45.539221+00
399	gedeonfinagnont@gmail.com	td	f	\N	2026-09-14 20:29:24.212008+00
400	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-14 20:29:56.162711+00
401	angekarson1@gmail.com	td	t	\N	2026-09-14 20:30:10.274982+00
402	leopoldchangodele@gmail.com	td	t	\N	2026-09-14 20:39:46.605144+00
403	jealexhouegbe	admin	t	\N	2026-09-14 20:44:59.542519+00
404	aldolalumiere80@gmail.com	td	t	\N	2026-09-14 20:54:46.695949+00
405	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:06.212954+00
406	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:16.180479+00
407	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:43.84361+00
408	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:55.789539+00
409	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:57:12.517721+00
410	zoutounnouf@gmail.com	td	t	\N	2026-09-14 21:24:39.426456+00
411	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:17.763746+00
412	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:32.558787+00
413	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:45.03107+00
414	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:54.291687+00
415	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:32:00.574816+00
416	louislucnou@gmail.com	td	t	\N	2026-09-14 21:34:28.667884+00
417	hounkponouhorus@gmail.com	td	t	\N	2026-09-14 21:51:07.715578+00
418	hounkponouhorus@gmail.com	td	t	\N	2026-09-14 21:51:38.507981+00
419	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:55:08.912686+00
420	claudekinninnon@gmail.com	td	t	\N	2026-09-14 22:20:04.702679+00
421	akakpoenock00@gmail.com	td	t	\N	2026-09-14 22:31:12.136727+00
422	akakpoenock00@gmail.com	td	t	\N	2026-09-14 22:31:14.213917+00
423	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-14 23:22:50.764148+00
424	jealexhouegbe	admin	t	\N	2026-09-14 23:23:43.072662+00
425	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:38:25.203824+00
426	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:38:48.274015+00
427	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:38:53.006946+00
428	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:39:10.161193+00
429	amankpemodeste761@gmail.com	td	t	\N	2026-09-15 00:39:35.540737+00
430	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 04:07:01.799311+00
431	jealexhouegbe	admin	t	\N	2026-09-15 04:56:34.935869+00
432	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-15 04:59:03.982198+00
433	degnonfrederics@gmail.com	td	f	\N	2026-09-15 05:08:47.078517+00
434	degnonfrederics@gmail.com	td	t	\N	2026-09-15 05:09:10.487664+00
435	akakpoenock00@gmail.com	td	t	\N	2026-09-15 05:27:01.58124+00
436	aremouramziath@gmail.com	td	t	\N	2026-09-15 05:39:19.151356+00
437	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 05:53:39.054546+00
438	louislucnou@gmail.com	td	t	\N	2026-09-15 06:00:45.081844+00
439	akakpoenock00@gmail.com	td	t	\N	2026-09-15 06:06:29.361792+00
440	jealexhouegbe	admin	t	\N	2026-09-15 06:08:34.872285+00
441	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 06:09:40.357533+00
442	akakpoenock00@gmail.com	td	t	\N	2026-09-15 06:10:01.633277+00
443	jealexhouegbe	admin	t	\N	2026-09-15 06:38:25.797637+00
444	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:11.29723+00
445	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:25.093319+00
446	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:43.038742+00
447	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:45.673678+00
448	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:48:15.905496+00
449	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 07:05:19.210638+00
450	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 07:05:44.8095+00
451	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:08:14.126559+00
452	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:08:29.266763+00
453	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:09:39.250525+00
454	jealexhouegbe	admin	t	\N	2026-09-15 07:09:47.267292+00
455	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:09:58.425099+00
456	akakpoenock00@gmail.com	td	t	\N	2026-09-15 07:12:29.200605+00
457	amankpemodeste761@gmail.com	td	t	\N	2026-09-15 07:28:12.147881+00
458	mawougnongael91@gmail.com	td	t	\N	2026-09-15 07:30:40.572581+00
459	akakpoenock00@gmail.com	td	t	\N	2026-09-15 07:33:41.146011+00
460	piomedesse@gmail.com	td	t	\N	2026-09-15 07:47:34.54749+00
802	jealexhouegbe	admin	t	\N	2026-09-24 00:31:57.016876+00
461	leopoldchangodele@gmail.com	td	t	\N	2026-09-15 08:00:08.413757+00
462	aremouramziath@gmail.com	td	t	\N	2026-09-15 08:04:56.646635+00
463	aremouramziath@gmail.com	td	t	\N	2026-09-15 08:09:40.444156+00
464	akakpoenock00@gmail.com	td	t	\N	2026-09-15 08:26:32.625503+00
465	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-15 08:27:18.535341+00
466	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-15 08:39:36.161849+00
467	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:41:26.81277+00
468	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:41:35.125522+00
469	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:42:00.524111+00
470	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:42:05.578068+00
471	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:42:30.051832+00
472	jealexhouegbe	admin	t	\N	2026-09-15 08:53:00.798155+00
473	aldolalumiere80@gmail.com	td	t	\N	2026-09-15 08:59:01.989166+00
474	sedodeconstant@gmail.com	td	t	\N	2026-09-15 09:05:49.196522+00
475	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 09:14:04.12642+00
476	degnonfrederics@gmail.com	td	f	\N	2026-09-15 09:16:40.101657+00
477	degnonfrederics@gmail.com	td	t	\N	2026-09-15 09:16:54.30772+00
478	claudekinninnon@gmail.com	td	t	\N	2026-09-15 09:26:30.168434+00
479	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:32:19.899545+00
480	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:32:25.211387+00
481	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:32:36.377973+00
482	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:36:09.17439+00
483	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:41:45.0129+00
484	jealexhouegbe	admin	t	\N	2026-09-15 09:49:38.81699+00
485	magbondejerome@gmail.com	admin	f	\N	2026-09-15 10:14:11.381824+00
486	magbondejerome@gmail.com	admin	f	\N	2026-09-15 10:14:34.715164+00
487	magbondejerome@gmail.com	admin	f	\N	2026-09-15 10:15:46.24324+00
488	magbondejerome@gmail.com	td	t	\N	2026-09-15 10:18:27.829812+00
489	faroukaremou5@gmail.com	td	t	\N	2026-09-15 10:19:57.850876+00
490	holonoubienvenu@gmail.com	td	t	\N	2026-09-15 10:21:28.390004+00
491	jealexhouegbe	admin	t	\N	2026-09-15 10:29:43.415169+00
492	holonoubienvenu@gmail.com	td	t	\N	2026-09-15 10:38:20.492+00
493	jealexhouegbe	admin	t	\N	2026-09-15 12:46:37.981173+00
494	florenthinnou@gmail.com	td	t	\N	2026-09-15 13:22:38.114858+00
495	aldolalumiere80@gmail.com	td	t	\N	2026-09-15 13:30:40.015791+00
496	florenthinnou@gmail.com	td	t	\N	2026-09-15 13:31:03.004454+00
497	jealexhouegbe	admin	t	\N	2026-09-15 17:15:21.820908+00
498	piomedesse@gmail.com	td	t	\N	2026-09-15 19:20:26.200688+00
499	simkiki30@gmail.com	td	t	\N	2026-09-15 20:01:36.169551+00
500	jealexhouegbe	admin	t	\N	2026-09-15 20:28:53.529723+00
501	piomedesse@gmail.com	td	t	\N	2026-09-15 20:34:14.08046+00
502	jealexhouegbe	admin	t	\N	2026-09-15 22:05:28.421328+00
503	degnonfrederics@gmail.com	td	t	\N	2026-09-15 22:35:18.00474+00
504	ferdinandagossou03@gmail.com	td	t	\N	2026-09-16 05:50:23.009355+00
505	jealexhouegbe	admin	t	\N	2026-09-16 05:54:01.306439+00
506	ferdinandagossou03@gmail.com	td	t	\N	2026-09-16 05:59:43.680547+00
507	kouamitode@gmail.com	td	t	\N	2026-09-16 06:34:18.896389+00
508	urielhouegbe	admin	t	\N	2026-09-16 06:47:28.534511+00
509	urielhouegbe	admin	t	\N	2026-09-16 07:19:56.141006+00
510	ferdinandagossou03@gmail.com	td	t	\N	2026-09-16 07:35:32.0397+00
511	jealexhouegbe	admin	t	\N	2026-09-16 07:44:53.897668+00
512	urielhouegbe	admin	t	\N	2026-09-16 08:38:24.625272+00
513	charliehounkanrin@gmail.com	td	t	\N	2026-09-16 09:05:00.595052+00
514	urielhouegbe	admin	t	\N	2026-09-16 12:38:59.529242+00
515	piomedesse@gmail.com	td	t	\N	2026-09-16 15:19:22.943976+00
516	akakpoenock00@gmail.com	td	t	\N	2026-09-16 15:54:17.422352+00
517	urielhouegbe	admin	t	\N	2026-09-16 16:51:58.420869+00
518	yessoufouassiath@gmail.com	td	f	\N	2026-09-16 21:08:55.763691+00
519	yessoufouassiath@gmail.com	td	f	\N	2026-09-16 21:09:03.15793+00
520	yessoufouassiath@gmail.com	td	f	\N	2026-09-16 21:10:13.965369+00
521	jealexhouegbe	admin	t	\N	2026-09-16 21:41:30.427353+00
522	urielhouegbe	admin	t	\N	2026-09-16 22:16:13.499436+00
523	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-16 22:37:03.384314+00
524	urielhouegbe	admin	t	\N	2026-09-17 00:21:52.699146+00
525	aldolalumiere80@gmail.com	td	t	\N	2026-09-17 05:09:51.625892+00
526	jealexhouegbe	admin	t	\N	2026-09-17 06:29:43.919173+00
527	jealexhouegbe	admin	t	\N	2026-09-17 07:13:48.070833+00
528	urielhouegbe	admin	t	\N	2026-09-17 08:41:20.920998+00
529	jealexhouegbe	admin	t	\N	2026-09-17 09:59:47.871253+00
530	yessoufouassiath@gmail.com	td	f	\N	2026-09-17 10:54:14.629609+00
531	yessoufouassiath@gmail.com	td	f	\N	2026-09-17 10:54:34.353802+00
532	yessoufouassiath@gmail.com	td	t	\N	2026-09-17 10:55:14.853525+00
533	jealexhouegbe	admin	t	\N	2026-09-17 10:57:34.035749+00
534	jealexhouegbe	admin	t	\N	2026-09-17 13:40:39.189304+00
535	jealexhouegbe	admin	t	\N	2026-09-17 14:14:39.533782+00
536	jealexhouegbe	admin	t	\N	2026-09-17 14:46:04.594068+00
537	urielhouegbe	admin	t	\N	2026-09-17 20:30:41.876733+00
538	urielhouegbe	admin	t	\N	2026-09-17 21:45:17.500877+00
539	urielhouegbe	admin	t	\N	2026-09-17 21:51:42.506607+00
540	jealexhouegbe	admin	t	\N	2026-09-17 22:17:26.964582+00
541	urielhouegbe	admin	t	\N	2026-09-17 22:56:07.356109+00
542	urielhouegbe	admin	t	\N	2026-09-17 22:57:53.68002+00
543	urielhouegbe	admin	t	\N	2026-09-18 00:38:26.097269+00
544	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 04:45:38.99622+00
545	urielhouegbe	admin	t	\N	2026-09-18 06:47:59.320793+00
546	urielhouegbe	admin	t	\N	2026-09-18 07:04:00.839454+00
547	urielhouegbe	admin	t	\N	2026-09-18 07:08:47.007735+00
548	faroukaremou5@gmail.com	td	t	\N	2026-09-18 08:31:36.95279+00
549	quenumparfait	admin	f	\N	2026-09-18 09:00:41.180427+00
550	quenumparfait	admin	f	\N	2026-09-18 09:00:50.080869+00
551	quenumparfait	admin	f	\N	2026-09-18 09:01:32.361146+00
552	quenumparfait	admin	f	\N	2026-09-18 09:01:42.120826+00
553	quenumparfait	admin	f	\N	2026-09-18 09:01:44.922874+00
554	jealexhouegbe	admin	t	\N	2026-09-18 09:09:50.880836+00
555	quenumparfait	admin	t	\N	2026-09-18 10:39:58.30649+00
556	quenumparfait	admin	t	\N	2026-09-18 11:38:37.272266+00
557	faroukaremou5@gmail.com	td	t	\N	2026-09-18 13:18:37.8919+00
558	viptomtogbe@gmail.com	td	t	\N	2026-09-18 15:40:07.82417+00
559	viptomtogbe@gmail.com	td	t	\N	2026-09-18 15:43:21.876298+00
560	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 16:13:11.609829+00
561	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 17:56:40.413214+00
562	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 17:58:27.453133+00
563	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 18:12:46.956095+00
564	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 18:18:54.503289+00
565	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 18:58:10.15049+00
566	ferdinandagossou03@gmail.com	td	t	\N	2026-09-18 19:17:00.736874+00
567	quenumparfait	admin	t	\N	2026-09-18 20:00:26.812911+00
568	jealexhouegbe	admin	t	\N	2026-09-18 20:09:43.264873+00
569	jealexhouegbe	admin	t	\N	2026-09-18 20:12:45.466909+00
570	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 20:16:11.676172+00
571	quenumparfait	admin	t	\N	2026-09-18 20:18:19.866688+00
572	quenumparfait	admin	t	\N	2026-09-18 20:26:52.878544+00
573	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-18 20:50:55.495249+00
574	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 21:46:01.408132+00
575	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 21:53:36.931866+00
576	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-18 21:57:47.330228+00
577	jealexhouegbe	admin	t	\N	2026-09-18 23:04:51.46287+00
578	quenumparfait	admin	t	\N	2026-09-19 00:00:36.673577+00
579	quenumparfait	admin	t	\N	2026-09-19 00:21:49.510363+00
580	quenumparfait	admin	t	\N	2026-09-19 00:23:52.178512+00
581	jealexhouegbe	admin	t	\N	2026-09-19 00:31:50.65233+00
582	jealexhouegbe	admin	t	\N	2026-09-19 03:59:08.55466+00
583	charliehounkanrin@gmail.com	td	t	\N	2026-09-19 05:13:46.631509+00
584	quenumparfait	admin	t	\N	2026-09-19 06:38:09.118844+00
585	mawougnongael91@gmail.com	td	t	\N	2026-09-19 07:20:34.268459+00
586	akakpoenock00@gmail.com	td	t	\N	2026-09-19 07:23:38.479629+00
587	degnonfrederics@gmail.com	td	f	\N	2026-09-19 07:25:46.266463+00
588	degnonfrederics@gmail.com	td	t	\N	2026-09-19 07:25:53.560794+00
589	quenumparfait	admin	t	\N	2026-09-19 08:00:09.485353+00
590	charliehounkanrin@gmail.com	td	t	\N	2026-09-19 08:37:12.55476+00
591	jealexhouegbe	admin	t	\N	2026-09-19 08:38:49.758004+00
592	urielhouegbe	admin	t	\N	2026-09-19 09:04:26.321409+00
593	quenumparfait	admin	t	\N	2026-09-19 09:05:39.215494+00
594	aremouramziath@gmail.com	td	t	\N	2026-09-19 09:16:13.106342+00
595	quenumparfait	admin	t	\N	2026-09-19 09:27:57.005945+00
596	padampierre@gmail.com	td	t	\N	2026-09-19 10:28:32.316665+00
597	degnonfrederics@gmail.com	td	t	\N	2026-09-19 10:29:27.90775+00
598	peter21	admin	f	\N	2026-09-19 10:30:12.207003+00
599	peter21	admin	f	\N	2026-09-19 10:30:53.983368+00
600	peter21	admin	f	\N	2026-09-19 10:31:07.742519+00
601	padampierre@gmail.com	admin	f	\N	2026-09-19 10:33:19.562825+00
602	peter21	admin	f	\N	2026-09-19 10:33:41.948272+00
603	peter21	admin	f	\N	2026-09-19 10:34:07.130362+00
604	Peter21	admin	f	\N	2026-09-19 10:35:40.955104+00
605	Peter21	admin	f	\N	2026-09-19 10:35:43.231535+00
606	Peter21	admin	t	\N	2026-09-19 10:37:43.441317+00
607	akakpoenock00@gmail.com	td	t	\N	2026-09-19 10:43:14.631566+00
608	faroukaremou5@gmail.com	td	t	\N	2026-09-19 11:16:01.096574+00
609	urielhouegbe	admin	t	\N	2026-09-19 12:09:18.502261+00
610	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-19 12:13:13.149981+00
611	aldolalumiere80@gmail.com	td	t	\N	2026-09-19 12:28:09.582062+00
612	piomedesse@gmail.com	td	t	\N	2026-09-19 13:14:00.904345+00
613	akakpoenock00@gmail.com	td	t	\N	2026-09-19 16:40:32.732899+00
614	degnonfrederics@gmail.com	td	f	\N	2026-09-19 17:21:51.549856+00
615	degnonfrederics@gmail.com	td	t	\N	2026-09-19 17:22:01.929853+00
616	faroukaremou5@gmail.com	td	t	\N	2026-09-19 19:01:29.538336+00
617	charliehounkanrin@gmail.com	td	t	\N	2026-09-19 22:18:55.475231+00
618	jealexhouegbe	admin	t	\N	2026-09-20 07:16:07.108822+00
619	jealexhouegbe	admin	t	\N	2026-09-20 07:46:23.200118+00
620	charliehounkanrin@gmail.com	td	t	\N	2026-09-20 09:20:50.362389+00
621	degnonfrederics@gmail.com	td	t	\N	2026-09-20 09:26:30.335328+00
622	akakpoenock00@gmail.com	td	t	\N	2026-09-20 09:43:15.088835+00
623	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 10:04:42.812199+00
624	viptomtogbe@gmail.com	td	t	\N	2026-09-20 10:14:26.174577+00
625	jealexhouegbe	admin	t	\N	2026-09-20 10:25:28.752378+00
626	kouamitode@gmail.com	td	t	\N	2026-09-20 11:11:52.362013+00
627	mawougnongael91@gmail.com	td	t	\N	2026-09-20 11:12:06.582752+00
628	jealexhouegbe	admin	t	\N	2026-09-20 11:13:14.247388+00
629	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 11:17:52.513866+00
630	leopoldchangodele@gmail.com	td	t	\N	2026-09-20 11:19:02.165555+00
631	viptomtogbe@gmail.com	td	t	\N	2026-09-20 11:28:23.259796+00
632	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-20 11:39:45.711076+00
633	kouamitode@gmail.com	td	t	\N	2026-09-20 11:43:27.187175+00
634	degnonfrederics@gmail.com	td	f	\N	2026-09-20 12:03:05.844224+00
635	degnonfrederics@gmail.com	td	t	\N	2026-09-20 12:03:15.505796+00
636	leopoldchangodele@gmail.com	td	t	\N	2026-09-20 13:00:34.422602+00
637	carlosbokononhoui@gmail.com	td	t	\N	2026-09-20 13:07:10.645152+00
638	carlosbokononhoui@gmail.com	td	t	\N	2026-09-20 13:07:58.626281+00
639	carlosbokononhoui@gmail.com	td	t	\N	2026-09-20 13:08:29.501287+00
640	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 13:20:12.064464+00
641	jealexhouegbe	admin	t	\N	2026-09-20 14:22:11.208248+00
642	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-20 15:26:03.210564+00
643	jealexhouegbe	admin	t	\N	2026-09-20 15:30:17.647904+00
644	charliehounkanrin@gmail.com	td	t	\N	2026-09-20 16:15:13.683793+00
645	jealexhouegbe	admin	t	\N	2026-09-20 18:18:43.699601+00
646	jealexhouegbe	admin	t	\N	2026-09-20 19:45:39.555992+00
647	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 19:51:41.88047+00
648	faroukaremou5@gmail.com	td	t	\N	2026-09-20 21:00:42.042149+00
649	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 22:37:49.158012+00
650	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 23:56:52.251064+00
651	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 04:22:31.521749+00
652	akakpoenock00@gmail.com	td	t	\N	2026-09-21 05:23:06.366007+00
653	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 06:13:18.383983+00
654	jealexhouegbe	admin	t	\N	2026-09-21 06:26:50.54392+00
655	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 07:00:00.648211+00
656	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 07:13:34.271488+00
657	mawougnongael91@gmail.com	td	t	\N	2026-09-21 07:55:33.183759+00
658	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:04:45.079888+00
659	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 08:14:18.613803+00
660	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:34:21.437383+00
661	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:35:11.537207+00
662	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 08:39:59.286978+00
663	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:48:32.101492+00
664	mawougnongael91@gmail.com	td	t	\N	2026-09-21 08:58:59.625854+00
665	faroukaremou5@gmail.com	td	t	\N	2026-09-21 08:59:59.218462+00
666	carlosbokononhoui@gmail.com	td	t	\N	2026-09-21 09:02:16.220066+00
667	jealexhouegbe	admin	t	\N	2026-09-21 09:08:54.273639+00
668	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-21 09:34:32.121988+00
669	hounkponouhorus@gmail.com	td	t	\N	2026-09-21 09:45:06.135643+00
670	kouamitode@gmail.com	td	t	\N	2026-09-21 09:45:12.439303+00
671	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-21 09:45:47.167143+00
672	akakpoenock00@gmail.com	td	t	\N	2026-09-21 09:47:21.026693+00
673	aremouramziath@gmail.com	td	t	\N	2026-09-21 09:48:21.872944+00
674	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 09:51:26.735023+00
675	florenthinnou@gmail.com	td	t	\N	2026-09-21 10:04:51.271533+00
676	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 10:09:28.002011+00
677	leopoldchangodele@gmail.com	td	t	\N	2026-09-21 10:28:35.84869+00
678	mawougnongael91@gmail.com	td	t	\N	2026-09-21 10:36:12.242166+00
679	jealexhouegbe	admin	t	\N	2026-09-21 10:45:07.11784+00
680	jealexhouegbe	admin	t	\N	2026-09-21 10:49:32.297775+00
681	viptomtogbe@gmail.com	td	t	\N	2026-09-21 11:07:58.662933+00
682	degnonfrederics@gmail.com	td	t	\N	2026-09-21 11:13:11.444998+00
683	amankpemodeste761@gmail.com	td	t	\N	2026-09-21 11:17:49.479503+00
684	dkobahubert@gmail.com	td	t	\N	2026-09-21 11:20:44.047378+00
685	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 11:21:16.539557+00
686	dkobahubert@gmail.com	td	t	\N	2026-09-21 11:21:21.748433+00
687	claudekinninnon@gmail.com	td	t	\N	2026-09-21 11:41:54.098608+00
688	ferdinandagossou03@gmail.com	td	t	\N	2026-09-21 11:50:41.465952+00
689	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-21 12:30:22.433864+00
690	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 12:40:55.292635+00
691	yessoufouassiath@gmail.com	td	t	\N	2026-09-21 13:05:48.106133+00
692	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 13:13:21.729536+00
693	jealexhouegbe	admin	t	\N	2026-09-21 13:18:40.859992+00
694	jealexhouegbe	admin	t	\N	2026-09-21 14:11:06.721033+00
695	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 14:42:58.312733+00
696	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 14:56:39.14915+00
697	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 15:15:47.540424+00
698	carlosbokononhoui@gmail.com	td	t	\N	2026-09-21 15:17:40.187382+00
699	akakpoenock00@gmail.com	td	t	\N	2026-09-21 15:39:40.373431+00
700	leopoldchangodele@gmail.com	td	t	\N	2026-09-21 15:44:21.905659+00
701	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-21 16:22:12.769817+00
702	amankpemodeste761@gmail.com	td	t	\N	2026-09-21 16:27:40.75787+00
703	piomedesse@gmail.com	td	t	\N	2026-09-21 17:07:10.13837+00
704	jealexhouegbe	admin	t	\N	2026-09-21 17:12:34.920753+00
705	mawougnongael91@gmail.com	td	t	\N	2026-09-21 18:11:19.886524+00
706	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 18:42:05.46564+00
707	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-21 18:48:39.820863+00
708	degnonfrederics@gmail.com	td	t	\N	2026-09-21 18:52:58.328667+00
709	yessoufouassiath@gmail.com	td	t	\N	2026-09-21 19:52:45.430887+00
710	carlosbokononhoui@gmail.com	td	t	\N	2026-09-21 19:55:40.372583+00
711	dkobahubert@gmail.com	td	t	\N	2026-09-21 20:31:29.86423+00
712	kouamitode@gmail.com	td	t	\N	2026-09-21 22:09:12.660567+00
713	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 22:31:38.480372+00
714	jealexhouegbe	admin	f	\N	2026-09-22 03:14:11.599391+00
715	jealexhouegbe	admin	t	\N	2026-09-22 03:14:33.387369+00
716	jealexhouegbe	admin	t	\N	2026-09-22 03:26:30.982668+00
717	jealexhouegbe	admin	t	\N	2026-09-22 05:22:14.787766+00
718	degnonfrederics@gmail.com	td	f	\N	2026-09-22 05:38:43.990037+00
719	degnonfrederics@gmail.com	td	t	\N	2026-09-22 05:39:10.651486+00
720	ghics2000@gmail.com	td	f	\N	2026-09-22 06:09:18.173894+00
721	ghics2000@gmail.com	td	f	\N	2026-09-22 06:09:59.31258+00
722	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:11:40.632043+00
723	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:14:20.146326+00
724	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:19:02.534852+00
725	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:22:07.507141+00
726	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:25:06.149431+00
727	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:25:39.658213+00
728	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:25:53.577016+00
729	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:26:32.421267+00
730	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:31:30.11526+00
731	yessoufouassiath@gmail.com	td	t	\N	2026-09-22 06:34:30.042176+00
732	urielhouegbe	admin	t	\N	2026-09-22 07:24:58.898319+00
733	jealexhouegbe	admin	t	\N	2026-09-22 07:47:41.045295+00
734	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 08:01:08.28837+00
735	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-22 08:08:21.264897+00
736	urielhouegbe	admin	t	\N	2026-09-22 08:50:12.028718+00
737	jealexhouegbe	admin	t	\N	2026-09-22 08:52:37.119133+00
738	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 09:29:14.665171+00
739	dkobahubert@gmail.com	td	t	\N	2026-09-22 09:33:38.516413+00
740	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:03.104267+00
741	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:07.792615+00
742	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:45.208212+00
743	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:48.903476+00
744	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 10:10:40.722216+00
745	degnonfrederics@gmail.com	td	f	\N	2026-09-22 10:58:42.525009+00
746	degnonfrederics@gmail.com	td	t	\N	2026-09-22 10:59:09.113603+00
747	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-22 11:08:16.963661+00
748	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 11:23:49.616765+00
749	dansoumika8@gmail.com	admin	f	\N	2026-09-22 11:33:22.085664+00
750	dansoumika8@gmail.com	admin	f	\N	2026-09-22 11:33:28.991237+00
751	dansoumika8@gmail.com	admin	f	\N	2026-09-22 11:33:46.389683+00
752	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:17:58.335261+00
753	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:18:12.163451+00
754	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:18:26.527632+00
755	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:18:55.406701+00
756	2026EN000063	admin	f	\N	2026-09-22 12:19:22.445348+00
757	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:19:42.527346+00
758	degnonfrederics@gmail.com	td	t	\N	2026-09-22 12:20:25.383561+00
759	aremouramziath@gmail.com	td	t	\N	2026-09-22 12:47:22.556455+00
760	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 12:52:56.858291+00
761	aremouramziath@gmail.com	td	t	\N	2026-09-22 13:01:04.007867+00
762	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 13:59:22.918114+00
763	dkobahubert@gmail.com	td	t	\N	2026-09-22 14:11:21.187369+00
764	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 14:38:03.947205+00
765	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 15:08:57.409302+00
766	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 15:48:28.05652+00
767	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 16:35:50.697029+00
768	jealexhouegbe	admin	t	\N	2026-09-22 16:45:38.54814+00
769	degnonfrederics@gmail.com	td	t	\N	2026-09-22 17:30:47.112596+00
770	jealexhouegbe	admin	t	\N	2026-09-22 18:09:47.271998+00
771	djossougermain0@gmail.com	td	t	\N	2026-09-22 18:38:55.690776+00
772	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-22 18:41:44.483811+00
773	degnonfrederics@gmail.com	td	t	\N	2026-09-22 18:44:54.511497+00
774	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 18:58:29.066525+00
775	piomedesse@gmail.com	td	t	\N	2026-09-22 19:06:18.95368+00
776	akakpoenock00@gmail.com	td	t	\N	2026-09-22 19:07:00.853812+00
777	dkobahubert@gmail.com	td	t	\N	2026-09-22 19:10:08.801389+00
778	leopoldchangodele@gmail.com	td	t	\N	2026-09-22 19:11:09.150577+00
779	holonoubienvenu@gmail.com	td	f	\N	2026-09-22 19:11:59.762983+00
780	holonoubienvenu@gmail.com	td	t	\N	2026-09-22 19:12:10.634667+00
781	holonoubienvenu@gmail.com	td	t	\N	2026-09-22 19:16:04.212906+00
782	amankpemodeste761@gmail.com	td	t	\N	2026-09-22 19:20:25.848577+00
783	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 19:23:46.007984+00
784	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-22 19:24:58.182638+00
785	degnonfrederics@gmail.com	td	t	\N	2026-09-22 19:29:34.514938+00
786	hounkponouhorus@gmail.com	td	t	\N	2026-09-22 19:29:51.574866+00
787	faroukaremou5@gmail.com	td	t	\N	2026-09-22 19:51:24.903828+00
788	dansoumika8@gmail.com	td	t	\N	2026-09-22 20:11:21.796009+00
789	dkobahubert@gmail.com	td	t	\N	2026-09-22 21:00:35.490529+00
790	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-22 21:05:55.069274+00
791	kouamitode@gmail.com	td	t	\N	2026-09-22 21:10:45.262108+00
792	mawougnongael91@gmail.com	td	t	\N	2026-09-22 21:48:05.230105+00
793	armelnou@gmail.com	td	t	\N	2026-09-22 21:52:33.28886+00
794	jealexhouegbe	admin	t	\N	2026-09-23 04:31:43.818535+00
795	degnonfrederics@gmail.com	td	t	\N	2026-09-23 04:56:17.839335+00
796	degnonfrederics@gmail.com	td	t	\N	2026-09-23 05:09:17.330679+00
797	jealexhouegbe	admin	t	\N	2026-09-23 05:45:15.42257+00
798	akakpoenock00@gmail.com	td	t	\N	2026-09-23 06:03:19.502578+00
799	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-23 06:48:42.105729+00
800	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-23 07:10:29.457729+00
801	charliehounkanrin@gmail.com	td	t	\N	2026-09-23 14:25:34.699875+00
803	jealexhouegbe	admin	t	\N	2026-09-24 07:37:52.805655+00
804	jealexhouegbe	admin	t	\N	2026-09-24 08:14:27.686267+00
805	louislucnou@gmail.com	td	t	\N	2026-09-24 08:44:52.59898+00
806	simkiki30@gmail.com	td	t	\N	2026-09-24 09:08:09.585531+00
807	jealexhouegbe	admin	t	\N	2026-09-24 10:15:35.802607+00
808	simkiki30@gmail.com	td	t	\N	2026-09-24 10:22:58.90969+00
809	simkiki30@gmail.com	td	t	\N	2026-09-24 10:31:28.519736+00
810	aldolalumiere80@gmail.com	td	t	\N	2026-09-24 12:18:42.486364+00
811	jealexhouegbe	admin	t	\N	2026-09-24 13:06:13.417248+00
812	jealexhouegbe	admin	t	\N	2026-09-24 14:39:52.763397+00
813	jealexhouegbe	admin	t	\N	2026-09-24 16:16:59.64551+00
814	aldolalumiere80@gmail.com	td	t	\N	2026-09-24 16:47:44.996481+00
815	leopoldchangodele@gmail.com	td	t	\N	2026-09-24 18:17:49.209922+00
816	jealexhouegbe	admin	t	\N	2026-09-24 22:13:25.45618+00
817	jealexhouegbe	admin	t	\N	2026-09-24 22:16:49.204616+00
818	aldolalumiere80@gmail.com	td	t	\N	2026-09-24 23:07:41.230018+00
819	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-25 09:08:51.182638+00
820	jealexhouegbe	admin	t	\N	2026-09-25 12:09:07.90138+00
821	louislucnou@gmail.com	td	t	\N	2026-09-25 12:37:31.165624+00
822	louislucnou@gmail.com	td	t	\N	2026-09-25 12:38:21.296757+00
823	jealexhouegbe	admin	t	\N	2026-09-25 12:38:44.399774+00
824	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-25 12:53:29.367939+00
825	jealexhouegbe	admin	t	\N	2026-09-25 13:14:08.016772+00
826	jealexhouegbe	admin	t	\N	2026-09-25 14:49:26.011764+00
827	jealexhouegbe	admin	t	\N	2026-09-25 15:51:19.591006+00
828	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-25 16:56:22.567264+00
829	jealexhouegbe	admin	t	\N	2026-09-25 17:06:01.75304+00
830	codjoabel00@gmail.com	td	t	\N	2026-09-25 17:20:49.126687+00
831	mawougnongael91@gmail.com	td	t	\N	2026-09-25 18:01:07.593248+00
832	quenumparfait	admin	f	\N	2026-09-25 18:13:54.792178+00
833	quenumparfait	admin	f	\N	2026-09-25 18:13:59.92519+00
834	quenumparfait	admin	f	\N	2026-09-25 18:14:08.645716+00
835	quenumparfait	admin	f	\N	2026-09-25 18:14:33.927259+00
836	jealexhouegbe	admin	t	\N	2026-09-25 18:27:03.960406+00
837	quenumparfait	admin	f	\N	2026-09-25 18:28:35.074759+00
838	jealexhouegbe	admin	t	\N	2026-09-25 18:28:49.355065+00
839	charliehounkanrin@gmail.com	td	t	\N	2026-09-25 19:23:58.175672+00
840	quenumparfait	admin	f	\N	2026-09-25 19:26:18.656304+00
841	jealexhouegbe	admin	t	\N	2026-09-25 20:43:54.857646+00
842	padampierre@gmail.com	admin	f	\N	2026-09-25 21:28:10.791936+00
843	padampierre@gmail.com	admin	f	\N	2026-09-25 21:30:25.117672+00
844	padampierre@gmail.com	admin	f	\N	2026-09-25 21:30:39.703394+00
845	peter21	admin	f	\N	2026-09-25 21:31:22.100499+00
846	peter21	admin	f	\N	2026-09-25 21:31:26.493751+00
847	peter21	admin	f	\N	2026-09-25 21:31:40.064108+00
848	jealexhouegbe	admin	t	\N	2026-09-25 21:38:58.22936+00
849	jealexhouegbe	admin	t	\N	2026-09-25 21:41:06.124744+00
850	aldolalumiere80@gmail.com	td	t	\N	2026-09-25 22:12:40.753467+00
851	jealexhouegbe	admin	t	\N	2026-09-25 22:23:50.77617+00
852	jealexhouegbe	admin	t	\N	2026-09-25 23:35:53.157482+00
853	jealexhouegbe	admin	t	\N	2026-09-26 00:25:49.017246+00
854	jealexhouegbe	admin	t	\N	2026-09-26 03:04:24.356975+00
855	quenumparfait	admin	t	\N	2026-09-26 06:13:57.159559+00
856	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-26 06:30:57.714532+00
857	degnonfrederics@gmail.com	td	t	\N	2026-09-26 06:47:04.50451+00
858	claudekinninnon@gmail.com	td	t	\N	2026-09-26 07:29:48.410028+00
859	quenumparfait	admin	t	\N	2026-09-26 08:03:04.631734+00
860	jealexhouegbe	admin	t	\N	2026-09-26 08:06:53.522833+00
861	padampierre@gmail.com	admin	f	\N	2026-09-26 08:07:00.338484+00
862	Peter21	admin	t	\N	2026-09-26 08:08:06.054818+00
863	Peter21	admin	t	\N	2026-09-26 08:08:26.189999+00
864	aldolalumiere80@gmail.com	td	t	\N	2026-09-26 09:05:57.011036+00
865	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-26 10:44:06.051618+00
866	leopoldchangodele@gmail.com	td	t	\N	2026-09-26 11:37:11.869333+00
867	amankpemodeste761@gmail.com	td	t	\N	2026-09-26 13:40:46.062941+00
868	jealexhouegbe	admin	t	\N	2026-09-26 14:25:59.16964+00
869	charliehounkanrin@gmail.com	td	t	\N	2026-09-26 16:14:26.982525+00
870	jealexhouegbe	admin	t	\N	2026-09-26 16:33:42.596611+00
871	andersondoliveira	admin	t	\N	2026-09-26 16:44:41.456664+00
872	aldolalumiere80@gmail.com	td	t	\N	2026-09-26 18:39:59.835207+00
873	aldolalumiere80@gmail.com	td	t	\N	2026-09-26 18:42:04.716285+00
874	simkiki30@gmail.com	td	t	\N	2026-09-26 18:49:04.722854+00
875	jealexhouegbe	admin	t	\N	2026-09-26 19:02:28.679927+00
876	charliehounkanrin@gmail.com	td	t	\N	2026-09-26 20:33:32.822187+00
877	charliehounkanrin@gmail.com	td	t	\N	2026-09-26 22:12:58.195429+00
878	holonoubienvenu@gmail.com	admin	f	\N	2026-09-26 23:46:30.7811+00
879	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 05:16:55.031397+00
880	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 05:36:35.298819+00
881	jealexhouegbe	admin	t	\N	2026-09-27 05:36:35.306872+00
882	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 06:35:17.471916+00
883	jealexhouegbe	admin	t	\N	2026-09-27 06:57:41.194654+00
884	aldolalumiere80@gmail.com	td	t	\N	2026-09-27 07:55:31.884613+00
885	Peter21	admin	t	\N	2026-09-27 08:16:31.87493+00
886	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 10:52:25.492249+00
887	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-27 11:17:23.5001+00
888	degnonfrederics@gmail.com	td	t	\N	2026-09-27 11:23:17.037678+00
889	jealexhouegbe	admin	t	\N	2026-09-27 12:34:52.405685+00
890	jealexhouegbe	admin	t	\N	2026-09-27 16:45:50.603129+00
891	piomedesse@gmail.com	td	t	\N	2026-09-27 18:05:31.600031+00
892	jealexhouegbe	admin	t	\N	2026-09-27 18:09:23.855996+00
893	jealexhouegbe	admin	t	\N	2026-09-27 21:40:15.921988+00
894	jealexhouegbe 	admin	f	\N	2026-09-28 02:22:55.23576+00
895	jealexhouegbe 	admin	f	\N	2026-09-28 02:44:44.808981+00
896	jealexhouegbe	admin	f	\N	2026-09-28 02:45:18.287681+00
897	jealexhouegbe	admin	t	\N	2026-09-28 02:46:00.466049+00
898	aremouramziath@gmail.com	td	t	\N	2026-09-28 07:06:43.914963+00
899	urielhouegbe	admin	t	\N	2026-09-28 07:25:15.949974+00
900	jealexhouegbe	admin	t	\N	2026-09-28 07:38:11.955329+00
901	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 08:12:13.456994+00
902	urielhouegbe	admin	t	\N	2026-09-28 08:21:55.313246+00
903	degnonfrederics@gmail.com	td	t	\N	2026-09-28 08:58:25.847896+00
904	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 09:12:27.397473+00
905	urielhouegbe	admin	t	\N	2026-09-28 09:25:30.589418+00
906	jealexhouegbe	admin	t	\N	2026-09-28 09:53:41.731619+00
907	jealexhouegbe	admin	t	\N	2026-09-28 10:10:01.437939+00
908	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 10:28:26.542615+00
909	jealexhouegbe	admin	t	\N	2026-09-28 10:33:40.5464+00
910	degnonfrederics@gmail.com	td	t	\N	2026-09-28 11:56:31.435797+00
911	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 11:57:11.462838+00
912	ghics2000@yahoo.fr	td	t	\N	2026-09-28 12:00:48.877366+00
913	jealexhouegbe	admin	t	\N	2026-09-28 12:04:33.242226+00
914	fauxence1994@gmail.com	td	f	\N	2026-09-28 12:05:11.606722+00
915	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-28 12:05:36.431875+00
916	aldolalumiere80@gmail.com	td	t	\N	2026-09-28 12:08:12.868778+00
917	amankpemodeste761@gmail.com	td	t	\N	2026-09-28 12:08:29.805651+00
918	viptomtogbe@gmail.com	td	t	\N	2026-09-28 12:10:42.977314+00
919	akakpoenock00@gmail.com	td	t	\N	2026-09-28 12:12:48.754333+00
920	ferdinandagossou03@gmail.com	td	t	\N	2026-09-28 12:15:26.424821+00
921	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:23:45.270668+00
922	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:24:08.864406+00
923	mawougnongael91@gmail.com	td	t	\N	2026-09-28 12:24:18.206716+00
924	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:24:28.598617+00
925	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:25:33.292107+00
926	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-28 12:26:29.310467+00
927	sedodeconstant@gmail.com	td	f	\N	2026-09-28 12:28:26.734464+00
928	sedodeconstant@gmail.com	td	t	\N	2026-09-28 12:29:09.728243+00
929	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-28 12:31:03.433319+00
930	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-28 12:39:47.6184+00
931	claudekinninnon@gmail.com	admin	f	\N	2026-09-28 12:49:51.237527+00
932	aremouramziath@gmail.com	td	t	\N	2026-09-28 12:49:59.997199+00
933	ferdinandagossou03@gmail.com	td	t	\N	2026-09-28 12:50:03.901876+00
934	claudekinninnon@gmail.com	td	t	\N	2026-09-28 12:54:16.042229+00
935	dkobahubert@gmail.com	td	t	\N	2026-09-28 13:10:24.005644+00
936	leopoldchangodele@gmail.com	td	t	\N	2026-09-28 13:21:45.277726+00
937	adjahocamille249@gmail.com	td	f	\N	2026-09-28 13:45:28.140341+00
938	jealexhouegbe	admin	t	\N	2026-09-28 13:48:31.834918+00
939	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-28 13:57:34.985237+00
940	jealexhouegbe	admin	t	\N	2026-09-28 14:23:35.930469+00
941	akakpoenock00@gmail.com	td	t	\N	2026-09-28 14:30:00.679238+00
942	leopoldchangodele@gmail.com	td	t	\N	2026-09-28 14:32:04.555936+00
943	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 14:52:40.972286+00
944	djossougermain0@gmail.com	td	t	\N	2026-09-28 15:13:41.885937+00
945	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-28 15:32:33.252928+00
946	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-28 15:59:59.422922+00
947	carlosbokononhoui@gmail.com	td	t	\N	2026-09-28 16:00:27.894438+00
948	carlosbokononhoui@gmail.com	td	t	\N	2026-09-28 16:00:40.769542+00
949	akakpoenock00@gmail.com	td	t	\N	2026-09-28 16:06:56.348371+00
950	jealexhouegbe	admin	t	\N	2026-09-28 16:15:57.454369+00
951	jealexhouegbe	admin	t	\N	2026-09-28 16:47:37.720738+00
952	piomedesse@gmail.com	td	t	\N	2026-09-28 16:56:41.308905+00
953	magbondejerome@gmail.com	td	t	\N	2026-09-28 17:00:30.19578+00
954	djossougermain0@gmail.com	td	t	\N	2026-09-28 17:04:22.09499+00
955	faroukaremou5@gmail.com	td	f	\N	2026-09-28 17:07:40.386422+00
956	faroukaremou5@gmail.com	td	t	\N	2026-09-28 17:08:41.253239+00
957	mawougnongael91@gmail.com	td	t	\N	2026-09-28 17:36:55.133281+00
958	ferdinandagossou03@gmail.com	td	t	\N	2026-09-28 17:46:38.897466+00
959	piomedesse@gmail.com	td	t	\N	2026-09-28 17:53:21.918739+00
960	magbondejerome@gmail.com	td	t	\N	2026-09-28 18:11:27.689911+00
961	holonoubienvenu@gmail.com	td	t	\N	2026-09-28 18:42:11.106318+00
962	simkiki30@gmail.com	td	t	\N	2026-09-28 19:16:07.972638+00
963	akakpoenock00@gmail.com	td	t	\N	2026-09-28 19:16:52.013134+00
964	simkiki30@gmail.com	td	t	\N	2026-09-28 19:19:38.978814+00
965	simkiki30@gmail.com	td	t	\N	2026-09-28 19:28:27.698074+00
966	simkiki30@gmail.com	td	t	\N	2026-09-28 20:01:55.680283+00
967	faroukaremou5@gmail.com	td	t	\N	2026-09-28 20:08:18.702277+00
968	florenthinnou@gmail.com	td	t	\N	2026-09-28 20:14:34.843304+00
969	piomedesse@gmail.com	td	t	\N	2026-09-28 21:19:18.922005+00
970	jealexhouegbe	admin	t	\N	2026-09-28 21:23:49.916652+00
971	aldolalumiere80@gmail.com	td	t	\N	2026-09-28 23:10:37.122487+00
972	mawougnongael91@gmail.com	td	t	\N	2026-09-28 23:23:47.467496+00
973	jealexhouegbe	admin	t	\N	2026-09-29 04:04:16.41575+00
974	faroukaremou5@gmail.com	td	t	\N	2026-09-29 04:23:04.252005+00
975	akakpoenock00@gmail.com	td	t	\N	2026-09-29 05:38:25.777566+00
976	jealexhouegbe	admin	t	\N	2026-09-29 06:01:06.793393+00
977	magbondejerome@gmail.com	td	t	\N	2026-09-29 06:22:20.391542+00
978	magbondejerome@gmail.com	td	t	\N	2026-09-29 06:24:22.577682+00
979	jealexhouegbe	admin	t	\N	2026-09-29 06:30:30.455479+00
980	marianototin@gmail.com	admin	f	\N	2026-09-29 06:35:16.285805+00
981	marianototin@gmail.com	admin	f	\N	2026-09-29 06:35:36.009177+00
982	marianototin@gmail.com	admin	f	\N	2026-09-29 06:35:43.592407+00
983	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-29 06:38:22.540984+00
984	charliehounkanrin@gmail.com	td	t	\N	2026-09-29 06:39:09.234493+00
985	amankpemodeste761@gmail.com	td	t	\N	2026-09-29 06:39:39.403209+00
986	marianototin@gmail.com	td	t	\N	2026-09-29 06:43:54.160939+00
987	ghics2000@yahoo.fr	td	t	\N	2026-09-29 06:44:52.995318+00
988	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-29 06:45:51.125232+00
989	ghics2000@yahoo.fr	td	t	\N	2026-09-29 06:46:33.556144+00
990	aremouramziath@gmail.com	td	t	\N	2026-09-29 06:50:53.408623+00
991	degnonfrederics@gmail.com	td	t	\N	2026-09-29 06:57:08.523945+00
992	akakpoenock00@gmail.com	td	t	\N	2026-09-29 07:02:13.669687+00
993	leopoldchangodele@gmail.com	td	t	\N	2026-09-29 07:04:22.636324+00
994	ferdinandagossou03@gmail.com	td	t	\N	2026-09-29 07:54:00.079497+00
995	urielhouegbe	admin	t	\N	2026-09-29 07:55:15.022187+00
996	dkobahubert@gmail.com	td	t	\N	2026-09-29 08:08:45.956821+00
997	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-29 08:11:06.565558+00
998	dkobahubert@gmail.com	td	t	\N	2026-09-29 08:18:52.816607+00
999	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-29 08:19:44.632297+00
1000	dansoumika8@gmail.com	td	t	\N	2026-09-29 08:22:20.287373+00
1001	charliehounkanrin@gmail.com	td	t	\N	2026-09-29 08:28:54.686968+00
1002	jealexhouegbe	admin	t	\N	2026-09-29 08:35:00.971902+00
1003	florenthinnou@gmail.com	td	t	\N	2026-09-29 08:55:47.156151+00
1004	djossougermain0@gmail.com	td	t	\N	2026-09-29 08:58:45.843733+00
1005	akakpoenock00@gmail.com	td	t	\N	2026-09-29 08:58:48.104826+00
1006	viptomtogbe@gmail.com	td	t	\N	2026-09-29 09:20:00.046595+00
1007	jealexhouegbe	admin	t	\N	2026-09-29 09:22:20.485908+00
1008	sedodeconstant@gmail.com	td	t	41.216.54.238	2026-09-29 10:28:45.622688+00
1009	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 10:36:34.101808+00
1010	angekarson1@gmail.com	admin	f	41.216.54.126	2026-09-29 10:54:45.480217+00
1011	angekarson1@gmail.com	admin	f	41.216.54.126	2026-09-29 10:54:54.497937+00
1012	angekarson1@gmail.com	admin	f	41.216.54.126	2026-09-29 10:55:02.819993+00
1013	HOUETO Olou Dayo Fabrice 	admin	f	41.216.54.126	2026-09-29 10:55:30.642258+00
1014	HOUETO Olou Dayo Fabrice 	admin	f	41.216.54.126	2026-09-29 10:55:40.834811+00
1015	degnonfrederics@gmail.com	td	f	102.202.111.199	2026-09-29 10:57:17.870737+00
1016	degnonfrederics@gmail.com	td	t	102.202.111.199	2026-09-29 10:57:31.058467+00
1017	carlosbokononhoui@gmail.com	td	t	154.72.112.20	2026-09-29 10:57:58.560853+00
1018	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 11:30:39.280162+00
1019	viptomtogbe@gmail.com	td	t	197.234.223.204	2026-09-29 11:34:12.089982+00
1020	degnonfrederics@gmail.com	td	t	102.202.111.191	2026-09-29 11:41:39.631229+00
1021	degnonfrederics@gmail.com	td	t	102.202.111.185	2026-09-29 11:46:53.171151+00
1022	bienvenuedou112@gmail.com	td	t	137.255.28.225	2026-09-29 12:35:54.188959+00
1023	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 12:43:23.46701+00
1024	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-09-29 12:43:55.571472+00
1025	bienvenuedou112@gmail.com	td	t	137.255.28.225	2026-09-29 12:55:06.919339+00
1026	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-29 13:07:08.376315+00
1027	yessoufouassiath@gmail.com	td	t	102.202.111.110	2026-09-29 13:15:18.509154+00
1028	degnonfrederics@gmail.com	td	t	102.202.111.129	2026-09-29 13:48:02.303913+00
1029	piomedesse@gmail.com	td	t	102.202.111.115	2026-09-29 15:04:37.741476+00
1030	piomedesse@gmail.com	td	t	102.202.111.115	2026-09-29 15:06:58.313464+00
1031	M. HOUETO 	admin	f	102.202.111.157	2026-09-29 16:06:03.674673+00
1032	M. HOUETO 	admin	f	102.202.111.157	2026-09-29 16:06:17.159998+00
1033	jealexhouegbe	admin	t	102.202.111.96	2026-09-29 16:56:33.169206+00
1034	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-09-29 17:10:02.732765+00
1035	angekarson1@gmail.com	td	t	41.216.53.139	2026-09-29 17:11:33.552724+00
1036	mawougnongael91@gmail.com	td	t	154.66.133.55	2026-09-29 17:34:00.517869+00
1037	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 17:42:26.849922+00
1038	piomedesse@gmail.com	td	t	154.72.113.17	2026-09-29 18:08:20.500522+00
1039	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 18:34:51.287348+00
1040	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 21:03:48.076475+00
1041	degnonfrederics@gmail.com	td	t	102.202.111.19	2026-09-29 21:43:20.013902+00
1042	akakpoenock00@gmail.com	td	t	41.85.167.73	2026-09-29 22:05:38.340018+00
1043	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 22:55:12.739169+00
1044	ferdinandagossou03@gmail.com	td	t	41.216.53.163	2026-09-29 23:10:53.490576+00
1045	jealexhouegbe	admin	t	154.66.142.115	2026-09-30 05:46:16.011542+00
1046	jealexhouegbe	admin	t	154.66.142.115	2026-09-30 06:20:47.630623+00
1047	bienvenuedou112@gmail.com	td	t	137.255.64.110	2026-09-30 07:16:25.866022+00
1048	bienvenuedou112@gmail.com	td	t	137.255.64.110	2026-09-30 07:20:45.327483+00
1049	jealexhouegbe	admin	t	154.66.142.115	2026-09-30 07:24:14.975305+00
1050	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-30 07:28:47.009343+00
1051	aldolalumiere80@gmail.com	td	t	197.234.223.235	2026-09-30 07:54:35.360188+00
1052	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-30 08:50:02.118825+00
1053	viptomtogbe@gmail.com	td	t	102.202.111.109	2026-09-30 11:02:37.198548+00
1054	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.30	2026-09-30 11:49:40.44796+00
1055	jealexhouegbe	admin	t	102.202.111.197	2026-09-30 12:00:25.995729+00
1056	piomedesse@gmail.com	td	t	102.202.111.215	2026-09-30 12:18:10.713659+00
1057	piomedesse@gmail.com	td	t	102.202.111.92	2026-09-30 12:34:37.632727+00
1058	marcepepe@gmail.com	td	t	41.138.91.163	2026-09-30 12:45:07.022253+00
1059	jealexhouegbe	admin	t	102.202.111.197	2026-09-30 12:46:36.679553+00
1060	marcepepe@gmail.com	td	t	41.138.91.163	2026-09-30 12:51:51.228897+00
1061	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-30 13:09:34.703728+00
1062	gedeonfintovitchede@gmail.com	td	t	41.85.163.244	2026-09-30 13:41:46.258743+00
1063	yessoufouassiath@gmail.com	td	t	102.202.111.50	2026-09-30 14:31:03.72259+00
1064	jealexhouegbe	admin	t	154.66.142.143	2026-09-30 14:33:31.496343+00
1065	yessoufouassiath@gmail.com	td	t	102.202.111.50	2026-09-30 14:38:19.364968+00
1066	nistani21@gmail.com	td	t	41.216.53.37	2026-09-30 14:45:49.060339+00
1067	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:46:10.969332+00
1068	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:46:54.694812+00
1069	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:54:22.513053+00
1070	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:54:35.045407+00
1071	jealexhouegbe	admin	t	154.66.142.143	2026-09-30 14:56:37.684629+00
1072	hotojules@gmail.com	td	t	41.216.54.91	2026-09-30 16:35:47.057553+00
1073	hotojules@gmail.com	td	f	41.216.54.91	2026-09-30 16:35:58.866363+00
1074	hotojules@gmail.com	td	f	41.216.54.91	2026-09-30 16:36:09.268705+00
1075	hotojules@gmail.com	td	f	41.216.54.91	2026-09-30 16:38:09.4865+00
1076	jealexhouegbe	admin	t	154.66.142.143	2026-09-30 16:46:52.608816+00
1077	hotojules@gmail.com	td	t	41.216.54.91	2026-09-30 16:48:54.066391+00
1078	bossouraoul82@gmail.com	td	t	41.138.89.222	2026-09-30 17:04:27.884109+00
1079	bossouraoul82@gmail.com	td	f	41.138.89.222	2026-09-30 17:05:36.404615+00
1080	bossouraoul82@gmail.com	td	f	41.138.89.222	2026-09-30 17:05:56.7929+00
1081	bossouraoul82@gmail.com	td	f	41.138.89.222	2026-09-30 17:06:21.107221+00
1082	bossouraoul82@gmail.com	td	t	41.138.89.222	2026-09-30 17:12:52.063283+00
1083	jeremieabidegbekponou@gmail.com	td	t	41.216.53.84	2026-09-30 18:36:27.04957+00
1084	degnonfrederics@gmail.com	td	t	197.234.219.136	2026-09-30 18:59:08.956023+00
1085	mawougnongael91@gmail.com	td	t	102.202.111.26	2026-09-30 19:28:45.162188+00
1086	louislucnou@gmail.com	td	t	102.202.111.158	2026-09-30 19:43:39.256769+00
1087	jealexhouegbe	admin	t	102.38.154.174	2026-09-30 21:34:40.265735+00
1088	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 03:12:33.618012+00
1089	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 03:59:27.980459+00
1090	nistani21@gmail.com	td	f	41.216.53.37	2026-10-01 04:34:17.234335+00
1091	nistani21@gmail.com	td	f	41.216.53.37	2026-10-01 04:34:34.976286+00
1092	nistani21@gmail.com	td	f	41.216.53.37	2026-10-01 04:36:52.061478+00
1093	nistani21@gmail.com	td	f	41.216.53.185	2026-10-01 04:40:50.653115+00
1094	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 04:41:20.990335+00
1095	nistani21@gmail.com	td	f	41.216.53.185	2026-10-01 04:41:26.533867+00
1096	nistani21@gmail.com	td	t	41.216.53.185	2026-10-01 04:45:06.614297+00
1097	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 05:47:16.155561+00
1098	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 08:00:24.15138+00
1099	leopoldchangodele@gmail.com	td	t	41.85.163.158	2026-10-01 08:27:46.192313+00
1100	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 08:28:47.96675+00
1101	amankpemodeste761@gmail.com	td	t	102.202.111.20	2026-10-01 08:33:41.369028+00
1102	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 09:20:57.503762+00
1103	ferdinandagossou03@gmail.com	td	t	41.85.163.107	2026-10-01 09:21:16.91992+00
1104	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 09:44:43.997461+00
1105	lucazandohounsi65@gmail.com	td	t	41.85.162.35	2026-10-01 11:27:50.686463+00
1106	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 11:53:00.787903+00
1107	gedeonfintovitchede@gmail.com	td	t	41.85.163.244	2026-10-01 12:41:46.320129+00
1108	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 12:51:07.910956+00
1109	lucazandohounsi65@gmail.com	td	t	41.85.162.35	2026-10-01 13:04:36.072975+00
1110	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 13:25:26.902587+00
1111	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 16:10:43.422594+00
1112	leopoldchangodele@gmail.com	td	t	197.234.219.245	2026-10-01 18:00:43.66035+00
1113	mawougnongael91@gmail.com	td	t	102.202.111.145	2026-10-01 20:31:18.842629+00
1114	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 20:36:32.257349+00
1115	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 20:38:09.527241+00
1116	gedeonfintovitchede@gmail.com	td	t	41.216.54.171	2026-10-01 22:26:42.104564+00
1117	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 09:01:32.351303+00
1118	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 10:39:23.679406+00
1119	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 12:20:37.020475+00
1120	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 12:47:07.248473+00
1121	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 13:11:44.914091+00
1122	leopoldchangodele@gmail.com	td	t	41.85.162.173	2026-10-02 13:22:07.606199+00
1123	jealexhouegbe	admin	t	102.202.111.236	2026-10-02 13:38:43.457981+00
1124	simkiki30@gmail.com	td	t	41.79.219.51	2026-10-02 15:19:03.40957+00
1125	urielaxelhouegbe@gmail.com	admin	f	102.215.138.253	2026-10-02 15:49:32.10139+00
1126	urielhouegbe	admin	t	102.215.138.253	2026-10-02 15:50:05.378861+00
1127	florenthinnou@gmail.com	td	t	41.85.163.192	2026-10-02 15:55:18.583028+00
1128	claudekinninnon@gmail.com	td	t	137.255.109.75	2026-10-02 16:00:39.061778+00
1129	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-02 18:32:22.720012+00
1130	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-02 18:34:02.611664+00
1131	ferdinandagossou03@gmail.com	td	t	41.85.163.226	2026-10-02 18:53:00.629351+00
1132	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-02 18:57:13.817202+00
1133	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-02 18:57:58.622073+00
1134	holonoubienvenu@gmail.com	td	t	41.216.54.249	2026-10-02 20:43:38.979221+00
1135	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-02 21:14:37.693336+00
1136	jeremieabidegbekponou@gmail.com	td	t	41.85.163.176	2026-10-02 22:14:29.402492+00
1137	jealexhouegbe	admin	t	154.66.138.55	2026-10-02 23:15:10.415599+00
1138	jealexhouegbe	admin	t	154.66.138.55	2026-10-03 00:10:18.548628+00
1139	urielhouegbe	admin	t	154.66.138.55	2026-10-03 00:39:43.641905+00
1140	leopoldchangodele@gmail.com	td	t	41.85.163.138	2026-10-03 01:56:09.460268+00
1141	urielhouegbe	admin	t	154.66.138.55	2026-10-03 02:47:12.235175+00
1142	jeremieabidegbekponou@gmail.com	td	t	41.85.162.207	2026-10-03 05:38:38.977445+00
1143	aremouramziath@gmail.com	td	t	41.85.163.68	2026-10-03 05:46:24.76686+00
1144	viptomtogbe@gmail.com	td	t	41.79.219.135	2026-10-03 06:11:39.083025+00
1145	viptomtogbe@gmail.com	td	t	41.79.219.135	2026-10-03 06:16:44.798254+00
1146	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.40	2026-10-03 06:16:45.462976+00
1147	quenumparfait	admin	t	41.85.162.115	2026-10-03 06:17:15.791457+00
1148	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-03 06:24:04.279511+00
1149	jealexhouegbe	admin	t	102.202.111.183	2026-10-03 06:39:31.968265+00
1150	quenumparfait	admin	t	41.216.54.89	2026-10-03 07:44:15.665691+00
1151	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 07:44:44.978292+00
1152	Peter21	admin	t	41.216.53.255	2026-10-03 08:09:31.010997+00
1153	quenumparfait	admin	t	41.216.53.109	2026-10-03 08:11:07.84098+00
1154	bienvenuedou112@gmail.com	td	t	102.202.111.147	2026-10-03 08:12:46.379127+00
1155	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 08:26:13.118554+00
1156	Peter21	admin	t	41.216.53.255	2026-10-03 08:50:25.907619+00
1157	bienvenuedou112@gmail.com	td	t	102.202.111.147	2026-10-03 09:04:18.757299+00
1158	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 09:23:12.606107+00
1159	Peter21	admin	t	41.216.53.255	2026-10-03 09:38:34.900232+00
1160	gedeonfintovitchede@gmail.com	td	t	41.85.162.137	2026-10-03 09:49:42.943375+00
1161	yetohoubago@gmail.com	td	f	156.0.213.149	2026-10-03 09:53:15.000708+00
1162	yetbaginn	admin	t	156.0.213.149	2026-10-03 09:55:51.535063+00
1163	charliehounkanrin@gmail.com	td	t	41.79.219.77	2026-10-03 10:21:24.526128+00
1164	leopoldchangodele@gmail.com	td	t	137.255.70.47	2026-10-03 10:45:00.319319+00
1165	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 11:45:29.681353+00
1166	gedeonfintovitchede@gmail.com	td	t	41.85.162.137	2026-10-03 11:52:50.820877+00
1167	amankpemodeste761@gmail.com	td	t	102.202.111.115	2026-10-03 12:17:58.486943+00
1168	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 12:29:24.84766+00
1169	akakpoenock00@gmail.com	td	t	197.234.223.199	2026-10-03 13:03:51.878018+00
1170	jealexhouegbe	admin	t	154.66.141.195	2026-10-03 13:41:30.823277+00
1171	leopoldchangodele@gmail.com	td	t	137.255.70.47	2026-10-03 14:25:11.873633+00
1172	ekponnatonjeanclaude@gmail.com	td	t	137.255.119.27	2026-10-03 14:41:12.525038+00
1173	andersondoliveira	admin	f	41.216.54.90	2026-10-03 15:49:38.955877+00
1174	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:22.309694+00
1175	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:25.939161+00
1176	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:38.343284+00
1177	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:49.607542+00
1178	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:51:01.115253+00
1179	jealexhouegbe	admin	f	154.66.141.195	2026-10-03 15:54:07.304356+00
1180	jealexhouegbe	admin	t	154.66.141.195	2026-10-03 15:54:33.393734+00
1181	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:38:29.989066+00
1182	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:40:00.727379+00
1183	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:45:18.560868+00
1184	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:45:21.784251+00
1185	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:47:09.092983+00
1186	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:48:43.116249+00
1187	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:53:01.622844+00
1188	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:55:06.33359+00
1189	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:56:23.99427+00
1190	andersondoliveira	admin	f	41.216.54.90	2026-10-03 16:57:24.61667+00
1191	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:58:07.449872+00
1192	andersondoliveira	admin	f	41.216.54.90	2026-10-03 16:58:07.931544+00
1193	Nabildoliveira	admin	f	41.216.54.90	2026-10-03 17:03:23.633994+00
1194	Nabildoliveira	admin	f	41.216.54.90	2026-10-03 17:03:55.72538+00
1195	nabildoliveira	admin	f	41.216.54.90	2026-10-03 17:04:15.927012+00
1196	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-03 21:14:20.062173+00
1197	gedeonfintovitchede@gmail.com	td	t	41.85.163.120	2026-10-03 21:33:40.314278+00
1198	magbondejerome@gmail.com	td	f	154.72.113.115	2026-10-03 22:24:50.884284+00
1199	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-03 22:25:07.672002+00
1200	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-04 03:59:19.836867+00
1201	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 04:26:36.641694+00
1202	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 05:05:22.829331+00
1203	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-04 05:45:50.635584+00
1204	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 07:45:04.226885+00
1205	bienvenuedou112@gmail.com	td	t	102.202.111.142	2026-10-04 07:59:45.679234+00
1206	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-04 08:00:24.531248+00
1207	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-04 08:02:07.104253+00
1208	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 08:33:09.063368+00
1209	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 09:12:29.547465+00
1210	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 10:19:08.686502+00
1211	bossouraoul82@gmail.com	td	t	41.138.89.155	2026-10-04 10:42:47.52612+00
1212	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-04 11:16:19.721013+00
1213	piomedesse@gmail.com	td	t	154.72.113.17	2026-10-04 11:33:24.535432+00
1214	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 11:38:54.641225+00
1215	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-04 12:44:01.158432+00
1216	charliehounkanrin@gmail.com	td	t	197.234.219.194	2026-10-04 13:33:19.894997+00
1217	jealexhouegbe	admin	t	102.202.111.106	2026-10-04 14:28:47.279936+00
1218	faroukaremou5@gmail.com	td	t	197.234.219.224	2026-10-04 15:42:06.412234+00
1219	dkobahubert@gmail.com	td	t	102.202.111.197	2026-10-04 17:31:48.467067+00
1220	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-04 17:32:27.794926+00
1221	akakpoenock00@gmail.com	td	t	137.255.134.243	2026-10-04 17:59:25.848947+00
1222	akakpoenock00@gmail.com	td	t	137.255.134.243	2026-10-04 18:27:43.47445+00
1223	mawougnongael91@gmail.com	td	t	197.234.219.129	2026-10-04 19:13:19.56934+00
1224	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 19:48:13.886396+00
1225	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-04 20:12:07.010956+00
1226	hotojules@gmail.com	td	t	41.85.162.167	2026-10-04 20:31:12.989849+00
1227	leopoldchangodele@gmail.com	td	t	41.85.162.194	2026-10-04 20:40:37.056035+00
1228	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-04 21:08:31.237202+00
1229	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 21:44:32.570018+00
1230	amankpemodeste761@gmail.com	td	t	102.202.111.95	2026-10-04 22:36:20.434218+00
1231	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 00:16:43.952211+00
1232	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 02:51:37.010269+00
1233	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 06:57:36.328005+00
1234	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:08:33.950839+00
1235	akakpoenock00@gmail.com	td	t	197.234.219.228	2026-10-05 07:29:07.794312+00
1236	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:32:21.273252+00
1237	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:33:12.449231+00
1238	amankpemodeste761@gmail.com	td	t	102.202.111.95	2026-10-05 07:48:06.339221+00
1239	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:48:21.538355+00
1240	leopoldchangodele@gmail.com	td	t	137.255.186.214	2026-10-05 07:52:03.921681+00
1241	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-05 07:56:32.676646+00
1242	florenthinnou@gmail.com	td	t	41.85.163.250	2026-10-05 08:03:01.160886+00
1243	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:00.643661+00
1244	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:09.474723+00
1245	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:31.708826+00
1246	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:38.493202+00
1247	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:47.615135+00
1248	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 08:05:46.233887+00
1249	mawougnongael91@gmail.com	td	t	197.234.219.214	2026-10-05 08:06:37.585452+00
1250	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 08:19:06.364547+00
1251	carlosbokononhoui@gmail.com	td	t	102.202.111.43	2026-10-05 08:19:58.729016+00
1252	piomedesse@gmail.com	td	t	102.202.111.173	2026-10-05 08:21:07.058444+00
1253	Sedodeconstant@gmail.com 	admin	f	102.202.111.244	2026-10-05 08:31:15.192955+00
1254	Sedodeconstant@gmail.com 	admin	f	102.202.111.244	2026-10-05 08:32:08.926894+00
1255	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:33:09.919101+00
1256	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:35:25.254177+00
1257	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:35:34.391453+00
1258	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:36:31.12604+00
1259	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 08:41:21.026707+00
1260	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 08:45:30.160547+00
1261	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:48:48.377639+00
1262	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:49:01.38347+00
1263	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-05 08:52:16.631181+00
1264	gedeonfintovitchede@gmail.com	td	t	197.234.219.155	2026-10-05 08:53:26.297354+00
1265	sedodeconstant@gmail.com	td	t	154.66.141.195	2026-10-05 08:56:18.520952+00
1266	sedodeconstant@gmail.com	td	f	154.66.141.195	2026-10-05 08:57:06.79749+00
1267	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 09:01:23.255301+00
1268	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:03:16.565399+00
1269	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:03:25.962472+00
1270	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:04:13.337169+00
1271	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:05:21.589525+00
1272	viptomtogbe@gmail.com	td	t	41.216.54.44	2026-10-05 09:11:19.247147+00
1273	gedeonfintovitchede@gmail.com	td	t	197.234.219.155	2026-10-05 09:19:13.247309+00
1274	nistani21@gmail.com	td	t	137.255.53.254	2026-10-05 09:24:09.530115+00
1275	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 09:27:28.172528+00
1276	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 09:32:02.432105+00
1277	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 09:34:02.520194+00
1278	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 09:34:41.599843+00
1279	sedodeconstant@gmail.com 	admin	f	102.202.111.231	2026-10-05 09:57:56.800918+00
1280	sedodeconstant@gmail.com 	admin	f	102.202.111.231	2026-10-05 09:58:20.837906+00
1281	sedodeconstant@gmail.com	td	t	102.202.111.139	2026-10-05 10:03:55.955969+00
1282	ekponnatonjeanclaude@gmail.com	td	t	137.255.28.252	2026-10-05 10:06:39.222629+00
1283	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 10:22:25.833368+00
1284	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 10:26:25.703564+00
1285	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 10:42:26.78937+00
1286	aldolalumiere80@gmail.com	td	t	41.79.219.209	2026-10-05 10:48:31.359631+00
1287	faroukaremou5@gmail.com	td	t	197.234.219.242	2026-10-05 10:55:04.627468+00
1288	amankpemodeste761@gmail.com	td	t	102.202.111.95	2026-10-05 10:56:13.386974+00
1289	lucazandohounsi65@gmail.com	td	t	41.85.162.79	2026-10-05 11:01:12.321838+00
1290	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 11:05:00.964383+00
1291	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:09:52.783606+00
1292	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 11:10:12.10213+00
1293	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 11:10:14.324596+00
1294	leopoldchangodele@gmail.com	td	t	137.255.112.187	2026-10-05 11:12:51.048224+00
1295	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:15:19.6002+00
1296	ekponnatonjeanclaude@gmail.com	td	t	137.255.28.252	2026-10-05 11:22:39.336926+00
1297	mawougnongael91@gmail.com	td	t	197.234.219.214	2026-10-05 11:24:31.199932+00
1298	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 11:28:05.6044+00
1299	claudekinninnon@gmail.com	td	t	137.255.144.192	2026-10-05 11:29:48.756138+00
1300	urielhouegbe	admin	t	154.66.141.195	2026-10-05 11:32:13.625871+00
1301	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-05 11:33:23.39249+00
1302	MAGBONDEJEROME@GMAIL.COM	parent	f	154.72.113.115	2026-10-05 11:35:12.436228+00
1303	degnonfrederics@gmail.com	td	t	102.202.111.71	2026-10-05 11:35:34.179337+00
1304	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 11:35:42.165183+00
1305	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 11:36:35.127713+00
1306	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:41:06.114122+00
1307	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:43:50.898892+00
1308	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:45:25.625486+00
1309	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 11:49:49.978701+00
1310	leopoldchangodele@gmail.com	td	t	137.255.112.187	2026-10-05 11:52:29.862782+00
1311	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 12:02:34.260154+00
1312	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 12:07:33.790546+00
1313	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 12:08:56.499903+00
1314	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 12:31:09.178885+00
1315	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 12:48:08.520067+00
1316	nistani21@gmail.com	td	t	41.216.54.151	2026-10-05 13:15:09.957654+00
1317	akakpoenock00@gmail.com	td	t	197.234.219.207	2026-10-05 13:15:21.609675+00
1318	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 14:51:19.240467+00
1319	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 15:07:03.450301+00
1320	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 15:12:08.387495+00
1321	carlosbokononhoui@gmail.com	td	t	137.255.105.28	2026-10-05 15:24:33.363892+00
1322	faroukaremou5@gmail.com	td	t	154.72.113.193	2026-10-05 16:04:04.911536+00
1323	bossouraoul82@gmail.com	td	t	41.138.89.153	2026-10-05 16:18:51.959919+00
1324	gedeonfintovitchede@gmail.com	td	t	41.85.163.172	2026-10-05 16:30:25.7722+00
1325	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 16:42:37.971549+00
1326	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 16:54:09.872957+00
1327	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 17:38:57.494612+00
1328	leopoldchangodele@gmail.com	td	t	197.234.219.145	2026-10-05 17:55:12.123674+00
1329	piomedesse@gmail.com	td	t	154.72.113.17	2026-10-05 18:03:25.543839+00
1330	degnonfrederics@gmail.com	td	t	102.202.111.211	2026-10-05 18:07:10.922897+00
1331	aremouramziath@gmail.com	td	t	41.216.54.253	2026-10-05 18:22:29.618729+00
1332	simkiki30@gmail.com	td	t	41.79.219.30	2026-10-05 18:22:43.577615+00
1333	akakpoenock00@gmail.com	td	t	137.255.151.168	2026-10-05 18:55:46.301118+00
1334	akakpoenock00@gmail.com	td	t	137.255.151.168	2026-10-05 19:20:39.43176+00
1335	claudekinninnon@gmail.com	td	t	102.202.111.93	2026-10-05 19:21:03.780571+00
1336	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-05 19:25:50.360661+00
1337	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-05 19:36:12.836868+00
1338	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-05 19:36:37.627979+00
1339	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-05 19:37:23.923742+00
1340	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 20:28:15.125467+00
1341	urielhouegbe	admin	t	154.66.141.195	2026-10-05 20:52:59.787978+00
1342	urielhouegbe	admin	t	154.66.141.195	2026-10-05 21:19:46.32682+00
1343	viptomtogbe@gmail.com	td	t	102.202.111.9	2026-10-05 21:34:51.724428+00
1344	urielhouegbe	admin	t	154.66.141.195	2026-10-05 21:36:48.417476+00
1345	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-05 21:49:20.158843+00
1346	djossougermain0@gmail.com	td	t	102.202.111.29	2026-10-05 22:23:37.788469+00
1347	urielhouegbe	admin	t	154.66.141.195	2026-10-05 22:43:54.97459+00
1348	urielhouegbe	admin	t	154.66.141.195	2026-10-05 23:19:03.56364+00
1349	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 03:00:08.578906+00
1350	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 04:24:33.697238+00
1351	akakpoenock00@gmail.com	td	t	137.255.151.168	2026-10-06 04:59:16.805699+00
1352	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 05:54:38.724794+00
1353	faroukaremou5@gmail.com	td	t	102.202.111.40	2026-10-06 06:52:59.548813+00
1354	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 07:05:07.252308+00
1355	sedodeconstant@gmail.com	admin	f	102.202.111.243	2026-10-06 07:48:19.278403+00
1356	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 07:49:28.250372+00
1357	sedodeconstant@gmail.com	td	t	102.202.111.243	2026-10-06 07:49:41.865767+00
1358	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 07:50:35.381888+00
1359	sedodeconstant@gmail.com	td	t	102.202.111.243	2026-10-06 07:50:56.452258+00
1360	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-06 08:04:29.649518+00
1361	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-06 08:05:22.459795+00
1362	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 08:29:14.548701+00
1363	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 08:34:13.183061+00
1364	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 08:41:14.163439+00
1365	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-06 08:52:07.711522+00
1366	gedeonfintovitchede@gmail.com	td	t	41.85.162.148	2026-10-06 09:08:30.213392+00
1367	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 09:13:54.561495+00
1368	degnonfrederics@gmail.com	td	t	102.202.111.217	2026-10-06 09:14:09.462753+00
1369	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 09:19:50.91596+00
1370	faroukaremou5@gmail.com	td	t	197.234.219.248	2026-10-06 09:26:06.077575+00
1371	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 10:19:54.446062+00
1372	ferdinandagossou03@gmail.com	td	t	41.85.162.91	2026-10-06 10:24:41.749936+00
1373	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 10:34:53.9726+00
1374	marianototin@gmail.com	td	t	102.202.111.83	2026-10-06 11:15:06.500989+00
1375	urielhouegbe	admin	t	154.66.141.195	2026-10-06 11:24:58.769558+00
1376	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.96	2026-10-06 11:30:55.293362+00
1377	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 11:53:16.041718+00
1378	mawougnongael91@gmail.com	td	t	154.72.113.130	2026-10-06 12:02:18.784397+00
1379	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 12:09:14.196858+00
1380	faroukaremou5@gmail.com	td	t	154.72.113.193	2026-10-06 12:19:25.853768+00
1381	urielhouegbe	admin	t	154.66.141.195	2026-10-06 12:23:48.109138+00
1382	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-06 12:24:19.850754+00
1383	amankpemodeste761@gmail.com	td	t	102.202.111.6	2026-10-06 12:55:38.366903+00
1384	leopoldchangodele@gmail.com	td	t	137.255.20.35	2026-10-06 14:08:02.675025+00
1385	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 14:11:35.355438+00
1386	angekarson1@gmail.com	td	t	41.216.53.94	2026-10-06 15:22:52.781101+00
1387	jealexhouegbe	admin	t	102.202.111.77	2026-10-06 16:37:22.737328+00
1388	holonoubienvenu@gmail.com	td	t	41.216.54.93	2026-10-06 16:45:48.913016+00
1389	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 18:12:41.639193+00
1390	akakpoenock00@gmail.com	td	t	197.234.219.207	2026-10-06 18:14:57.924687+00
1391	hotojules@gmail.com	td	t	41.216.54.148	2026-10-06 18:29:34.213241+00
1392	jealexhouegbe	admin	t	102.202.111.77	2026-10-06 19:18:25.449373+00
1393	jealexhouegbe	admin	t	102.202.111.77	2026-10-06 20:21:55.879355+00
1394	lucazandohounsi65@gmail.com	td	t	154.72.113.64	2026-10-06 20:36:30.598231+00
1395	jealexhouegbe	admin	t	102.202.111.51	2026-10-06 20:53:54.971938+00
1396	charliehounkanrin@gmail.com	td	t	197.234.219.200	2026-10-06 21:20:51.446111+00
1397	akakpoenock00@gmail.com	td	t	41.85.168.176	2026-10-06 23:34:58.961158+00
1398	jealexhouegbe	admin	t	154.66.142.100	2026-10-07 00:32:17.622824+00
1399	jealexhouegbe	admin	t	154.66.142.100	2026-10-07 01:30:16.651401+00
1400	charliehounkanrin@gmail.com	td	t	137.255.161.57	2026-10-07 05:59:44.844015+00
1401	jealexhouegbe	admin	t	102.202.111.51	2026-10-07 06:04:24.364367+00
1402	akakpoenock00@gmail.com	td	t	41.85.168.176	2026-10-07 06:06:59.728129+00
1403	akakpoenock00@gmail.com	td	t	197.234.219.203	2026-10-07 07:07:19.533526+00
1404	aremouramziath@gmail.com	td	t	41.216.54.253	2026-10-07 07:22:32.572046+00
1405	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-07 07:29:24.730677+00
1406	jealexhouegbe	admin	t	102.215.137.220	2026-10-07 07:44:10.682611+00
1407	faroukaremou5@gmail.com	td	t	197.234.219.156	2026-10-07 08:58:55.013243+00
1408	bienvenuedou112@gmail.com	td	t	137.255.161.57	2026-10-07 09:08:45.592616+00
1409	bienvenuedou112@gmail.com	td	t	137.255.161.57	2026-10-07 09:10:09.061236+00
1410	viptomtogbe@gmail.com	td	t	41.85.163.40	2026-10-07 10:15:52.421052+00
1411	dkobahubert@gmail.com	td	t	137.255.20.136	2026-10-07 10:32:55.910404+00
1412	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-07 11:22:21.114992+00
1413	ferdinandagossou03@gmail.com	td	t	41.85.162.194	2026-10-07 12:56:00.178382+00
1414	charliehounkanrin@gmail.com	td	t	197.234.219.216	2026-10-07 13:09:59.116781+00
1415	ferdinandagossou03@gmail.com	td	f	41.85.162.194	2026-10-07 13:16:02.359913+00
1416	ferdinandagossou03@gmail.com	td	t	41.85.162.194	2026-10-07 13:16:17.111622+00
1417	charliehounkanrin@gmail.com	td	t	197.234.219.225	2026-10-07 13:23:51.277957+00
1418	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-07 15:01:05.382204+00
1419	claudekinninnon@gmail.com	td	t	102.202.111.111	2026-10-07 15:12:19.771433+00
1420	akakpoenock00@gmail.com	td	t	197.234.219.203	2026-10-07 16:00:34.147321+00
1421	akakpoenock00@gmail.com	td	t	197.234.219.203	2026-10-07 17:02:16.163331+00
1422	bossouraoul82@gmail.com	td	t	41.138.90.87	2026-10-07 17:29:54.081524+00
1423	faroukaremou5@gmail.com	td	t	197.234.219.156	2026-10-07 17:58:00.401586+00
1424	florenthinnou@gmail.com	td	t	41.216.54.159	2026-10-07 18:37:02.219999+00
1425	charliehounkanrin@gmail.com	td	t	197.234.223.213	2026-10-07 19:29:14.829933+00
1426	jealexhouegbe	admin	t	41.79.217.109	2026-10-07 20:01:54.4158+00
1427	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-07 20:05:19.415406+00
1428	yessoufouassiath@gmail.com	td	t	102.202.111.56	2026-10-07 20:34:10.055686+00
1429	charliehounkanrin@gmail.com	td	t	197.234.223.213	2026-10-07 20:39:22.831324+00
1430	faroukaremou5@gmail.com	td	t	102.202.111.198	2026-10-07 20:48:31.359609+00
1431	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-07 21:05:05.473318+00
1432	faroukaremou5@gmail.com	td	t	102.202.111.198	2026-10-08 04:50:09.180557+00
1433	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 05:53:46.760589+00
1434	urielhouegbe	admin	t	41.85.162.154	2026-10-08 06:08:54.798362+00
1435	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-08 06:46:17.67669+00
1436	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-08 06:46:39.409512+00
1437	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-08 07:12:16.259842+00
1438	leopoldchangodele@gmail.com	td	t	41.216.54.198	2026-10-08 07:45:39.668491+00
1439	charliehounkanrin@gmail.com	td	t	197.234.219.147	2026-10-08 07:53:01.987687+00
1440	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 08:31:18.160361+00
1441	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 09:08:06.415051+00
1442	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 10:48:34.235521+00
1443	florenthinnou@gmail.com	td	t	41.216.54.240	2026-10-08 11:15:01.099106+00
1444	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 12:04:17.891288+00
1445	gedeonfintovitchede@gmail.com	td	t	41.216.54.9	2026-10-08 12:19:08.724006+00
1446	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 12:56:25.215866+00
1447	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-08 13:09:38.128784+00
1448	charliehounkanrin@gmail.com	td	t	197.234.219.201	2026-10-08 17:30:22.064754+00
1449	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 17:43:44.380368+00
1450	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 18:36:37.407715+00
1451	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 19:04:59.569608+00
1452	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 20:54:08.049664+00
1453	florenthinnou@gmail.com	td	t	41.216.54.253	2026-10-08 20:54:25.765931+00
1454	nistani21@gmail.com	td	t	41.85.163.145	2026-10-08 20:55:58.870324+00
1455	ferdinandagossou03@gmail.com	td	t	41.216.53.136	2026-10-08 23:14:32.188779+00
1456	jealexhouegbe	admin	t	102.202.111.255	2026-10-09 00:32:53.011755+00
1457	jealexhouegbe	admin	t	102.202.111.255	2026-10-09 02:29:16.889698+00
1458	jealexhouegbe	admin	t	102.202.111.255	2026-10-09 05:23:31.44193+00
1459	jealexhouegbe	admin	t	102.202.111.21	2026-10-09 07:25:39.15503+00
1460	marcepepe@gmail.com	td	t	156.0.213.219	2026-10-09 07:59:43.816444+00
1461	gedeonfintovitchede@gmail.com	td	t	41.79.219.190	2026-10-09 08:30:59.99896+00
1462	jealexhouegbe	admin	t	154.66.139.228	2026-10-09 10:47:02.620592+00
1463	charliehounkanrin@gmail.com	td	t	41.79.219.156	2026-10-09 10:52:20.655415+00
1464	jealexhouegbe	admin	t	154.66.139.228	2026-10-09 13:54:27.074967+00
1465	leopoldchangodele@gmail.com	td	t	41.79.219.216	2026-10-09 14:01:11.33646+00
1466	bienvenuedou112@gmail.com	td	t	102.202.111.78	2026-10-09 15:06:02.02817+00
1467	jealexhouegbe	admin	t	102.202.111.86	2026-10-09 17:31:12.528282+00
1468	quenumparfait	admin	f	41.216.53.160	2026-10-09 19:07:21.035785+00
1469	quenumparfait	admin	f	41.216.53.160	2026-10-09 19:07:44.740043+00
1470	bossouraoul82@gmail.com	td	t	41.85.162.221	2026-10-09 20:41:01.375042+00
1471	quenumparfait	admin	f	41.85.163.243	2026-10-09 20:46:06.740311+00
1472	jealexhouegbe	admin	t	154.66.139.228	2026-10-09 20:52:04.154866+00
1473	viptomtogbe@gmail.com	td	t	102.202.111.102	2026-10-09 20:56:50.898305+00
1474	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-09 21:27:07.621903+00
1475	faroukaremou5@gmail.com	td	t	154.72.113.193	2026-10-09 21:46:15.675202+00
1476	jealexhouegbe	admin	t	154.66.139.228	2026-10-09 21:58:39.800182+00
1477	jealexhouegbe	admin	t	154.66.139.228	2026-10-09 21:59:22.068406+00
1478	jealexhouegbe	admin	t	154.66.139.228	2026-10-09 23:06:38.243442+00
1479	jealexhouegbe	admin	t	154.66.139.228	2026-10-09 23:56:20.961105+00
1480	jealexhouegbe	admin	t	154.66.139.228	2026-10-10 01:12:56.992437+00
1481	florenthinnou@gmail.com	td	t	41.85.163.94	2026-10-10 06:16:56.338308+00
1482	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-10 06:19:09.689524+00
1483	gedeonfintovitchede@gmail.com	td	t	102.202.111.73	2026-10-10 08:53:11.928835+00
1484	ferdinandagossou03@gmail.com	td	t	41.85.162.163	2026-10-10 09:01:09.123533+00
1485	akakpoenock00@gmail.com	td	t	102.202.111.217	2026-10-10 12:23:22.498009+00
1486	leopoldchangodele@gmail.com	td	t	41.79.219.13	2026-10-10 12:44:02.422509+00
1487	viptomtogbe@gmail.com	td	t	197.234.219.208	2026-10-10 13:59:44.294771+00
1488	akakpoenock00@gmail.com	td	t	137.255.210.110	2026-10-10 13:59:56.58657+00
1489	ghics2000@yahoo.fr	td	t	41.79.219.223	2026-10-10 14:47:11.459601+00
1490	ferdinandagossou03@gmail.com	td	t	41.216.54.157	2026-10-10 16:23:11.443784+00
1491	ferdinandagossou03@gmail.com	td	t	41.216.54.157	2026-10-10 16:55:35.609996+00
1492	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-10 17:30:27.784057+00
1493	charliehounkanrin@gmail.com	td	t	197.234.219.222	2026-10-10 18:49:07.47301+00
1494	leopoldchangodele@gmail.com	td	t	41.216.54.9	2026-10-10 20:48:20.743755+00
1495	gedeonfintovitchede@gmail.com	td	t	197.234.223.241	2026-10-10 22:43:41.102043+00
1496	jealexhouegbe	admin	t	154.66.139.228	2026-10-10 22:48:53.939949+00
1497	jealexhouegbe	admin	t	102.215.137.131	2026-10-11 04:29:23.749887+00
1498	amankpemodeste761@gmail.com	td	t	197.234.219.212	2026-10-11 06:43:12.336205+00
1499	amankpemodeste761@gmail.com	td	t	197.234.219.212	2026-10-11 06:44:50.112847+00
1500	amankpemodeste761@gmail.com	td	t	197.234.219.212	2026-10-11 06:45:22.007895+00
1501	charliehounkanrin@gmail.com	td	t	197.234.219.217	2026-10-11 06:51:23.792316+00
1502	akakpoenock00@gmail.com	td	t	137.255.175.147	2026-10-11 06:51:52.923812+00
1503	charliehounkanrin@gmail.com	td	t	197.234.223.218	2026-10-11 08:52:30.09763+00
1504	jealexhouegbe	admin	t	102.215.137.131	2026-10-11 10:46:30.170748+00
1505	leopoldchangodele@gmail.com	td	t	102.202.111.84	2026-10-11 10:57:21.140924+00
1506	aldolalumiere80@gmail.com	td	t	41.79.219.23	2026-10-11 11:00:10.519528+00
1507	amankpemodeste761@gmail.com	td	t	102.202.111.218	2026-10-11 11:02:47.19656+00
1508	ghics2000@yahoo.fr	td	t	41.79.219.223	2026-10-11 11:06:17.574664+00
1509	ghics2000@yahoo.fr	td	t	41.79.219.223	2026-10-11 11:06:40.883717+00
1510	leopoldchangodele@gmail.com	td	t	102.202.111.84	2026-10-11 11:07:53.768421+00
1511	sedodeconstant@gmail.com	admin	f	41.85.162.15	2026-10-11 11:11:42.523757+00
1512	sedodeconstant@gmail.com	admin	f	41.85.162.15	2026-10-11 11:14:45.048449+00
1513	sedodeconstant@gmail.com	admin	f	41.85.162.15	2026-10-11 11:15:09.064365+00
1514	sedodeconstant@gmail.com	admin	f	41.85.162.15	2026-10-11 11:15:35.463212+00
1515	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-11 11:18:20.518159+00
1516	gedeonfintovitchede@gmail.com	td	t	197.234.223.211	2026-10-11 11:21:37.537618+00
1517	urielaxelhouegbe@gmail.com	td	f	41.85.163.146	2026-10-11 11:22:50.090269+00
1518	urielaxelhouegbe@gmail.com	td	t	41.85.163.146	2026-10-11 11:23:38.918719+00
1519	nistani21@gmail.com	td	t	41.85.162.225	2026-10-11 11:32:38.318063+00
1520	charliehounkanrin@gmail.com	td	t	197.234.223.218	2026-10-11 11:40:30.603392+00
1521	ekponnatonjeanclaude@gmail.com	td	t	137.255.55.211	2026-10-11 11:43:30.511506+00
1522	mawougnongael91@gmail.com	td	t	154.72.113.130	2026-10-11 11:53:36.193147+00
1523	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-11 12:25:08.378657+00
1524	charliehounkanrin@gmail.com	td	t	197.234.223.218	2026-10-11 12:30:51.687819+00
1525	viptomtogbe@gmail.com	td	t	197.234.219.232	2026-10-11 12:43:29.452671+00
1526	akakpoenock00@gmail.com	td	t	137.255.175.147	2026-10-11 12:52:17.449146+00
1527	degnonfrederics@gmail.com	td	t	102.202.111.167	2026-10-11 13:26:55.794043+00
1528	ghics2000@yahoo.fr	td	t	41.79.219.223	2026-10-11 14:12:30.425401+00
1529	charliehounkanrin@gmail.com	td	t	197.234.223.218	2026-10-11 14:48:16.820308+00
1530	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-11 14:58:45.538903+00
1531	florenthinnou@gmail.com	td	t	41.216.53.24	2026-10-11 16:12:24.769234+00
1532	jeremieabidegbekponou@gmail.com	td	t	41.138.89.146	2026-10-11 16:30:11.73459+00
1533	carlosbokononhoui@gmail.com	td	t	137.255.67.199	2026-10-11 16:36:10.570034+00
1534	carlosbokononhoui@gmail.com	td	t	137.255.67.199	2026-10-11 16:36:28.340613+00
1535	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.97	2026-10-11 17:56:40.571219+00
1536	faroukaremou5@gmail.com	td	t	102.202.111.52	2026-10-11 18:44:42.049173+00
1537	charliehounkanrin@gmail.com	td	t	197.234.223.218	2026-10-11 19:44:02.939418+00
1538	gedeonfintovitchede@gmail.com	td	t	197.234.223.217	2026-10-11 20:14:06.822397+00
1539	jealexhouegbe	admin	t	41.79.219.191	2026-10-11 21:30:18.801666+00
1540	angekarson1@gmail.com	td	t	41.216.53.255	2026-10-11 22:46:31.908914+00
1541	marcepepe@gmail.com	td	t	41.138.89.141	2026-10-11 23:06:11.189401+00
1542	akakpoenock00@gmail.com	td	t	137.255.175.147	2026-10-12 05:00:47.175136+00
1543	degnonfrederics@gmail.com	td	t	102.202.111.42	2026-10-12 05:05:25.079628+00
1544	sedodeconstant@gmail.com	admin	f	41.85.162.140	2026-10-12 06:25:22.449273+00
1545	amankpemodeste761@gmail.com	td	t	102.202.111.80	2026-10-12 06:25:24.2002+00
1546	sedodeconstant@gmail.com	td	t	41.85.162.140	2026-10-12 06:26:03.57739+00
1547	charliehounkanrin@gmail.com	td	t	137.255.116.98	2026-10-12 06:49:24.960546+00
1548	charliehounkanrin@gmail.com	td	t	137.255.116.98	2026-10-12 06:49:32.717293+00
1549	carlosbokononhoui@gmail.com	td	t	137.255.190.237	2026-10-12 06:53:22.668672+00
1550	sedodeconstant@gmail.com	td	t	41.85.162.140	2026-10-12 07:40:56.809659+00
1551	jealexhouegbe	admin	t	197.234.219.152	2026-10-12 07:45:22.159121+00
1552	mawougnongael91@gmail.com	td	t	102.202.111.94	2026-10-12 07:56:32.421965+00
1553	degnonfrederics@gmail.com	td	f	102.202.111.81	2026-10-12 08:03:32.265628+00
1554	degnonfrederics@gmail.com	td	t	102.202.111.81	2026-10-12 08:04:07.98783+00
1555	charliehounkanrin@gmail.com	td	t	137.255.116.98	2026-10-12 08:14:56.190445+00
1556	jealexhouegbe	admin	t	102.38.153.224	2026-10-12 08:34:02.756223+00
1557	carlosbokononhoui@gmail.com	td	t	137.255.190.237	2026-10-12 08:55:47.718716+00
1558	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-12 09:02:35.997432+00
1559	ghics2000@yahoo.fr	td	t	137.255.49.197	2026-10-12 09:09:57.929776+00
1560	leopoldchangodele@gmail.com	td	t	41.85.162.70	2026-10-12 09:14:18.110217+00
1561	aldolalumiere80@gmail.com	td	t	102.202.111.129	2026-10-12 09:18:16.764288+00
1562	ghics2000@yahoo.fr	td	t	137.255.49.197	2026-10-12 09:19:01.473751+00
1563	claudekinninnon@gmail.com	td	t	137.255.49.197	2026-10-12 09:33:15.077565+00
1564	gedeonfintovitchede@gmail.com	td	t	197.234.223.217	2026-10-12 09:46:50.672296+00
1565	faroukaremou5@gmail.com	td	t	154.72.113.114	2026-10-12 10:07:27.564+00
1566	charliehounkanrin@gmail.com	td	t	197.234.223.218	2026-10-12 10:28:23.957584+00
1567	amankpemodeste761@gmail.com	td	t	102.202.111.80	2026-10-12 10:31:57.165427+00
1568	mawougnongael91@gmail.com	td	t	102.202.111.94	2026-10-12 10:34:22.682308+00
1569	charliehounkanrin@gmail.com	td	t	197.234.223.198	2026-10-12 10:35:46.716139+00
1570	dansoumika8@gmail.com	td	t	102.202.111.244	2026-10-12 10:37:58.581312+00
1571	leopoldchangodele@gmail.com	td	t	41.216.53.57	2026-10-12 10:38:55.020721+00
1572	aremouramziath@gmail.com	td	t	154.66.134.70	2026-10-12 10:42:00.752922+00
1573	faroukaremou5@gmail.com	td	t	154.72.113.114	2026-10-12 10:45:14.746491+00
1574	gedeonfintovitchede@gmail.com	td	t	197.234.223.217	2026-10-12 10:45:14.840167+00
1575	florenthinnou@gmail.com	td	t	41.85.162.249	2026-10-12 10:46:05.101529+00
1576	nistani21@gmail.com	td	t	41.216.54.242	2026-10-12 10:50:31.614602+00
1577	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-12 10:52:54.40327+00
1578	viptomtogbe@gmail.com	td	t	197.234.223.214	2026-10-12 11:07:45.753797+00
1579	viptomtogbe@gmail.com	td	t	197.234.223.214	2026-10-12 11:12:16.979632+00
1580	jealexhouegbe	admin	t	102.38.153.224	2026-10-12 11:14:04.159783+00
1581	degnonfrederics@gmail.com	td	t	102.202.111.81	2026-10-12 11:14:22.678189+00
1582	viptomtogbe@gmail.com	td	t	197.234.223.214	2026-10-12 11:18:39.558598+00
1583	claudekinninnon@gmail.com	td	t	137.255.49.197	2026-10-12 11:27:10.806252+00
1584	aldolalumiere80@gmail.com	td	t	102.202.111.129	2026-10-12 11:29:48.337134+00
1585	ghics2000@yahoo.fr	td	t	137.255.49.197	2026-10-12 11:31:53.62713+00
1586	sedodeconstant@gmail.com	td	t	137.255.49.197	2026-10-12 11:44:01.960479+00
1587	jeremieabidegbekponou@gmail.com	td	t	41.138.89.146	2026-10-12 11:53:48.673933+00
1588	viptomtogbe@gmail.com	td	t	197.234.223.214	2026-10-12 12:57:39.294993+00
1589	degnonfrederics@gmail.com	td	t	102.202.111.81	2026-10-12 13:12:00.022044+00
1590	viptomtogbe@gmail.com	td	t	197.234.223.214	2026-10-12 13:19:13.36374+00
1591	charliehounkanrin@gmail.com	td	t	197.234.223.250	2026-10-12 14:20:21.363542+00
1592	amankpemodeste761@gmail.com	td	t	102.202.111.80	2026-10-12 15:02:15.255479+00
1593	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-12 15:12:22.062516+00
1594	faroukaremou5@gmail.com	td	t	102.202.111.80	2026-10-12 17:04:24.90123+00
1595	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-12 17:16:26.862786+00
1596	amankpemodeste761@gmail.com	td	t	102.202.111.86	2026-10-12 17:23:52.703975+00
1597	akakpoenock00@gmail.com	td	t	197.234.219.210	2026-10-12 17:42:02.417024+00
1598	dansoumika8@gmail.com	td	t	102.202.111.227	2026-10-12 17:59:37.877916+00
1599	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-12 18:11:39.074318+00
1600	claudekinninnon@gmail.com	td	t	102.202.111.121	2026-10-12 18:48:39.661696+00
1601	charliehounkanrin@gmail.com	td	t	197.234.223.250	2026-10-12 18:52:20.672822+00
1602	degnonfrederics@gmail.com	td	f	41.216.54.168	2026-10-12 19:07:55.750611+00
1603	degnonfrederics@gmail.com	td	t	41.216.54.168	2026-10-12 19:08:10.206173+00
1604	florenthinnou@gmail.com	td	t	41.85.162.41	2026-10-12 19:53:20.435719+00
1605	marianototin@gmail.com	td	t	41.216.53.237	2026-10-12 20:10:46.174644+00
1606	faroukaremou5@gmail.com	td	t	102.202.111.200	2026-10-12 21:23:38.705339+00
1607	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-12 22:15:51.275535+00
1608	florenthinnou@gmail.com	td	t	41.85.162.41	2026-10-13 02:31:04.927637+00
1609	faroukaremou5@gmail.com	td	t	102.202.111.200	2026-10-13 04:26:46.428589+00
1610	nistani21@gmail.com	td	t	41.216.53.154	2026-10-13 04:33:40.293406+00
1611	jealexhouegbe	admin	t	102.38.153.224	2026-10-13 05:27:57.700717+00
1612	amankpemodeste761@gmail.com	td	t	102.202.111.238	2026-10-13 05:56:18.578203+00
1613	amankpemodeste761@gmail.com	td	t	102.202.111.238	2026-10-13 05:57:02.862209+00
1614	ferdinandagossou03@gmail.com	td	f	41.85.163.137	2026-10-13 06:16:03.952667+00
1615	ferdinandagossou03@gmail.com	td	t	41.85.163.137	2026-10-13 06:16:32.292518+00
1616	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-13 06:17:32.460343+00
1617	ferdinandagossou03@gmail.com	td	t	41.85.163.137	2026-10-13 06:24:13.392925+00
1618	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-13 06:37:19.579186+00
1619	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-13 07:00:05.912623+00
1620	degnonfrederics@gmail.com	td	t	102.202.111.212	2026-10-13 07:03:16.240818+00
1621	charliehounkanrin@gmail.com	td	t	197.234.223.250	2026-10-13 07:17:08.747304+00
1622	degnonfrederics@gmail.com	td	t	102.202.111.212	2026-10-13 07:34:03.099488+00
1623	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-13 07:37:03.001484+00
1624	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-13 07:49:58.191799+00
1625	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-13 07:57:23.856449+00
1626	angekarson1@gmail.com	td	t	41.85.162.45	2026-10-13 08:08:35.662662+00
1627	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-13 08:36:25.841661+00
1628	simkiki30@gmail.com	td	t	197.234.219.194	2026-10-13 08:41:04.401339+00
1629	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-13 08:59:08.89515+00
1630	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-13 09:01:24.85379+00
1631	ekponnatonjeanclaude@gmail.com	td	t	137.255.54.84	2026-10-13 09:18:19.060831+00
1632	florenthinnou@gmail.com	td	t	41.85.162.236	2026-10-13 09:30:26.93754+00
1633	simkiki30@gmail.com	td	t	197.234.219.194	2026-10-13 09:35:23.771964+00
1634	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-13 09:47:05.942738+00
1635	mawougnongael91@gmail.com	td	t	102.202.111.186	2026-10-13 09:51:35.228374+00
1636	nistani21@gmail.com	td	t	41.216.53.96	2026-10-13 09:52:39.275532+00
1637	aremouramziath@gmail.com	td	t	41.216.54.32	2026-10-13 09:53:01.520186+00
1638	faroukaremou5@gmail.com	td	t	102.202.111.200	2026-10-13 09:56:37.717174+00
1639	gedeonfintovitchede@gmail.com	td	t	41.79.219.10	2026-10-13 09:58:12.029729+00
1640	jeremieabidegbekponou@gmail.com	td	t	41.138.89.146	2026-10-13 09:58:27.478068+00
1641	amankpemodeste761@gmail.com	td	t	102.202.111.219	2026-10-13 10:02:52.334381+00
1642	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-13 10:05:56.875261+00
1643	ghics2000@yahoo.fr	td	t	41.79.219.223	2026-10-13 10:29:04.844876+00
1644	jeremieabidegbekponou@gmail.com	td	t	41.138.89.146	2026-10-13 10:36:05.153543+00
1645	jealexhouegbe	admin	t	102.38.153.224	2026-10-13 11:02:10.94053+00
1646	leopoldchangodele@gmail.com	td	t	137.255.160.248	2026-10-13 11:09:12.080533+00
1647	yessoufouassiath@gmail.com	td	t	102.202.111.10	2026-10-13 13:22:50.814525+00
1648	claudekinninnon@gmail.com	td	t	102.202.111.121	2026-10-13 13:48:04.567439+00
1649	viptomtogbe@gmail.com	td	t	41.79.217.121	2026-10-13 15:24:20.124319+00
1650	viptomtogbe@gmail.com	td	t	41.79.217.121	2026-10-13 15:37:58.035911+00
1651	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-13 16:23:34.333804+00
1652	degnonfrederics@gmail.com	td	t	102.202.111.146	2026-10-13 16:56:40.757504+00
1653	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-13 18:37:34.931892+00
1654	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-13 18:40:57.917054+00
1655	jealexhouegbe	admin	t	102.38.153.224	2026-10-13 19:14:41.654725+00
1656	gedeonfintovitchede@gmail.com	td	t	197.234.223.255	2026-10-13 21:40:44.221694+00
1657	jealexhouegbe	admin	t	102.38.153.224	2026-10-14 06:15:25.730055+00
1658	jealexhouegbe	admin	t	102.38.153.224	2026-10-14 08:18:12.035138+00
1659	bossouraoul82@gmail.com	td	t	41.216.54.113	2026-10-14 09:18:07.558728+00
1660	charliehounkanrin@gmail.com	td	t	197.234.223.231	2026-10-14 10:09:44.208681+00
1661	urielhouegbe	admin	t	102.38.153.224	2026-10-14 10:34:39.408923+00
1662	urielhouegbe	admin	t	102.38.153.224	2026-10-14 11:24:36.10552+00
1663	carlosbokononhoui@gmail.com	td	t	137.255.136.46	2026-10-14 11:27:55.909201+00
1664	jealexhouegbe	admin	t	102.38.153.224	2026-10-14 11:53:49.859265+00
1665	angekarson1@gmail.com	td	t	41.216.53.248	2026-10-14 13:45:11.387164+00
1666	gedeonfintovitchede@gmail.com	td	t	197.234.223.255	2026-10-14 13:51:50.521378+00
1667	jealexhouegbe	admin	t	197.234.219.201	2026-10-14 14:13:20.997363+00
1668	jealexhouegbe	admin	t	197.234.219.201	2026-10-14 15:14:02.942728+00
1669	degnonfrederics@gmail.com	td	t	102.202.111.237	2026-10-14 15:20:48.271031+00
1670	degnonfrederics@gmail.com	td	t	102.202.111.237	2026-10-14 16:01:37.357296+00
1671	bienvenuedou112@gmail.com	td	t	102.202.111.255	2026-10-14 18:32:32.306947+00
1672	jealexhouegbe	admin	t	102.38.153.224	2026-10-14 20:17:03.446936+00
1673	carlosbokononhoui@gmail.com	td	t	197.234.223.225	2026-10-14 21:49:18.727643+00
1674	jealexhouegbe	admin	t	102.38.153.224	2026-10-14 22:20:08.981848+00
1675	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 02:51:47.078876+00
1676	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 03:38:50.699974+00
1677	urielhouegbe	admin	t	102.38.153.224	2026-10-15 04:09:08.047569+00
1678	jealexhouegbe	admin	t	41.79.219.153	2026-10-15 05:54:51.305184+00
1679	leopoldchangodele@gmail.com	td	t	41.85.162.143	2026-10-15 05:55:51.876514+00
1680	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 06:24:13.453489+00
1681	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 07:22:19.002007+00
1682	ekponnatonjeanclaude@gmail.com	td	t	137.255.155.242	2026-10-15 07:24:52.621604+00
1683	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 07:48:53.75207+00
1684	carlosbokononhoui@gmail.com	td	t	197.234.219.196	2026-10-15 07:57:12.364501+00
1685	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 08:46:36.060616+00
1686	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 09:54:03.693998+00
1687	urielhouegbe	admin	t	102.38.153.224	2026-10-15 10:40:30.021888+00
1688	piomedesse@gmail.com	td	f	102.202.111.241	2026-10-15 14:38:06.4987+00
1689	piomedesse@gmail.com	td	f	102.202.111.241	2026-10-15 14:38:26.339839+00
1690	piomedesse@gmail.com	td	t	102.202.111.241	2026-10-15 14:38:48.066992+00
1691	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 15:13:44.745056+00
1692	angekarson1@gmail.com	td	t	41.216.54.38	2026-10-15 16:14:56.228918+00
1693	carlosbokononhoui@gmail.com	td	t	197.234.219.196	2026-10-15 17:08:15.493837+00
1694	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 17:12:14.622924+00
1695	magbondejerome@gmail.com	td	t	197.234.219.128	2026-10-15 18:54:56.125794+00
1696	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 18:56:44.402838+00
1697	magbondejerome@gmail.com	td	t	197.234.219.128	2026-10-15 19:51:42.184527+00
1698	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 20:04:40.164992+00
1699	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 20:27:04.275361+00
1700	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 21:05:25.561323+00
1701	gedeonfintovitchede@gmail.com	td	t	197.234.223.255	2026-10-15 21:20:47.595652+00
1702	leopoldchangodele@gmail.com	td	t	102.202.111.252	2026-10-15 22:30:25.543405+00
1703	jealexhouegbe	admin	t	102.38.153.224	2026-10-15 22:53:19.476098+00
1704	kpogbagislain323@gmail.com	td	f	197.234.219.235	2026-10-15 22:54:13.964355+00
1705	kpogbagislain323@gmail.com	td	f	197.234.219.235	2026-10-15 22:54:42.270661+00
1706	urielhouegbe	admin	t	102.38.153.224	2026-10-15 23:10:48.091995+00
1707	degnonfrederics@gmail.com	td	t	41.85.163.168	2026-10-16 00:42:28.677855+00
1708	jealexhouegbe	admin	t	102.38.153.224	2026-10-16 01:09:07.404688+00
1709	urielhouegbe	admin	t	102.38.153.224	2026-10-16 05:24:54.750293+00
1710	urielhouegbe	admin	t	102.38.153.224	2026-10-16 06:19:27.852775+00
1711	urielhouegbe	admin	t	102.38.153.224	2026-10-16 07:32:56.06751+00
1712	aremouramziath@gmail.com	td	t	41.85.163.85	2026-10-16 08:02:33.032511+00
1713	ekponnatonjeanclaude@gmail.com	td	t	41.79.217.110	2026-10-16 13:17:36.766032+00
1714	magbondejerome@gmail.com	td	t	197.234.219.143	2026-10-16 14:50:26.274558+00
1715	urielhouegbe	admin	t	102.38.153.224	2026-10-16 18:11:19.949773+00
1716	urielhouegbe	admin	t	102.38.153.224	2026-10-16 18:14:59.587698+00
1717	urielhouegbe	admin	t	102.38.153.224	2026-10-16 18:17:09.430464+00
1718	gedeonfintovitchede@gmail.com	td	t	197.234.219.144	2026-10-16 18:23:18.420943+00
1719	urielhouegbe	admin	t	102.38.153.224	2026-10-16 18:50:10.836738+00
1720	jealexhouegbe	admin	t	41.79.219.86	2026-10-16 19:47:37.822834+00
1721	magbondejerome@gmail.com	td	t	41.79.219.179	2026-10-16 21:10:24.358476+00
1722	jealexhouegbe	admin	t	197.234.223.239	2026-10-16 22:30:32.361627+00
1723	jealexhouegbe	admin	t	102.38.153.224	2026-10-16 22:55:20.940203+00
1724	urielhouegbe	admin	t	102.38.153.224	2026-10-16 23:53:36.420858+00
1725	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.121	2026-10-17 02:47:31.177598+00
1726	jealexhouegbe	admin	t	102.38.153.224	2026-10-17 04:08:24.331858+00
1727	degnonfrederics@gmail.com	td	t	137.255.23.198	2026-10-17 04:57:32.091708+00
1728	degnonfrederics@gmail.com	td	t	137.255.23.198	2026-10-17 05:28:06.067684+00
1729	faroukaremou5@gmail.com	td	t	197.234.219.150	2026-10-17 05:53:39.388544+00
1730	faroukaremou5@gmail.com	td	t	197.234.219.150	2026-10-17 05:54:07.838749+00
1731	faroukaremou5@gmail.com	td	t	197.234.219.150	2026-10-17 05:54:29.490115+00
1732	claudekinninnon@gmail.com	td	t	102.202.111.160	2026-10-17 06:01:48.829538+00
1733	aremouramziath@gmail.com	td	t	41.85.163.85	2026-10-17 06:23:41.2679+00
1734	peter21	admin	f	41.85.163.134	2026-10-17 06:56:24.673487+00
1735	peter21	admin	f	41.85.163.134	2026-10-17 06:56:28.798135+00
1736	peter21	admin	f	41.85.163.134	2026-10-17 06:56:38.918584+00
1737	peter21	admin	f	41.85.163.134	2026-10-17 06:56:52.587571+00
1738	peter21	admin	f	41.85.163.134	2026-10-17 06:57:13.239739+00
1739	leopoldchangodele@gmail.com	td	t	102.202.111.56	2026-10-17 08:10:52.866968+00
1740	urielhouegbe	admin	t	41.216.53.183	2026-10-17 08:38:46.277976+00
1741	kpogbagislain323@gmail.com	td	t	154.72.113.138	2026-10-17 08:50:45.586466+00
1742	kpogbagislain323@gmail.com	td	f	154.72.113.138	2026-10-17 09:02:04.634851+00
1743	kpogbagislain323@gmail.com	td	f	154.72.113.138	2026-10-17 09:02:59.8827+00
1744	kpogbagislain323@gmail.com	td	f	154.72.113.138	2026-10-17 09:17:24.812814+00
1745	kpogbagislain323@gmail.com	td	f	154.72.113.138	2026-10-17 09:18:37.737403+00
1746	kpogbagislain323@gmail.com	td	f	154.72.113.138	2026-10-17 09:18:40.564009+00
1747	leopoldchangodele@gmail.com	td	t	41.85.163.254	2026-10-17 09:28:58.213534+00
1748	jealexhouegbe	admin	t	197.234.219.218	2026-10-17 10:11:52.312841+00
1749	degnonfrederics@gmail.com	td	t	102.202.111.15	2026-10-17 11:02:37.832064+00
1750	urielhouegbe	admin	t	41.216.53.183	2026-10-17 12:57:13.471842+00
1751	amankpemodeste761@gmail.com	td	t	102.202.111.187	2026-10-17 13:00:27.919441+00
1752	magbondejerome@gmail.com	td	t	41.79.219.129	2026-10-17 13:09:52.795556+00
1753	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-17 13:32:46.547256+00
1754	jealexhouegbe	admin	t	197.234.223.238	2026-10-17 14:06:24.767122+00
1755	carlosbokononhoui@gmail.com	td	t	197.234.219.154	2026-10-17 14:28:33.615601+00
1756	claudekinninnon@gmail.com	td	t	102.202.111.160	2026-10-17 16:17:25.318415+00
1757	ekponnatonjeanclaude@gmail.com	td	t	137.255.110.18	2026-10-17 16:26:46.901563+00
1758	aremouramziath@gmail.com	td	t	154.66.134.70	2026-10-17 16:31:05.557274+00
1759	kpogbagislain323@gmail.com	td	t	154.72.113.138	2026-10-17 16:53:19.27066+00
1760	urielhouegbe	admin	t	41.216.53.183	2026-10-17 17:08:25.954249+00
1761	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-17 19:12:28.686801+00
1762	carlosbokononhoui@gmail.com	td	t	197.234.219.154	2026-10-17 19:39:41.146797+00
1763	jealexhouegbe	admin	t	102.38.153.224	2026-10-17 20:03:43.196816+00
1764	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-17 21:35:56.772225+00
1765	jealexhouegbe	admin	t	102.38.153.224	2026-10-18 05:13:58.275952+00
1766	degnonfrederics@gmail.com	td	f	41.79.219.156	2026-10-18 05:27:49.083252+00
1767	degnonfrederics@gmail.com	td	f	41.79.219.156	2026-10-18 05:28:03.724848+00
1768	degnonfrederics@gmail.com	td	f	41.79.219.156	2026-10-18 05:28:15.823376+00
1769	degnonfrederics@gmail.com	td	t	41.79.219.156	2026-10-18 05:28:28.523348+00
1770	degnonfrederics@gmail.com	td	f	41.79.219.156	2026-10-18 05:29:39.499964+00
1771	degnonfrederics@gmail.com	td	f	41.79.219.156	2026-10-18 05:29:53.086413+00
1772	degnonfrederics@gmail.com	td	t	41.79.219.156	2026-10-18 05:51:10.873052+00
1773	jealexhouegbe	admin	t	102.38.153.224	2026-10-18 06:00:23.108685+00
1774	jealexhouegbe	admin	t	102.38.153.224	2026-10-18 06:00:35.873276+00
1775	degnonfrederics@gmail.com	td	t	41.79.219.156	2026-10-18 06:06:06.157064+00
1776	degnonfrederics@gmail.com	td	t	41.79.219.156	2026-10-18 06:37:50.200639+00
1777	magbondejerome@gmail.com	td	t	197.234.223.237	2026-10-18 07:31:26.027304+00
1778	degnonfrederics@gmail.com	td	t	197.234.219.223	2026-10-18 08:26:41.497503+00
1779	jealexhouegbe	admin	t	102.38.153.224	2026-10-18 08:35:41.133978+00
1780	degnonfrederics@gmail.com	td	t	197.234.219.223	2026-10-18 09:29:32.174694+00
1781	charliehounkanrin@gmail.com	td	t	197.234.219.209	2026-10-18 10:03:04.125188+00
1782	degnonfrederics@gmail.com	td	t	197.234.219.152	2026-10-18 11:03:06.631831+00
1783	florenthinnou@gmail.com	td	t	41.216.53.239	2026-10-18 11:36:30.906855+00
1784	akakpoenock00@gmail.com	td	t	137.255.42.89	2026-10-18 11:37:18.068462+00
1785	degnonfrederics@gmail.com	td	t	197.234.219.152	2026-10-18 11:52:20.493791+00
1786	viptomtogbe@gmail.com	td	t	41.79.217.119	2026-10-18 12:06:48.044941+00
1787	gedeonfintovitchede@gmail.com	td	t	197.234.219.156	2026-10-18 12:45:28.263681+00
1788	jealexhouegbe	admin	t	102.38.153.224	2026-10-18 12:47:21.566937+00
1789	urielhouegbe	admin	t	102.38.153.224	2026-10-18 13:00:37.325892+00
1790	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-18 13:59:58.22907+00
1791	charliehounkanrin@gmail.com	td	t	197.234.219.211	2026-10-18 15:23:06.217334+00
1792	leopoldchangodele@gmail.com	td	t	102.202.111.179	2026-10-18 15:37:06.448856+00
1793	jealexhouegbe	admin	t	102.38.153.224	2026-10-18 19:30:37.435832+00
1794	carlosbokononhoui@gmail.com	td	t	197.234.219.229	2026-10-18 20:05:10.154776+00
1795	leopoldchangodele@gmail.com	td	t	102.202.111.179	2026-10-18 20:44:41.585873+00
1796	jealexhouegbe	admin	t	102.38.153.224	2026-10-18 21:43:27.932788+00
1797	nistani21@gmail.com	td	t	41.216.53.16	2026-10-18 22:01:28.33566+00
1798	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-18 23:02:26.944283+00
1799	amankpemodeste761@gmail.com	td	t	102.202.111.33	2026-10-18 23:13:31.180979+00
1800	akakpoenock00@gmail.com	td	t	137.255.42.89	2026-10-19 03:53:21.259058+00
1801	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-19 04:45:58.636737+00
1802	jealexhouegbe	admin	t	102.38.153.224	2026-10-19 05:12:24.74243+00
1803	amankpemodeste761@gmail.com	td	t	102.202.111.50	2026-10-19 05:27:00.614908+00
1804	magbondejerome@gmail.com	td	t	41.79.219.123	2026-10-19 05:51:39.075857+00
1805	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-19 06:01:23.450453+00
1806	florenthinnou@gmail.com	td	t	41.216.53.22	2026-10-19 06:14:04.378511+00
1807	urielhouegbe	admin	t	41.216.54.159	2026-10-19 06:16:56.996734+00
1808	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-19 06:18:41.205841+00
1809	urielaxelhouegbe@gmail.com	td	t	41.216.54.159	2026-10-19 06:19:26.812008+00
1810	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-19 06:24:35.308488+00
1811	jealexhouegbe	admin	t	102.38.153.224	2026-10-19 06:29:48.110608+00
1812	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-19 06:33:40.025578+00
1813	aremouramziath@gmail.com	td	t	154.66.134.70	2026-10-19 06:36:36.835007+00
1814	degnonfrederics@gmail.com	td	t	41.85.163.13	2026-10-19 06:38:56.859649+00
1815	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.224	2026-10-19 06:42:44.904725+00
1816	magbondejerome@gmail.com	td	t	41.79.219.123	2026-10-19 06:45:05.707012+00
1817	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-19 06:45:14.853568+00
1818	degnonfrederics@gmail.com	td	t	41.85.163.13	2026-10-19 06:45:59.755583+00
1819	carlosbokononhoui@gmail.com	td	t	137.255.150.92	2026-10-19 06:55:14.434844+00
1820	carlosbokononhoui@gmail.com	td	t	137.255.150.92	2026-10-19 06:55:50.275579+00
1821	charliehounkanrin@gmail.com	td	t	197.234.219.227	2026-10-19 06:57:10.979725+00
1822	magbondejerome@gmail.com	td	t	41.79.219.123	2026-10-19 07:11:14.066397+00
1823	nistani21@gmail.com	td	t	41.216.54.116	2026-10-19 07:15:47.860289+00
1824	simkiki30@gmail.com	td	t	197.234.223.219	2026-10-19 07:23:04.638313+00
1825	simkiki30@gmail.com	td	t	197.234.223.219	2026-10-19 07:24:12.241823+00
1826	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-19 07:37:54.95592+00
1827	florenthinnou@gmail.com	td	t	41.216.53.22	2026-10-19 07:53:14.772654+00
1828	florenthinnou@gmail.com	td	t	41.216.53.22	2026-10-19 07:57:34.026486+00
1829	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 08:01:35.798364+00
1830	sedodeconstant@gmail.com	admin	f	41.216.54.105	2026-10-19 08:01:49.651798+00
1831	jealexhouegbe	admin	f	102.38.153.224	2026-10-19 08:06:11.640857+00
1832	piomedesse@gmail.com	td	t	102.202.111.119	2026-10-19 08:06:18.266593+00
1833	jealexhouegbe	admin	t	102.38.153.224	2026-10-19 08:06:22.487326+00
1834	amankpemodeste761@gmail.com	td	t	102.202.111.50	2026-10-19 08:07:05.130321+00
1835	sedodeconstant@gmail.com	td	t	41.216.54.105	2026-10-19 08:20:54.120744+00
1836	faroukaremou5@gmail.com	td	t	102.202.111.217	2026-10-19 08:28:18.16513+00
1837	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 08:34:05.306096+00
1838	urielaxelhouegbe@gmail.com	td	t	41.216.54.159	2026-10-19 08:38:54.377304+00
1839	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-19 08:42:17.76988+00
1840	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 08:52:47.070789+00
1841	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 09:01:25.741401+00
1842	charliehounkanrin@gmail.com	td	t	137.255.148.176	2026-10-19 09:12:37.949886+00
1843	degnonfrederics@gmail.com	td	f	41.85.163.13	2026-10-19 09:13:55.985417+00
1844	degnonfrederics@gmail.com	td	t	41.85.163.13	2026-10-19 09:14:10.413987+00
1845	florenthinnou@gmail.com	td	t	41.216.53.22	2026-10-19 09:14:41.71256+00
1846	aldolalumiere80@gmail.com	td	t	41.85.163.70	2026-10-19 09:15:03.909343+00
1847	simkiki30@gmail.com	td	t	197.234.223.219	2026-10-19 09:17:23.75582+00
1848	simkiki30@gmail.com	td	t	197.234.223.219	2026-10-19 09:19:30.988324+00
1849	leopoldchangodele@gmail.com	td	t	102.202.111.191	2026-10-19 09:19:40.397199+00
1850	ghics2000@yahoo.fr	td	t	137.255.28.69	2026-10-19 09:20:14.06035+00
1851	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 09:20:17.900298+00
1852	magbondejerome@gmail.com	td	t	41.79.219.123	2026-10-19 09:20:37.889295+00
1853	amankpemodeste761@gmail.com	td	t	102.202.111.50	2026-10-19 09:21:51.09274+00
1854	ghics2000@yahoo.fr	td	t	137.255.28.69	2026-10-19 09:22:33.533246+00
1855	marcepepe@gmail.com	td	t	137.255.150.92	2026-10-19 09:28:07.970329+00
1856	faroukaremou5@gmail.com	td	t	102.202.111.217	2026-10-19 09:29:40.521189+00
1857	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 09:37:02.185056+00
1858	ferdinandagossou03@gmail.com	td	t	41.85.163.213	2026-10-19 09:41:37.186743+00
1859	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-19 09:49:41.451602+00
1860	urielaxelhouegbe@gmail.com	td	t	41.216.54.159	2026-10-19 10:05:24.68032+00
1861	mawougnongael91@gmail.com	td	t	41.216.54.199	2026-10-19 10:06:46.060385+00
1862	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 10:10:53.437429+00
1863	sedodeconstant@gmail.com	admin	f	41.216.54.105	2026-10-19 10:17:17.969407+00
1864	sedodeconstant@gmail.com	td	t	41.216.54.105	2026-10-19 10:17:36.252647+00
1865	jealexhouegbe	admin	t	102.38.153.224	2026-10-19 10:22:30.364712+00
1866	yessoufouassiath@gmail.com	td	t	156.0.213.219	2026-10-19 10:38:08.271901+00
1867	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 10:43:50.585882+00
1868	sedodeconstant@gmail.com	td	t	41.216.54.105	2026-10-19 11:10:11.984355+00
1869	akakpoenock00@gmail.com	td	t	102.202.111.129	2026-10-19 11:13:20.108106+00
1870	aldolalumiere80@gmail.com	td	t	41.216.54.216	2026-10-19 11:17:09.586376+00
1975	jealexhouegbe	admin	t	41.79.219.215	2026-10-21 15:26:44.216473+00
1871	aldolalumiere80@gmail.com	td	t	102.202.111.174	2026-10-19 11:18:16.47222+00
1872	degnonfrederics@gmail.com	td	t	41.85.163.13	2026-10-19 11:19:42.966216+00
1873	piomedesse@gmail.com	td	t	102.202.111.255	2026-10-19 11:30:23.839346+00
1874	piomedesse@gmail.com	td	t	102.202.111.255	2026-10-19 11:31:00.415412+00
1875	piomedesse@gmail.com	td	t	102.202.111.255	2026-10-19 11:31:50.249618+00
1876	jealexhouegbe	admin	t	154.66.139.79	2026-10-19 11:35:35.062877+00
1877	degnonfrederics@gmail.com	td	t	41.85.163.13	2026-10-19 11:53:25.29026+00
1878	carlosbokononhoui@gmail.com	td	t	197.234.219.229	2026-10-19 12:10:13.05541+00
1879	carlosbokononhoui@gmail.com	td	t	197.234.219.229	2026-10-19 12:10:36.006322+00
1880	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 12:23:04.054923+00
1881	claudekinninnon@gmail.com	td	t	102.202.111.160	2026-10-19 12:51:23.058497+00
1882	claudekinninnon@gmail.com	td	t	102.202.111.160	2026-10-19 12:51:53.342529+00
1883	jealexhouegbe	admin	t	154.66.142.176	2026-10-19 13:32:41.208918+00
1884	claudekinninnon@gmail.com	td	t	137.255.70.72	2026-10-19 13:33:41.623897+00
1885	nistani21@gmail.com	td	t	41.216.54.90	2026-10-19 13:48:45.714882+00
1886	ghics2000@yahoo.fr	td	t	137.255.70.72	2026-10-19 13:55:58.836863+00
1887	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 14:06:52.751787+00
1888	leopoldchangodele@gmail.com	td	t	137.255.29.80	2026-10-19 14:28:11.425389+00
1889	bienvenuedou112@gmail.com	td	t	137.255.120.110	2026-10-19 15:17:54.06688+00
1890	nistani21@gmail.com	td	t	41.216.54.90	2026-10-19 16:07:55.92729+00
1891	charliehounkanrin@gmail.com	td	t	41.79.219.33	2026-10-19 16:36:51.964796+00
1892	ghics2000@yahoo.fr	td	t	102.202.111.165	2026-10-19 18:58:43.902134+00
1893	ghics2000@yahoo.fr	td	t	102.202.111.165	2026-10-19 18:59:02.170045+00
1894	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.81	2026-10-19 19:16:56.443025+00
1895	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-19 20:52:03.14683+00
1896	jealexhouegbe	admin	t	154.66.138.152	2026-10-19 21:28:15.27687+00
1897	amankpemodeste761@gmail.com	td	t	102.202.111.50	2026-10-19 21:37:15.723282+00
1898	viptomtogbe@gmail.com	td	t	41.85.162.20	2026-10-19 22:18:03.943735+00
1899	amankpemodeste761@gmail.com	td	t	102.202.111.50	2026-10-19 22:45:50.284948+00
1900	viptomtogbe@gmail.com	td	t	41.85.162.20	2026-10-19 22:54:28.886142+00
1901	faroukaremou5@gmail.com	td	t	154.72.113.114	2026-10-19 22:58:30.971074+00
1902	amankpemodeste761@gmail.com	td	t	102.202.111.50	2026-10-19 23:14:21.441399+00
1903	amankpemodeste761@gmail.com	td	t	102.202.111.50	2026-10-19 23:31:25.052554+00
1904	jealexhouegbe	admin	t	154.66.138.152	2026-10-20 00:00:59.704239+00
1905	degnonfrederics@gmail.com	td	t	41.216.53.90	2026-10-20 04:51:58.968589+00
1906	charliehounkanrin@gmail.com	td	t	41.79.217.115	2026-10-20 04:55:15.825607+00
1907	charliehounkanrin@gmail.com	td	t	41.79.217.115	2026-10-20 05:44:06.658289+00
1908	jealexhouegbe	admin	t	154.66.138.152	2026-10-20 06:08:32.099578+00
1909	ekponnatonjeanclaude@gmail.com	td	t	137.255.144.195	2026-10-20 06:33:27.879225+00
1910	charliehounkanrin@gmail.com	td	t	41.79.217.115	2026-10-20 06:40:34.717283+00
1911	charliehounkanrin@gmail.com	td	t	41.79.217.124	2026-10-20 07:29:42.144025+00
1912	marianototin@gmail.com	td	t	41.79.219.164	2026-10-20 07:33:12.935285+00
1913	jealexhouegbe	admin	t	154.66.138.152	2026-10-20 08:04:21.793664+00
1914	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-20 08:11:17.826394+00
1915	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-20 08:11:48.961098+00
1916	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-20 08:15:36.778356+00
1917	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-20 08:16:09.985397+00
1918	florenthinnou@gmail.com	td	t	41.85.163.107	2026-10-20 08:25:27.586159+00
1919	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 08:29:15.246382+00
1920	mawougnongael91@gmail.com	td	t	154.66.133.55	2026-10-20 09:15:59.377256+00
1921	angekarson1@gmail.com	td	t	41.216.53.68	2026-10-20 09:18:37.502743+00
1922	jealexhouegbe	admin	t	154.66.138.152	2026-10-20 09:27:02.530732+00
1923	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 09:37:16.932295+00
1924	ferdinandagossou03@gmail.com	td	t	41.216.54.84	2026-10-20 09:43:21.271906+00
1925	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 10:02:08.424993+00
1926	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 10:02:29.806326+00
1927	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 10:53:47.35337+00
1928	piomedesse@gmail.com	td	f	102.202.111.23	2026-10-20 11:18:16.204946+00
1929	piomedesse@gmail.com	td	t	102.202.111.23	2026-10-20 11:18:53.053545+00
1930	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 11:49:12.692911+00
1931	florenthinnou@gmail.com	td	t	41.85.163.107	2026-10-20 12:02:37.311253+00
1932	leopoldchangodele@gmail.com	td	t	137.255.146.158	2026-10-20 12:09:35.849348+00
1933	amankpemodeste761@gmail.com	td	t	102.202.111.25	2026-10-20 12:40:28.942823+00
1934	ghics2000@yahoo.fr	td	t	137.255.147.71	2026-10-20 12:59:54.10257+00
1935	jealexhouegbe	admin	t	154.66.138.152	2026-10-20 13:00:51.356072+00
1936	aldolalumiere80@gmail.com	td	t	102.202.111.235	2026-10-20 13:34:10.172612+00
1937	aldolalumiere80@gmail.com	td	t	102.202.111.235	2026-10-20 13:34:47.107098+00
1938	simkiki30@gmail.com	td	t	197.234.219.235	2026-10-20 13:35:58.87076+00
1939	simkiki30@gmail.com	td	t	197.234.219.235	2026-10-20 13:36:41.636469+00
1940	nistani21@gmail.com	td	t	41.85.162.208	2026-10-20 13:37:03.363207+00
1941	magbondejerome@gmail.com	td	t	41.79.219.97	2026-10-20 13:38:15.927224+00
1942	faroukaremou5@gmail.com	td	t	102.202.111.180	2026-10-20 13:46:34.253793+00
1943	aremouramziath@gmail.com	td	t	154.66.134.70	2026-10-20 13:47:47.513403+00
1944	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 13:49:53.404813+00
1945	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-20 13:49:54.482351+00
1946	charliehounkanrin@gmail.com	td	t	197.234.223.229	2026-10-20 13:50:33.502903+00
1947	ekponnatonjeanclaude@gmail.com	td	t	137.255.144.195	2026-10-20 13:55:30.850172+00
1948	ferdinandagossou03@gmail.com	td	t	41.85.162.189	2026-10-20 14:39:10.055791+00
1949	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-20 15:01:44.118744+00
1950	viptomtogbe@gmail.com	td	t	137.255.151.170	2026-10-20 15:09:11.078561+00
1951	jealexhouegbe	admin	t	154.66.138.152	2026-10-20 15:43:49.464815+00
1952	kpogbagislain323@gmail.com	td	t	154.72.113.138	2026-10-20 15:55:17.177924+00
1953	ghics2000@yahoo.fr	td	t	137.255.147.71	2026-10-20 16:09:07.132197+00
1954	djossougermain0@gmail.com	td	t	41.216.53.239	2026-10-20 16:20:20.730207+00
1955	florenthinnou@gmail.com	td	t	41.216.54.29	2026-10-20 16:26:32.32437+00
1956	florenthinnou@gmail.com	td	t	41.216.54.29	2026-10-20 16:28:50.168402+00
1957	degnonfrederics@gmail.com	td	t	41.85.162.88	2026-10-20 16:29:29.088261+00
1958	jealexhouegbe	admin	t	154.66.143.212	2026-10-20 19:05:38.811107+00
1959	jealexhouegbe	admin	t	154.66.143.212	2026-10-20 19:38:52.089908+00
1960	charliehounkanrin@gmail.com	td	t	197.234.219.229	2026-10-20 20:09:37.358478+00
1961	akakpoenock00@gmail.com	td	t	137.255.128.87	2026-10-20 21:17:58.982653+00
1962	sedodeconstant@gmail.com	td	t	41.85.163.124	2026-10-20 22:52:25.773869+00
1963	claudekinninnon@gmail.com	td	t	137.255.70.255	2026-10-21 06:28:55.643042+00
1964	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-21 10:28:26.769967+00
1965	urielhouegbe	admin	t	154.66.143.212	2026-10-21 10:51:24.874982+00
1966	urielhouegbe	admin	t	154.66.143.212	2026-10-21 11:34:31.229506+00
1967	urielhouegbe	admin	t	154.66.143.212	2026-10-21 11:39:34.418636+00
1968	charliehounkanrin@gmail.com	td	t	41.79.219.184	2026-10-21 12:12:18.713958+00
1969	jealexhouegbe	admin	t	154.66.143.212	2026-10-21 12:47:54.934298+00
1970	kpogbagislain323@gmail.com	td	t	137.255.216.237	2026-10-21 13:05:40.917656+00
1971	charliehounkanrin@gmail.com	td	t	41.79.219.184	2026-10-21 13:57:17.481355+00
1972	jealexhouegbe	admin	t	197.234.219.216	2026-10-21 14:55:32.377822+00
1973	yetbaginn	admin	f	41.138.89.198	2026-10-21 14:57:47.988151+00
1974	yetbaginn	admin	t	41.138.89.198	2026-10-21 14:59:12.050375+00
1976	jealexhouegbe	admin	t	154.66.140.119	2026-10-21 20:59:35.868064+00
1977	jealexhouegbe	admin	t	154.66.140.119	2026-10-21 21:05:22.549787+00
1978	charliehounkanrin@gmail.com	td	t	41.79.219.184	2026-10-21 21:56:04.034332+00
1979	jealexhouegbe	admin	t	154.66.140.119	2026-10-21 22:33:24.567415+00
1980	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-21 23:20:59.064974+00
1981	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 03:20:35.725968+00
1982	jealexhouegbe	admin	t	197.234.223.245	2026-10-22 05:55:44.764246+00
1983	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 07:02:52.756997+00
1984	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 09:33:02.989371+00
1985	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 09:57:30.101966+00
1986	urielhouegbe	admin	t	154.66.140.119	2026-10-22 10:15:19.354221+00
1987	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-22 10:54:01.202031+00
1988	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 11:22:47.994388+00
1989	urielhouegbe	admin	t	154.66.140.119	2026-10-22 11:28:33.641348+00
1990	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 11:47:06.568853+00
1991	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-22 11:51:39.759051+00
1992	urielaxelhouegbe@gmail.com	td	t	154.66.140.119	2026-10-22 12:05:03.309518+00
1993	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-22 12:14:18.062718+00
1994	magbondejerome@gmail.com	td	t	41.79.217.116	2026-10-22 13:08:25.761958+00
1995	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 13:24:15.566963+00
1996	kpogbagislain323@gmail.com	td	t	137.255.213.194	2026-10-22 13:53:07.081313+00
1997	magbondejerome@gmail.com	td	t	41.79.217.116	2026-10-22 14:41:12.321989+00
1998	jealexhouegbe	admin	t	154.66.140.119	2026-10-22 16:05:33.431889+00
1999	faroukaremou5@gmail.com	td	t	41.79.217.109	2026-10-22 16:13:57.488614+00
2000	ekponnatonjeanclaude@gmail.com	td	t	137.255.119.247	2026-10-22 21:09:24.582265+00
2001	35543435	admin	f	154.66.140.119	2026-10-22 22:18:53.153953+00
2002	jealexhouegbe	admin	t	154.66.140.119	2026-10-23 05:45:41.761867+00
2003	jealexhouegbe	admin	t	154.66.140.119	2026-10-23 06:16:18.569137+00
2004	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-23 09:41:44.16459+00
2005	florenthinnou@gmail.com	td	t	41.216.54.70	2026-10-23 14:36:15.767499+00
2006	jealexhouegbe	admin	t	154.66.140.119	2026-10-23 15:35:13.482272+00
2007	leopoldchangodele@gmail.com	td	t	41.85.162.62	2026-10-23 17:09:07.63081+00
2008	urielhouegbe	admin	t	154.66.140.119	2026-10-23 18:04:31.364049+00
2009	aldolalumiere80@gmail.com	td	t	137.255.188.5	2026-10-23 18:18:09.193291+00
2010	jealexhouegbe	admin	t	197.234.219.159	2026-10-23 19:27:07.616727+00
2011	quenumparfait	admin	t	41.138.89.254	2026-10-23 19:52:19.258923+00
2012	urielhouegbe	admin	t	154.66.140.119	2026-10-23 20:31:30.563729+00
2013	jealexhouegbe	admin	t	197.234.223.211	2026-10-23 22:07:06.707133+00
2014	jealexhouegbe	admin	t	102.215.138.186	2026-10-24 01:25:02.609703+00
2015	urielhouegbe	admin	t	102.215.138.186	2026-10-24 01:32:40.888166+00
2016	jealexhouegbe	admin	t	102.215.138.186	2026-10-24 02:28:23.42964+00
2017	urielhouegbe	admin	t	102.215.138.186	2026-10-24 03:41:14.156428+00
2018	jealexhouegbe	admin	t	102.215.138.186	2026-10-24 03:48:13.018605+00
2019	amankpemodeste761@gmail.com	td	t	197.234.219.195	2026-10-24 04:57:46.702277+00
2020	urielhouegbe	admin	t	102.215.138.186	2026-10-24 05:25:43.079013+00
2021	faroukaremou5@gmail.com	td	t	102.202.111.223	2026-10-24 05:41:22.075934+00
2022	charliehounkanrin@gmail.com	td	t	41.79.217.120	2026-10-24 05:51:16.741602+00
2023	jealexhouegbe	admin	t	41.79.219.145	2026-10-24 06:11:17.369303+00
2024	jealexhouegbe	admin	t	41.79.219.145	2026-10-24 06:18:05.968268+00
2025	sedodeconstant@gmail.com	td	t	41.216.53.84	2026-10-24 06:26:25.120833+00
2026	peter21	admin	f	41.216.53.51	2026-10-24 07:17:43.432302+00
2027	peter21	admin	f	41.216.53.51	2026-10-24 07:17:55.364989+00
2028	yetbaginn	admin	t	156.0.213.129	2026-10-24 07:18:24.89415+00
2029	jealexhouegbe	admin	t	41.79.219.145	2026-10-24 07:46:58.558571+00
2030	quenumparfait	admin	t	156.0.213.189	2026-10-24 08:00:02.839949+00
2031	mawougnongael91@gmail.com	td	t	102.202.111.203	2026-10-24 08:05:15.266247+00
2032	aldolalumiere80@gmail.com	td	t	102.202.111.218	2026-10-24 08:42:30.881515+00
2033	charliehounkanrin@gmail.com	td	t	41.79.217.120	2026-10-24 08:49:01.145397+00
2034	peter21	admin	f	41.216.53.51	2026-10-24 08:50:36.042576+00
2035	jealexhouegbe	admin	t	41.79.219.145	2026-10-24 08:50:57.575917+00
2036	mawougnongael91@gmail.com	td	t	102.202.111.203	2026-10-24 09:09:08.56425+00
2037	akakpoenock00@gmail.com	td	t	102.202.111.212	2026-10-24 09:10:56.285863+00
2038	jealexhouegbe	admin	t	41.79.219.145	2026-10-24 09:21:32.117547+00
2039	yetbaginn	admin	t	156.0.213.129	2026-10-24 09:51:14.648666+00
2040	gedeonfintovitchede@gmail.com	td	t	197.234.219.241	2026-10-24 12:37:01.746647+00
2041	jealexhouegbe	admin	t	41.79.219.145	2026-10-24 12:48:16.713922+00
2042	jealexhouegbe	admin	t	41.79.219.145	2026-10-24 13:42:05.639223+00
2043	charliehounkanrin@gmail.com	td	t	41.79.217.120	2026-10-24 14:46:52.289201+00
2044	jealexhouegbe	admin	t	102.215.138.186	2026-10-24 16:14:38.825074+00
2045	jealexhouegbe	admin	t	41.79.219.35	2026-10-24 17:12:36.498774+00
2046	leopoldchangodele@gmail.com	td	t	41.216.54.189	2026-10-24 18:01:23.861921+00
2047	charliehounkanrin@gmail.com	td	t	41.79.217.120	2026-10-24 19:33:55.518355+00
2048	leopoldchangodele@gmail.com	td	t	41.216.54.189	2026-10-24 20:07:50.175668+00
2049	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.164	2026-10-24 20:27:09.543987+00
2050	leopoldchangodele@gmail.com	td	t	41.216.54.189	2026-10-24 21:36:05.368054+00
2051	viptomtogbe@gmail.com	td	t	137.255.210.30	2026-10-24 21:36:05.536723+00
2052	aldolalumiere80@gmail.com	td	t	102.202.111.164	2026-10-24 22:44:29.683466+00
2053	aldolalumiere80@gmail.com	td	t	102.202.111.164	2026-10-24 22:45:27.445683+00
2054	akakpoenock00@gmail.com	td	t	137.255.36.183	2026-10-24 23:21:34.689248+00
2055	leopoldchangodele@gmail.com	td	t	41.216.53.117	2026-10-25 06:57:04.977057+00
2056	akakpoenock00@gmail.com	td	t	137.255.36.183	2026-10-25 06:57:41.942673+00
2057	charliehounkanrin@gmail.com	td	t	137.255.50.114	2026-10-25 07:02:09.884499+00
2058	leopoldchangodele@gmail.com	td	t	41.216.53.117	2026-10-25 07:50:56.158405+00
2059	jealexhouegbe	admin	t	102.215.138.186	2026-10-25 07:56:24.726482+00
2060	charliehounkanrin@gmail.com	td	t	137.255.50.114	2026-10-25 08:01:49.339869+00
2061	ferdinandagossou03@gmail.com	td	t	41.216.53.89	2026-10-25 08:08:11.475718+00
2062	ghics2000@yahoo.fr	td	t	156.0.213.173	2026-10-25 08:16:00.486899+00
2063	ghics2000@yahoo.fr	td	t	156.0.213.173	2026-10-25 08:16:47.048774+00
2064	gedeonfintovitchede@gmail.com	td	t	197.234.219.254	2026-10-25 08:29:18.534707+00
2065	leopoldchangodele@gmail.com	td	t	41.216.53.117	2026-10-25 10:17:58.34093+00
2066	jealexhouegbe	admin	t	102.215.138.186	2026-10-25 11:26:32.711741+00
2067	leopoldchangodele@gmail.com	td	t	41.216.53.102	2026-10-25 14:22:50.745254+00
2068	charliehounkanrin@gmail.com	td	t	197.234.219.249	2026-10-25 15:31:34.320279+00
2069	quenumparfait	admin	t	41.138.89.211	2026-10-25 15:35:11.404459+00
2070	leopoldchangodele@gmail.com	td	t	41.216.53.102	2026-10-25 16:26:35.387934+00
2071	amankpemodeste761@gmail.com	td	t	41.79.219.85	2026-10-25 18:30:00.008341+00
2072	leopoldchangodele@gmail.com	td	t	41.216.53.102	2026-10-25 19:17:16.919256+00
2073	jealexhouegbe	admin	t	102.215.138.186	2026-10-25 19:36:45.186478+00
2074	charliehounkanrin@gmail.com	td	t	197.234.219.249	2026-10-25 19:49:50.700266+00
2075	ekponnatonjeanclaude@gmail.com	td	t	137.255.67.240	2026-10-25 19:50:27.717819+00
2076	aremouramziath@gmail.com	td	t	154.66.134.70	2026-10-25 19:53:48.150642+00
2077	leopoldchangodele@gmail.com	td	t	41.216.53.102	2026-10-25 19:56:09.551926+00
2078	degnonfrederics@gmail.com	td	f	197.234.219.199	2026-10-25 20:32:17.689044+00
2079	degnonfrederics@gmail.com	td	f	197.234.219.199	2026-10-25 20:32:37.431646+00
2080	degnonfrederics@gmail.com	td	t	197.234.219.199	2026-10-25 20:32:46.388709+00
2081	leopoldchangodele@gmail.com	td	t	41.216.53.102	2026-10-25 20:39:51.689142+00
2082	aldolalumiere80@gmail.com	td	t	102.202.111.195	2026-10-25 20:54:57.517448+00
2083	aldolalumiere80@gmail.com	td	t	102.202.111.195	2026-10-25 20:55:54.015264+00
2084	nistani21@gmail.com	td	t	41.216.54.75	2026-10-25 21:17:47.129358+00
2085	faroukaremou5@gmail.com	td	t	102.202.111.10	2026-10-25 21:23:45.308212+00
2086	jealexhouegbe	admin	t	102.215.138.186	2026-10-25 22:51:52.171718+00
2087	jealexhouegbe	admin	t	102.215.138.186	2026-10-25 23:31:30.91948+00
2088	aldolalumiere80@gmail.com	td	t	102.202.111.29	2026-10-26 00:17:54.326283+00
2089	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 02:36:47.615029+00
2090	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 03:49:01.964072+00
2091	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 06:26:19.527134+00
2092	charliehounkanrin@gmail.com	td	t	197.234.219.249	2026-10-26 06:29:20.899242+00
2093	charliehounkanrin@gmail.com	td	t	197.234.219.249	2026-10-26 06:40:17.985252+00
2094	charliehounkanrin@gmail.com	td	t	197.234.219.249	2026-10-26 06:42:12.8915+00
2095	charliehounkanrin@gmail.com	td	t	197.234.219.249	2026-10-26 06:44:34.480598+00
2096	carlosbokononhoui@gmail.com	td	t	137.255.176.189	2026-10-26 06:45:20.509778+00
2097	carlosbokononhoui@gmail.com	td	t	137.255.176.189	2026-10-26 06:46:54.718947+00
2098	mawougnongael91@gmail.com	td	t	102.202.111.128	2026-10-26 06:50:42.102698+00
2099	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-26 06:51:08.57896+00
2100	faroukaremou5@gmail.com	td	t	102.202.111.10	2026-10-26 06:57:27.509612+00
2101	ekponnatonjeanclaude@gmail.com	td	t	137.255.146.207	2026-10-26 06:58:53.813518+00
2102	sedodeconstant@gmail.com	td	t	41.216.54.9	2026-10-26 07:07:47.039784+00
2103	charliehounkanrin@gmail.com	td	t	197.234.219.249	2026-10-26 07:21:16.820208+00
2104	nistani21@gmail.com	td	t	41.216.54.75	2026-10-26 07:24:41.173281+00
2105	piomedesse@gmail.com	td	t	197.234.219.145	2026-10-26 07:25:16.285546+00
2106	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 07:29:34.751294+00
2107	mawougnongael91@gmail.com	td	t	102.202.111.128	2026-10-26 07:31:29.351688+00
2108	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 07:54:25.713494+00
2109	amankpemodeste761@gmail.com	td	t	197.234.219.233	2026-10-26 07:54:33.291901+00
2110	urielaxelhouegbe@gmail.com	td	t	102.215.138.186	2026-10-26 08:09:43.294202+00
2111	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-26 08:21:01.681997+00
2112	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 08:35:20.280304+00
2113	ferdinandagossou03@gmail.com	td	t	41.85.163.45	2026-10-26 08:45:29.61636+00
2114	charliehounkanrin@gmail.com	td	t	137.255.181.218	2026-10-26 08:56:58.735874+00
2115	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 08:58:49.720524+00
2116	degnonfrederics@gmail.com	td	f	197.234.219.219	2026-10-26 09:04:23.014779+00
2117	degnonfrederics@gmail.com	td	f	197.234.219.219	2026-10-26 09:04:34.709745+00
2118	degnonfrederics@gmail.com	td	f	197.234.219.219	2026-10-26 09:04:45.411767+00
2119	degnonfrederics@gmail.com	td	f	197.234.219.219	2026-10-26 09:04:55.192336+00
2120	degnonfrederics@gmail.com	td	t	197.234.219.219	2026-10-26 09:05:36.922476+00
2121	ghics2000@yahoo.fr	td	t	137.255.165.14	2026-10-26 09:14:20.487161+00
2122	ghics2000@yahoo.fr	td	t	137.255.165.14	2026-10-26 09:14:40.890271+00
2123	viptomtogbe@gmail.com	td	t	197.234.219.253	2026-10-26 09:20:15.518967+00
2124	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 09:25:07.943371+00
2125	viptomtogbe@gmail.com	td	t	197.234.219.253	2026-10-26 09:32:12.161429+00
2126	leopoldchangodele@gmail.com	td	t	137.255.58.222	2026-10-26 09:47:42.350568+00
2127	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 09:48:37.705924+00
2128	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 09:59:27.280432+00
2129	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 10:16:08.591309+00
2130	aldolalumiere80@gmail.com	td	t	102.202.111.220	2026-10-26 10:27:57.027784+00
2131	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 10:50:50.109758+00
2132	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 11:02:33.306921+00
2133	degnonfrederics@gmail.com	td	f	197.234.219.219	2026-10-26 11:18:58.262561+00
2134	degnonfrederics@gmail.com	td	t	197.234.219.219	2026-10-26 11:19:03.732489+00
2135	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 11:42:12.882304+00
2136	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 11:43:37.945483+00
2137	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 11:48:29.343946+00
2138	faroukaremou5@gmail.com	td	t	102.202.111.10	2026-10-26 11:48:35.543835+00
2139	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 12:00:33.662177+00
2140	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 12:29:21.387954+00
2141	gedeonfintovitchede@gmail.com	td	t	197.234.223.199	2026-10-26 13:23:59.160997+00
2142	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 13:56:28.482943+00
2143	nistani21@gmail.com	td	t	197.234.223.205	2026-10-26 14:01:03.449691+00
2144	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 14:14:52.761984+00
2145	urielhouegbe	admin	t	102.215.138.186	2026-10-26 14:40:14.527968+00
2146	bienvenuedou112@gmail.com	td	t	102.202.111.124	2026-10-26 14:43:46.344227+00
2147	urielaxelhouegbe@gmail.com	td	t	102.215.138.186	2026-10-26 15:25:22.80764+00
2148	lucazandohounsi65@gmail.com	td	t	41.85.163.103	2026-10-26 15:59:28.386+00
2149	magbondejerome@gmail.com	td	t	197.234.219.158	2026-10-26 16:32:54.403695+00
2150	gedeonfintovitchede@gmail.com	td	t	197.234.223.199	2026-10-26 16:45:10.830798+00
2151	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 16:55:47.514729+00
2152	nistani21@gmail.com	td	t	197.234.223.205	2026-10-26 17:09:54.631179+00
2153	urielaxelhouegbe@gmail.com	td	t	102.215.138.186	2026-10-26 17:23:31.811033+00
2154	jealexhouegbe	admin	t	102.215.138.186	2026-10-26 17:30:25.891102+00
2155	charliehounkanrin@gmail.com	td	t	41.79.219.68	2026-10-26 18:18:55.649648+00
2156	jeremieabidegbekponou@gmail.com	td	t	156.0.213.182	2026-10-26 18:48:29.022775+00
2157	piomedesse@gmail.com	td	t	197.234.219.254	2026-10-26 18:49:58.622034+00
2158	faroukaremou5@gmail.com	td	t	41.79.217.111	2026-10-26 18:55:33.828632+00
2159	viptomtogbe@gmail.com	td	t	137.255.221.118	2026-10-26 20:01:53.201197+00
2160	ghics2000@yahoo.fr	td	t	102.202.111.221	2026-10-26 20:16:19.843376+00
2161	viptomtogbe@gmail.com	td	t	137.255.221.118	2026-10-26 20:23:29.05513+00
2162	amankpemodeste761@gmail.com	td	t	41.79.219.179	2026-10-26 21:34:52.391956+00
2163	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-26 22:41:14.903459+00
2164	gedeonfintovitchede@gmail.com	td	t	197.234.223.199	2026-10-26 23:02:22.653806+00
2165	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 00:48:06.723279+00
2166	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 00:57:23.641392+00
2167	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 01:55:22.595052+00
2168	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 01:55:39.583284+00
2169	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 01:56:23.948445+00
2170	faroukaremou5@gmail.com	td	t	102.202.111.237	2026-10-27 02:08:22.5882+00
2171	amankpemodeste761@gmail.com	td	t	102.202.111.234	2026-10-27 03:41:24.243107+00
2172	marianototin@gmail.com	td	t	41.216.54.78	2026-10-27 03:46:09.037427+00
2173	charliehounkanrin@gmail.com	td	t	137.255.206.161	2026-10-27 03:53:57.840497+00
2174	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 04:00:35.823822+00
2175	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 04:00:49.536198+00
2176	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 04:01:14.968699+00
2177	bienvenuedou112@gmail.com	td	t	41.138.89.214	2026-10-27 04:15:53.447346+00
2178	bienvenuedou112@gmail.com	td	t	41.138.89.214	2026-10-27 04:24:48.123382+00
2179	ekponnatonjeanclaude@gmail.com	td	t	137.255.23.219	2026-10-27 04:29:25.345417+00
2180	amankpemodeste761@gmail.com	td	t	102.202.111.59	2026-10-27 04:39:30.019463+00
2181	bienvenuedou112@gmail.com	td	t	41.138.89.214	2026-10-27 04:44:28.099116+00
2182	degnonfrederics@gmail.com	td	t	102.202.111.159	2026-10-27 04:49:38.265652+00
2183	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-27 05:16:42.358759+00
2184	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-27 05:31:14.492343+00
2185	florenthinnou@gmail.com	td	t	41.85.162.41	2026-10-27 05:40:38.13177+00
2186	magbondejerome@gmail.com	td	t	197.234.223.232	2026-10-27 05:49:31.822339+00
2187	charliehounkanrin@gmail.com	td	t	102.202.111.41	2026-10-27 06:21:00.536053+00
2188	urielaxelhouegbe@gmail.com	td	t	102.215.136.53	2026-10-27 06:21:30.016592+00
2189	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 06:21:34.197503+00
2190	viptomtogbe@gmail.com	td	t	137.255.71.202	2026-10-27 06:25:31.038662+00
2191	gedeonfintovitchede@gmail.com	td	t	197.234.219.149	2026-10-27 06:35:05.712483+00
2192	viptomtogbe@gmail.com	td	t	137.255.71.202	2026-10-27 06:36:03.702214+00
2193	sedodeconstant@gmail.com	td	t	197.234.223.205	2026-10-27 06:40:44.856141+00
2194	carlosbokononhoui@gmail.com	td	t	102.202.111.101	2026-10-27 06:41:21.815572+00
2195	nistani21@gmail.com	td	t	102.202.111.52	2026-10-27 06:43:58.443027+00
2196	jeremieabidegbekponou@gmail.com	td	t	156.0.213.182	2026-10-27 06:44:42.255309+00
2197	aldolalumiere80@gmail.com	td	t	102.202.111.166	2026-10-27 06:44:55.897753+00
2198	urielaxelhouegbe@gmail.com	td	t	102.215.136.53	2026-10-27 06:48:21.03278+00
2199	aremouramziath@gmail.com	td	t	41.85.163.196	2026-10-27 06:53:12.503591+00
2200	ghics2000@yahoo.fr	td	t	41.79.217.127	2026-10-27 07:04:57.482188+00
2201	amankpemodeste761@gmail.com	td	t	102.202.111.32	2026-10-27 07:06:25.407731+00
2202	sedodeconstant@gmail.com	td	t	197.234.223.205	2026-10-27 07:09:32.504589+00
2203	gedeonfintovitchede@gmail.com	td	t	197.234.219.149	2026-10-27 07:10:28.00024+00
2204	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-27 07:15:31.463558+00
2205	charliehounkanrin@gmail.com	td	t	102.202.111.41	2026-10-27 07:35:46.049284+00
2206	mawougnongael91@gmail.com	td	t	102.202.111.25	2026-10-27 07:43:18.621062+00
2207	bienvenuedou112@gmail.com	td	t	137.255.151.38	2026-10-27 07:45:28.571131+00
2208	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 08:06:46.21927+00
2209	gedeonfintovitchede@gmail.com	td	t	197.234.219.149	2026-10-27 08:09:37.927511+00
2210	bienvenuedou112@gmail.com	td	t	137.255.151.38	2026-10-27 08:11:35.220185+00
2211	bienvenuedou112@gmail.com	td	t	137.255.151.38	2026-10-27 08:15:17.324573+00
2212	faroukaremou5@gmail.com	td	t	41.79.219.212	2026-10-27 08:35:33.578923+00
2213	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.122	2026-10-27 08:37:48.588282+00
2214	charliehounkanrin@gmail.com	td	t	102.202.111.41	2026-10-27 08:41:48.149022+00
2215	charliehounkanrin@gmail.com	td	t	102.202.111.41	2026-10-27 09:08:02.656013+00
2216	zoutounnouf@gmail.com	td	t	197.234.219.199	2026-10-27 09:10:53.622151+00
2217	ferdinandagossou03@gmail.com	td	t	41.216.53.156	2026-10-27 09:15:43.296878+00
2218	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-27 09:22:31.655311+00
2219	charliehounkanrin@gmail.com	td	t	102.202.111.41	2026-10-27 09:59:45.956511+00
2220	leopoldchangodele@gmail.com	td	t	102.202.111.19	2026-10-27 10:09:28.937034+00
2221	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 10:10:10.331824+00
2222	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	102.215.136.53	2026-10-27 10:11:35.520764+00
2223	piomedesse@gmail.com	td	t	102.202.111.41	2026-10-27 10:30:08.872357+00
2224	nistani21@gmail.com	td	t	102.202.111.240	2026-10-27 10:33:24.070898+00
2225	florenthinnou@gmail.com	td	t	41.216.53.153	2026-10-27 10:36:07.638203+00
2226	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-27 10:39:06.241174+00
2227	aremouramziath@gmail.com	td	t	154.66.134.70	2026-10-27 10:41:59.738145+00
2228	charliehounkanrin@gmail.com	td	t	102.202.111.41	2026-10-27 10:42:11.735736+00
2229	degnonfrederics@gmail.com	td	f	102.202.111.40	2026-10-27 10:49:53.581615+00
2230	degnonfrederics@gmail.com	td	f	102.202.111.40	2026-10-27 10:49:56.245198+00
2231	degnonfrederics@gmail.com	td	f	102.202.111.40	2026-10-27 10:49:59.408174+00
2232	degnonfrederics@gmail.com	td	t	102.202.111.40	2026-10-27 10:50:12.69266+00
2233	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-27 10:54:30.158563+00
2234	piomedesse@gmail.com	td	t	102.202.111.107	2026-10-27 10:56:04.936125+00
2235	jeremieabidegbekponou@gmail.com	td	t	156.0.213.182	2026-10-27 11:00:22.723815+00
2236	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 11:01:46.220997+00
2237	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	102.215.136.53	2026-10-27 11:02:25.7885+00
2238	amankpemodeste761@gmail.com	td	t	102.202.111.226	2026-10-27 11:05:42.529336+00
2239	nistani21@gmail.com	td	t	102.202.111.240	2026-10-27 11:06:53.272346+00
2240	piomedesse@gmail.com	td	f	102.202.111.178	2026-10-27 11:20:47.780886+00
2241	piomedesse@gmail.com	td	t	102.202.111.178	2026-10-27 11:21:10.564147+00
2242	mawougnongael91@gmail.com	td	t	102.202.111.25	2026-10-27 11:44:02.635059+00
2243	charliehounkanrin@gmail.com	td	t	102.202.111.41	2026-10-27 11:53:38.09027+00
2244	ekponnatonjeanclaude@gmail.com	td	t	137.255.23.219	2026-10-27 11:56:15.443231+00
2245	claudekinninnon@gmail.com	td	t	137.255.144.170	2026-10-27 12:19:23.517152+00
2246	jealexhouegbe	admin	t	102.215.136.53	2026-10-27 12:27:48.529732+00
2247	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	102.215.136.53	2026-10-27 12:28:15.117564+00
2248	yessoufouassiath@gmail.com	td	t	41.79.219.98	2026-10-27 12:29:23.821831+00
2249	bienvenuedou112@gmail.com	td	t	137.255.151.38	2026-10-27 12:45:17.194348+00
2250	leopoldchangodele@gmail.com	td	t	137.255.115.73	2026-10-27 12:50:55.078528+00
2251	nistani21@gmail.com	td	t	102.202.111.192	2026-10-27 14:36:54.491332+00
2252	magbondejerome@gmail.com	td	t	197.234.223.232	2026-10-27 16:05:44.125247+00
2253	nistani21@gmail.com	td	t	102.202.111.192	2026-10-27 18:15:50.5055+00
2254	urielhouegbe	admin	t	154.66.139.32	2026-10-27 18:43:44.186593+00
2255	urielhouegbe	admin	t	154.66.139.32	2026-10-27 18:51:35.345727+00
2256	carlosbokononhoui@gmail.com	td	t	102.202.111.101	2026-10-27 19:29:50.505377+00
2257	piomedesse@gmail.com	td	t	102.202.111.250	2026-10-27 19:39:13.271259+00
2258	angekarson1@gmail.com	td	t	41.216.54.116	2026-10-27 20:30:36.000549+00
2259	aldolalumiere80@gmail.com	td	t	102.202.111.206	2026-10-27 21:51:21.160196+00
2260	akakpoenock00@gmail.com	td	t	137.255.138.39	2026-10-27 22:27:39.39407+00
2261	degnonfrederics@gmail.com	td	t	102.202.111.28	2026-10-28 04:09:20.298476+00
2262	leopoldchangodele@gmail.com	td	t	102.202.111.176	2026-10-28 04:40:30.680447+00
2263	aldolalumiere80@gmail.com	td	t	41.85.163.241	2026-10-28 04:54:40.499046+00
2264	leopoldchangodele@gmail.com	td	t	102.202.111.176	2026-10-28 05:06:31.702417+00
2265	ekponnatonjeanclaude@gmail.com	td	t	137.255.193.31	2026-10-28 05:14:19.981508+00
2266	degnonfrederics@gmail.com	td	t	102.202.111.28	2026-10-28 05:21:37.567474+00
2267	jealexhouegbe	admin	t	154.66.139.32	2026-10-28 06:15:13.779417+00
2268	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.32	2026-10-28 06:15:45.982923+00
2269	degnonfrederics@gmail.com	td	t	102.202.111.28	2026-10-28 06:28:23.423445+00
2270	magbondejerome@gmail.com	td	t	102.202.111.190	2026-10-28 06:41:56.30954+00
2271	urielaxelhouegbe@gmail.com	td	t	154.66.139.32	2026-10-28 06:48:16.700179+00
2272	magbondejerome@gmail.com	td	t	102.202.111.190	2026-10-28 06:59:32.448902+00
2273	leopoldchangodele@gmail.com	td	t	102.202.111.176	2026-10-28 07:22:48.554766+00
2274	urielhouegbe	admin	t	154.66.139.32	2026-10-28 07:36:38.020199+00
2275	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.75	2026-10-28 07:41:44.783363+00
2276	magbondejerome@gmail.com	td	f	102.202.111.190	2026-10-28 07:49:57.714204+00
2277	magbondejerome@gmail.com	td	t	102.202.111.190	2026-10-28 07:50:15.227464+00
2278	ghics2000@yahoo.fr	td	t	137.255.16.88	2026-10-28 08:07:21.024039+00
2279	ghics2000@yahoo.fr	td	t	137.255.16.88	2026-10-28 08:24:21.264924+00
2280	viptomtogbe@gmail.com	td	t	137.255.170.84	2026-10-28 08:36:28.116753+00
2281	ghics2000@yahoo.fr	td	t	137.255.16.88	2026-10-28 08:40:46.813915+00
2282	ghics2000@yahoo.fr	td	t	137.255.16.88	2026-10-28 08:46:30.480678+00
2283	aldolalumiere80@gmail.com	td	t	41.85.163.241	2026-10-28 09:08:30.274847+00
2284	florenthinnou@gmail.com	td	t	137.255.139.242	2026-10-28 09:14:06.395059+00
2285	leopoldchangodele@gmail.com	td	t	102.202.111.176	2026-10-28 09:22:44.470794+00
2286	urielhouegbe	admin	t	154.66.139.32	2026-10-28 11:18:58.456189+00
2287	florenthinnou@gmail.com	td	t	41.85.162.105	2026-10-28 11:33:53.911378+00
2288	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-28 11:38:50.428567+00
2289	viptomtogbe@gmail.com	td	t	137.255.170.84	2026-10-28 11:44:19.425748+00
2290	degnonfrederics@gmail.com	td	f	102.202.111.124	2026-10-28 11:58:41.449393+00
2291	degnonfrederics@gmail.com	td	f	102.202.111.124	2026-10-28 11:58:59.067713+00
2292	degnonfrederics@gmail.com	td	t	102.202.111.124	2026-10-28 11:59:20.819449+00
2293	jealexhouegbe	admin	t	102.202.111.213	2026-10-28 11:59:36.679876+00
2294	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	f	102.202.111.213	2026-10-28 12:00:25.643099+00
2295	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	102.202.111.213	2026-10-28 12:00:49.79237+00
2296	leopoldchangodele@gmail.com	td	t	137.255.107.72	2026-10-28 12:01:27.939919+00
2297	angekarson1@gmail.com	td	t	41.85.162.177	2026-10-28 12:03:20.024407+00
2298	ghics2000@yahoo.fr	td	t	197.234.219.196	2026-10-28 12:19:00.275663+00
2299	urielhouegbe	admin	t	154.66.139.32	2026-10-28 12:23:37.311494+00
2300	ghics2000@yahoo.fr	td	t	197.234.219.196	2026-10-28 12:28:32.019469+00
2301	claudekinninnon@gmail.com	td	t	41.79.217.119	2026-10-28 12:31:28.82069+00
2302	jealexhouegbe	admin	t	102.202.111.213	2026-10-28 12:33:02.450019+00
2303	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	102.202.111.213	2026-10-28 12:33:31.563119+00
2304	ghics2000@yahoo.fr	td	t	137.255.16.88	2026-10-28 12:37:24.358574+00
2305	degnonfrederics@gmail.com	td	t	102.202.111.124	2026-10-28 13:17:24.040049+00
2306	ferdinandagossou03@gmail.com	td	t	41.85.162.109	2026-10-28 13:21:55.24992+00
2307	leopoldchangodele@gmail.com	td	t	137.255.107.72	2026-10-28 13:30:36.524765+00
2308	charliehounkanrin@gmail.com	td	t	102.202.111.49	2026-10-28 13:48:38.267266+00
2309	aldolalumiere80@gmail.com	td	t	41.85.163.241	2026-10-28 14:17:42.563475+00
2310	yetbaginn	admin	f	41.138.89.156	2026-10-28 14:44:06.923226+00
2311	yetbaginn	admin	f	41.138.89.156	2026-10-28 14:44:37.017371+00
2312	yetbaginn	admin	f	41.138.89.156	2026-10-28 14:44:51.047554+00
2313	yetbaginn	admin	f	41.138.89.156	2026-10-28 14:45:16.630634+00
2314	yetbaginn	admin	f	41.138.89.156	2026-10-28 14:46:09.745408+00
2315	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-28 14:59:16.591888+00
2316	carlosbokononhoui@gmail.com	td	t	137.255.192.118	2026-10-28 15:06:27.030835+00
2317	charliehounkanrin@gmail.com	td	t	102.202.111.49	2026-10-28 15:12:43.236184+00
2318	yetbaginn	admin	f	41.138.89.156	2026-10-28 15:19:23.069516+00
2319	yetbaginn	admin	f	41.138.89.156	2026-10-28 15:19:56.457304+00
2320	urielhouegbe	admin	t	41.85.163.242	2026-10-28 15:20:23.357958+00
2321	yetbaginn	admin	f	41.138.89.156	2026-10-28 15:20:36.840173+00
2322	yetbaginn	admin	f	41.138.89.156	2026-10-28 15:21:35.637466+00
2323	yetbaginn	admin	f	41.138.89.156	2026-10-28 15:23:47.302652+00
2324	yetbaginn	admin	f	41.85.163.242	2026-10-28 15:28:01.480361+00
2325	urielhouegbe	admin	t	41.85.163.242	2026-10-28 15:33:20.606054+00
2326	yetbaginn	admin	f	41.138.89.156	2026-10-28 15:35:33.627468+00
2327	yetbaginn	admin	f	41.138.89.156	2026-10-28 15:36:31.387638+00
2328	yetbaginn	admin	f	41.85.163.242	2026-10-28 15:37:20.564265+00
2329	urielhouegbe	admin	t	41.85.163.242	2026-10-28 15:37:44.212321+00
2330	gedeonfintovitchede@gmail.com	td	t	102.202.111.221	2026-10-28 15:47:19.003281+00
2331	carlosbokononhoui@gmail.com	td	t	137.255.192.118	2026-10-28 16:22:03.704776+00
2332	akakpoenock00@gmail.com	td	t	102.202.111.199	2026-10-28 18:10:57.281399+00
2333	leopoldchangodele@gmail.com	td	t	41.85.163.134	2026-10-28 18:15:38.313027+00
2334	charliehounkanrin@gmail.com	td	t	102.202.111.49	2026-10-28 19:00:30.091453+00
2335	faroukaremou5@gmail.com	td	t	197.234.223.223	2026-10-28 19:12:16.634061+00
2336	simkiki30@gmail.com	td	t	102.202.111.235	2026-10-28 19:14:28.962247+00
2337	simkiki30@gmail.com	td	t	102.215.139.93	2026-10-28 19:50:39.062076+00
2338	carlosbokononhoui@gmail.com	td	t	137.255.48.3	2026-10-28 19:58:20.690208+00
2339	akakpoenock00@gmail.com	td	t	137.255.138.39	2026-10-28 21:15:41.681305+00
2340	nistani21@gmail.com	td	t	41.85.163.231	2026-10-28 21:30:32.046471+00
2341	nistani21@gmail.com	td	t	41.85.163.231	2026-10-28 21:35:43.615051+00
2342	jealexhouegbe	admin	t	102.202.111.159	2026-10-28 23:02:10.445261+00
2343	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	102.202.111.159	2026-10-28 23:03:27.371586+00
2344	jealexhouegbe	admin	t	102.202.111.159	2026-10-29 01:56:06.647264+00
2345	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	f	102.202.111.159	2026-10-29 01:56:43.940951+00
2346	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	102.202.111.159	2026-10-29 01:57:14.432978+00
2347	jealexhouegbe	admin	t	102.202.111.202	2026-10-29 03:47:52.725617+00
2348	charliehounkanrin@gmail.com	td	t	137.255.104.3	2026-10-29 05:04:33.665375+00
2349	jealexhouegbe	admin	t	154.66.139.198	2026-10-29 06:03:14.869279+00
2350	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-29 06:03:47.844361+00
2351	urielaxelhouegbe@gmail.com	td	t	154.66.139.198	2026-10-29 06:16:38.613394+00
2352	marianototin@gmail.com	td	t	197.234.219.222	2026-10-29 06:21:37.816734+00
2353	jealexhouegbe	admin	t	154.66.139.198	2026-10-29 06:54:56.843043+00
2354	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-29 06:55:43.82585+00
2355	sedodeconstant@gmail.com	td	t	197.234.219.249	2026-10-29 07:21:17.961595+00
2356	jealexhouegbe	admin	t	154.66.139.198	2026-10-29 07:32:56.966698+00
2357	faroukaremou5@gmail.com	td	t	154.72.113.193	2026-10-29 08:14:02.368815+00
2358	marianototin@gmail.com	td	t	197.234.219.249	2026-10-29 08:50:42.304455+00
2359	carlosbokononhoui@gmail.com	td	t	154.72.113.198	2026-10-29 09:00:09.046569+00
2360	sedodeconstant@gmail.com	td	t	197.234.219.249	2026-10-29 09:01:00.531555+00
2361	bienvenuedou112@gmail.com	td	t	41.138.89.199	2026-10-29 10:29:53.276434+00
2362	bienvenuedou112@gmail.com	td	t	41.138.89.199	2026-10-29 10:32:46.509703+00
2363	gedeonfintovitchede@gmail.com	td	t	102.202.111.181	2026-10-29 11:04:33.754978+00
2364	jealexhouegbe	admin	f	154.66.139.198	2026-10-29 11:43:11.767238+00
2365	jealexhouegbe	admin	t	154.66.139.198	2026-10-29 11:43:29.561224+00
2366	jealexhouegbe	admin	t	154.66.139.198	2026-10-29 11:44:30.121518+00
2367	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-29 11:45:18.146242+00
2368	ghics2000@yahoo.fr	td	t	137.255.16.88	2026-10-29 11:56:26.678656+00
2369	piomedesse@gmail.com	td	t	41.85.162.208	2026-10-29 16:18:31.314672+00
2370	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-29 16:26:07.406431+00
2371	mawougnongael91@gmail.com	td	t	197.234.223.223	2026-10-29 18:54:34.611642+00
2372	angekarson1@gmail.com	td	t	41.216.53.143	2026-10-29 19:22:10.828052+00
2373	faroukaremou5@gmail.com	td	t	197.234.219.243	2026-10-29 20:32:00.385547+00
2374	leopoldchangodele@gmail.com	td	t	41.85.162.54	2026-10-29 20:32:44.345962+00
2375	yetbaginn	admin	f	156.0.213.180	2026-10-29 20:52:46.575524+00
2376	jealexhouegbe	admin	t	154.66.139.198	2026-10-29 20:54:30.153827+00
2377	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-29 20:55:14.314198+00
2378	angekarson1@gmail.com	td	t	41.216.54.231	2026-10-29 20:59:17.897919+00
2379	yetbaginn	admin	t	156.0.213.180	2026-10-29 21:00:15.958339+00
2380	urielhouegbe	admin	t	154.66.139.198	2026-10-29 21:15:40.6291+00
2381	urielaxelhouegbe@gmail.com	admin	f	154.66.139.198	2026-10-29 21:40:22.502792+00
2382	urielaxelhouegbe@gmail.com	td	t	154.66.139.198	2026-10-29 21:41:19.60369+00
2383	yessoufouassiath@gmail.com	td	t	197.234.219.237	2026-10-29 21:52:38.084696+00
2384	dkobahubert@gmail.com	td	t	102.202.111.230	2026-10-29 22:20:08.424225+00
2385	jealexhouegbe	admin	t	154.66.139.198	2026-10-29 22:21:50.110835+00
2386	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-29 22:22:42.075122+00
2387	jealexhouegbe	admin	t	154.66.139.198	2026-10-30 04:13:57.660745+00
2388	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-30 04:14:33.378529+00
2389	akakpoenock00@gmail.com	td	t	137.255.36.209	2026-10-30 07:07:56.870945+00
2390	urielhouegbe	admin	t	154.66.139.198	2026-10-30 10:38:54.898073+00
2391	angekarson1@gmail.com	td	t	41.85.162.46	2026-10-30 13:04:04.462772+00
2392	urielhouegbe	admin	t	154.66.139.198	2026-10-30 13:10:14.186449+00
2393	jealexhouegbe	admin	t	154.66.139.198	2026-10-30 14:40:08.243883+00
2394	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-30 14:40:45.906137+00
2395	charliehounkanrin@gmail.com	td	t	41.79.219.23	2026-10-30 14:46:33.380858+00
2396	jealexhouegbe	admin	t	154.66.139.198	2026-10-30 14:59:01.630618+00
2397	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-30 14:59:47.480042+00
2398	urielhouegbe	admin	f	154.66.139.198	2026-10-30 16:46:24.032108+00
2399	urielhouegbe	admin	t	154.66.139.198	2026-10-30 16:46:41.402437+00
2400	jealexhouegbe	admin	t	197.234.219.219	2026-10-30 18:14:25.05985+00
2401	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	197.234.219.219	2026-10-30 18:14:57.4423+00
2402	urielhouegbe	admin	t	154.66.139.198	2026-10-30 18:18:05.984213+00
2403	bienvenuedou112@gmail.com	td	t	197.234.219.244	2026-10-30 18:33:56.465908+00
2404	aremouramziath@gmail.com	td	t	154.66.134.70	2026-10-30 19:02:34.244944+00
2405	leopoldchangodele@gmail.com	td	t	41.216.53.170	2026-10-30 19:14:37.567246+00
2406	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.80	2026-10-30 19:16:36.418778+00
2407	urielhouegbe	admin	t	154.66.139.198	2026-10-30 19:29:34.695676+00
2408	akakpoenock00@gmail.com	td	t	137.255.73.207	2026-10-30 19:45:17.887126+00
2409	dansoumika8@gmail.com	td	t	102.202.111.220	2026-10-30 20:25:58.550633+00
2410	akakpoenock00@gmail.com	td	t	137.255.73.207	2026-10-30 20:48:39.028736+00
2411	jealexhouegbe	admin	t	154.66.139.198	2026-10-30 22:06:17.181536+00
2412	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-30 22:08:13.302527+00
2413	akakpoenock00@gmail.com	td	t	137.255.73.207	2026-10-30 23:41:20.660526+00
2414	jealexhouegbe	admin	t	154.66.139.198	2026-10-31 04:14:22.202935+00
2415	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-31 04:14:51.157507+00
2416	jealexhouegbe	admin	t	154.66.139.198	2026-10-31 06:11:10.781447+00
2417	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.198	2026-10-31 06:11:34.964063+00
2418	urielhouegbe	admin	t	197.234.219.209	2026-10-31 06:33:14.864666+00
2419	urielhouegbe	admin	t	197.234.219.209	2026-10-31 07:19:44.447854+00
2420	jealexhouegbe	admin	t	154.66.139.198	2026-10-31 07:22:16.237587+00
2421	yetbaginn	admin	t	41.138.90.85	2026-10-31 07:28:50.247775+00
2422	urielhouegbe	admin	t	197.234.219.209	2026-10-31 07:30:44.873699+00
2423	akakpoenock00@gmail.com	td	t	102.202.111.251	2026-10-31 08:14:21.496303+00
2424	quenumparfait	admin	t	156.0.213.213	2026-10-31 08:20:01.095278+00
2425	bienvenuedou112@gmail.om	td	f	197.234.219.206	2026-10-31 08:42:23.180389+00
2426	bienvenuedou112@gmail.om	td	f	197.234.219.206	2026-10-31 08:42:59.46544+00
2427	bienvenuedou112@gmail.om	td	f	197.234.219.206	2026-10-31 08:43:16.602917+00
2428	bienvenuedou112@gmail.om	td	f	197.234.219.206	2026-10-31 08:44:13.430956+00
2429	bienvenuedou112@gmail.om	td	f	197.234.219.206	2026-10-31 08:44:46.299391+00
2430	bienvenuedou112@gmail.com	td	t	197.234.219.206	2026-10-31 08:57:57.004025+00
2431	urielhouegbe	admin	t	197.234.219.209	2026-10-31 09:12:24.112643+00
2432	yetbaginn	admin	t	41.138.90.85	2026-10-31 10:19:43.353292+00
2433	urielhouegbe	admin	t	197.234.219.209	2026-10-31 10:20:02.680818+00
2434	jeremieabidegbekponou@gmail.com	td	t	156.0.213.195	2026-10-31 11:00:32.983049+00
2435	urielhouegbe	admin	t	197.234.219.209	2026-10-31 11:09:26.417478+00
2436	peter21	admin	f	197.234.219.209	2026-10-31 11:21:56.841998+00
2437	peter21	admin	f	197.234.219.209	2026-10-31 11:26:45.505069+00
2438	urielhouegbe	admin	t	197.234.219.209	2026-10-31 12:13:55.77017+00
2439	charliehounkanrin@gmail.com	td	t	41.79.219.180	2026-10-31 12:28:52.777247+00
2440	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-31 12:52:26.539139+00
2441	lucazandohounsi65@gmail.com	admin	f	154.72.113.118	2026-10-31 14:17:23.650426+00
2442	lucazandohounsi65@gmail.com	admin	f	154.72.113.118	2026-10-31 14:18:35.651307+00
2443	lucazandohounsi65@gmail.com	admin	f	154.72.113.118	2026-10-31 14:20:32.007282+00
2444	lucazandohounsi65@gmail.com	admin	f	154.72.113.118	2026-10-31 14:20:58.199145+00
2445	lucazandohounsi65@gmail.com	admin	f	154.72.113.118	2026-10-31 14:21:05.663391+00
2446	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-31 14:25:43.937954+00
2447	viptomtogbe@gmail.com	td	t	41.79.219.96	2026-10-31 14:33:00.903447+00
2448	andersondoliveira	admin	f	41.85.162.137	2026-10-31 14:44:19.701762+00
2449	andersondoliveira	admin	f	41.85.162.137	2026-10-31 14:47:55.846257+00
2450	azandohounsi	admin	f	154.72.113.118	2026-10-31 14:56:44.139583+00
2451	lucazandohounsi65@gmail.com	admin	f	154.72.113.118	2026-10-31 14:57:11.275159+00
2452	andersondoliveira	admin	f	41.85.162.137	2026-10-31 14:58:40.213874+00
2453	jealexhouegbe	admin	t	41.79.217.128	2026-10-31 14:58:56.507834+00
2454	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	41.79.217.128	2026-10-31 15:00:39.558399+00
2455	andersondoliveira	admin	f	41.85.162.137	2026-10-31 15:01:27.924424+00
2456	andersondoliveira	admin	f	41.85.162.137	2026-10-31 15:01:41.856736+00
2457	andersondoliveira	admin	f	41.85.162.137	2026-10-31 15:02:11.237432+00
2458	nanildoliveira	admin	f	41.85.162.137	2026-10-31 15:05:53.979486+00
2459	nanildoliveira	admin	f	41.85.162.137	2026-10-31 15:07:44.657411+00
2460	nanildoliveira	admin	f	41.85.162.137	2026-10-31 15:07:57.771137+00
2461	peter21	admin	f	41.216.53.234	2026-10-31 15:15:26.230393+00
2462	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 15:26:12.173272+00
2463	usergsr	admin	t	197.234.219.209	2026-10-31 15:32:53.970377+00
2464	andersondoliveira	admin	t	41.85.162.137	2026-10-31 15:41:33.980639+00
2465	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 16:17:06.47641+00
2466	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-31 16:20:30.300684+00
2467	jeremieabidegbekponou@gmail.com	td	t	41.138.89.201	2026-10-31 16:54:33.369915+00
2468	piomedesse@gmail.com	td	t	102.202.111.243	2026-10-31 17:08:13.297279+00
2469	jeremieabidegbekponou@gmail.com	td	t	41.138.89.201	2026-10-31 17:53:59.454537+00
2470	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 17:54:41.257475+00
2471	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 18:03:22.49559+00
2472	charliehounkanrin@gmail.com	td	t	41.79.219.180	2026-10-31 18:08:54.443542+00
2473	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 18:17:47.463975+00
2474	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 18:28:11.009456+00
2475	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 18:34:52.499108+00
2476	jealexhouegbe	admin	t	197.234.219.209	2026-10-31 18:41:19.035313+00
2477	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	197.234.219.209	2026-10-31 18:43:15.577667+00
2478	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-31 18:58:01.863713+00
2479	amankpemodeste761@gmail.com	td	t	102.202.111.121	2026-10-31 19:06:12.3975+00
2480	jeremieabidegbekponou@gmail.com	td	t	41.138.89.201	2026-10-31 19:06:41.270713+00
2481	akakpoenock00@gmail.com	td	t	102.202.111.251	2026-10-31 19:12:35.177889+00
2482	bossouraoul82@gmail.com	td	t	156.0.213.190	2026-10-31 19:17:36.662436+00
2483	simkiki30@gmail.com	td	t	102.202.111.200	2026-10-31 19:17:41.302667+00
2484	dansoumika8@gmail.com	td	t	102.202.111.249	2026-10-31 19:19:49.965613+00
2485	ekponnatonjeanclaude@gmail.com	td	t	137.255.65.93	2026-10-31 19:21:36.316927+00
2486	akakpoenock00@gmail.com	td	t	102.202.111.251	2026-10-31 19:48:31.944899+00
2487	jeremieabidegbekponou@gmail.com	td	t	41.138.89.201	2026-10-31 19:54:19.289658+00
2488	ekponnatonjeanclaude@gmail.com	td	t	137.255.65.93	2026-10-31 20:05:59.051251+00
2489	bienvenuedou112@gmail.com	td	t	197.234.219.206	2026-10-31 20:09:48.218306+00
2490	jealexhouegbe	admin	t	41.79.219.202	2026-10-31 20:47:56.675996+00
2491	amankpemodeste761@gmail.com	td	t	102.202.111.121	2026-10-31 20:48:25.514011+00
2492	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	41.79.219.202	2026-10-31 20:49:03.291114+00
2493	faroukaremou5@gmail.com	td	t	197.234.223.214	2026-10-31 20:53:02.578969+00
2494	jeremieabidegbekponou@gmail.com	td	t	156.0.213.196	2026-10-31 21:07:17.430513+00
2495	bossouraoul82@gmail.com	td	t	156.0.213.135	2026-10-31 21:22:36.266353+00
2496	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 21:22:43.633947+00
2497	marcepepe@gmail.com	td	t	41.138.90.79	2026-10-31 21:25:21.657279+00
2498	bossouraoul82@gmail.com	td	t	41.138.89.139	2026-10-31 21:41:03.586556+00
2499	jeremieabidegbekponou@gmail.com	td	t	156.0.213.196	2026-10-31 21:42:55.323555+00
2500	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 21:56:12.129764+00
2501	jealexhouegbe	admin	f	154.66.139.79	2026-10-31 21:58:26.210322+00
2502	jealexhouegbe	admin	f	154.66.139.79	2026-10-31 21:58:42.378212+00
2503	jealexhouegbe	admin	f	154.66.139.79	2026-10-31 21:58:55.627259+00
2504	jealexhouegbe	admin	f	154.66.139.79	2026-10-31 21:59:00.366757+00
2505	jealexhouegbe	admin	t	154.66.139.79	2026-10-31 21:59:25.674308+00
2506	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.79	2026-10-31 21:59:51.431146+00
2507	zoutounnouf@gmail.com	td	t	41.216.54.91	2026-10-31 22:06:54.572217+00
2508	lucazandohounsi65@gmail.com	td	t	154.72.113.118	2026-10-31 22:52:48.586693+00
2509	jealexhouegbe	admin	t	154.66.139.79	2026-11-01 05:56:01.869062+00
2510	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.79	2026-11-01 05:57:37.273599+00
2511	urielhouegbe	admin	t	154.66.139.79	2026-11-01 06:02:52.162558+00
2512	jealexhouegbe	admin	t	154.66.139.79	2026-11-01 06:24:25.711158+00
2513	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.79	2026-11-01 06:24:49.939929+00
2514	jealexhouegbe	admin	t	154.66.139.79	2026-11-01 07:29:55.010156+00
2515	jealexhouegbe	admin	t	154.66.139.79	2026-11-01 07:40:56.37744+00
2516	55899634-2a3d-4d0c-a169-c883ddd3b72f	admin	t	154.66.139.79	2026-11-01 07:41:16.296074+00
2517	charliehounkanrin@gmail.com	td	t	137.255.54.105	2026-11-01 07:49:38.704594+00
\.


--
-- Data for Name: matieres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matieres (id, nom, code, ordre, actif) FROM stdin;
1	Francais	FR	1	t
2	Mathematiques	MATHS	2	t
3	Anglais	ANG	3	t
5	SVT	SVT	5	t
6	Philosophie	PHILO	6	t
7	Histoire-Geographie	HG	7	t
8	Economie	ECO	8	t
9	Espagnol	ESP	9	t
10	Allemand	ALL	10	t
11	Com. Ecrite	COM_ECRITE	11	t
4	PCT	PCT	4	t
\.


--
-- Data for Name: mfa_backup_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mfa_backup_codes (id, user_id, code_hash, utilise, utilise_le, cree_le) FROM stdin;
1	55899634-2a3d-4d0c-a169-c883ddd3b72f	b0e0d282193d5a5212ac9600fe7d09dd218dbe4d27265e6e1f7ad9e80b4df86d	f	\N	2026-10-27 00:54:37.22565+00
2	55899634-2a3d-4d0c-a169-c883ddd3b72f	1bfe7d0de2491c99c23489730fe0a39f430a5244c2cf9e13811e342abc5f23b2	f	\N	2026-10-27 00:54:37.22565+00
3	55899634-2a3d-4d0c-a169-c883ddd3b72f	88341fafeddb6256d7771e9cb21a2664897329ee373756aac8174b1cebe31d69	f	\N	2026-10-27 00:54:37.22565+00
4	55899634-2a3d-4d0c-a169-c883ddd3b72f	3550448ce912eed9d3f9a72a6444296c1baf4124bc8b4f2c0359d0d2838a797a	f	\N	2026-10-27 00:54:37.22565+00
5	55899634-2a3d-4d0c-a169-c883ddd3b72f	0282ad7648f917cb1f02630eaa0e52e6ea9a14c35abfd629b73956d389a9f516	f	\N	2026-10-27 00:54:37.22565+00
\.


--
-- Data for Name: mois_exoneres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mois_exoneres (id, eleve_id, mois_souscription, annee_scolaire_id, motif, exonere_par, date_exoneration) FROM stdin;
1	467	Octobre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
2	467	Novembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
3	467	Decembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
4	467	Janvier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
5	467	Fevrier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
6	467	Mars	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
7	467	Avril	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
8	467	Mai	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
9	855	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:22:05.079475+00
10	855	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:22:05.079475+00
11	878	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:23:04.275416+00
12	737	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:23:58.686231+00
13	51	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:24:37.841311+00
14	419	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:38:02.728866+00
15	72	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:14.642648+00
16	72	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:14.642648+00
17	215	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:37.179525+00
18	215	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:37.179525+00
19	11	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:57:17.641216+00
20	902	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:57:59.869182+00
21	621	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-24 00:55:53.870528+00
22	936	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-24 00:57:37.93378+00
23	977	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-27 16:49:33.343448+00
24	977	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-27 16:49:33.343448+00
25	1049	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:06:18.230057+00
26	972	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:08:16.872281+00
27	843	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:14:14.497711+00
28	550	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:15:47.070313+00
29	530	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:16:51.747933+00
30	588	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:17:09.399889+00
31	55	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:54.068454+00
32	55	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:54.068454+00
33	55	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:54.068454+00
34	209	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.304046+00
35	209	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.304046+00
36	209	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.304046+00
37	243	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:46.103177+00
38	243	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:46.103177+00
39	243	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:46.103177+00
40	334	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.929034+00
41	334	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.929034+00
42	334	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.929034+00
43	457	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.770753+00
44	457	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.770753+00
45	457	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.770753+00
46	487	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:48.04716+00
47	487	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:48.04716+00
48	487	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:48.04716+00
49	497	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:24.107326+00
50	497	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:24.107326+00
51	497	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:24.107326+00
52	501	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.827843+00
53	501	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.827843+00
54	501	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.827843+00
55	58	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:30:20.558852+00
56	58	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:30:20.558852+00
57	164	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:05.159222+00
58	164	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:05.159222+00
59	270	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:47.012443+00
60	270	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:47.012443+00
63	456	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:02.425967+00
64	456	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:02.425967+00
65	480	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:44.225683+00
66	480	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:44.225683+00
67	490	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:26.566471+00
68	490	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:26.566471+00
69	502	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:58.908046+00
70	502	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:58.908046+00
72	193	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:36:33.104756+00
74	449	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:24.850541+00
75	469	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:51.278798+00
76	491	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:19.441822+00
77	509	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:59.567692+00
78	980	Octobre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
79	980	Novembre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
80	980	Decembre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
81	980	Janvier	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
82	980	Fevrier	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
83	980	Mars	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
84	980	Avril	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
85	980	Mai	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
86	549	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.360261+00
87	549	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.360261+00
88	549	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.360261+00
89	530	Fevrier	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:46:03.939152+00
90	530	Mars	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:46:03.939152+00
92	560	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.840072+00
93	560	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.840072+00
94	560	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.840072+00
95	564	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:37.897925+00
96	564	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:37.897925+00
97	570	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:07.16807+00
98	625	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.754526+00
99	625	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.754526+00
100	625	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.754526+00
101	862	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:51:08.758264+00
102	862	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:51:08.758264+00
103	620	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:21.538583+00
104	650	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.636325+00
105	650	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.636325+00
106	650	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.636325+00
110	328	Novembre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:55:12.497769+00
111	243	Avril	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:38:47.083336+00
112	244	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:45:33.926076+00
113	848	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:46:43.469785+00
114	53	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:47:08.76016+00
115	961	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:47:52.555197+00
116	177	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 04:25:20.939924+00
117	959	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 09:13:36.445431+00
118	459	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:46:09.269885+00
119	251	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:53:16.266288+00
120	251	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:53:16.266288+00
121	156	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:58:53.869719+00
122	156	Mai	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:00:23.352356+00
123	623	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:09:43.37038+00
124	623	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:09:43.37038+00
125	604	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:23:42.219663+00
126	605	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:25:10.011343+00
127	574	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:35:36.356497+00
128	842	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:43:22.176691+00
129	1072	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:50:47.530783+00
130	1060	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:55:52.963461+00
131	133	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:00:40.989879+00
132	133	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:00:40.989879+00
133	873	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:08:29.303855+00
134	1026	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:31:41.9043+00
135	1004	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:37:50.257888+00
136	203	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 20:51:49.442606+00
137	729	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-06 04:25:54.090502+00
138	395	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-06 20:54:45.857517+00
139	839	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 12:56:57.771222+00
140	100	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 19:07:19.89949+00
141	101	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 19:07:59.5437+00
142	1028	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 19:08:26.914104+00
143	935	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-09 23:13:08.242374+00
144	620	Fevrier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-09 23:15:00.788846+00
145	580	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-09 23:23:05.094686+00
146	815	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 06:23:24.883538+00
147	523	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 06:24:05.795251+00
148	1063	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 06:33:57.339723+00
149	1048	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 06:35:16.565063+00
150	633	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 06:36:17.780038+00
151	953	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 06:50:26.677715+00
152	34	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 06:55:37.893479+00
153	742	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:22:49.326304+00
154	241	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:32:22.588621+00
155	926	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:36:19.889561+00
156	410	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:44:19.537562+00
157	911	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:44:42.899762+00
158	201	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:45:08.353802+00
159	471	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:45:30.6391+00
160	355	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 07:50:18.68989+00
161	515	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 03:07:47.233264+00
162	264	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 03:08:47.958264+00
163	314	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 03:09:18.541285+00
164	434	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 03:09:52.291046+00
165	624	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 15:17:51.073373+00
166	927	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 13:49:40.795403+00
167	167	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 13:50:19.649372+00
168	851	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 13:52:42.858479+00
169	844	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 13:53:19.333809+00
170	1052	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 14:47:40.375116+00
171	1217	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 15:15:30.49166+00
172	1190	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-19 15:16:00.479861+00
173	288	Octobre	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
174	288	Novembre	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
175	288	Decembre	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
176	288	Janvier	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
177	288	Fevrier	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
178	288	Mars	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
179	288	Avril	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
180	288	Mai	1	Exonération permanente : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 10:48:45.543738+00
181	618	Octobre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
182	618	Novembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
183	618	Decembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
184	618	Janvier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
185	618	Fevrier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
186	618	Mars	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
187	618	Avril	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
188	618	Mai	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 11:46:39.856969+00
189	609	Octobre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
190	609	Novembre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
191	609	Decembre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
192	609	Janvier	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
193	609	Fevrier	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
194	609	Mars	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
195	609	Avril	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
196	609	Mai	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-20 12:13:14.885764+00
197	492	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-21 22:45:24.554881+00
198	1057	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-22 03:31:19.430288+00
199	1058	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-22 03:31:48.588266+00
200	504	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-22 03:38:33.570985+00
201	1273	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:13:48.461299+00
202	1274	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:29:40.30717+00
203	1275	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:30:08.169535+00
204	1276	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:35:41.227346+00
205	1277	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 08:41:34.985042+00
206	1278	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:09:36.244025+00
207	1279	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:10:52.99062+00
208	1280	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:12:54.470951+00
209	1281	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:42:14.522792+00
210	1282	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 09:48:47.044353+00
211	1285	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:01:09.76802+00
212	1284	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:02:35.300555+00
213	1283	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:03:19.747423+00
214	1235	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:15:26.704223+00
215	1286	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:16:17.014951+00
216	1287	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 10:22:52.835256+00
217	1236	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 12:53:03.407731+00
218	56	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 13:01:28.932739+00
219	1289	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 13:42:31.518583+00
220	494	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 13:54:51.3356+00
221	364	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 13:57:36.290691+00
222	1055	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 14:14:18.155866+00
223	746	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 14:16:34.242021+00
224	391	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 14:16:58.984362+00
225	1290	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 14:30:24.070917+00
226	1292	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 14:37:33.130136+00
227	575	Fevrier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:32:07.189069+00
228	1258	Octobre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
229	1258	Novembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
230	1258	Decembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
231	1258	Janvier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
232	1258	Fevrier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
233	1258	Mars	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
234	1258	Avril	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
235	1258	Mai	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 23:44:38.021975+00
236	1288	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-28 14:01:53.715094+00
237	1297	Octobre	1	Bourse (1 mois) : Cas social	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 11:52:06.492335+00
238	753	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 12:01:24.285332+00
\.


--
-- Data for Name: moyennes_semestrielles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.moyennes_semestrielles (id, eleve_id, annee_scolaire_id, semestre, moyenne_generale, cloture_par, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, eleve_id, matiere_id, type_note, valeur, annee_scolaire_id, updated_at, semestre) FROM stdin;
1	732	4	I1	15.00	1	2026-10-17 08:42:23.876881+00	1
2	845	4	I1	14.00	1	2026-10-17 08:43:51.821063+00	1
3	480	1	I1	10.00	1	2026-10-17 08:45:32.573125+00	1
4	489	2	I1	16.00	1	2026-10-17 08:47:14.721915+00	1
5	467	5	I1	15.50	1	2026-10-17 08:47:44.683736+00	1
6	487	2	I1	19.00	1	2026-10-17 08:49:12.059217+00	1
7	487	4	I1	15.00	1	2026-10-17 08:50:12.757358+00	1
8	487	6	I1	20.00	1	2026-10-17 08:50:59.208437+00	1
9	482	1	I1	10.00	1	2026-10-17 08:53:20.692482+00	1
10	482	6	I1	19.00	1	2026-10-17 08:54:39.379333+00	1
11	739	3	I1	20.00	1	2026-10-17 08:55:34.959876+00	1
12	457	2	I1	14.00	1	2026-10-17 08:55:53.724773+00	1
13	457	3	I1	20.00	1	2026-10-17 08:56:23.226223+00	1
14	456	5	I1	20.00	1	2026-10-17 08:57:10.047306+00	1
16	152	2	I1	7.00	1	2026-10-17 09:01:46.121658+00	1
17	158	2	I1	15.00	1	2026-10-17 09:02:13.270441+00	1
18	1146	2	I1	12.00	1	2026-10-17 09:02:22.306934+00	1
19	148	2	I1	12.00	1	2026-10-17 09:02:37.443564+00	1
20	152	4	I1	18.50	1	2026-10-17 09:02:56.70786+00	1
21	156	5	I1	20.00	1	2026-10-17 09:03:55.336816+00	1
22	232	1	I1	8.00	1	2026-10-17 09:13:03.69587+00	1
24	1122	1	I1	16.00	1	2026-10-17 09:17:00.561694+00	1
25	1122	1	I2	6.00	1	2026-10-17 09:17:19.60664+00	1
26	1045	1	I1	6.00	1	2026-10-17 09:17:57.43915+00	1
27	932	1	I1	16.00	1	2026-10-17 09:18:12.765889+00	1
28	980	1	I1	17.00	1	2026-10-17 09:18:26.887053+00	1
29	976	2	I1	12.00	1	2026-10-17 09:19:37.798681+00	1
30	209	2	I1	19.00	1	2026-10-17 09:19:56.095167+00	1
31	932	2	I1	16.00	1	2026-10-17 09:20:14.891281+00	1
32	1122	2	I1	12.00	1	2026-10-17 09:20:24.623292+00	1
33	1045	3	I1	12.00	1	2026-10-17 09:21:18.56541+00	1
34	932	3	I1	12.00	1	2026-10-17 09:21:38.625018+00	1
35	1122	3	I1	19.00	1	2026-10-17 09:22:13.759577+00	1
36	1122	3	I2	4.00	1	2026-10-17 09:22:56.827685+00	1
37	224	4	I1	20.00	1	2026-10-17 09:23:24.576694+00	1
38	1122	4	I1	16.00	1	2026-10-17 09:23:48.459713+00	1
39	897	5	I1	18.75	1	2026-10-17 09:26:49.967344+00	1
40	966	5	I1	16.00	1	2026-10-17 09:27:04.289498+00	1
41	232	5	I1	7.50	1	2026-10-17 09:27:37.251863+00	1
42	1122	7	I1	9.00	1	2026-10-17 09:30:29.085103+00	1
43	980	7	I1	18.00	1	2026-10-17 09:32:23.118117+00	1
44	72	1	I1	17.00	1	2026-10-17 09:38:24.63274+00	1
45	84	2	I1	13.00	1	2026-10-17 09:38:46.540366+00	1
46	69	2	I1	16.00	1	2026-10-17 09:39:05.236094+00	1
47	77	2	I1	8.00	1	2026-10-17 09:39:24.242934+00	1
48	64	2	I1	9.00	1	2026-10-17 09:39:37.668505+00	1
49	72	3	I1	8.00	1	2026-10-17 09:40:35.255712+00	1
50	64	3	I1	17.00	1	2026-10-17 09:40:51.138899+00	1
51	64	4	I1	17.00	1	2026-10-17 09:41:22.711397+00	1
52	69	4	I1	13.50	1	2026-10-17 09:41:47.796145+00	1
53	72	4	I1	20.00	1	2026-10-17 09:41:57.511942+00	1
54	72	5	I1	11.00	1	2026-10-17 09:42:14.925454+00	1
55	873	5	I1	19.50	1	2026-10-17 09:42:39.825814+00	1
56	69	5	I1	16.75	1	2026-10-17 09:42:58.169297+00	1
57	30	7	I1	6.00	1	2026-10-17 09:43:36.285477+00	1
58	64	7	I1	10.00	1	2026-10-17 09:43:48.987306+00	1
59	135	1	I1	17.00	1	2026-10-17 09:50:16.618937+00	1
60	889	1	I1	20.00	1	2026-10-17 09:50:35.683847+00	1
61	127	1	I1	20.00	1	2026-10-17 09:50:50.264803+00	1
62	815	1	I1	10.00	1	2026-10-17 09:51:11.237702+00	1
63	840	1	I1	20.00	1	2026-10-17 09:51:39.43485+00	1
64	840	1	I2	16.00	1	2026-10-17 09:51:47.953289+00	1
65	840	2	I1	17.00	1	2026-10-17 09:52:06.690647+00	1
66	127	2	I1	11.00	1	2026-10-17 09:52:16.841429+00	1
67	135	2	I1	20.00	1	2026-10-17 09:52:26.960028+00	1
68	135	2	I2	13.00	1	2026-10-17 09:52:40.11778+00	1
69	889	2	I1	14.00	1	2026-10-17 09:53:01.299323+00	1
70	135	3	I1	15.00	1	2026-10-17 09:53:22.400986+00	1
71	889	3	I1	13.50	1	2026-10-17 09:53:33.983616+00	1
72	127	3	I1	18.00	1	2026-10-17 09:53:43.464546+00	1
74	135	4	I1	18.00	1	2026-10-17 09:54:47.849688+00	1
75	135	4	I2	20.00	1	2026-10-17 09:54:53.417385+00	1
73	135	5	I1	20.00	1	2026-10-17 09:54:06.010976+00	1
77	135	5	I2	15.00	1	2026-10-17 09:55:31.524569+00	1
78	840	7	I1	19.00	1	2026-10-17 09:56:17.675596+00	1
79	844	7	I1	4.00	1	2026-10-17 09:56:37.889819+00	1
80	135	7	I1	6.00	1	2026-10-17 09:56:40.783303+00	1
81	1022	11	I1	18.00	1	2026-10-17 10:05:50.834571+00	1
82	931	11	I1	14.00	1	2026-10-17 10:06:28.988142+00	1
83	931	1	I1	14.00	1	2026-10-17 10:07:00.165535+00	1
84	931	11	I2	9.00	1	2026-10-17 10:07:25.303524+00	1
85	901	1	I1	15.50	1	2026-10-17 10:07:42.655469+00	1
86	901	11	I1	19.50	1	2026-10-17 10:08:19.83097+00	1
87	1033	1	I1	20.00	1	2026-10-17 10:09:13.75633+00	1
88	1019	1	I1	14.00	1	2026-10-17 10:09:25.672746+00	1
89	846	1	I1	17.00	1	2026-10-17 10:09:37.003516+00	1
90	931	2	I1	15.00	1	2026-10-17 10:09:47.934466+00	1
91	931	2	I2	12.00	1	2026-10-17 10:09:59.259765+00	1
92	901	2	I1	15.50	1	2026-10-17 10:10:13.518337+00	1
93	1022	3	I1	20.00	1	2026-10-17 10:10:26.092107+00	1
94	901	3	I1	5.00	1	2026-10-17 10:10:37.447541+00	1
95	901	3	I2	14.00	1	2026-10-17 10:10:50.627718+00	1
96	1023	4	I1	18.50	1	2026-10-17 10:11:20.860154+00	1
97	901	4	I1	14.00	1	2026-10-17 10:11:32.769308+00	1
98	901	4	I2	19.00	1	2026-10-17 10:11:42.952723+00	1
99	243	4	I1	18.00	1	2026-10-17 10:11:57.331383+00	1
100	907	5	I1	19.00	1	2026-10-17 10:12:19.888894+00	1
101	901	5	I1	20.00	1	2026-10-17 10:12:36.134322+00	1
102	901	5	I2	10.25	1	2026-10-17 10:13:13.034642+00	1
103	238	5	I1	16.00	1	2026-10-17 10:13:40.511339+00	1
104	1019	5	I1	17.00	1	2026-10-17 10:13:50.932549+00	1
105	931	7	I1	9.00	1	2026-10-17 10:14:04.317302+00	1
106	907	7	I1	20.00	1	2026-10-17 10:14:17.136726+00	1
107	901	7	I1	12.00	1	2026-10-17 10:14:26.082977+00	1
108	846	9	I1	11.00	1	2026-10-17 10:14:46.550769+00	1
109	1033	9	I1	9.00	1	2026-10-17 10:14:59.359234+00	1
110	969	2	I1	16.00	1	2026-10-17 10:15:51.592581+00	1
111	312	1	I1	15.00	1	2026-10-17 10:18:15.366955+00	1
112	962	2	I1	13.00	1	2026-10-17 10:18:40.321476+00	1
113	312	3	I1	14.00	1	2026-10-17 10:18:55.579735+00	1
114	1116	3	I1	12.00	1	2026-10-17 10:19:12.215053+00	1
115	1116	5	I1	14.00	1	2026-10-17 10:19:43.447996+00	1
116	279	9	I1	11.00	1	2026-10-17 10:20:13.475489+00	1
117	1184	5	I1	16.50	1	2026-10-17 10:23:48.882194+00	1
118	927	1	I1	16.50	1	2026-10-17 10:24:05.664308+00	1
119	914	1	I1	14.00	1	2026-10-17 10:24:16.178124+00	1
120	1182	1	I1	17.50	1	2026-10-17 10:24:26.155844+00	1
121	914	2	I1	10.00	1	2026-10-17 10:24:37.897235+00	1
122	1182	2	I1	8.00	1	2026-10-17 10:24:54.593435+00	1
123	927	2	I1	18.00	1	2026-10-17 10:25:08.894093+00	1
125	927	5	I1	18.00	1	2026-10-17 10:26:14.032171+00	1
126	914	5	I1	18.00	1	2026-10-17 10:26:22.678134+00	1
127	1182	5	I1	16.00	1	2026-10-17 10:26:32.043328+00	1
128	1182	7	I1	20.00	1	2026-10-17 10:26:45.247671+00	1
129	914	7	I1	8.00	1	2026-10-17 10:26:55.430848+00	1
124	927	7	I1	10.00	1	2026-10-17 10:25:54.181664+00	1
131	870	1	I1	16.00	1	2026-10-17 10:27:40.687754+00	1
132	870	6	I1	14.00	1	2026-10-17 10:28:24.040693+00	1
15	156	1	I1	14.00	1	2026-10-17 09:00:31.217221+00	1
135	1004	1	I1	16.00	1	2026-10-29 22:33:15.884535+00	1
136	403	1	I1	20.00	1	2026-10-29 22:33:58.186179+00	1
137	1056	1	I1	14.00	1	2026-10-29 22:36:58.661777+00	1
138	1056	1	I2	18.00	1	2026-10-29 22:37:03.463226+00	1
139	1006	1	I1	17.00	1	2026-10-29 22:37:31.5521+00	1
140	1006	1	I2	12.00	1	2026-10-29 22:37:52.268436+00	1
141	1004	1	I2	9.00	1	2026-10-29 22:38:01.280702+00	1
142	432	1	I1	14.00	1	2026-10-29 22:38:55.851788+00	1
143	432	1	I2	18.00	1	2026-10-29 22:39:30.644257+00	1
144	391	1	I1	16.00	1	2026-10-29 22:39:44.123586+00	1
145	391	1	I2	16.00	1	2026-10-29 22:40:06.224377+00	1
146	1072	1	I1	11.00	1	2026-10-29 22:40:09.478607+00	1
147	1072	1	I2	18.00	1	2026-10-29 22:40:34.460723+00	1
148	419	2	I1	14.00	1	2026-10-29 22:41:00.939924+00	1
149	403	2	I1	11.00	1	2026-10-29 22:41:11.375767+00	1
150	403	3	I1	20.00	1	2026-10-29 22:41:27.052949+00	1
151	1006	4	I1	11.50	1	2026-10-29 22:41:53.97387+00	1
152	1056	4	I1	15.00	1	2026-10-29 22:42:06.415907+00	1
153	432	4	I1	5.50	1	2026-10-29 22:42:24.40937+00	1
155	960	5	I1	14.00	1	2026-10-29 22:43:02.489134+00	1
157	960	7	I1	18.00	1	2026-10-29 22:43:38.964432+00	1
159	1004	7	I1	15.00	1	2026-10-29 22:44:11.16511+00	1
160	403	7	I1	14.00	1	2026-10-29 22:44:26.61002+00	1
161	432	7	I1	2.00	1	2026-10-29 22:45:09.285534+00	1
163	402	7	I1	11.00	1	2026-10-29 22:45:34.147423+00	1
164	391	7	I1	6.00	1	2026-10-29 22:45:50.336307+00	1
165	403	7	I2	11.00	1	2026-10-29 22:46:12.885028+00	1
166	960	10	I1	20.00	1	2026-10-29 22:46:44.501805+00	1
167	419	10	I1	14.00	1	2026-10-29 22:46:53.304408+00	1
168	965	1	I1	15.50	1	2026-10-29 23:03:06.364438+00	1
169	323	1	I1	15.00	1	2026-10-29 23:03:29.866763+00	1
170	330	1	I1	10.00	1	2026-10-29 23:03:41.748679+00	1
171	334	1	I1	15.00	1	2026-10-29 23:04:00.407571+00	1
172	332	1	I1	18.00	1	2026-10-29 23:04:17.990164+00	1
173	952	1	I1	12.00	1	2026-10-29 23:04:51.295256+00	1
174	364	1	I1	5.00	1	2026-10-29 23:05:03.946345+00	1
175	883	1	I1	9.00	1	2026-10-29 23:05:29.265232+00	1
176	883	1	I2	12.50	1	2026-10-29 23:05:43.587661+00	1
177	847	1	I1	14.00	1	2026-10-29 23:06:01.218657+00	1
178	953	1	I1	13.00	1	2026-10-29 23:06:22.142956+00	1
179	333	1	I1	11.00	1	2026-10-29 23:06:44.67413+00	1
180	965	2	I1	16.00	1	2026-10-29 23:07:28.445386+00	1
181	323	2	I1	20.00	1	2026-10-29 23:08:01.842219+00	1
182	323	2	I2	17.00	1	2026-10-29 23:08:17.577577+00	1
183	334	2	I1	20.00	1	2026-10-29 23:08:58.343132+00	1
184	332	2	I1	11.00	1	2026-10-29 23:09:15.071875+00	1
185	952	2	I1	16.00	1	2026-10-29 23:10:41.900686+00	1
186	364	2	I1	14.00	1	2026-10-29 23:11:05.403064+00	1
187	883	2	I1	12.00	1	2026-10-29 23:11:42.390468+00	1
188	358	2	I1	10.00	1	2026-10-29 23:12:01.701456+00	1
189	333	2	I1	20.00	1	2026-10-29 23:12:45.304277+00	1
190	333	4	I1	19.50	1	2026-10-29 23:13:44.151883+00	1
191	1137	1	I1	14.00	1	2026-10-29 23:14:05.684033+00	1
192	1137	4	I1	14.00	1	2026-10-29 23:15:21.486559+00	1
193	965	3	I1	19.00	1	2026-10-29 23:15:49.837553+00	1
194	323	3	I1	11.00	1	2026-10-29 23:17:00.545437+00	1
195	345	3	I1	17.50	1	2026-10-29 23:19:59.925381+00	1
196	330	3	I1	9.00	1	2026-10-29 23:20:29.619559+00	1
197	334	3	I1	20.00	1	2026-10-29 23:20:45.995471+00	1
198	952	3	I1	8.00	1	2026-10-29 23:21:09.044382+00	1
199	364	3	I1	4.00	1	2026-10-29 23:21:25.938968+00	1
200	381	3	I1	2.00	1	2026-10-29 23:21:49.384105+00	1
201	347	3	I1	16.00	1	2026-10-29 23:22:09.583773+00	1
202	358	3	I1	10.00	1	2026-10-29 23:22:21.659425+00	1
203	333	3	I1	15.00	1	2026-10-29 23:22:48.508481+00	1
204	1137	3	I1	19.00	1	2026-10-29 23:23:09.28037+00	1
205	1137	3	I2	19.00	1	2026-10-29 23:23:25.76652+00	1
206	965	4	I1	11.00	1	2026-10-29 23:24:04.876745+00	1
207	323	4	I1	13.00	1	2026-10-29 23:24:28.531658+00	1
208	330	4	I1	7.00	1	2026-10-29 23:24:40.488343+00	1
209	332	4	I1	11.00	1	2026-10-29 23:24:57.096417+00	1
210	952	4	I1	15.00	1	2026-10-29 23:25:34.74721+00	1
211	364	4	I1	12.00	1	2026-10-29 23:25:45.17347+00	1
212	883	4	I1	7.00	1	2026-10-29 23:26:04.114788+00	1
213	375	4	I1	9.00	1	2026-10-29 23:27:46.165447+00	1
214	847	4	I1	7.00	1	2026-10-29 23:28:00.848811+00	1
215	953	4	I1	15.00	1	2026-10-29 23:28:13.429272+00	1
217	323	5	I1	20.00	1	2026-10-29 23:29:14.841713+00	1
218	330	5	I1	19.00	1	2026-10-29 23:29:48.983338+00	1
219	332	5	I1	16.00	1	2026-10-29 23:30:19.789479+00	1
220	952	5	I1	20.00	1	2026-10-29 23:30:40.455264+00	1
216	375	5	I1	8.00	1	2026-10-29 23:28:43.518964+00	1
222	364	5	I1	9.00	1	2026-10-29 23:31:24.911402+00	1
223	953	5	I1	4.00	1	2026-10-29 23:31:47.371112+00	1
224	333	5	I1	14.00	1	2026-10-29 23:32:14.910034+00	1
225	1137	5	I1	8.50	1	2026-10-29 23:32:47.333033+00	1
226	1137	5	I2	15.50	1	2026-10-29 23:33:46.117679+00	1
227	965	7	I1	14.00	1	2026-10-29 23:34:05.948749+00	1
228	965	7	I2	4.00	1	2026-10-29 23:34:16.754417+00	1
229	323	5	I2	13.00	1	2026-10-29 23:34:46.966346+00	1
230	330	7	I1	13.00	1	2026-10-29 23:35:25.677167+00	1
231	330	7	I2	15.00	1	2026-10-29 23:35:41.819108+00	1
232	334	7	I1	18.00	1	2026-10-29 23:35:55.02111+00	1
233	334	7	I2	18.00	1	2026-10-29 23:36:07.099617+00	1
234	879	7	I1	14.00	1	2026-10-29 23:36:35.515367+00	1
235	332	7	I1	8.00	1	2026-10-29 23:36:58.792556+00	1
236	332	7	I2	9.00	1	2026-10-29 23:37:11.460531+00	1
237	952	7	I1	19.00	1	2026-10-29 23:37:42.624467+00	1
238	952	7	I2	20.00	1	2026-10-29 23:37:54.177748+00	1
239	364	7	I1	10.00	1	2026-10-29 23:38:03.213532+00	1
240	364	7	I2	5.00	1	2026-10-29 23:38:21.670059+00	1
241	883	7	I1	0.00	1	2026-10-29 23:38:31.056367+00	1
242	883	7	I2	2.00	1	2026-10-29 23:38:43.507734+00	1
162	911	7	I1	8.00	1	2026-10-29 22:45:23.71458+00	1
158	419	7	I1	6.00	1	2026-10-29 22:43:53.822599+00	1
243	347	7	I1	2.00	1	2026-10-29 23:38:54.094193+00	1
244	953	7	I1	15.00	1	2026-10-29 23:39:16.338108+00	1
245	358	7	I1	8.00	1	2026-10-29 23:39:29.092372+00	1
246	333	7	I1	15.00	1	2026-10-29 23:39:57.891289+00	1
247	333	7	I2	10.00	1	2026-10-29 23:40:18.506301+00	1
248	1137	7	I1	5.00	1	2026-10-29 23:40:45.853272+00	1
249	1137	7	I2	11.00	1	2026-10-29 23:41:12.540481+00	1
250	1137	7	I3	15.00	1	2026-10-29 23:41:33.937013+00	1
251	358	7	I2	8.50	1	2026-10-29 23:42:01.894359+00	1
252	1137	9	I1	15.00	1	2026-10-29 23:48:09.818733+00	1
253	1137	10	I1	10.00	1	2026-10-29 23:55:18.426446+00	1
254	879	10	I1	10.00	1	2026-10-29 23:56:33.350015+00	1
255	355	3	I1	20.00	1	2026-10-29 23:57:25.838582+00	1
256	355	1	I1	11.00	1	2026-10-29 23:57:57.259163+00	1
257	355	1	I2	13.00	1	2026-10-29 23:58:13.823651+00	1
258	322	3	I1	12.00	1	2026-10-29 23:58:49.475112+00	1
259	322	7	I1	11.00	1	2026-10-29 23:59:13.848301+00	1
260	322	1	I1	8.00	1	2026-10-29 23:59:30.054152+00	1
261	328	2	I1	16.00	1	2026-10-29 23:59:44.531569+00	1
262	328	4	I1	19.00	1	2026-10-30 00:00:03.563061+00	1
263	708	7	I1	5.00	1	2026-10-30 00:00:42.691094+00	1
264	708	3	I1	11.00	1	2026-10-30 00:01:16.701299+00	1
265	365	3	I1	12.00	1	2026-10-30 00:01:45.265929+00	1
266	365	9	I1	11.00	1	2026-10-30 00:02:09.420595+00	1
267	1137	5	I3	17.00	1	2026-10-30 00:02:41.602406+00	1
268	1137	4	I2	11.00	1	2026-10-30 00:03:02.75024+00	1
269	1137	2	I1	7.00	1	2026-10-30 00:03:28.368674+00	1
270	1137	1	I2	6.00	1	2026-10-30 00:03:51.216236+00	1
271	337	1	I1	16.00	1	2026-10-30 00:04:01.774362+00	1
272	337	4	I1	9.00	1	2026-10-30 00:04:17.146093+00	1
273	953	2	I1	6.00	1	2026-10-30 00:04:35.199103+00	1
274	953	3	I1	5.00	1	2026-10-30 00:05:12.54032+00	1
275	339	10	I1	8.00	1	2026-10-30 00:05:28.280899+00	1
276	339	5	I1	17.00	1	2026-10-30 00:05:49.994642+00	1
277	339	3	I1	5.00	1	2026-10-30 00:06:09.950895+00	1
278	339	3	I2	3.50	1	2026-10-30 00:06:23.390151+00	1
279	339	2	I1	2.00	1	2026-10-30 00:06:33.626011+00	1
280	339	4	I1	3.00	1	2026-10-30 00:06:50.631795+00	1
281	339	1	I1	2.00	1	2026-10-30 00:07:24.629909+00	1
282	1065	1	I1	13.00	1	2026-10-30 00:07:50.675292+00	1
283	389	1	I1	17.00	1	2026-10-30 00:08:09.888719+00	1
284	389	1	I2	13.00	1	2026-10-30 00:08:27.426536+00	1
285	389	1	I3	11.00	1	2026-10-30 00:09:06.519255+00	1
286	389	11	I1	9.00	1	2026-10-30 00:09:27.513409+00	1
287	421	11	I1	9.00	1	2026-10-30 00:09:42.335698+00	1
288	421	1	I1	12.00	1	2026-10-30 00:09:57.663257+00	1
289	421	1	I2	14.00	1	2026-10-30 00:10:07.158204+00	1
290	421	1	I3	15.00	1	2026-10-30 00:10:22.179999+00	1
291	396	1	I1	6.50	1	2026-10-30 00:10:48.572271+00	1
292	391	1	I3	16.00	1	2026-10-30 00:12:12.549141+00	1
293	1057	1	I1	20.00	1	2026-10-30 00:12:21.579795+00	1
294	1057	1	I2	13.00	1	2026-10-30 00:12:35.586742+00	1
295	410	1	I1	8.00	1	2026-10-30 00:12:48.575233+00	1
296	1058	2	I1	9.00	1	2026-10-30 00:13:07.511684+00	1
297	389	2	I1	17.00	1	2026-10-30 00:13:25.223124+00	1
298	1053	2	I1	10.00	1	2026-10-30 00:13:36.831618+00	1
299	1065	3	I1	14.00	1	2026-10-30 00:13:57.809297+00	1
300	389	3	I1	20.00	1	2026-10-30 00:14:09.838872+00	1
301	396	3	I1	15.00	1	2026-10-30 00:14:23.166404+00	1
302	1058	3	I1	10.00	1	2026-10-30 00:14:41.001455+00	1
303	410	3	I1	8.00	1	2026-10-30 00:14:59.820105+00	1
304	1057	3	I1	18.00	1	2026-10-30 00:15:24.35113+00	1
305	1181	3	I1	13.00	1	2026-10-30 00:15:33.402392+00	1
306	410	4	I1	11.50	1	2026-10-30 00:15:54.401736+00	1
307	1058	4	I1	10.00	1	2026-10-30 00:16:06.815271+00	1
308	421	4	I1	10.00	1	2026-10-30 00:16:25.444711+00	1
309	396	4	I1	9.50	1	2026-10-30 00:16:30.977967+00	1
154	391	4	I1	6.00	1	2026-10-29 22:42:34.905221+00	1
311	1065	4	I1	10.00	1	2026-10-30 00:16:55.144594+00	1
312	389	4	I1	17.00	1	2026-10-30 00:17:03.86269+00	1
313	1053	5	I1	6.00	1	2026-10-30 00:17:14.875579+00	1
156	911	5	I1	9.00	1	2026-10-29 22:43:16.504812+00	1
315	1053	7	I1	6.00	1	2026-10-30 00:17:37.771808+00	1
317	1053	7	I2	19.00	1	2026-10-30 00:18:17.490946+00	1
318	410	7	I1	13.00	1	2026-10-30 00:18:39.843996+00	1
319	1057	7	I1	9.00	1	2026-10-30 00:18:51.214698+00	1
320	1058	7	I1	10.00	1	2026-10-30 00:19:07.734599+00	1
321	421	7	I1	7.00	1	2026-10-30 00:19:11.553887+00	1
323	389	7	I1	10.00	1	2026-10-30 00:19:35.78539+00	1
324	391	9	I1	7.00	1	2026-10-30 00:19:58.861268+00	1
325	1057	9	I1	10.00	1	2026-10-30 00:20:13.069186+00	1
326	410	10	I1	9.00	1	2026-10-30 00:20:31.589038+00	1
327	410	10	I2	8.00	1	2026-10-30 00:20:49.569644+00	1
328	1181	9	I1	18.00	1	2026-10-30 00:21:32.679678+00	1
329	1181	9	I2	19.00	1	2026-10-30 00:22:09.916552+00	1
330	58	3	I1	20.00	1	2026-10-30 00:24:08.712588+00	1
331	58	2	I1	14.00	1	2026-10-30 00:24:33.799379+00	1
332	58	5	I1	19.00	1	2026-10-30 00:24:50.466484+00	1
333	58	1	I1	20.00	1	2026-10-30 00:25:10.747023+00	1
334	58	1	I2	15.00	1	2026-10-30 00:25:27.526124+00	1
335	41	3	I1	15.00	1	2026-10-30 00:25:44.505932+00	1
336	41	1	I1	4.00	1	2026-10-30 00:25:58.243651+00	1
337	41	4	I1	5.00	1	2026-10-30 00:26:12.498004+00	1
338	66	3	I1	14.00	1	2026-10-30 00:26:38.283407+00	1
339	66	5	I1	17.75	1	2026-10-30 00:27:03.260167+00	1
340	57	3	I1	6.00	1	2026-10-30 00:27:24.134188+00	1
341	57	3	I2	14.00	1	2026-10-30 00:27:39.366531+00	1
342	57	5	I1	14.25	1	2026-10-30 00:27:59.342246+00	1
343	57	1	I1	14.00	1	2026-10-30 00:28:30.717865+00	1
344	15	2	I1	11.00	1	2026-10-30 00:28:48.368395+00	1
345	15	3	I1	13.00	1	2026-10-30 00:29:45.919876+00	1
346	15	1	I1	20.00	1	2026-10-30 00:30:02.376202+00	1
347	15	5	I1	17.00	1	2026-10-30 00:30:21.280714+00	1
348	16	1	I1	9.50	1	2026-10-30 00:30:52.400759+00	1
349	16	1	I2	3.50	1	2026-10-30 00:31:10.823617+00	1
350	5	4	I1	7.00	1	2026-10-30 00:31:30.317707+00	1
351	5	3	I1	11.00	1	2026-10-30 00:31:47.040175+00	1
352	5	1	I1	16.00	1	2026-10-30 00:32:26.47563+00	1
353	5	4	I2	15.00	1	2026-10-30 00:33:04.021675+00	1
354	888	3	I1	20.00	1	2026-10-30 00:33:32.705275+00	1
355	888	5	I1	8.75	1	2026-10-30 00:34:01.097584+00	1
356	888	2	I1	1.00	1	2026-10-30 00:34:19.583849+00	1
357	888	4	I1	10.50	1	2026-10-30 00:34:48.599442+00	1
358	1243	3	I1	16.00	1	2026-10-30 00:35:46.33477+00	1
359	10	3	I1	10.00	1	2026-10-30 00:35:56.008541+00	1
360	762	5	I1	18.50	1	2026-10-30 00:36:26.324228+00	1
361	762	1	I1	18.00	1	2026-10-30 00:36:43.782544+00	1
362	762	3	I1	20.00	1	2026-10-30 00:37:00.336508+00	1
363	762	3	I2	16.00	1	2026-10-30 00:37:11.084107+00	1
364	959	1	I1	20.00	1	2026-10-30 00:37:37.176242+00	1
365	959	5	I1	12.00	1	2026-10-30 00:37:56.148769+00	1
366	959	2	I1	14.00	1	2026-10-30 00:38:12.733049+00	1
367	959	3	I1	14.00	1	2026-10-30 00:38:30.805704+00	1
368	42	1	I1	20.00	1	2026-10-30 00:38:50.160204+00	1
369	42	3	I1	16.00	1	2026-10-30 00:39:04.770963+00	1
370	42	3	I2	14.00	1	2026-10-30 00:39:16.789793+00	1
371	62	5	I1	20.00	1	2026-10-30 00:39:39.314498+00	1
372	62	1	I1	19.00	1	2026-10-30 00:39:54.423894+00	1
373	62	3	I1	12.00	1	2026-10-30 00:40:14.663822+00	1
374	34	1	I1	6.00	1	2026-10-30 00:40:50.340978+00	1
375	34	1	I2	12.00	1	2026-10-30 00:41:06.069301+00	1
376	53	2	I1	20.00	1	2026-10-30 00:41:25.71749+00	1
377	53	3	I1	20.00	1	2026-10-30 00:41:48.726629+00	1
378	53	1	I1	17.00	1	2026-10-30 00:42:06.635966+00	1
379	64	4	I2	17.00	1	2026-10-30 00:43:01.532176+00	1
380	64	7	I2	10.00	1	2026-10-30 00:43:45.468912+00	1
381	887	3	I1	10.00	1	2026-10-30 00:45:21.773099+00	1
382	7	7	I1	11.00	1	2026-10-30 00:45:41.041114+00	1
383	49	3	I1	12.00	1	2026-10-30 00:45:56.159828+00	1
384	49	1	I1	20.00	1	2026-10-30 00:46:10.236776+00	1
385	49	3	I2	16.00	1	2026-10-30 00:46:30.361027+00	1
386	133	5	I1	15.00	1	2026-10-30 00:46:52.63516+00	1
387	1133	7	I1	18.00	1	2026-10-30 00:47:13.802348+00	1
388	1133	1	I1	13.00	1	2026-10-30 00:47:54.393168+00	1
389	682	4	I1	12.00	1	2026-10-30 00:48:30.950469+00	1
390	682	4	I2	6.00	1	2026-10-30 00:48:48.352808+00	1
391	682	1	I1	10.00	1	2026-10-30 00:49:09.5338+00	1
392	682	3	I1	8.00	1	2026-10-30 00:49:45.943985+00	1
393	1131	3	I1	15.00	1	2026-10-30 00:49:56.295708+00	1
394	116	7	I1	18.00	1	2026-10-30 00:50:16.28691+00	1
395	116	4	I1	14.00	1	2026-10-30 00:50:39.436842+00	1
396	1104	4	I1	14.00	1	2026-10-30 00:50:55.048837+00	1
397	127	5	I1	15.00	1	2026-10-30 00:51:15.182171+00	1
398	103	1	I1	19.00	1	2026-10-30 00:51:35.100744+00	1
399	137	2	I1	14.00	1	2026-10-30 00:51:56.751651+00	1
400	837	7	I1	17.00	1	2026-10-30 00:52:22.132676+00	1
401	837	4	I1	10.00	1	2026-10-30 00:52:40.979587+00	1
402	1128	3	I1	9.00	1	2026-10-30 00:53:03.591976+00	1
403	1128	4	I1	18.00	1	2026-10-30 00:53:23.715882+00	1
404	1130	3	I1	12.00	1	2026-10-30 00:53:45.893949+00	1
405	1025	4	I1	11.00	1	2026-10-30 00:54:09.437428+00	1
406	1025	2	I1	5.00	1	2026-10-30 00:54:39.09459+00	1
407	1025	3	I1	20.00	1	2026-10-30 00:54:56.565053+00	1
408	1025	5	I1	13.25	1	2026-10-30 00:55:23.911591+00	1
409	815	3	I1	6.00	1	2026-10-30 00:55:42.645417+00	1
410	815	5	I1	8.00	1	2026-10-30 00:56:07.554555+00	1
411	815	4	I1	6.00	1	2026-10-30 00:56:31.821695+00	1
412	128	3	I1	14.00	1	2026-10-30 00:56:59.721332+00	1
413	128	1	I1	13.00	1	2026-10-30 00:57:18.208856+00	1
414	1167	3	I1	17.00	1	2026-10-30 00:57:43.653515+00	1
415	1167	1	I1	15.00	1	2026-10-30 00:58:00.054342+00	1
416	141	5	I1	16.00	1	2026-10-30 00:58:38.720709+00	1
417	100	5	I1	14.00	1	2026-10-30 00:59:00.136123+00	1
418	840	5	I1	18.00	1	2026-10-30 00:59:16.705416+00	1
419	882	3	I1	16.00	1	2026-10-30 00:59:39.21601+00	1
420	882	4	I1	12.00	1	2026-10-30 01:00:09.234559+00	1
421	882	1	I1	7.00	1	2026-10-30 01:00:42.490233+00	1
422	882	11	I1	12.00	1	2026-10-30 01:01:11.43301+00	1
423	1164	7	I1	20.00	1	2026-10-30 01:01:43.312944+00	1
424	1164	4	I1	6.00	1	2026-10-30 01:02:15.261273+00	1
425	1164	1	I1	8.00	1	2026-10-30 01:02:46.422868+00	1
426	1248	3	I1	14.00	1	2026-10-30 01:03:10.046651+00	1
427	1248	4	I1	9.00	1	2026-10-30 01:03:38.000132+00	1
428	1248	1	I1	19.00	1	2026-10-30 01:03:57.787206+00	1
429	1248	4	I2	16.00	1	2026-10-30 01:04:32.467107+00	1
430	101	5	I1	18.50	1	2026-10-30 01:05:06.925695+00	1
431	1168	5	I1	15.00	1	2026-10-30 01:05:27.325726+00	1
432	1168	1	I1	18.00	1	2026-10-30 01:05:51.544267+00	1
433	1168	2	I1	11.00	1	2026-10-30 01:06:20.304227+00	1
434	1168	3	I1	11.00	1	2026-10-30 01:06:42.652251+00	1
435	135	1	I2	20.00	1	2026-10-30 01:07:15.106104+00	1
436	893	1	I1	19.00	1	2026-10-30 01:08:36.346246+00	1
437	893	5	I1	19.50	1	2026-10-30 01:09:11.227919+00	1
438	893	2	I1	16.00	1	2026-10-30 01:09:45.552897+00	1
439	893	3	I1	16.00	1	2026-10-30 01:10:18.276241+00	1
440	872	5	I1	20.00	1	2026-10-30 01:19:50.191642+00	1
441	872	3	I1	14.00	1	2026-10-30 01:20:07.689309+00	1
442	872	4	I1	14.00	1	2026-10-30 01:20:28.652964+00	1
443	176	7	I1	12.00	1	2026-10-30 01:20:58.031179+00	1
444	1146	7	I1	20.00	1	2026-10-30 01:21:13.247203+00	1
445	1146	4	I1	19.50	1	2026-10-30 01:21:34.984489+00	1
446	156	3	I1	8.00	1	2026-10-30 01:21:55.357154+00	1
447	195	3	I1	20.00	1	2026-10-30 01:22:18.021941+00	1
448	165	3	I1	12.00	1	2026-10-30 01:22:29.315626+00	1
449	165	1	I1	10.00	1	2026-10-30 01:22:48.178647+00	1
450	165	5	I1	11.75	1	2026-10-30 01:23:21.915798+00	1
451	1170	7	I1	9.00	1	2026-10-30 01:23:44.593054+00	1
452	1170	5	I1	20.00	1	2026-10-30 01:24:11.805108+00	1
453	1170	3	I1	14.00	1	2026-10-30 01:25:16.488565+00	1
454	157	2	I1	7.00	1	2026-10-30 01:25:39.834729+00	1
455	885	3	I1	15.00	1	2026-10-30 01:25:57.948667+00	1
456	885	5	I1	7.50	1	2026-10-30 01:26:15.931442+00	1
457	885	1	I1	7.00	1	2026-10-30 01:26:27.916476+00	1
458	148	4	I1	19.50	1	2026-10-30 01:26:54.141005+00	1
459	148	7	I1	19.00	1	2026-10-30 01:27:06.149549+00	1
460	162	4	I1	20.00	1	2026-10-30 01:27:32.643587+00	1
461	162	7	I1	19.00	1	2026-10-30 01:28:23.945984+00	1
462	162	2	I1	12.00	1	2026-10-30 01:28:50.546896+00	1
463	164	7	I1	20.00	1	2026-10-30 01:29:14.313146+00	1
464	178	7	I1	18.00	1	2026-10-30 01:29:28.741834+00	1
465	178	1	I1	10.00	1	2026-10-30 01:29:47.112604+00	1
466	1234	4	I1	14.00	1	2026-10-30 01:30:06.434267+00	1
467	1234	4	I2	15.00	1	2026-10-30 01:30:41.247949+00	1
468	1234	5	I1	16.00	1	2026-10-30 01:31:51.934673+00	1
469	1234	3	I1	16.00	1	2026-10-30 01:33:47.714781+00	1
470	1234	2	I1	16.00	1	2026-10-30 01:34:08.527683+00	1
471	1234	1	I1	16.00	1	2026-10-30 01:34:30.493382+00	1
472	1043	5	I1	4.00	1	2026-10-30 04:15:52.088255+00	1
473	1043	3	I1	12.00	1	2026-10-30 04:16:25.99075+00	1
474	1043	7	I1	5.00	1	2026-10-30 04:17:02.3612+00	1
475	1043	4	I1	3.00	1	2026-10-30 04:17:33.169591+00	1
476	1238	5	I1	16.00	1	2026-10-30 04:17:50.14232+00	1
477	1238	4	I1	20.00	1	2026-10-30 04:19:09.748413+00	1
478	1238	5	I2	12.00	1	2026-10-30 04:19:48.59881+00	1
479	967	5	I1	16.00	1	2026-10-30 04:20:12.265923+00	1
480	967	5	I2	11.00	1	2026-10-30 04:20:23.097246+00	1
481	932	4	I1	18.50	1	2026-10-30 04:21:04.609937+00	1
482	932	7	I1	6.00	1	2026-10-30 04:21:38.433173+00	1
483	980	2	I1	15.00	1	2026-10-30 04:22:02.700979+00	1
484	980	1	I2	13.00	1	2026-10-30 04:22:21.050707+00	1
485	980	5	I1	6.00	1	2026-10-30 04:22:48.123514+00	1
486	215	1	I1	15.00	1	2026-10-30 04:23:17.219029+00	1
487	215	3	I1	7.00	1	2026-10-30 04:23:44.56304+00	1
488	215	5	I1	15.00	1	2026-10-30 04:24:15.062554+00	1
489	1045	7	I1	7.00	1	2026-10-30 04:24:49.959352+00	1
490	1061	7	I1	18.00	1	2026-10-30 04:25:07.188248+00	1
491	1011	1	I1	16.00	1	2026-10-30 04:25:27.590038+00	1
492	1011	7	I1	9.00	1	2026-10-30 04:25:48.976626+00	1
493	206	7	I1	20.00	1	2026-10-30 04:26:02.1151+00	1
494	206	1	I1	7.00	1	2026-10-30 04:26:24.488612+00	1
495	898	5	I1	11.25	1	2026-10-30 04:26:53.79465+00	1
496	898	1	I1	6.00	1	2026-10-30 04:27:12.705847+00	1
497	203	3	I1	14.00	1	2026-10-30 04:27:33.235066+00	1
498	203	5	I1	12.00	1	2026-10-30 04:27:52.462968+00	1
499	203	1	I1	10.00	1	2026-10-30 04:28:08.13232+00	1
500	1009	5	I1	19.75	1	2026-10-30 04:28:30.270495+00	1
501	1009	1	I1	11.00	1	2026-10-30 04:28:41.012656+00	1
502	1009	3	I1	12.00	1	2026-10-30 04:29:04.930613+00	1
503	1121	5	I1	11.75	1	2026-10-30 04:29:25.56423+00	1
504	190	7	I1	10.00	1	2026-10-30 04:29:46.175646+00	1
505	196	7	I1	16.00	1	2026-10-30 04:30:02.113341+00	1
506	201	4	I1	20.00	1	2026-10-30 04:30:28.061396+00	1
507	964	4	I1	15.00	1	2026-10-30 04:30:40.275627+00	1
508	207	5	I1	16.00	1	2026-10-30 04:31:24.472595+00	1
509	207	5	I2	12.00	1	2026-10-30 04:31:41.075674+00	1
510	1240	4	I1	19.00	1	2026-10-30 04:32:04.779809+00	1
511	1240	3	I1	12.00	1	2026-10-30 04:32:22.788711+00	1
512	1240	1	I1	10.00	1	2026-10-30 04:32:46.316423+00	1
513	1240	2	I1	13.00	1	2026-10-30 04:33:08.739488+00	1
514	1240	7	I1	10.00	1	2026-10-30 04:33:35.033879+00	1
515	1239	7	I1	11.00	1	2026-10-30 04:33:48.817921+00	1
516	1239	4	I1	5.50	1	2026-10-30 04:34:06.858541+00	1
517	907	10	I1	16.00	1	2026-10-30 04:37:11.571997+00	1
518	846	7	I1	19.00	1	2026-10-30 04:38:06.612259+00	1
519	846	4	I1	8.00	1	2026-10-30 04:38:40.10491+00	1
520	900	7	I1	20.00	1	2026-10-30 04:39:26.14195+00	1
521	1031	3	I1	10.00	1	2026-10-30 04:39:51.838963+00	1
522	1031	5	I1	12.00	1	2026-10-30 04:40:07.529622+00	1
523	1031	2	I1	8.00	1	2026-10-30 04:41:28.089504+00	1
524	907	2	I1	14.00	1	2026-10-30 04:42:59.063491+00	1
525	1037	1	I1	19.00	1	2026-10-30 04:43:30.062114+00	1
526	1037	7	I1	13.00	1	2026-10-30 04:43:56.936971+00	1
527	1119	4	I1	11.00	1	2026-10-30 04:44:41.382141+00	1
528	252	9	I1	11.00	1	2026-10-30 04:45:13.082037+00	1
529	252	2	I1	11.00	1	2026-10-30 04:45:35.349095+00	1
530	252	5	I1	7.00	1	2026-10-30 04:46:12.125325+00	1
531	252	4	I1	10.00	1	2026-10-30 04:46:28.367632+00	1
532	252	3	I1	11.00	1	2026-10-30 04:46:45.370829+00	1
533	252	7	I1	17.00	1	2026-10-30 04:47:07.933608+00	1
534	242	5	I1	11.00	1	2026-10-30 04:47:29.756099+00	1
536	242	9	I1	5.00	1	2026-10-30 04:48:28.827454+00	1
537	276	4	I1	18.00	1	2026-10-30 04:48:57.848661+00	1
538	276	3	I1	6.00	1	2026-10-30 04:49:24.567103+00	1
539	276	1	I1	17.00	1	2026-10-30 04:49:49.685348+00	1
540	276	7	I1	16.00	1	2026-10-30 04:50:21.199473+00	1
541	968	11	I1	15.00	1	2026-10-30 04:50:41.43385+00	1
542	968	7	I1	17.00	1	2026-10-30 04:51:01.740293+00	1
543	968	3	I1	14.00	1	2026-10-30 04:51:23.520654+00	1
544	968	3	I2	4.00	1	2026-10-30 04:51:38.899795+00	1
545	968	11	I2	11.00	1	2026-10-30 04:52:00.47618+00	1
546	1033	1	I2	14.00	1	2026-10-30 04:52:24.761383+00	1
547	1033	7	I1	14.00	1	2026-10-30 04:52:46.065874+00	1
548	1033	3	I1	20.00	1	2026-10-30 04:53:17.389895+00	1
549	1033	5	I1	5.00	1	2026-10-30 04:53:35.326028+00	1
550	1024	3	I1	18.00	1	2026-10-30 04:54:03.828944+00	1
551	1024	5	I1	13.00	1	2026-10-30 04:54:35.0312+00	1
552	1024	9	I1	13.00	1	2026-10-30 04:54:52.56102+00	1
553	1024	7	I1	11.00	1	2026-10-30 04:55:13.830712+00	1
555	1119	9	I1	18.00	1	2026-10-30 04:56:10.017929+00	1
556	1040	9	I1	18.00	1	2026-10-30 04:56:55.589406+00	1
557	1019	1	I2	12.00	1	2026-10-30 04:57:19.777347+00	1
558	1019	4	I1	10.00	1	2026-10-30 04:57:36.096524+00	1
559	1019	7	I1	18.00	1	2026-10-30 04:57:57.781795+00	1
560	1036	1	I1	10.00	1	2026-10-30 04:58:18.270026+00	1
561	1036	3	I1	10.00	1	2026-10-30 04:58:44.185812+00	1
562	1036	7	I1	9.00	1	2026-10-30 04:59:12.150556+00	1
563	1036	2	I1	4.00	1	2026-10-30 04:59:27.132127+00	1
564	245	4	I1	13.00	1	2026-10-30 04:59:51.702047+00	1
565	245	3	I1	12.00	1	2026-10-30 05:00:28.909454+00	1
566	264	4	I1	14.00	1	2026-10-30 05:00:50.926289+00	1
567	264	3	I1	14.00	1	2026-10-30 05:01:06.484914+00	1
568	243	2	I1	17.00	1	2026-10-30 05:01:23.183332+00	1
569	243	1	I1	20.00	1	2026-10-30 05:01:50.2501+00	1
570	1035	3	I1	10.00	1	2026-10-30 05:02:05.434909+00	1
571	1035	4	I1	8.00	1	2026-10-30 05:02:21.030564+00	1
572	270	1	I1	15.00	1	2026-10-30 05:02:45.930115+00	1
573	270	7	I1	17.00	1	2026-10-30 05:04:13.574905+00	1
574	270	3	I1	20.00	1	2026-10-30 05:05:06.384208+00	1
575	257	1	I1	16.00	1	2026-10-30 05:05:45.631142+00	1
576	257	2	I1	14.00	1	2026-10-30 05:06:16.237492+00	1
577	257	3	I1	20.00	1	2026-10-30 05:06:33.946075+00	1
578	257	3	I2	10.00	1	2026-10-30 05:06:55.040938+00	1
579	241	7	I1	18.00	1	2026-10-30 05:07:09.381269+00	1
580	241	4	I1	19.50	1	2026-10-30 05:07:28.107007+00	1
581	241	2	I1	16.00	1	2026-10-30 05:07:43.856109+00	1
582	241	1	I1	8.00	1	2026-10-30 05:07:51.00971+00	1
535	242	1	I1	7.00	1	2026-10-30 04:48:06.200819+00	1
554	1024	1	I1	9.00	1	2026-10-30 04:55:46.940487+00	1
585	251	4	I1	19.00	1	2026-10-30 05:08:35.511706+00	1
586	1022	7	I1	20.00	1	2026-10-30 05:09:22.179459+00	1
587	904	7	I1	20.00	1	2026-10-30 05:09:35.860704+00	1
588	904	4	I1	17.50	1	2026-10-30 05:09:57.28213+00	1
589	244	1	I1	15.00	1	2026-10-30 05:10:12.526907+00	1
590	244	4	I1	10.00	1	2026-10-30 05:10:28.722491+00	1
591	244	11	I1	15.00	1	2026-10-30 05:10:46.326477+00	1
592	1023	5	I1	12.00	1	2026-10-30 05:11:11.064291+00	1
593	1023	1	I1	14.00	1	2026-10-30 05:11:36.681671+00	1
594	1023	1	I2	18.00	1	2026-10-30 05:11:47.353177+00	1
595	1023	3	I1	20.00	1	2026-10-30 05:12:08.972171+00	1
596	1023	2	I1	2.00	1	2026-10-30 05:12:27.906636+00	1
597	1018	2	I1	11.00	1	2026-10-30 05:12:38.472266+00	1
598	849	3	I1	20.00	1	2026-10-30 05:13:00.383598+00	1
599	849	4	I1	14.50	1	2026-10-30 05:13:23.123984+00	1
600	849	1	I1	16.00	1	2026-10-30 05:13:56.137608+00	1
601	849	1	I2	19.00	1	2026-10-30 05:14:06.697556+00	1
602	849	5	I1	17.00	1	2026-10-30 05:14:23.902745+00	1
603	1021	1	I1	13.00	1	2026-10-30 05:14:37.339719+00	1
604	263	4	I1	19.00	1	2026-10-30 05:14:57.94455+00	1
605	263	1	I1	9.00	1	2026-10-30 05:15:16.815684+00	1
606	272	3	I1	9.00	1	2026-10-30 05:15:36.716981+00	1
607	272	1	I1	18.00	1	2026-10-30 05:16:00.411837+00	1
608	903	5	I1	12.00	1	2026-10-30 05:16:30.690623+00	1
609	903	2	I1	8.00	1	2026-10-30 05:17:08.571186+00	1
610	906	4	I1	18.00	1	2026-10-30 05:17:46.435875+00	1
611	906	2	I1	12.00	1	2026-10-30 05:17:54.816424+00	1
612	906	3	I1	13.00	1	2026-10-30 05:18:21.16967+00	1
613	906	1	I1	8.00	1	2026-10-30 05:18:58.942764+00	1
614	906	10	I1	18.00	1	2026-10-30 05:19:24.800185+00	1
615	906	10	I2	17.50	1	2026-10-30 05:19:56.031474+00	1
616	905	2	I1	7.00	1	2026-10-30 05:20:20.897005+00	1
617	905	10	I1	13.00	1	2026-10-30 05:20:51.671481+00	1
618	905	5	I1	16.00	1	2026-10-30 05:21:58.872646+00	1
619	905	3	I1	6.00	1	2026-10-30 05:22:10.165648+00	1
620	1171	3	I1	7.00	1	2026-10-30 10:40:33.108557+00	1
621	1171	4	I1	2.00	1	2026-10-30 10:41:24.839933+00	1
622	1171	5	I1	11.00	1	2026-10-30 10:41:52.281683+00	1
623	1171	10	I1	15.50	1	2026-10-30 10:49:07.849938+00	1
625	1171	10	I2	13.00	1	2026-10-30 10:49:44.031733+00	1
626	1231	1	I1	7.00	1	2026-10-30 11:04:06.146541+00	1
627	255	3	I1	15.00	1	2026-10-30 11:19:07.343913+00	1
628	279	7	I1	12.00	1	2026-10-30 11:19:39.429002+00	1
629	310	4	I1	20.00	1	2026-10-30 11:26:34.103951+00	1
630	310	2	I1	7.00	1	2026-10-30 11:27:09.919918+00	1
631	310	3	I1	20.00	1	2026-10-30 11:28:18.710196+00	1
632	310	5	I1	16.00	1	2026-10-30 11:28:36.728982+00	1
633	310	1	I1	12.00	1	2026-10-30 11:28:50.170737+00	1
635	310	11	I1	17.00	1	2026-10-30 11:29:30.641877+00	1
636	1116	1	I1	12.00	1	2026-10-30 11:48:31.784032+00	1
637	1116	4	I1	8.00	1	2026-10-30 11:48:54.185993+00	1
638	1116	1	I2	14.00	1	2026-10-30 11:49:35.485242+00	1
639	1116	7	I1	18.00	1	2026-10-30 11:49:51.6548+00	1
640	314	11	I1	9.00	1	2026-10-30 11:51:17.957204+00	1
641	314	4	I1	20.00	1	2026-10-30 11:52:27.380105+00	1
642	314	7	I1	11.00	1	2026-10-30 11:53:06.100478+00	1
643	1176	11	I1	13.00	1	2026-10-30 11:53:56.753882+00	1
644	1172	1	I1	14.50	1	2026-10-30 11:55:34.416456+00	1
645	1172	11	I1	15.00	1	2026-10-30 11:56:06.912532+00	1
646	1172	5	I1	18.50	1	2026-10-30 11:56:31.714302+00	1
647	1229	1	I1	12.00	1	2026-10-30 11:57:16.874235+00	1
648	1229	4	I1	8.00	1	2026-10-30 11:57:39.861554+00	1
649	1117	3	I1	12.00	1	2026-10-30 11:58:25.046954+00	1
650	262	2	I1	14.00	1	2026-10-30 11:59:32.068692+00	1
651	262	1	I1	14.00	1	2026-10-30 11:59:52.104918+00	1
652	262	11	I1	16.00	1	2026-10-30 12:00:09.164227+00	1
653	262	5	I1	16.00	1	2026-10-30 12:02:31.464393+00	1
654	262	3	I1	16.00	1	2026-10-30 12:02:52.37632+00	1
655	262	4	I1	9.00	1	2026-10-30 12:03:23.734059+00	1
656	1174	4	I1	17.25	1	2026-10-30 12:04:17.176615+00	1
657	1174	9	I1	13.00	1	2026-10-30 12:04:37.983513+00	1
658	1174	9	I2	15.00	1	2026-10-30 12:04:54.463005+00	1
659	1174	7	I1	10.00	1	2026-10-30 12:05:10.189674+00	1
660	1174	2	I1	14.00	1	2026-10-30 12:05:49.311528+00	1
661	1174	2	I2	10.00	1	2026-10-30 12:06:07.83114+00	1
663	1174	5	I1	6.50	1	2026-10-30 12:07:23.073776+00	1
665	962	4	I1	10.00	1	2026-10-30 13:11:42.632708+00	1
666	1064	1	I1	15.00	1	2026-10-30 13:12:12.485456+00	1
667	1220	3	I1	6.00	1	2026-10-30 13:12:55.943613+00	1
668	1220	9	I1	19.00	1	2026-10-30 13:13:11.791952+00	1
669	1220	7	I1	16.00	1	2026-10-30 13:13:30.016635+00	1
670	1220	2	I1	13.00	1	2026-10-30 13:13:48.63809+00	1
671	1219	9	I1	14.00	1	2026-10-30 13:14:44.1604+00	1
672	1219	2	I1	12.00	1	2026-10-30 13:15:02.339749+00	1
673	1219	3	I1	4.00	1	2026-10-30 13:15:22.159584+00	1
664	1174	3	I1	3.00	1	2026-10-30 12:07:57.671441+00	1
675	295	2	I1	15.00	1	2026-10-30 13:15:46.563029+00	1
676	1135	3	I1	5.00	1	2026-10-30 13:16:33.386832+00	1
678	1135	3	I2	7.00	1	2026-10-30 13:17:03.140979+00	1
679	1135	2	I1	8.00	1	2026-10-30 13:17:26.059297+00	1
680	300	3	I1	12.00	1	2026-10-30 13:17:51.649786+00	1
681	300	2	I1	10.00	1	2026-10-30 13:18:16.806913+00	1
682	300	11	I1	10.00	1	2026-10-30 13:19:03.217592+00	1
662	1174	11	I1	4.00	1	2026-10-30 12:06:43.995998+00	1
684	309	11	I1	12.00	1	2026-10-30 13:19:32.869132+00	1
685	309	3	I1	14.00	1	2026-10-30 13:19:50.507807+00	1
686	309	5	I1	14.00	1	2026-10-30 13:20:13.37159+00	1
687	309	9	I1	7.00	1	2026-10-30 13:20:31.093789+00	1
688	309	7	I1	4.00	1	2026-10-30 13:20:46.194146+00	1
689	874	7	I1	19.00	1	2026-10-30 13:21:11.459416+00	1
690	874	11	I1	8.00	1	2026-10-30 13:21:28.471191+00	1
691	874	5	I1	10.00	1	2026-10-30 13:21:47.837332+00	1
692	874	9	I1	11.50	1	2026-10-30 13:22:26.083862+00	1
693	732	6	I1	15.00	1	2026-10-30 13:26:28.839605+00	1
694	469	6	I1	12.00	1	2026-10-30 13:29:58.812821+00	1
695	469	4	I1	8.00	1	2026-10-30 13:30:06.378065+00	1
696	447	6	I1	12.00	1	2026-10-30 13:32:35.422902+00	1
697	447	2	I1	10.00	1	2026-10-30 13:32:42.939352+00	1
698	447	3	I1	14.00	1	2026-10-30 13:33:08.906981+00	1
699	447	5	I1	19.00	1	2026-10-30 13:33:28.826398+00	1
700	464	1	I1	12.00	1	2026-10-30 13:34:41.674017+00	1
701	464	6	I1	19.00	1	2026-10-30 13:34:51.177385+00	1
702	450	5	I1	17.00	1	2026-10-30 13:35:46.868128+00	1
703	450	2	I1	9.00	1	2026-10-30 13:36:12.299133+00	1
704	450	6	I1	13.00	1	2026-10-30 13:36:54.999712+00	1
705	450	5	I2	15.00	1	2026-10-30 13:37:27.095192+00	1
706	450	3	I1	16.00	1	2026-10-30 13:37:40.416638+00	1
707	1263	7	I1	16.00	1	2026-10-30 13:40:06.452936+00	1
708	1263	6	I1	10.00	1	2026-10-30 13:40:45.234004+00	1
709	1263	5	I1	11.00	1	2026-10-30 13:47:58.368023+00	1
710	1263	3	I1	8.00	1	2026-10-30 13:48:20.244309+00	1
711	1263	1	I1	14.00	1	2026-10-30 13:49:43.696194+00	1
712	1263	4	I1	9.00	1	2026-10-30 13:50:16.280862+00	1
713	951	4	I1	10.00	1	2026-10-30 13:55:53.469023+00	1
714	951	7	I1	8.00	1	2026-10-30 13:56:19.877464+00	1
715	1188	4	I1	4.50	1	2026-10-30 13:56:51.804289+00	1
716	1188	7	I1	11.00	1	2026-10-30 13:57:39.070351+00	1
717	468	2	I1	18.00	1	2026-10-30 13:59:57.39305+00	1
718	468	6	I1	15.00	1	2026-10-30 14:03:39.923919+00	1
719	468	4	I1	12.00	1	2026-10-30 14:03:50.10064+00	1
720	452	6	I1	14.00	1	2026-10-30 14:04:39.899108+00	1
721	452	3	I1	20.00	1	2026-10-30 14:04:49.102282+00	1
722	452	5	I1	17.00	1	2026-10-30 14:11:46.809292+00	1
723	452	5	I2	19.00	1	2026-10-30 14:12:27.168428+00	1
724	880	8	I1	15.00	1	2026-10-30 14:28:05.487767+00	1
725	880	3	I1	11.00	1	2026-10-30 14:28:18.1324+00	1
726	880	9	I1	9.00	1	2026-10-30 14:28:35.123733+00	1
727	870	7	I1	20.00	1	2026-10-30 14:29:13.72329+00	1
728	870	8	I1	16.00	1	2026-10-30 14:29:24.170132+00	1
729	913	1	I1	14.00	1	2026-10-30 14:41:30.675805+00	1
730	913	5	I1	16.00	1	2026-10-30 14:42:02.608965+00	1
731	913	7	I1	8.00	1	2026-10-30 14:42:21.548208+00	1
732	913	2	I1	10.00	1	2026-10-30 14:42:34.768718+00	1
733	926	1	I1	18.00	1	2026-10-30 14:43:35.687924+00	1
734	926	7	I1	10.00	1	2026-10-30 14:43:45.400679+00	1
735	926	4	I1	11.00	1	2026-10-30 14:44:13.73591+00	1
736	926	6	I1	16.00	1	2026-10-30 14:44:36.363283+00	1
737	926	5	I1	18.00	1	2026-10-30 14:45:56.253172+00	1
738	973	5	I1	16.00	1	2026-10-30 14:46:19.735114+00	1
739	973	6	I1	14.00	1	2026-10-30 14:46:29.796175+00	1
740	1251	7	I1	17.00	1	2026-10-30 14:47:06.51007+00	1
741	1251	6	I1	18.00	1	2026-10-30 14:47:31.234679+00	1
742	1251	5	I1	19.00	1	2026-10-30 14:47:35.431827+00	1
743	1251	4	I1	15.00	1	2026-10-30 14:47:53.498115+00	1
744	871	7	I1	19.00	1	2026-10-30 14:48:45.70744+00	1
745	916	4	I1	12.00	1	2026-10-30 14:49:27.358006+00	1
746	916	5	I1	15.00	1	2026-10-30 14:49:44.694677+00	1
747	916	2	I1	15.00	1	2026-10-30 14:50:05.442893+00	1
748	1037	4	I1	10.00	1	2026-10-31 08:04:27.699145+00	1
749	135	2	D1	20.00	1	2026-10-31 09:13:46.837734+00	1
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, site_id, contenu, lu, date_creation, roles_cibles) FROM stdin;
1	2	⚠️ Alerte assiduité : ADECHOLA Saad (5ème, Y08261292) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
2	2	⚠️ Alerte assiduité : BANGO Emmanuel (5ème, Y08265886) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
3	2	⚠️ Alerte assiduité : BOGNON Isaac (5ème, Y08267046) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
4	2	⚠️ Alerte assiduité : HOUESSOU Emmanuel (5ème, Y08261959) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
5	2	⚠️ Alerte assiduité : ISSEKI Marie Thérèse (5ème, Y08262321) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
6	2	⚠️ Alerte assiduité : KEKE Florent (5ème, Y08268089) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
7	2	⚠️ Alerte assiduité : ODI Bernice (5ème, Y08263327) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
8	2	⚠️ Alerte assiduité : SALIOU Fridaous (5ème, Y08265146) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
9	2	⚠️ Alerte assiduité : SOHE Abebi (5ème, Y08265526) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
10	2	⚠️ Alerte assiduité : TAO Hidirou (5ème, Y08266928) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
11	2	⚠️ Alerte assiduité : ADAMON Assande (4ème, Y08264402) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
12	2	⚠️ Alerte assiduité : ADAMON Rossime (4ème, Y08268668) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
13	2	⚠️ Alerte assiduité : ALLODE Jérémie (4ème, Y08263589) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
14	2	⚠️ Alerte assiduité : BANKOLE Noel (4ème, Y08263174) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
15	2	⚠️ Alerte assiduité : DANSOU Laurence (4ème, Y08269579) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
16	2	⚠️ Alerte assiduité : HOUNDETON Silvia (4ème, Y08269420) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
17	2	⚠️ Alerte assiduité : HOUNDETON Louise (4ème, Y08263538) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
18	2	⚠️ Alerte assiduité : HOUNKPATIN Constance (4ème, Y08269245) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
19	2	⚠️ Alerte assiduité : KOUKOUI Mariette (4ème, Y08264713) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
20	2	⚠️ Alerte assiduité : LAKOUSSAN Josué (4ème, Y08268145) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
21	2	⚠️ Alerte assiduité : TCHANGOTADE Doris (4ème, Y08267413) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
22	2	⚠️ Alerte assiduité : TOLOFON Eben Ezer (4ème, Y08263533) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
23	2	⚠️ Alerte assiduité : ZANNOU Kephil (4ème, Y08261636) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
24	2	⚠️ Alerte assiduité : FASSINOU Esther (4ème, Y09264641) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
25	2	⚠️ Alerte assiduité : HOUNGA Océane (4ème, Y09263033) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
26	2	⚠️ Alerte assiduité : ADANHONDJI Osias (6ème, Y08268030) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
27	2	⚠️ Alerte assiduité : AGOSSOU Dossa Rosvald (6ème, Y08268870) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
28	2	⚠️ Alerte assiduité : AHLOU GOZO Exaucé (6ème, Y08266698) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
29	2	⚠️ Alerte assiduité : ALI Roubayatou (6ème, Y08261849) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
30	2	⚠️ Alerte assiduité : DANGBEDJI Cynthia Grâce (6ème, Y08267913) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
31	2	⚠️ Alerte assiduité : DOSSOU-KOKO Gentille (6ème, Y08261375) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
32	2	⚠️ Alerte assiduité : DOURODOLA Sofiath Adéola (6ème, Y08269847) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
33	2	⚠️ Alerte assiduité : GOUTHON Guillaume Guérin (6ème, Y08261805) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
34	2	⚠️ Alerte assiduité : HOUNGNANNOU Marius (6ème, Y08267369) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
35	2	⚠️ Alerte assiduité : HOUSSOU Eric Samuel (6ème, Y08265665) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
36	2	⚠️ Alerte assiduité : KANGNIDE Bénoit (6ème, Y08268529) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
37	2	⚠️ Alerte assiduité : KASSA Rock Kodjo (6ème, Y08268504) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
38	2	⚠️ Alerte assiduité : MAIGA Fatoumata (6ème, Y08262415) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
39	2	⚠️ Alerte assiduité : MAIGA Halimata (6ème, Y08263608) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
40	2	⚠️ Alerte assiduité : OUABI Romdonne (6ème, Y08264124) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
41	2	⚠️ Alerte assiduité : TITI Farida (6ème, Y08264735) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
42	2	⚠️ Alerte assiduité : OUMAROU Ramatou (6ème, Y09261630) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
43	2	⚠️ Alerte assiduité : ADANHONDJI Edith (3ème, Y08266767) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
44	2	⚠️ Alerte assiduité : ADJAGNISSOUDE Parfait (3ème, Y08264406) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
45	2	⚠️ Alerte assiduité : AKALA Achani (3ème, Y08263391) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
46	2	⚠️ Alerte assiduité : DANTODJI Amos (3ème, Y08263904) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
47	2	⚠️ Alerte assiduité : DANTON Emmanuella (3ème, Y08263449) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
48	2	⚠️ Alerte assiduité : DJIDENOU Elysée (3ème, Y08269761) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
49	2	⚠️ Alerte assiduité : DJODE Wilson (3ème, Y08269235) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
50	2	⚠️ Alerte assiduité : HOUNKPATIN Melvine (3ème, Y08262562) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
51	2	⚠️ Alerte assiduité : LANKPOEDJA Pascaline (3ème, Y08264767) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
52	2	⚠️ Alerte assiduité : MINTOKIN Bernadette (3ème, Y08266002) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
53	2	⚠️ Alerte assiduité : SAMOU Ashley (3ème, Y08265213) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
54	2	⚠️ Alerte assiduité : SOSSOU Ornella (3ème, Y08266220) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
55	2	⚠️ Alerte assiduité : YOLOU Chaidatou (3ème, Y08266195) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
56	2	⚠️ Alerte assiduité : ZANNOU Bilal (3ème, Y08261815) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
57	2	⚠️ Alerte assiduité : ADAMOU Rassida (3ème, Y09267706) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
58	2	⚠️ Alerte assiduité : DJIMASSA Caméria (3ème, Y09262133) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
59	2	⚠️ Alerte assiduité : HOUNNOU Sandrine (3ème, Y09268075) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
60	2	⚠️ Alerte assiduité : MINTOWANOU Christiane (3ème, Y09261514) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
61	1	⚠️ Alerte assiduité : ADANMAHO Ruth (6ème A, J08268022) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
62	1	⚠️ Alerte assiduité : AGOSSOU Gael (6ème A, J08262268) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
63	1	⚠️ Alerte assiduité : AHOTON Aristide (6ème A, J08268267) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
64	1	⚠️ Alerte assiduité : AHOUANDJINOU Mitricia (6ème A, J08261730) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
65	1	⚠️ Alerte assiduité : BODJOSSOU Chimène (6ème A, J08263536) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
66	1	⚠️ Alerte assiduité : DANNOUDO Joanita (6ème A, J08266999) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
67	1	⚠️ Alerte assiduité : DANSOU René (6ème A, J08262951) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
68	1	⚠️ Alerte assiduité : DEGBO Abel (6ème A, J08261500) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
69	1	⚠️ Alerte assiduité : EDIBO Haidou (6ème A, J08262766) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
70	1	⚠️ Alerte assiduité : GANGNON Abidémi Mourana (6ème A, J08263543) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
71	1	⚠️ Alerte assiduité : GODONOU Gloria Merveille (6ème A, J08264361) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
72	1	⚠️ Alerte assiduité : HONVOU Josué Norbert (6ème A, J08262551) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
73	1	⚠️ Alerte assiduité : HOUADJETO Rose (6ème A, J08268178) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
74	1	⚠️ Alerte assiduité : HOUADJETO Jéhovany (6ème A, J08265291) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
75	1	⚠️ Alerte assiduité : HOUESSOU Prince (6ème A, J08264295) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
76	1	⚠️ Alerte assiduité : HOUNGBO Urielle (6ème A, J08268757) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
77	1	⚠️ Alerte assiduité : HOUNSOU Béni (6ème A, J08262703) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
78	1	⚠️ Alerte assiduité : OLOUGBADE Fèmi Ruthe (6ème A, J08269413) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
79	1	⚠️ Alerte assiduité : SIMENOU M. Jérôme (6ème A, J08269042) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
80	1	⚠️ Alerte assiduité : THON Elians (6ème A, J08264309) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
81	1	⚠️ Alerte assiduité : TRAORE Azizé (6ème A, J08265282) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
82	1	⚠️ Alerte assiduité : YEHOUENOU Elisabeth (6ème A, J08263772) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
83	1	⚠️ Alerte assiduité : ZINHO Edwige (6ème A, J08267089) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
84	1	⚠️ Alerte assiduité : ADEYEMON Alphé (6ème A, J08263259) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
85	1	⚠️ Alerte assiduité : ADJOVI Gilles-Christ (6ème A, J08266080) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
86	1	⚠️ Alerte assiduité : AKINOCHO Espérancia (6ème A, J08263759) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
87	1	⚠️ Alerte assiduité : ALANGBOKINTO Christ-fort (6ème A, J08264362) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
88	1	⚠️ Alerte assiduité : ALI Nabilath (6ème A, J08266596) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
89	1	⚠️ Alerte assiduité : ALOSSE Mahutin (6ème A, J08265636) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
90	1	⚠️ Alerte assiduité : AZOUASSI Arielle (6ème A, J08268975) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
91	1	⚠️ Alerte assiduité : COUMASSOU Fifamè (6ème A, J08266460) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
92	1	⚠️ Alerte assiduité : DENAKPO Samuel (6ème A, J08268114) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
93	1	⚠️ Alerte assiduité : GNONLONFOUN Elisabeth (6ème A, J08266111) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
94	1	⚠️ Alerte assiduité : GNONLONFOUN Majoie (6ème A, J08268706) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
95	1	⚠️ Alerte assiduité : HESSOU Inès (6ème A, J08269126) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
96	1	⚠️ Alerte assiduité : HOUESSOU Brice (6ème A, J08262289) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
97	1	⚠️ Alerte assiduité : HOUNGBEDJI Christian (6ème A, J08266301) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
98	1	⚠️ Alerte assiduité : HOUNGBO Emannuel (6ème A, J08264399) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
99	1	⚠️ Alerte assiduité : IMOROU Arafat (6ème A, J08263486) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
100	1	⚠️ Alerte assiduité : KOUMA Patricia (6ème A, J08261761) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
101	1	⚠️ Alerte assiduité : MEGNIZIN Melvine (6ème A, J08262790) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
102	1	⚠️ Alerte assiduité : NASSARA Firmin Tobias (6ème A, J08262583) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
103	1	⚠️ Alerte assiduité : NASSARA Augustin (6ème A, J08264701) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
104	1	⚠️ Alerte assiduité : OTCHRAN Micheline (6ème A, J08266095) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
105	1	⚠️ Alerte assiduité : QUENUM Wahib (6ème A, J08264530) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
106	1	⚠️ Alerte assiduité : SOUNOUVOU Christophe (6ème A, J08265267) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
107	1	⚠️ Alerte assiduité : SOVIGUIDI Nadège (6ème A, J08263178) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
108	1	⚠️ Alerte assiduité : COSSE Florentine (6ème B, J08264120) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
109	1	⚠️ Alerte assiduité : NOUGBODJI Chantale (6ème B, J08264951) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
110	1	⚠️ Alerte assiduité : OYASIDI Amed (6ème B, J08261282) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
111	1	⚠️ Alerte assiduité : ABDOULAYE Anas (6ème B, J08268492) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
112	1	⚠️ Alerte assiduité : ADAM Hamirath (6ème B, J08262251) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
113	1	⚠️ Alerte assiduité : ADAN Ginette (6ème B, J08268011) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
114	1	⚠️ Alerte assiduité : ADINGNI Espoir (6ème B, J08264206) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
115	1	⚠️ Alerte assiduité : ADONON Agathe (6ème B, J08266648) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
116	1	⚠️ Alerte assiduité : AHOUMENOU Jephte (6ème B, J08262485) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
117	1	⚠️ Alerte assiduité : AYIVODJI Bernice (6ème B, J08261768) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
118	1	⚠️ Alerte assiduité : BEAHENOU Luchrist (6ème B, J08269030) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
119	1	⚠️ Alerte assiduité : BONI Gloire (6ème B, J08265020) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
120	1	⚠️ Alerte assiduité : CHOGOLOU Géovani (6ème B, J08261340) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
121	1	⚠️ Alerte assiduité : DAVI Elysée (6ème B, J08268419) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
122	1	⚠️ Alerte assiduité : DANSOU Constantin (6ème B, J08262136) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
123	1	⚠️ Alerte assiduité : DIAWARA Aicha (6ème B, J08269531) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
124	1	⚠️ Alerte assiduité : GANDJI Donald (6ème B, J08261370) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
125	1	⚠️ Alerte assiduité : GBETCHOEVI Ornela (6ème B, J08263929) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
126	1	⚠️ Alerte assiduité : GNANSOUNOU Angelo (6ème B, J08268290) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
127	1	⚠️ Alerte assiduité : GNITABOU Pierrette (6ème B, J08263073) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
128	1	⚠️ Alerte assiduité : HONFO Irène (6ème B, J08262823) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
129	1	⚠️ Alerte assiduité : HOUENOU Chrismel (6ème B, J08265639) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
130	1	⚠️ Alerte assiduité : HOUNGUE Huguette (6ème B, J08268864) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
131	1	⚠️ Alerte assiduité : HOUNGUIEVI Firmin (6ème B, J08262013) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
132	1	⚠️ Alerte assiduité : HOUNMENOU Urielle (6ème B, J08265471) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
133	1	⚠️ Alerte assiduité : LATEDJOU Arafat (6ème B, J08262492) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
134	1	⚠️ Alerte assiduité : LINDE Houeffa (6ème B, J08264113) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
135	1	⚠️ Alerte assiduité : MEGNIHA Darius (6ème B, J08261580) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
136	1	⚠️ Alerte assiduité : MONNOU Mariam (6ème B, J08264738) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
137	1	⚠️ Alerte assiduité : MOUSSA Souraimou (6ème B, J08265910) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
138	1	⚠️ Alerte assiduité : MOUTAIROU Sékinath (6ème B, J08265457) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
139	1	⚠️ Alerte assiduité : ODOUTAN Florent (6ème B, J08268253) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
140	1	⚠️ Alerte assiduité : OUSSA Soubela (6ème B, J08263689) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
141	1	⚠️ Alerte assiduité : SOKE Elisée (6ème B, J08268798) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
142	1	⚠️ Alerte assiduité : VOITAN Mirabelle (6ème B, J08262675) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
143	1	⚠️ Alerte assiduité : ZANNOU Hervé (6ème B, J08264158) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
144	1	⚠️ Alerte assiduité : ZOUNDJIEKPON Clément (6ème B, J08269788) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
145	1	⚠️ Alerte assiduité : AHIHA Antoine (6ème B, J08267999) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
146	1	⚠️ Alerte assiduité : AHIHA Joanès (6ème B, J08265432) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
147	1	⚠️ Alerte assiduité : AHOUANGONOU Pauline (6ème B, J08262391) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
148	1	⚠️ Alerte assiduité : AKAKPO Marie Jeanne (6ème B, J08263647) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
149	1	⚠️ Alerte assiduité : ADEOSSI Sergino (6ème B, J08269684) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
150	1	⚠️ Alerte assiduité : BOTON FATCHE Augustin (6ème B, J08266047) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
151	1	⚠️ Alerte assiduité : GNANSOUNOU William (6ème B, J08265023) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
152	1	⚠️ Alerte assiduité : HONFO Adjimon Jean (6ème B, J08264804) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
153	1	⚠️ Alerte assiduité : HOUNGA Eric (6ème B, J08263162) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
154	1	⚠️ Alerte assiduité : HOUNKONDE Christ (6ème B, J08269644) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
155	1	⚠️ Alerte assiduité : OGOUDJOBI Mounirath (6ème B, J08261480) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
156	1	⚠️ Alerte assiduité : QUENUM Miracle (6ème B, J08269868) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
157	1	⚠️ Alerte assiduité : TODE Alexandre (6ème B, J08263582) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
158	1	⚠️ Alerte assiduité : TOKPO Dieu donné (6ème B, J08262231) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
159	1	⚠️ Alerte assiduité : ZINSOU Sènami (6ème B, J08265238) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
160	1	⚠️ Alerte assiduité : VITIN Anath Elisée (6ème B, J09264694) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
161	1	⚠️ Alerte assiduité : ADANZOUNNON Marie Louise (4ème B, J08265678) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
162	1	⚠️ Alerte assiduité : ALANGBOKINTO Marc Vivien (4ème B, J08264875) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
163	1	⚠️ Alerte assiduité : DANSOU Madeleine (4ème B, J08269655) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
164	1	⚠️ Alerte assiduité : DJIGBE Gédéon (4ème B, J08266833) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
165	1	⚠️ Alerte assiduité : HOUNTON Mathieu (4ème B, J08268053) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
166	1	⚠️ Alerte assiduité : HOUNVO Géronime (4ème B, J08267063) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
167	1	⚠️ Alerte assiduité : KLADJI Joinelle (4ème B, J08264987) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
168	1	⚠️ Alerte assiduité : KLOTOE Dénis (4ème B, J08263930) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
169	1	⚠️ Alerte assiduité : OKOU ADE Huguette (4ème B, J08267289) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
170	1	⚠️ Alerte assiduité : TODJINOU Bénoit (4ème B, J08266189) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
171	1	⚠️ Alerte assiduité : AHISSOU Marcolino (4ème B, J08264502) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
172	1	⚠️ Alerte assiduité : AWODJE Eric (4ème B, J08262903) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
173	1	⚠️ Alerte assiduité : CHEMITAN Widad (4ème B, J08266858) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
174	1	⚠️ Alerte assiduité : GNONLONFOUN José (4ème B, J08263141) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
175	1	⚠️ Alerte assiduité : KOULIHO Giovanie (4ème B, J08264286) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
176	1	⚠️ Alerte assiduité : MASSANGA Emmanuel (4ème B, J08266367) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
177	1	⚠️ Alerte assiduité : DANKE Junior (4ème B, J08264161) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
178	1	⚠️ Alerte assiduité : HONNAHO Jahsther (4ème B, J08269070) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
179	1	⚠️ Alerte assiduité : HOUNGBEMEY Emmanuella (4ème B, J08269518) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
180	1	⚠️ Alerte assiduité : ODJO Archimède (4ème B, J08268466) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
181	1	⚠️ Alerte assiduité : ABOUDOU Enock (4ème A, J08263316) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
182	1	⚠️ Alerte assiduité : ADJOVI Dylane (4ème A, J08269590) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
183	1	⚠️ Alerte assiduité : AGONYE Monique (4ème A, J08261424) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
184	1	⚠️ Alerte assiduité : AHOUAGA Fabrice (4ème A, J08262029) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
185	1	⚠️ Alerte assiduité : AMOUSSOU Elfrida (4ème A, J08264258) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
186	1	⚠️ Alerte assiduité : AVLESSI Sylvia (4ème A, J08267011) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
187	1	⚠️ Alerte assiduité : DAKOSSI Constance (4ème A, J08265577) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
188	1	⚠️ Alerte assiduité : DAVI Emmanuel (4ème A, J08266520) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
189	1	⚠️ Alerte assiduité : DAVI Elias (4ème A, J08261989) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
190	1	⚠️ Alerte assiduité : FOFANA Tidjani (4ème A, J08262738) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
191	1	⚠️ Alerte assiduité : KOUDJOU Alves (4ème A, J08261576) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
192	1	⚠️ Alerte assiduité : WINSAVI Nadège (4ème A, J08264859) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
193	1	⚠️ Alerte assiduité : AFO Fabienne (4ème A, J08263921) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
194	1	⚠️ Alerte assiduité : AGONZAN Victoire (4ème A, J08269613) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
195	1	⚠️ Alerte assiduité : ANAGONOU Lydwine Judith (4ème A, J08266187) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
196	1	⚠️ Alerte assiduité : DJOSSOU Adèle (4ème A, J08267492) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
197	1	⚠️ Alerte assiduité : GANDONOU Olivia (4ème A, J08262042) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
198	1	⚠️ Alerte assiduité : GANDONOU Olivier (4ème A, J08265175) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
199	1	⚠️ Alerte assiduité : GANKOU Nelda (4ème A, J08262658) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
200	1	⚠️ Alerte assiduité : HOUSSOU Grâce (4ème A, J08267619) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
201	1	⚠️ Alerte assiduité : HOUSSOU Jean Pascal (4ème A, J08264225) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
202	1	⚠️ Alerte assiduité : IJIDINAN Romain (4ème A, J08269487) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
203	1	⚠️ Alerte assiduité : KINSOU Wilsdom (4ème A, J08267503) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
204	1	⚠️ Alerte assiduité : KOUNNOU Chancelle (4ème A, J08261832) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
205	1	⚠️ Alerte assiduité : N'TIA Auristelle (4ème A, J08261907) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
206	1	⚠️ Alerte assiduité : PRINCE AGBODJAN Marius (4ème A, J08267045) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
207	1	⚠️ Alerte assiduité : SYLLA Alassane (4ème A, J08262326) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
208	1	⚠️ Alerte assiduité : SYLLA Fousséni (4ème A, J08269245) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
209	1	⚠️ Alerte assiduité : TCHIAKPE Exaucée (4ème A, J08269120) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
210	1	⚠️ Alerte assiduité : TCHOKOTI Peace (4ème A, J08269234) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
211	1	⚠️ Alerte assiduité : ZANNOU Géraldo (4ème A, J08266134) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
212	1	⚠️ Alerte assiduité : ZINLI Dario (4ème A, J08267300) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
213	1	⚠️ Alerte assiduité : AHOUANGANON Mariella (4ème A, J08263545) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
214	1	⚠️ Alerte assiduité : BATOSSI Alexia (4ème A, J08262861) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
215	1	⚠️ Alerte assiduité : HOUETO Madochée Pio (4ème A, J08268479) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
216	1	⚠️ Alerte assiduité : IMOROU Nabil (4ème A, J08267178) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
217	1	⚠️ Alerte assiduité : AYIDOKINHOU Kévine Junior (4ème A, J08267530) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
218	1	⚠️ Alerte assiduité : SALE Nicole (4ème A, J08265051) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
219	1	⚠️ Alerte assiduité : DJOSSOU Adèle (4ème A, J09264148) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
220	1	⚠️ Alerte assiduité : AGOSSOU Ashley (Première C, J08267214) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
221	1	⚠️ Alerte assiduité : DOVI Edwige (Première C, J08266270) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
222	1	⚠️ Alerte assiduité : HOUNGA Christian (Première C, J08266856) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
223	1	⚠️ Alerte assiduité : KANA Emmanuella (Première C, J08266085) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
224	1	⚠️ Alerte assiduité : LEGUEDE Emmanuel (Première D, J08262339) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
225	1	⚠️ Alerte assiduité : ADEKPODJOU Fatima (Première D, J08262634) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
226	1	⚠️ Alerte assiduité : ADIMOU Julie (Première D, J08265985) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
227	1	⚠️ Alerte assiduité : ADJAGNISSOUDE Pamella (Première D, J08261913) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
228	1	⚠️ Alerte assiduité : AHOUANGANON Nadège (Première D, J08262897) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
229	1	⚠️ Alerte assiduité : AMONDO Kiriya (Première D, J08262066) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
230	1	⚠️ Alerte assiduité : DJOCHOU Louise (Première D, J08267175) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
231	1	⚠️ Alerte assiduité : FAGNISSE Majoie (Première D, J08265173) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
232	1	⚠️ Alerte assiduité : KODJO Miracle (Première D, J08265430) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
233	1	⚠️ Alerte assiduité : KOUNNOU Jocelyne (Première D, J08263898) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
234	1	⚠️ Alerte assiduité : OLLIVIER DE MONTAGUERE Luce (Première D, J08266694) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
235	1	⚠️ Alerte assiduité : RADJEDO Pierrette (Première D, J08268728) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
236	1	⚠️ Alerte assiduité : AKPOTINKPE Jacqueline (Première D, J08267751) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
237	1	⚠️ Alerte assiduité : ASSONGBA Ruth (Première D, J08263781) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
238	1	⚠️ Alerte assiduité : ATEDJI Madine (Première D, J08263809) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
239	1	⚠️ Alerte assiduité : KOTTIN Modeste (Première D, J08261574) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
240	1	⚠️ Alerte assiduité : MEVOGNON Exelle (Première D, J08269599) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
241	1	⚠️ Alerte assiduité : MIFOKPO Jacqueline (Première D, J08267702) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
242	1	⚠️ Alerte assiduité : ZOSSOU YOVO Daniel (Première D, J08265326) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
243	1	⚠️ Alerte assiduité : ADJIWANOU Gérade (5ème B, J08269360) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
244	1	⚠️ Alerte assiduité : AGLO-HOUNGA Fèmi (5ème B, J08265248) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
245	1	⚠️ Alerte assiduité : AGUE Dolorès (5ème B, J08268059) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
246	1	⚠️ Alerte assiduité : AKPOVI Freshnelle (5ème B, J08267899) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
247	1	⚠️ Alerte assiduité : ATEDJI Fernand (5ème B, J08264845) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
248	1	⚠️ Alerte assiduité : DJIGBE Bernadin (5ème B, J08265241) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
249	1	⚠️ Alerte assiduité : DJOWADAN Christine (5ème B, J08266725) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
250	1	⚠️ Alerte assiduité : GANHOUNOUTO Marie Thérèse (5ème B, J08264321) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
251	1	⚠️ Alerte assiduité : GUELIFO Romuald (5ème B, J08268159) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
252	1	⚠️ Alerte assiduité : HOUENOU Abdias (5ème B, J08263744) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
253	1	⚠️ Alerte assiduité : HOUNSOU Adéline (5ème B, J08266932) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
254	1	⚠️ Alerte assiduité : HOYETON Daniel (5ème B, J08264360) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
255	1	⚠️ Alerte assiduité : IBRAHIM Mohamed (5ème B, J08263025) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
256	1	⚠️ Alerte assiduité : KOUTON Dorcas Mahugnon (5ème B, J08268081) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
257	1	⚠️ Alerte assiduité : LAHADE Christelle (5ème B, J08268611) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
258	1	⚠️ Alerte assiduité : MUIDEEN Adidjathou (5ème B, J08266524) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
259	1	⚠️ Alerte assiduité : MOUKAILA Adidjath (5ème B, J08267191) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
260	1	⚠️ Alerte assiduité : OUSSENI Ramdia (5ème B, J08262732) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
261	1	⚠️ Alerte assiduité : SAVIAKO Achille (5ème B, J08263366) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
262	1	⚠️ Alerte assiduité : TOKPANOU Osé (5ème B, J08265715) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
263	1	⚠️ Alerte assiduité : TOUNAOU Mohamed (5ème B, J08264817) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
264	1	⚠️ Alerte assiduité : VIGAN Horsman (5ème B, J08264526) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
265	1	⚠️ Alerte assiduité : YEVO EDO Bénédicte (5ème B, J08269533) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
266	1	⚠️ Alerte assiduité : ZOUNDJI Inès (5ème B, J08264376) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
267	1	⚠️ Alerte assiduité : HOUNTONDJI Gaspard (5ème B, J08265135) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
268	1	⚠️ Alerte assiduité : AYIMETON Pierrette (5ème B, J08267093) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
269	1	⚠️ Alerte assiduité : KANGNI Fernande (5ème B, J08266944) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
270	1	⚠️ Alerte assiduité : ADANDE Fifamè (5ème A, J08267193) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
271	1	⚠️ Alerte assiduité : AGBO Bénédicte (5ème A, J08268357) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
272	1	⚠️ Alerte assiduité : AGOGNON Junior (5ème A, J08263105) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
273	1	⚠️ Alerte assiduité : AHISSOU Exaucé (5ème A, J08269605) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
274	1	⚠️ Alerte assiduité : ALLOSSE Charafath (5ème A, J08264017) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
275	1	⚠️ Alerte assiduité : ATCHONDE Fednand (5ème A, J08263879) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
276	1	⚠️ Alerte assiduité : AYONOU Samuel (5ème A, J08262999) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
277	1	⚠️ Alerte assiduité : DE CAMPOS Lionel (5ème A, J08266153) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
278	1	⚠️ Alerte assiduité : DHESSIN Ingrid (5ème A, J08264331) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
279	1	⚠️ Alerte assiduité : DJOTCHOU Arnaud (5ème A, J08263996) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
280	1	⚠️ Alerte assiduité : FOHOU Eunice (5ème A, J08265816) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
281	1	⚠️ Alerte assiduité : HOUNSOU Grâce (5ème A, J08265404) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
282	1	⚠️ Alerte assiduité : HOYETON Diane (5ème A, J08267821) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
283	1	⚠️ Alerte assiduité : KABADE Doreil (5ème A, J08269582) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
284	1	⚠️ Alerte assiduité : KAKPO Précieuse (5ème A, J08265429) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
285	1	⚠️ Alerte assiduité : KPIKPONSOUHOU Chérif (5ème A, J08267855) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
286	1	⚠️ Alerte assiduité : LAWANI Nourou Dine (5ème A, J08262887) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
287	1	⚠️ Alerte assiduité : OLADELE Mukaram (5ème A, J08268326) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
288	1	⚠️ Alerte assiduité : OLOUGBADE Anne Yémissi (5ème A, J08269233) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
289	1	⚠️ Alerte assiduité : PADONOU Chancelle (5ème A, J08263282) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
290	1	⚠️ Alerte assiduité : SALAMI Mourtador (5ème A, J08267573) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
291	1	⚠️ Alerte assiduité : SEDJRO Abiba Fifamè (5ème A, J08264312) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
292	1	⚠️ Alerte assiduité : TIDJANI Imraan (5ème A, J08263674) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
293	1	⚠️ Alerte assiduité : TOSSA Kasmi (5ème A, J08267188) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
294	1	⚠️ Alerte assiduité : BOGNON Isaac (5ème A, J08263297) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
295	1	⚠️ Alerte assiduité : FOHOU Tite (5ème A, J08266114) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
296	1	⚠️ Alerte assiduité : VICTOR VITOHOUINDJI Appolinaire (5ème A, J08267310) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
746	1	Régularisation : levée de la suspension pour CODJIA Joinès (J08265649) — scolarité de Octobre soldée à 100 %.	f	2026-11-01 07:47:09.85389+00	{coordonnateur,comptable,superviseur,chef_site}
299	1	Suppression définitive : ABOUDOU Enock (J08263316) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-08 21:05:18.002047+00	{coordonnateur,comptable}
297	1	Paiement supprimé : 2 500 F (Octobre) annulé pour MOIDE Fènou Jériel Antonio (J09266010) par jealexhouegbe — Motif : Erreur de saisie du montant normal payé	t	2026-10-04 23:29:12.353035+00	{coordonnateur,comptable}
298	1	Paiement supprimé : 5 000 F (Octobre) annulé pour CAPO-CHICHI Elysée Eléna Nathalie (J09261327) par jealexhouegbe — Motif : Erreur de saisie du montant payé	t	2026-10-04 23:36:39.712032+00	{coordonnateur,comptable}
307	1	Suppression définitive : AHOUANGANON Nadège (J08262897) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-09 05:35:16.421796+00	{coordonnateur,comptable}
306	1	Suppression définitive : ADJAGNISSOUDE Pamella (J08261913) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-09 05:34:43.07877+00	{coordonnateur,comptable}
319	1	Suppression définitive : 8 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:14:16.668705+00	{coordonnateur,comptable}
318	1	Suppression définitive : 10 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:04:06.038929+00	{coordonnateur,comptable}
302	1	Suppression définitive : AGBOGLO Landryne (J08262660) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-09 02:47:51.321478+00	{coordonnateur,comptable}
303	1	Suppression définitive : AGBOGLO Landréa (J08267224) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-09 02:48:15.393884+00	{coordonnateur,comptable}
304	1	Suppression définitive : AMEGAN Eliséi (J08263741) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-09 02:48:31.543393+00	{coordonnateur,comptable}
305	1	Suppression définitive : ADIMOU Julie (J08265985) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-09 05:34:27.479029+00	{coordonnateur,comptable}
300	1	Suppression définitive : AHISSOU Jean Eudes (J09262533) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-08 22:42:03.022836+00	{coordonnateur,comptable}
301	1	Suppression définitive : SIMENOU Jérôme (J10265483) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-08 22:50:29.32281+00	{coordonnateur,comptable}
308	1	Paiement supprimé : 3 000 F (Octobre) annulé pour HOUETCHOU Précieux (J08263005) par jealexhouegbe — Motif : Erreur de saisie du montant	t	2026-10-14 20:27:33.978658+00	{coordonnateur,comptable}
309	1	Paiement supprimé : 4 000 F (Octobre) annulé pour GANSA Shalom (J09265287) par jealexhouegbe — Motif : Erreur de saisie du montant	t	2026-10-14 20:36:20.276645+00	{coordonnateur,comptable}
310	1	Paiement supprimé : 2 000 F (Octobre) annulé pour AGOSSOU Eunice (J08263684) par jealexhouegbe — Motif : Erreur de saisie du montant	t	2026-10-15 03:18:06.978782+00	{coordonnateur,comptable}
311	1	Suppression définitive : 11 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 17:23:34.45432+00	{coordonnateur,comptable}
312	1	Suppression définitive : 5 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 17:25:41.584647+00	{coordonnateur,comptable}
313	1	Suppression définitive : 5 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 17:33:17.356971+00	{coordonnateur,comptable}
314	1	Suppression définitive : 2 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 17:35:02.82091+00	{coordonnateur,comptable}
315	1	Suppression définitive : 2 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 17:36:55.684654+00	{coordonnateur,comptable}
316	1	Suppression définitive : HOSSOU Sidonie Fifamè (J09263247) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 17:46:31.039095+00	{coordonnateur,comptable}
317	1	Suppression définitive : 12 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 21:14:54.902749+00	{coordonnateur,comptable}
320	1	Suppression définitive : TCHIBOZO Sharon (J10268623) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:16:40.407692+00	{coordonnateur,comptable}
321	1	Suppression définitive : ZOUNDJI Inès (J08264376) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:18:11.491252+00	{coordonnateur,comptable}
322	1	Suppression définitive : 12 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:42:18.621816+00	{coordonnateur,comptable}
323	1	Suppression définitive : 3 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:43:52.443921+00	{coordonnateur,comptable}
324	1	Suppression définitive : ZINLI Dario (J08267300) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:46:30.325116+00	{coordonnateur,comptable}
325	1	Suppression définitive : ZOUNDJI Lucien (J08268271) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:46:55.902093+00	{coordonnateur,comptable}
326	1	Suppression définitive : TOSSOU Marc Owen (J08266681) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:52:21.711288+00	{coordonnateur,comptable}
327	1	Suppression définitive : 15 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-15 23:55:17.753131+00	{coordonnateur,comptable}
328	1	Suppression définitive : 9 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:03:38.866525+00	{coordonnateur,comptable}
329	1	Suppression définitive : SAGBO Rebecca (J08267022) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:04:11.692515+00	{coordonnateur,comptable}
330	1	Suppression définitive : 2 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:14:12.794714+00	{coordonnateur,comptable}
331	1	Suppression définitive : 2 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:17:29.882001+00	{coordonnateur,comptable}
332	1	Suppression définitive : 3 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:21:51.91242+00	{coordonnateur,comptable}
333	1	Suppression définitive : AKPATA Philomène (J10264208) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:24:44.220641+00	{coordonnateur,comptable}
334	1	Suppression définitive : 13 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:34:17.471642+00	{coordonnateur,comptable}
335	1	Suppression définitive : 5 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:36:33.596058+00	{coordonnateur,comptable}
336	1	Suppression définitive : 20 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-16 00:40:33.584846+00	{coordonnateur,comptable}
359	1	⚠️ Alerte assiduité : ABENI Edith (3ème B, J08263933) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-21 15:07:36.423151+00	{coordonnateur,superviseur,chef_site}
360	1	⚠️ Alerte assiduité : WIGNANON Jéssica (3ème B, J09268877) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-21 15:07:36.423151+00	{coordonnateur,superviseur,chef_site}
343	1	Suppression définitive : 43 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 16:55:46.13507+00	{coordonnateur,comptable}
344	1	Suppression définitive : 31 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 16:56:36.571747+00	{coordonnateur,comptable}
345	1	Suppression définitive : 36 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 16:57:12.520923+00	{coordonnateur,comptable}
346	1	Suppression définitive : 50 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 16:58:14.815792+00	{coordonnateur,comptable}
347	1	Suppression définitive : WIGNANON Jessica (J10269777) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 17:01:19.428354+00	{coordonnateur,comptable}
348	1	Suppression définitive : 18 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 17:02:26.410648+00	{coordonnateur,comptable}
337	1	Suppression définitive : HAROUNA Hamza (J08262550) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-18 07:43:04.398879+00	{coordonnateur,comptable}
338	1	Suppression définitive : 7 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-18 09:04:29.658036+00	{coordonnateur,comptable}
339	1	Suppression définitive : VITIN Anath Elisée (J09264694) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-18 09:04:51.285065+00	{coordonnateur,comptable}
340	1	Suppression définitive : CHOKKI Basilia (J09269454) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-18 09:14:12.537367+00	{coordonnateur,comptable}
341	1	Suppression définitive : 50 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 16:54:10.508524+00	{coordonnateur,comptable}
342	1	Suppression définitive : 50 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 16:54:44.947576+00	{coordonnateur,comptable}
349	2	Suppression définitive : 18 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 17:20:24.852988+00	{coordonnateur,comptable}
350	2	Suppression définitive : 2 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-19 17:25:54.940124+00	{coordonnateur,comptable}
351	2	Suppression définitive : 10 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 00:07:11.14358+00	{coordonnateur,comptable}
352	2	Suppression définitive : 8 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 06:15:40.649996+00	{coordonnateur,comptable}
353	2	Suppression définitive : LAKOUSSAN Josué (Y08268145) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 06:16:59.246345+00	{coordonnateur,comptable}
354	2	Suppression définitive : 2 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 06:20:34.735124+00	{coordonnateur,comptable}
355	2	Suppression définitive : 12 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 06:34:40.990975+00	{coordonnateur,comptable}
356	2	Suppression définitive : 3 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 06:36:53.591562+00	{coordonnateur,comptable}
357	2	Suppression définitive : MINTOWANOU Christiane (Y09261514) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 06:37:42.222774+00	{coordonnateur,comptable}
358	2	Suppression définitive : 3 élève(s) supprimé(s) par le coordonnateur jealexhouegbe.	t	2026-10-20 06:46:31.557312+00	{coordonnateur,comptable}
361	1	Paiement supprimé : 5 000 F (Novembre) annulé pour SEDE Josias (J09264352) par jealexhouegbe — Motif : Erreur de saisie	t	2026-10-22 03:25:39.676775+00	{coordonnateur,comptable}
362	1	Paiement supprimé : 5 000 F (Novembre) annulé pour SEDE Abigaëlle (J09269640) par jealexhouegbe — Motif : Erreur de saisie	t	2026-10-22 03:26:25.1288+00	{coordonnateur,comptable}
363	1	Paiement supprimé : 5 000 F (Octobre) annulé pour SEDE Abigaëlle (J09269640) par jealexhouegbe — Motif : Erreur de saisie	t	2026-10-22 03:29:59.105518+00	{coordonnateur,comptable}
364	1	Paiement supprimé : 5 000 F (Octobre) annulé pour SEDE Josias (J09264352) par jealexhouegbe — Motif : Erreur de saisie	t	2026-10-22 03:30:23.334023+00	{coordonnateur,comptable}
365	1	⚠️ Alerte assiduité : AGOSSOU Victorine (5ème A, J08265785) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:25:25.02784+00	{coordonnateur,superviseur,chef_site}
366	1	⚠️ Alerte assiduité : HOUNTONDJI Gaspard (5ème A, J08265135) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:25:25.02784+00	{coordonnateur,superviseur,chef_site}
367	1	⚠️ Alerte assiduité : ADJASSOHO Conceptine (Première D, J08262094) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:42:18.606599+00	{coordonnateur,superviseur,chef_site}
368	1	⚠️ Alerte assiduité : AGOSSOU Victoria (5ème B, J08263499) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:54:14.526599+00	{coordonnateur,superviseur,chef_site}
369	1	⚠️ Alerte assiduité : KOUTON Dorcas Mahugnon (5ème B, J08268081) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:54:14.526599+00	{coordonnateur,superviseur,chef_site}
370	1	⚠️ Alerte assiduité : YEVO EDO Bénédicte (5ème B, J08269533) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:54:14.526599+00	{coordonnateur,superviseur,chef_site}
371	1	⚠️ Alerte assiduité : KOUNOUHO Florentin (5ème B, J09267347) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:54:14.526599+00	{coordonnateur,superviseur,chef_site}
372	1	⚠️ Alerte assiduité : TOKINHO Ebénézer (5ème B, J09261792) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 07:54:14.526599+00	{coordonnateur,superviseur,chef_site}
373	1	⚠️ Alerte assiduité : YETIN Aliou (4ème B, J09263820) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 08:00:44.465709+00	{coordonnateur,superviseur,chef_site}
374	2	⚠️ Alerte assiduité : KEKE Florent (5ème, Y08268089) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 08:03:31.944632+00	{coordonnateur,superviseur,chef_site}
375	1	⚠️ Alerte assiduité : BONOU Andréa (6ème A, J08264473) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 08:18:01.604131+00	{coordonnateur,superviseur,chef_site}
376	2	⚠️ Alerte assiduité : ADAMON Assande (4ème, Y08264402) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 08:23:28.906421+00	{coordonnateur,superviseur,chef_site}
377	2	⚠️ Alerte assiduité : OGOUTCHI Oré Oluwa Merveille (4ème, Y08262014) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 08:23:28.906421+00	{coordonnateur,superviseur,chef_site}
378	1	⚠️ Alerte assiduité : SIMENOU M. Jérôme (6ème B, J08269042) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 08:25:48.864241+00	{coordonnateur,superviseur,chef_site}
379	1	⚠️ Alerte assiduité : VOITAN Mirabelle (6ème B, J08262675) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-24 08:25:48.864241+00	{coordonnateur,superviseur,chef_site}
381	1	⚠️ Alerte assiduité : EZOUNKATON Merveille (3ème B, J08263905) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:42:09.952794+00	{coordonnateur,superviseur,chef_site}
382	1	⚠️ Alerte assiduité : ESSOU Joseph (3ème B, J09261584) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:42:09.952794+00	{coordonnateur,superviseur,chef_site}
383	1	⚠️ Alerte assiduité : AKANDJONAN Belmond (3ème C, J08265072) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:42:12.747321+00	{coordonnateur,superviseur,chef_site}
384	1	⚠️ Alerte assiduité : ADI Océane (3ème C, J10268826) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:42:12.747321+00	{coordonnateur,superviseur,chef_site}
385	1	⚠️ Alerte assiduité : TOSSOU Bernadine (3ème C, J10267811) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:42:12.747321+00	{coordonnateur,superviseur,chef_site}
386	1	⚠️ Alerte assiduité : SOGLO Jordan (3ème C, J10268435) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:42:12.747321+00	{coordonnateur,superviseur,chef_site}
387	1	⚠️ Alerte assiduité : DOSSA Immaculée (Terminale C, J08262060) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:43:46.86278+00	{coordonnateur,superviseur,chef_site}
388	1	⚠️ Alerte assiduité : HOUNTO ADA Francis (Terminale D, J08268157) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-28 15:46:36.404439+00	{coordonnateur,superviseur,chef_site}
391	1	⚠️ Alerte assiduité : BOUBAKAR Youssouf (5ème A, J10264969) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 07:35:44.499545+00	{coordonnateur,superviseur,chef_site}
392	1	⚠️ Alerte assiduité : ALLAGBE Espoir (4ème A, J09262619) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 07:43:01.981321+00	{coordonnateur,superviseur,chef_site}
393	1	⚠️ Alerte assiduité : GLO Esméralda (4ème A, J09266481) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 07:43:01.981321+00	{coordonnateur,superviseur,chef_site}
394	1	⚠️ Alerte assiduité : ALANHOUHEDO Pélagie (4ème A, J09262191) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 07:43:01.981321+00	{coordonnateur,superviseur,chef_site}
395	1	⚠️ Alerte assiduité : MONLIGUI Dorcas (4ème A, J09269399) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 07:43:01.981321+00	{coordonnateur,superviseur,chef_site}
396	1	⚠️ Alerte assiduité : METEHOUE Gracia (Première C, J10263209) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 07:56:16.560544+00	{coordonnateur,superviseur,chef_site}
397	1	⚠️ Alerte assiduité : AGOSSOU Immaculée (Première D, J08268263) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:01:16.456858+00	{coordonnateur,superviseur,chef_site}
398	1	⚠️ Alerte assiduité : KINTCHIMON Charbelle (Première D, J08265611) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:01:16.456858+00	{coordonnateur,superviseur,chef_site}
399	1	⚠️ Alerte assiduité : ALI Zeynab (Première D, J09269532) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:01:16.456858+00	{coordonnateur,superviseur,chef_site}
400	1	⚠️ Alerte assiduité : HOUETO Yanis (Première D, J10268019) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:01:16.456858+00	{coordonnateur,superviseur,chef_site}
401	1	⚠️ Alerte assiduité : SOTON Williams (5ème B, J08265047) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:10:01.74285+00	{coordonnateur,superviseur,chef_site}
402	1	⚠️ Alerte assiduité : SOUNOUVO Ezéchiel (5ème B, J08262359) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:10:01.74285+00	{coordonnateur,superviseur,chef_site}
403	1	⚠️ Alerte assiduité : HOUNMENOU Isaïe (5ème B, J10261355) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:10:01.74285+00	{coordonnateur,superviseur,chef_site}
404	1	⚠️ Alerte assiduité : HOUNGBO Kafui Belle (6ème A, J08264348) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:23:21.513617+00	{coordonnateur,superviseur,chef_site}
405	1	⚠️ Alerte assiduité : AHEHEHINNOU Princesse (6ème A, J08263823) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:23:21.513617+00	{coordonnateur,superviseur,chef_site}
406	1	⚠️ Alerte assiduité : HONFO Irène (6ème B, J08262823) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:33:08.710013+00	{coordonnateur,superviseur,chef_site}
407	2	⚠️ Alerte assiduité : BISSIRIOU Fatiath (4ème, Y10266847) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:36:15.524682+00	{coordonnateur,superviseur,chef_site}
408	1	⚠️ Alerte assiduité : HOUNGBE Ouzziel (Seconde D, J09265408) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:38:36.972927+00	{coordonnateur,superviseur,chef_site}
409	2	⚠️ Alerte assiduité : KANGNIDE Bénoit (6ème, Y08268529) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:39:12.860055+00	{coordonnateur,superviseur,chef_site}
410	2	⚠️ Alerte assiduité : ADJANOHOUN Brice (3ème, Y09263625) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:46:59.754407+00	{coordonnateur,superviseur,chef_site}
411	2	⚠️ Alerte assiduité : TIKO Océane (3ème, Y10262263) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:46:59.754407+00	{coordonnateur,superviseur,chef_site}
412	2	⚠️ Alerte assiduité : AKPA-GANGBE Junior (3ème, Y10262691) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:46:59.754407+00	{coordonnateur,superviseur,chef_site}
413	2	⚠️ Alerte assiduité : ADANHONDJI Marc (3ème, Y10267838) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:46:59.754407+00	{coordonnateur,superviseur,chef_site}
414	1	⚠️ Alerte assiduité : HOUNGBEMEY Emmanuella (4ème B, J08269518) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:49:34.234046+00	{coordonnateur,superviseur,chef_site}
415	1	⚠️ Alerte assiduité : DADIDJE Esther (4ème B, J10265240) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 08:49:34.234046+00	{coordonnateur,superviseur,chef_site}
416	1	⚠️ Alerte assiduité : DOUROSSIMI Rodiath (3ème C, J08266783) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 15:53:52.36911+00	{coordonnateur,superviseur,chef_site}
417	1	⚠️ Alerte assiduité : HOUADJETO Emilio (3ème C, J08265706) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 15:53:52.36911+00	{coordonnateur,superviseur,chef_site}
418	1	⚠️ Alerte assiduité : HOUENOU Jean Véronique (3ème C, J08268377) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 15:53:52.36911+00	{coordonnateur,superviseur,chef_site}
419	1	⚠️ Alerte assiduité : DJOSSOU Gwladys (3ème C, J09266065) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 15:53:52.36911+00	{coordonnateur,superviseur,chef_site}
420	1	⚠️ Alerte assiduité : GAYET Miracle (3ème B, J08261528) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 16:00:24.862635+00	{coordonnateur,superviseur,chef_site}
421	1	⚠️ Alerte assiduité : KOUMA Léonce (3ème B, J08266455) a cumulé 2 absences au cours du mois de Octobre.	f	2026-10-31 16:00:24.862635+00	{coordonnateur,superviseur,chef_site}
380	1	Paiement supprimé : 3 000 F (Novembre) annulé pour AHOUANDJE Alexie (J10268479) par jealexhouegbe — Motif : Erreur de saisie	t	2026-10-25 12:50:19.506812+00	{coordonnateur,comptable}
389	1	Paiement supprimé : 5 000 F (Octobre) annulé pour LOKONON Anaëlle (J09268409) par jealexhouegbe — Motif : Erreur de saisie	t	2026-10-29 11:58:59.292513+00	{coordonnateur,comptable}
390	1	Paiement supprimé : 4 000 F (Octobre) annulé pour LOKONON Danick (J08262890) par jealexhouegbe — Motif : Erreur de saisie	t	2026-10-29 12:00:48.740387+00	{coordonnateur,comptable}
422	1	Suspension automatique : LALA-AKAMBI Habib (J10262511) — défaut de paiement Octobre, 1750 F restants.	t	2026-11-01 00:03:51.331063+00	\N
423	1	Suspension automatique : ADJASSA Gracia (J10265396) — défaut de paiement Octobre, 1750 F restants.	t	2026-11-01 00:03:52.271028+00	\N
424	1	Suspension automatique : HOUESSINON Océane (J08262797) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:53.192106+00	\N
425	1	Suspension automatique : AFFO Régina (J08268546) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:53.968179+00	\N
426	1	Suspension automatique : AHOTON Aristide (J08268267) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:54.706273+00	\N
427	1	Suspension automatique : ALI KPONOU Barnabé (J08267548) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:55.460873+00	\N
428	1	Suspension automatique : AMOUSSOU Angéline Tété (J08263106) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:56.385519+00	\N
429	1	Suspension automatique : BONOU Andréa (J08264473) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:57.132585+00	\N
430	1	Suspension automatique : DANNOUDO Belvine (J08268911) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:57.872459+00	\N
431	1	Suspension automatique : DEGBO Abel (J08261500) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:58.394781+00	\N
432	1	Suspension automatique : DJOHA Fridaouce (J08264569) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:59.133053+00	\N
433	1	Suspension automatique : HASSANE Abdoul Razack (J08264212) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:03:59.857995+00	\N
434	1	Suspension automatique : HOUNGBO Kafui Belle (J08264348) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:00.387407+00	\N
435	1	Suspension automatique : KOUKPAKI Habiguel (J08269137) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:00.7559+00	\N
436	1	Suspension automatique : KPLAKOTCHA Bignon Pascaline (J08267246) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:01.280579+00	\N
437	1	Suspension automatique : ZANNOU Charles (J08265784) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:02.024071+00	\N
438	1	Suspension automatique : AGOSSOU Diane Christiane (J08268517) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:02.97223+00	\N
439	1	Suspension automatique : AHEHEHINNOU Princesse (J08263823) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:03.935951+00	\N
440	1	Suspension automatique : ALLOSSE Merveil (J08267893) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:04.681991+00	\N
441	1	Suspension automatique : DENAKPO Samuel (J08268114) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:05.428587+00	\N
442	1	Suspension automatique : HOUNDO Urbain (J08269872) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:04:05.768213+00	\N
443	1	Suspension automatique : HOUNGA Romuald (J08262719) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:06.32902+00	\N
444	1	Suspension automatique : HOUNNOU Rachelle Fèmi (J08264253) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:07.05734+00	\N
445	1	Suspension automatique : HONFOGA Juliette (J08269764) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:07.784717+00	\N
446	1	Suspension automatique : SIMENOU M. Jérôme (J08269042) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:08.124021+00	\N
447	2	Suspension automatique : BISSIRIOU Fatiath (Y10266847) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:08.682406+00	\N
448	1	Suspension automatique : TCHEWENOU Arsène (J08264180) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:09.08941+00	\N
449	1	Suspension automatique : ASSOCLE Gaëlle (J10267278) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:04:09.619568+00	\N
450	1	Suspension automatique : ARIORI Parfaite (J10268229) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:04:10.354075+00	\N
451	1	Suspension automatique : TCHIBOZO Nadia (J10263340) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:04:10.722913+00	\N
452	1	Suspension automatique : HOUNGBO Delphin (J08264552) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:11.280746+00	\N
453	1	Suspension automatique : ADOUNVO Jennifer (J08269363) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:11.619538+00	\N
454	1	Suspension automatique : AGBODJINOU Mariale (J08263763) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:12.180769+00	\N
455	1	Suspension automatique : AGOSSOU Emmanuella Théodora (J08268080) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:12.713121+00	\N
456	1	Suspension automatique : AMADOU Yasmine (J08267273) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:13.482595+00	\N
457	1	Suspension automatique : FANOU Daniel (J08264655) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:14.031732+00	\N
458	1	Suspension automatique : KONGNON Délia (J08264575) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:14.37242+00	\N
459	1	Suspension automatique : NOUHOU Abdoul Malick (J08269085) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:14.716959+00	\N
460	1	Suspension automatique : OSSE Rodiath (J08265347) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:15.250596+00	\N
461	1	Suspension automatique : TCHOUTCHOU Julien (J08265266) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:15.789687+00	\N
462	1	Suspension automatique : VODOUNON Abigael (J08268635) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:16.332744+00	\N
463	1	Suspension automatique : HONFO Irène (J08262823) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:16.677661+00	\N
464	1	Suspension automatique : VOITAN Mirabelle (J08262675) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:17.017039+00	\N
465	1	Suspension automatique : OLAGUNJU Mariame (J10265237) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:04:17.377277+00	\N
466	1	Suspension automatique : AGOSSOU Victorine (J08265785) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:18.107647+00	\N
467	1	Suspension automatique : GNANMLIN Miracle (J08261302) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:18.664697+00	\N
468	1	Suspension automatique : KOULIHO Esther (J08269254) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:18.999565+00	\N
469	1	Suspension automatique : YEDIYETON Bénoit (J08267645) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:19.343352+00	\N
470	1	Suspension automatique : AGOSSOU Lorice (J08262276) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:19.690235+00	\N
471	1	Suspension automatique : ADOUVO Gertrude (J10269732) — défaut de paiement Octobre, 750 F restants.	t	2026-11-01 00:04:20.059315+00	\N
472	1	Suspension automatique : DOSSA Ifè Edwige M. (J08268276) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:04:20.393858+00	\N
473	1	Suspension automatique : HOUETCHOU Boris (J08265768) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:20.948044+00	\N
474	1	Suspension automatique : AKITOBY Sergine (J10262824) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:21.287646+00	\N
475	1	Suspension automatique : MIGNONTODE Flora (J08267340) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:21.638097+00	\N
476	1	Suspension automatique : YESSOUFOU Ambidath (J08262689) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:21.985972+00	\N
477	1	Suspension automatique : KOUTON Dorcas Mahugnon (J08268081) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:04:22.34531+00	\N
478	1	Suspension automatique : AGOSSOU Victoria (J08263499) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:22.683746+00	\N
479	1	Suspension automatique : ARIORI Sagesse (J08264964) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:23.032011+00	\N
480	1	Suspension automatique : IBRAHIM Mohamed (J08263025) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:23.372828+00	\N
481	1	Suspension automatique : GLELE David Junior (J08261310) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:23.960446+00	\N
482	1	Suspension automatique : DJIGBE Bernadin (J08265241) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:24.308254+00	\N
483	1	Suspension automatique : DA SILVA Peace Joy (J08266547) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:24.661492+00	\N
484	1	Suspension automatique : AGBO ZINSOU Anick (J08264547) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:25.233704+00	\N
485	1	Suspension automatique : YESSOUFOU Himayath (J08267962) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:25.567878+00	\N
486	1	Suspension automatique : SOUNOUVO Ezéchiel (J08262359) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:25.924874+00	\N
487	1	Suspension automatique : MEGOTIN Inecia Gloria (J08265895) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:26.290381+00	\N
488	1	Suspension automatique : AHOUHENOU Trésor (J08263082) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:26.626124+00	\N
489	1	Suspension automatique : YEVO EDO Bénédicte (J08269533) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:27.177663+00	\N
490	1	Suspension automatique : AHISSOU Exaucé (J08269605) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:27.541419+00	\N
491	1	Suspension automatique : SOUNOUVO Exaucé Nadège (J08265037) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:27.919967+00	\N
492	1	Suspension automatique : DANSI-GAH Sèdjro Assuerus (J08269052) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:28.466665+00	\N
493	1	Suspension automatique : KPIKPONSOUHOU Chérif (J08267855) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:28.805718+00	\N
494	1	Suspension automatique : AGUE Dolorès (J08268059) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:29.143136+00	\N
495	1	Suspension automatique : BAHOUNON Zéphaniah (J08262629) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:29.487292+00	\N
496	1	Suspension automatique : GORY-SYLLA Amadou (J10262267) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:04:29.839251+00	\N
497	1	Suspension automatique : AKPLAGBE Surprise (J08265274) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:30.208362+00	\N
498	1	Suspension automatique : GNONLONFOUN Amour (J08267347) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:30.555018+00	\N
499	1	Suspension automatique : KODJO Merveille (J08263201) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:31.086199+00	\N
500	1	Suspension automatique : AFO Fabienne (J08263921) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:31.423397+00	\N
501	1	Suspension automatique : HOUNSOU Adéline (J10264256) — défaut de paiement Octobre, 250 F restants.	t	2026-11-01 00:04:31.774558+00	\N
502	1	Suspension automatique : NOUDAMESSI Esther (J08262068) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:32.115443+00	\N
503	1	Suspension automatique : SEDJAME Fifamè (J08267091) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:04:32.469274+00	\N
504	1	Suspension automatique : ADJINAKOU Dénise (J08262750) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:32.807579+00	\N
505	1	Suspension automatique : AGOGNON Ericaelle (J08265741) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:04:33.164023+00	\N
506	1	Suspension automatique : AHLONSOU Gloria (J08267659) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:04:33.496823+00	\N
507	1	Suspension automatique : FRANCISCO Géovani Bignon (J08261299) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:33.850847+00	\N
508	1	Suspension automatique : HOUENOU Lorindo (J08262991) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:04:34.187099+00	\N
509	1	Suspension automatique : SAGBO Madoché (J08264739) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:34.53354+00	\N
510	1	Suspension automatique : AGOSSOU Damienne (J08267841) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:35.100512+00	\N
511	1	Suspension automatique : AHISSOU Marcolino (J08264502) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:35.449413+00	\N
512	1	Suspension automatique : CHEMITAN Widad (J08266858) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:36.048679+00	\N
513	1	Suspension automatique : GNONLONFOUN Emmanuella (J08266360) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:36.408951+00	\N
514	1	Suspension automatique : GOUSSANOU Fanelle (J08265474) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:36.940553+00	\N
515	1	Suspension automatique : YESSOUFOU Ihssane (J08266763) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:37.277057+00	\N
516	1	Suspension automatique : ATEKPO Modérand (J08265442) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:37.615671+00	\N
517	1	Suspension automatique : GANKOU Nelda (J08262658) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:37.988638+00	\N
518	1	Suspension automatique : ZANNOU Géraldo (J08266134) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:04:38.329523+00	\N
519	1	Suspension automatique : AHOKPE Odile (J08267451) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:04:38.672611+00	\N
520	1	Suspension automatique : YESSOUFOU Karimath (J08264426) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:04:39.230417+00	\N
521	1	Suspension automatique : ABENI Edith (J08263933) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:39.585197+00	\N
522	1	Suspension automatique : MEDJOGBE Léonie (J10263379) — défaut de paiement Octobre, 250 F restants.	t	2026-11-01 00:04:39.9555+00	\N
523	1	Suspension automatique : ADANNOU Sheerine (J08267295) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:40.319425+00	\N
524	1	Suspension automatique : AHOGBO Mariette (J08269195) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:40.656745+00	\N
525	1	Suspension automatique : AKINOCHO Joseph (J08263176) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:41.003918+00	\N
526	1	Suspension automatique : AMOUSSOU Floriane (J08269135) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:41.359209+00	\N
527	1	Suspension automatique : GAYET Miracle (J08261528) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:41.712126+00	\N
528	1	Suspension automatique : ZANNOU Ghislain (J08268467) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:04:42.055763+00	\N
529	1	Suspension automatique : AGOSSOU Ange (J08262113) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:42.403056+00	\N
530	1	Suspension automatique : AGOSSOU Eunice (J08263684) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:42.773828+00	\N
531	1	Suspension automatique : AHLONSOU Francois (J08261595) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:43.116842+00	\N
532	1	Suspension automatique : MEDJOGBE Anita (J10268623) — défaut de paiement Octobre, 250 F restants.	t	2026-11-01 00:04:43.454176+00	\N
533	1	Suspension automatique : AKANDJONAN Belmond (J08265072) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:43.83805+00	\N
534	1	Suspension automatique : AKOUETE Eugénio (J08266577) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:44.176146+00	\N
535	1	Suspension automatique : AMOUSSOU Fanette (J08267662) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:44.549531+00	\N
536	1	Suspension automatique : AMOUSSOU Nicolette (J08266028) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:44.888106+00	\N
537	1	Suspension automatique : CHANGOTADE Landry (J08264946) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:45.243183+00	\N
538	1	Suspension automatique : HONFO AICHATH Aichath (J08266089) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:45.790162+00	\N
539	1	Suspension automatique : HOUENOU Jean Véronique (J08268377) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:46.153017+00	\N
540	1	Suspension automatique : TOSSOU Conforte (J08263375) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:46.697098+00	\N
541	1	Suspension automatique : ADELEYE Fulbert (J08264316) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:47.215424+00	\N
542	1	Suspension automatique : DOVI Edwige (J08266270) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:47.562183+00	\N
543	1	Suspension automatique : FASSINOU Odette (J08264476) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:47.914342+00	\N
544	1	Suspension automatique : KANA Emmanuella (J08266085) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:04:48.339707+00	\N
545	1	Suspension automatique : ADJASSOHO Conceptine (J08262094) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:48.700597+00	\N
546	1	Suspension automatique : AGOSSOU Immaculée (J08268263) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:49.088059+00	\N
547	1	Suspension automatique : AHOGBO Dieu donné (J08266158) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:49.4458+00	\N
548	1	Suspension automatique : DOVONON Samuel (J08268703) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:49.797804+00	\N
549	1	Suspension automatique : EZOUNKATON Merveille (J08263905) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:04:50.149572+00	\N
550	1	Suspension automatique : GNONLONFOUN Rose Kèmi (J08269687) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:50.509219+00	\N
551	1	Suspension automatique : KINTCHIMON Charbelle (J08265611) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:50.865064+00	\N
552	1	Suspension automatique : HOUNGBEME Jean-Claude (J10268789) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:04:51.207054+00	\N
553	1	Suspension automatique : HOLOEYI Félicien (J08263238) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:51.5559+00	\N
554	1	Suspension automatique : OGOULOLA Léa (J08264009) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:04:51.90859+00	\N
555	1	Suspension automatique : SEDJAME Néhémie (J08269335) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:52.260995+00	\N
556	1	Suspension automatique : AGOSSOU Nicodème (J08265110) — défaut de paiement Octobre, 8000 F restants.	t	2026-11-01 00:04:52.612044+00	\N
557	1	Suspension automatique : AVANDE Mauriace (J08262331) — défaut de paiement Octobre, 8000 F restants.	t	2026-11-01 00:04:52.962619+00	\N
558	1	Suspension automatique : ATEKPO Néoland (J08265608) — défaut de paiement Octobre, 8000 F restants.	t	2026-11-01 00:04:53.320364+00	\N
559	1	Suspension automatique : D'ALMEIDA Merveille Ifè (J08268464) — défaut de paiement Octobre, 8000 F restants.	t	2026-11-01 00:04:53.679617+00	\N
560	1	Suspension automatique : HOUNTO ADA Francis (J08268157) — défaut de paiement Octobre, 8000 F restants.	t	2026-11-01 00:04:54.02739+00	\N
561	1	Suspension automatique : MARCOS Mariano (J08266137) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:04:54.389585+00	\N
562	1	Suspension automatique : ZANNOU Foeube (J08263060) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:54.736353+00	\N
563	1	Suspension automatique : ZANNOU Julien (J08263934) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:55.196778+00	\N
564	2	Suspension automatique : HOUNGBO Mardoché (Y08265256) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:04:55.542174+00	\N
565	2	Suspension automatique : ADAMON Assande (Y08264402) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:55.896951+00	\N
566	2	Suspension automatique : AHLONSOU Synthiche (Y08268677) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:56.242122+00	\N
567	2	Suspension automatique : AKOGOUN Zékiath (Y08267993) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:56.608857+00	\N
568	2	Suspension automatique : GNAMBODE Bénédicte (Y08264249) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:56.94003+00	\N
569	2	Suspension automatique : HOUNDETON Silvia (Y08269420) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:57.301253+00	\N
570	2	Suspension automatique : KOUKOUI Mariette (Y08264713) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:57.642843+00	\N
571	2	Suspension automatique : LOKO Carolle (Y08268871) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:04:57.985132+00	\N
572	2	Suspension automatique : OGOUTCHI Oré Oluwa Merveille (Y08262014) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:58.334935+00	\N
573	2	Suspension automatique : SOSSOU Ruth (Y08262955) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:58.698498+00	\N
574	1	Suspension automatique : AVODAGBE Emmanuella (J10261984) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:04:59.02684+00	\N
575	2	Suspension automatique : TOLOFON Eben Ezer (Y08263533) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:04:59.395831+00	\N
576	2	Suspension automatique : ADJAGNISSOUDE Jérémie (Y08261739) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:04:59.742443+00	\N
577	2	Suspension automatique : AKON Junior (Y08261253) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:00.120723+00	\N
578	2	Suspension automatique : HESSANON Marie Noel (Y08264481) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:00.496251+00	\N
579	2	Suspension automatique : HOUNMENOU Odile (Y08265469) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:00.860175+00	\N
580	2	Suspension automatique : SETON Innocent (Y08263046) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:01.232032+00	\N
581	1	Suspension automatique : CODJIA Joinès (J08265649) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:01.600665+00	\N
582	1	Suspension automatique : VITCHOEDO Clémence (J08268280) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:01.952746+00	\N
583	1	Suspension automatique : OLAITAN Chefiou (J08268256) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:02.313497+00	\N
584	1	Suspension automatique : HOUNTONDJI Gaspard (J08265135) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:02.706862+00	\N
585	1	Suspension automatique : METOZOUNVE Bernadin (J10268410) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:05:03.089722+00	\N
586	1	Suspension automatique : ADJASSOHO Bernard (J08265739) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:03.452455+00	\N
587	1	Suspension automatique : OLAITAN Kêphil (J08267578) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:03.816733+00	\N
588	1	Suspension automatique : AFFO Roukayath (J08265891) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:04.164117+00	\N
589	1	Suspension automatique : AKPOTINKPE Jacqueline (J08267751) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:04.532047+00	\N
590	1	Suspension automatique : OLAITAN Rafiath (J08268681) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:04.917755+00	\N
591	1	Suspension automatique : MAIGA Fadie (J08264199) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:05.278074+00	\N
592	1	Suspension automatique : FAGBITE Pascal (J10267394) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:05:05.631566+00	\N
593	1	Suspension automatique : ADAHE Gisèle (J09265900) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:05.987691+00	\N
594	1	Suspension automatique : KANVI Edwige (J10262301) — défaut de paiement Octobre, 1250 F restants.	t	2026-11-01 00:05:06.335952+00	\N
595	1	Suspension automatique : ALLAGBE Josué Boris (J09263199) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:06.688284+00	\N
596	1	Suspension automatique : DJOSSOU Assanath (J09265772) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:05:07.040026+00	\N
597	1	Suspension automatique : LOKONON Anaëlle (J09268409) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:07.38977+00	\N
598	1	Suspension automatique : ESSOU Valentine (J09267751) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:07.746604+00	\N
599	1	Suspension automatique : HOUNGA Abigaelle (J09262629) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:08.112105+00	\N
600	1	Suspension automatique : HOUNTONDJI Faoziath Aminath (J09268322) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:08.471776+00	\N
601	1	Suspension automatique : HOUNTONDJI Affissou (J09269107) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:08.829728+00	\N
602	1	Suspension automatique : ADDY Prince (J09265561) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:09.176055+00	\N
603	1	Suspension automatique : WIGNANON Phanuel (J09268851) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:09.535578+00	\N
604	1	Suspension automatique : YABI Chérifath (J09266244) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:09.876391+00	\N
605	1	Suspension automatique : FADELE Prince (J09262749) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:10.242932+00	\N
606	1	Suspension automatique : DEGBOGBAHOUN Samuel (J09263905) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:10.602635+00	\N
607	1	Suspension automatique : AGUIDA Raphaëlla (J09262320) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:10.971162+00	\N
608	1	Suspension automatique : ADEGBINDIN Sodic (J09265217) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:11.335133+00	\N
609	1	Suspension automatique : TOLEFO Marie Félicité (J09263774) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:11.68573+00	\N
610	1	Suspension automatique : KPEHOUNTON Auguste (J09268232) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:12.036384+00	\N
611	1	Suspension automatique : HOLO Doris (J09269442) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:12.642747+00	\N
612	1	Suspension automatique : BOUKARI Bakiath (J09267044) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:05:12.984679+00	\N
613	1	Suspension automatique : SEKPONNA Noëlie (J09268180) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:13.347605+00	\N
614	1	Suspension automatique : DEGUENONVO Estelle (J09267263) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:13.683899+00	\N
615	1	Suspension automatique : ALLAGBE Espoir (J09262619) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:14.02919+00	\N
616	1	Suspension automatique : ADELOU Michel Alix (J09265173) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:14.581756+00	\N
617	2	Suspension automatique : ADJANOHOUN Brice (Y09263625) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:15.138073+00	\N
618	2	Suspension automatique : ATINDEYETIN David (Y09264387) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:15.892928+00	\N
619	1	Suspension automatique : KOUNOUHO Florentin (J09267347) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:16.450483+00	\N
620	1	Suspension automatique : ESSOU Joseph (J09261584) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:16.803815+00	\N
621	1	Suspension automatique : METOZOUNVE Fati (J09263043) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:17.172549+00	\N
622	1	Suspension automatique : OGOUBIYI Nanyimanth (J09263770) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:17.518533+00	\N
623	1	Suspension automatique : DANSI-GAH Godwin (J09266868) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:17.880686+00	\N
624	1	Suspension automatique : AHISSOU Jean Eudes (J09264941) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:18.442349+00	\N
625	1	Suspension automatique : BAOLA Faosath (J09268472) — défaut de paiement Octobre, 8000 F restants.	t	2026-11-01 00:05:18.806377+00	\N
626	1	Suspension automatique : GANNEYEDO Merveille (J09262370) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:19.15203+00	\N
627	1	Suspension automatique : DAASSI Armandine (J09262693) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:19.718588+00	\N
628	1	Suspension automatique : TCHEHOUNDJE Rolande (J09266458) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:20.059561+00	\N
629	1	Suspension automatique : KOUDJANNAGNI Lydie (J09266457) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:20.418554+00	\N
630	1	Suspension automatique : SEKPONNA Merveille (J09267221) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:20.760418+00	\N
631	2	Suspension automatique : OGOUHOLA Expédit (Y09263504) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:21.118723+00	\N
632	1	Suspension automatique : ADANNOU Lucienne (J09266223) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:21.502789+00	\N
633	2	Suspension automatique : BOGNON Emmanuel (Y09262152) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:22.084868+00	\N
634	2	Suspension automatique : OGOUDJOBI Aurelie (Y09263913) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:22.429305+00	\N
635	2	Suspension automatique : MAMA Imourane (Y09267411) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:22.792355+00	\N
636	1	Suspension automatique : ALAO Faoziath (J09268895) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:23.141398+00	\N
637	1	Suspension automatique : MASSESSI Mathilde (J09268975) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:23.491418+00	\N
638	1	Suspension automatique : GLO Esméralda (J09266481) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:24.028072+00	\N
639	1	Suspension automatique : ALANHOUHEDO Pélagie (J09262191) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:24.40446+00	\N
640	1	Suspension automatique : ADJASSOHO Ossénath (J09269689) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:24.869074+00	\N
641	1	Suspension automatique : DJOGBE Sègla Anicette (J09268778) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:25.210697+00	\N
642	1	Suspension automatique : DAASSI Freud (J09264452) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:25.547442+00	\N
643	1	Suspension automatique : HAMIDU Haruna (J09265092) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:25.892549+00	\N
644	1	Suspension automatique : DEDO Divine (J09265272) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:26.247261+00	\N
645	1	Suspension automatique : TODJINOU Océane (J09264607) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:26.593615+00	\N
646	1	Suspension automatique : DOSSEH Vicentia (J09268331) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:26.937687+00	\N
647	1	Suspension automatique : WIKON Mariam (J09266004) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:27.320227+00	\N
648	1	Suspension automatique : HOUESSOU Salomé (J09262141) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:27.671342+00	\N
649	1	Suspension automatique : MEDJOGBE Fifamè (J09265584) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:28.023394+00	\N
650	1	Suspension automatique : AKELE Christian (J09261983) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:28.393962+00	\N
651	1	Suspension automatique : HOUETO Yasmine (J09261744) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:28.749225+00	\N
652	1	Suspension automatique : MONLIGUI Dorcas (J09269399) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:29.108259+00	\N
653	1	Suspension automatique : AZANKPO Elisée (J09267041) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:29.477201+00	\N
654	1	Suspension automatique : KPOVIESSI Victorine (J09262488) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:29.823616+00	\N
655	1	Suspension automatique : MEDJOGBE Exaucée (J09266260) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:30.166452+00	\N
656	1	Suspension automatique : KPETOTON Saturnin (J09268731) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:30.525554+00	\N
657	1	Suspension automatique : LOUMINGOU Grâce (J09266924) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:30.873432+00	\N
658	1	Suspension automatique : TOGNIFODE Vlad (J09264136) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:31.215704+00	\N
659	1	Suspension automatique : SETOME Basilia (J09266463) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:31.570123+00	\N
660	1	Suspension automatique : TCHINAN Sévérine (J09269783) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:31.922704+00	\N
661	1	Suspension automatique : HOUNMENOU Aurel (J09265505) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:32.276565+00	\N
662	1	Suspension automatique : AKELE Jean-Baptiste (J09262714) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:32.616653+00	\N
663	1	Suspension automatique : KPADONOU Miracle (J10263181) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:33.177375+00	\N
664	1	Suspension automatique : KOUEVI Mélissa (J10268288) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:33.532381+00	\N
665	1	Suspension automatique : METOZOUNVE Eunice (J10266226) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:33.875328+00	\N
666	1	Suspension automatique : TOSSOU Bernadine (J10267811) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:34.227375+00	\N
667	1	Suspension automatique : ADI Océane (J10268826) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:34.595378+00	\N
668	1	Suspension automatique : HOUNKANRIN Estelle (J10266781) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:35.008247+00	\N
669	1	Suspension automatique : GBENONMEDJI Dorcas (J10266544) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:35.344309+00	\N
670	2	Suspension automatique : TAIROU Mohamed Fridaous (Y10265475) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:35.673138+00	\N
671	2	Suspension automatique : BOLO Naomie (Y10263424) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:36.012115+00	\N
672	2	Suspension automatique : FADEYI Donaldine (Y10268452) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:36.356022+00	\N
673	1	Suspension automatique : SAGBO Esther (J09262968) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:36.70351+00	\N
674	2	Suspension automatique : HOUANGNI Fériol (Y10264683) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:37.05332+00	\N
675	2	Suspension automatique : HOUNSA Othniel (Y10266361) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:37.405247+00	\N
676	2	Suspension automatique : SAIZONOU Lumen (Y10264760) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:37.739474+00	\N
677	2	Suspension automatique : DJIMA Raoudath (Y10266598) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:38.092617+00	\N
678	2	Suspension automatique : HINTEGNI Georjinio (Y10262246) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:38.447206+00	\N
679	2	Suspension automatique : OKPEICHA Wadoud (Y10265483) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:38.787726+00	\N
680	2	Suspension automatique : ODOUNHARO Antoine (Y10261711) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:39.143595+00	\N
681	2	Suspension automatique : ABOUBAKAR Youssouf (Y10266810) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:39.525622+00	\N
682	2	Suspension automatique : OLOUKPEDE Charbel (Y10264902) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:39.857825+00	\N
683	2	Suspension automatique : TIKO Océane (Y10262263) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:40.208704+00	\N
684	1	Suspension automatique : ASSOGBA Ariel (J10268851) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:05:40.555657+00	\N
685	1	Suspension automatique : ADJIWANOU Emmanuella (J10267800) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:05:40.896422+00	\N
686	1	Suspension automatique : SOGLO Jordan (J10268435) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:41.232467+00	\N
687	1	Suspension automatique : AGBOOLA Saobane (J10263085) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:41.587331+00	\N
688	1	Suspension automatique : KPADONOU Jacques (J10266199) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:41.957756+00	\N
689	1	Suspension automatique : ASSOGBA Christelle (J10261340) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:42.330137+00	\N
690	1	Suspension automatique : DEDJILA Marigine (J10264408) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:42.668761+00	\N
691	1	Suspension automatique : HOUETO Yanis (J10268019) — défaut de paiement Octobre, 3000 F restants.	t	2026-11-01 00:05:43.006203+00	\N
692	1	Suspension automatique : DEGBO Aubin (J10265203) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:43.352324+00	\N
693	1	Suspension automatique : KOUASSI Shalom (J10263248) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:43.704099+00	\N
694	1	Suspension automatique : AHOUANVOEGBLA Aurore (J10261938) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:44.032205+00	\N
695	1	Suspension automatique : NEVICE Prunelle (J10265210) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:44.380399+00	\N
696	1	Suspension automatique : N'SOYENOU Abigaëlle (J10261977) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:44.716645+00	\N
697	1	Suspension automatique : BOTON FATCHE Honoré (J10268944) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:45.061111+00	\N
698	1	Suspension automatique : ADANZOUNNON Irène (J10262787) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:45.412482+00	\N
699	1	Suspension automatique : ATORO Failylath (J10266527) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:45.745571+00	\N
700	1	Suspension automatique : WIGNANON Jéssica (J09268877) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:46.071718+00	\N
701	1	Suspension automatique : LOKO Etienne (J10261305) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:46.424809+00	\N
702	1	Suspension automatique : KPATINVO Jean Marc (J10267429) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:46.766747+00	\N
703	1	Suspension automatique : OKATTA Esta (J10267059) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:47.10794+00	\N
704	1	Suspension automatique : HOUNKPE Romaric (J10262020) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:47.482575+00	\N
705	1	Suspension automatique : DJEKETE Arafath (J10267511) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:47.823321+00	\N
706	1	Suspension automatique : HOUNMENOU Isaïe (J10261355) — défaut de paiement Octobre, 500 F restants.	t	2026-11-01 00:05:48.180692+00	\N
707	1	Suspension automatique : SENOU Ella (J10265661) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:48.532368+00	\N
708	1	Suspension automatique : DADIDJE Esther (J10265240) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:49.079368+00	\N
709	1	Suspension automatique : LOKO Centhia (J10262938) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:49.420833+00	\N
710	1	Suspension automatique : TANKPINOU Exaucé (J10263720) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:49.75311+00	\N
711	1	Suspension automatique : KOGODE Charbel (J10263021) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:50.086209+00	\N
712	1	Suspension automatique : KOSSOUKINI Anne Marie (J10264799) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:50.431048+00	\N
713	1	Suspension automatique : GANKOU Perrine (J10267705) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:50.7972+00	\N
714	1	Suspension automatique : ADJASSOHO Osseni (J10269553) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:51.133803+00	\N
715	1	Suspension automatique : ADJOVI Fleurette (J10261252) — défaut de paiement Octobre, 5000 F restants.	t	2026-11-01 00:05:51.473347+00	\N
716	1	Suspension automatique : METEHOUE Gracia (J10263209) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:05:51.824007+00	\N
717	1	Suspension automatique : SEZONDJI-SOTIN Nelly (J10266071) — défaut de paiement Octobre, 6000 F restants.	t	2026-11-01 00:05:52.171215+00	\N
718	1	Suspension automatique : GBEKPO Anselme (J10269600) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:52.514364+00	\N
719	1	Suspension automatique : ALLOSSE Marie-Polycarpe (J10265391) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:52.852775+00	\N
720	2	Suspension automatique : KANGNIDE Firmine (Y10267392) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:53.201373+00	\N
721	2	Suspension automatique : KANGNIDE Bénoit (Y08268529) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:53.546935+00	\N
722	2	Suspension automatique : AGBANRIN Ebenezer (Y10266663) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:53.893866+00	\N
723	2	Suspension automatique : AMADOU Sahidatou (Y10266284) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:54.236192+00	\N
724	2	Suspension automatique : SAVI Malick (Y10267418) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:54.598764+00	\N
725	2	Suspension automatique : AYENA Immaculée (Y10261874) — défaut de paiement Octobre, 1500 F restants.	t	2026-11-01 00:05:54.932267+00	\N
726	2	Suspension automatique : DJIDONOU Josias (Y10264752) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:55.272613+00	\N
727	2	Suspension automatique : LIADI Kismath (Y10262022) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:55.641461+00	\N
728	2	Suspension automatique : GNANIH Christelle (Y10266603) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:55.976872+00	\N
729	2	Suspension automatique : HOUNWANOU Osnelle (Y10267679) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:56.321481+00	\N
730	2	Suspension automatique : OUMAROU Mouna (Y10264471) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:56.660905+00	\N
731	2	Suspension automatique : ADOYATON Rubène (Y10264716) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:57.007144+00	\N
732	2	Suspension automatique : CHAGANOU Esther (Y10268172) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:05:57.34524+00	\N
733	2	Suspension automatique : KOUDOGBO Prophétie (Y10263750) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:57.687694+00	\N
734	2	Suspension automatique : EDOKPA Sarah (Y10267800) — défaut de paiement Octobre, 1000 F restants.	t	2026-11-01 00:05:58.023477+00	\N
735	2	Suspension automatique : AKPA-GANGBE Junior (Y10262691) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:58.368147+00	\N
736	2	Suspension automatique : LOKO Jérémie (Y10268466) — défaut de paiement Octobre, 4000 F restants.	t	2026-11-01 00:05:58.707221+00	\N
737	1	Suspension automatique : NOUATIN Pascal (J10267793) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:59.051859+00	\N
738	1	Suspension automatique : NOUATIN Nestor (J10268192) — défaut de paiement Octobre, 3500 F restants.	t	2026-11-01 00:05:59.379129+00	\N
739	1	Suspension automatique : N'SOYENOU Jean de Dieu (J10268351) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:05:59.718015+00	\N
740	1	Suspension automatique : ZOUNDJI Inès (J10264209) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:06:00.064265+00	\N
741	1	Suspension automatique : KPADONOU Prudence (J10262006) — défaut de paiement Octobre, 2000 F restants.	t	2026-11-01 00:06:00.415406+00	\N
742	1	Suspension automatique : HAMONDJI Samson (J10267888) — défaut de paiement Octobre, 1750 F restants.	t	2026-11-01 00:06:00.757596+00	\N
743	1	Suspension automatique : KEITA Fanta (J10264241) — défaut de paiement Octobre, 250 F restants.	t	2026-11-01 00:06:01.114646+00	\N
744	1	Suspension automatique : KABADE Géraude (J10263892) — défaut de paiement Octobre, 2500 F restants.	t	2026-11-01 00:06:01.459743+00	\N
745	1	Suspension automatique : TOGNIMASSOU Divine (J10262532) — défaut de paiement Octobre, 1750 F restants.	t	2026-11-01 00:06:01.813866+00	\N
\.


--
-- Data for Name: paiements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements (id, eleve_id, mois_souscription, montant_paye, date_paiement, mode_paiement, annee_scolaire_id, enregistre_par) FROM stdin;
1	871	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
2	870	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
3	872	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
4	855	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
5	855	Novembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
6	855	Decembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
7	855	Janvier	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
8	855	Fevrier	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
9	855	Mars	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
10	878	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
11	878	Novembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
12	878	Decembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
13	737	Octobre	6000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
14	737	Novembre	6000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
15	737	Decembre	6000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
16	51	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
17	51	Novembre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
18	51	Decembre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
19	558	Octobre	1000	2026-09-22	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
20	222	Octobre	2000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
21	71	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
22	884	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
23	189	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
24	318	Octobre	3500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
25	914	Octobre	1000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
26	915	Octobre	1000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
27	582	Octobre	2000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
28	606	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
29	946	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
30	419	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
31	419	Novembre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
32	419	Decembre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
33	385	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
34	528	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
35	750	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
36	423	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
38	332	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
39	888	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
40	896	Octobre	1000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
41	486	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
42	275	Octobre	2000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
43	897	Octobre	1500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
44	72	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
45	72	Novembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
46	72	Decembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
47	72	Janvier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
48	72	Fevrier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
49	72	Mars	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
50	215	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
51	215	Novembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
52	215	Decembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
53	215	Janvier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
54	215	Fevrier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
55	215	Mars	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
56	11	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
57	11	Novembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
58	11	Decembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
59	902	Octobre	3500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
60	902	Novembre	3500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
61	902	Decembre	3500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
62	912	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
63	893	Octobre	1500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
64	37	Octobre	2000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
65	221	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
66	621	Octobre	3000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
67	621	Novembre	3000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
68	621	Decembre	3000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
69	936	Octobre	2000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
70	936	Novembre	2000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
71	936	Decembre	2000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
73	563	Octobre	2000	2026-09-25	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
74	628	Octobre	3000	2026-09-26	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
75	977	Octobre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
76	977	Novembre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
77	977	Decembre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
78	977	Janvier	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
79	977	Fevrier	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
80	977	Mars	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
81	1050	Octobre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
82	328	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
86	896	Octobre	500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
87	1012	Octobre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
88	1025	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
89	19	Octobre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
90	202	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
91	1049	Octobre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
92	1049	Novembre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
93	1049	Decembre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
94	972	Octobre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
95	972	Novembre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
96	972	Decembre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
97	1047	Octobre	4000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
98	895	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
99	915	Octobre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
100	843	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
101	843	Novembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
102	843	Decembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
103	550	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
104	550	Novembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
105	550	Decembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
106	530	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
107	530	Novembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
108	530	Decembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
109	588	Octobre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
110	588	Novembre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
111	588	Decembre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
112	943	Octobre	4000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
113	999	Octobre	1000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
114	418	Octobre	5000	2026-09-28	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
115	243	Janvier	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
116	243	Fevrier	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
117	243	Mars	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
118	244	Octobre	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
119	244	Novembre	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
120	244	Decembre	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
121	848	Octobre	5000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
122	848	Novembre	5000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
123	848	Decembre	5000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
124	53	Octobre	2500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
125	53	Novembre	2500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
126	53	Decembre	2500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
127	961	Octobre	6000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
128	961	Novembre	6000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
129	961	Decembre	6000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
130	558	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
131	295	Octobre	3500	2026-10-01	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
132	847	Octobre	5000	2026-10-01	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
133	841	Octobre	2500	2026-10-01	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
134	177	Octobre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
135	177	Novembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
136	177	Decembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
137	959	Octobre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
138	959	Novembre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
139	959	Decembre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
140	459	Octobre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
141	459	Novembre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
142	459	Decembre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
143	951	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
144	1134	Octobre	3000	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
145	1065	Octobre	3000	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
146	251	Octobre	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
147	251	Novembre	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
148	251	Decembre	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
149	251	Janvier	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
150	251	Fevrier	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
151	251	Mars	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
152	156	Octobre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
153	156	Novembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
154	156	Decembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
155	156	Fevrier	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
156	156	Mars	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
157	156	Avril	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
158	938	Octobre	3000	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
159	643	Octobre	4000	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
160	886	Octobre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
161	379	Octobre	5000	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
162	1088	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
163	623	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
164	623	Novembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
165	623	Decembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
166	623	Janvier	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
167	623	Fevrier	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
168	623	Mars	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
169	654	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
170	941	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
171	1086	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
172	1100	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
173	1083	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
174	1082	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
175	607	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
176	608	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
177	1092	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
178	594	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
179	604	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
180	604	Novembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
181	604	Decembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
182	605	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
183	605	Novembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
184	605	Decembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
185	984	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
186	1093	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
187	644	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
188	574	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
189	574	Novembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
190	574	Decembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
191	663	Octobre	4000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
192	626	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
193	631	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
194	949	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
195	1066	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
196	641	Octobre	4000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
197	640	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
198	842	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
199	842	Novembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
200	842	Decembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
201	1070	Octobre	4000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
202	432	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
203	328	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
204	1072	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
205	1072	Novembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
206	1072	Decembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
207	1060	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
208	1060	Novembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
209	1060	Decembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
210	1108	Octobre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
211	1133	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
212	837	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
213	133	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
214	133	Novembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
215	133	Decembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
216	133	Janvier	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
217	133	Fevrier	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
218	133	Mars	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
219	1114	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
220	1113	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
221	1132	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
222	896	Octobre	500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
223	115	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
224	116	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
225	1120	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
226	873	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
227	873	Novembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
228	873	Decembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
229	190	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
230	1105	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
231	1026	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
232	1026	Novembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
233	1026	Decembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
234	1004	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
235	1004	Novembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
236	1004	Decembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
237	1016	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
238	1042	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
239	1021	Octobre	3500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
240	915	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
241	895	Octobre	500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
242	206	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
243	966	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
244	967	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
245	968	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
246	165	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
247	846	Octobre	3500	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
248	840	Octobre	2500	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
249	1136	Octobre	2000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
250	1046	Octobre	6000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
251	739	Octobre	3000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
252	615	Octobre	3000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
253	989	Octobre	3000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
254	990	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
255	992	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
256	664	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
257	991	Octobre	2000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
258	996	Octobre	1000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
259	864	Octobre	2000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
260	958	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
263	1115	Octobre	3500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
264	1115	Novembre	3500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
265	203	Octobre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
266	203	Novembre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
267	203	Decembre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
268	876	Octobre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
269	877	Octobre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
270	729	Octobre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
271	729	Novembre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
272	729	Decembre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
273	545	Octobre	2000	2026-10-06	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
274	585	Octobre	3000	2026-10-06	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
275	882	Octobre	2500	2026-10-06	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
276	395	Octobre	5000	2026-10-05	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
277	395	Novembre	5000	2026-10-05	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
278	395	Decembre	5000	2026-10-05	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
279	381	Octobre	5000	2026-10-07	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
280	371	Octobre	5000	2026-10-07	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
281	634	Octobre	4000	2026-10-08	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
282	1007	Octobre	5000	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
283	839	Octobre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
284	839	Novembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
285	839	Decembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
286	100	Octobre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
287	100	Novembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
288	100	Decembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
289	101	Octobre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
290	101	Novembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
291	101	Decembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
292	1028	Octobre	3500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
293	1028	Novembre	3500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
294	1028	Decembre	3500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
295	595	Octobre	3000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
296	828	Octobre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
297	226	Octobre	2500	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
298	935	Octobre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
299	935	Novembre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
300	935	Decembre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
301	620	Novembre	3000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
302	620	Decembre	3000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
303	620	Janvier	3000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
304	590	Octobre	3000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
305	850	Octobre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
306	1163	Octobre	4000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
307	580	Octobre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
308	580	Novembre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
309	580	Decembre	2000	2026-10-09	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
310	965	Octobre	5000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
311	815	Octobre	2500	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
312	815	Novembre	2500	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
313	815	Decembre	2500	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
314	523	Octobre	8000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
315	523	Novembre	8000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
316	523	Decembre	8000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
317	853	Octobre	6000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
318	875	Octobre	5000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
319	178	Octobre	2500	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
320	1063	Octobre	6000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
321	1063	Novembre	6000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
322	1063	Decembre	6000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
323	1048	Octobre	6000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
324	1048	Novembre	6000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
325	1048	Decembre	6000	2026-10-10	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
326	633	Octobre	3000	2026-10-13	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
327	633	Novembre	3000	2026-10-13	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
328	633	Decembre	3000	2026-10-13	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
329	1164	Octobre	2500	2026-10-13	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
330	710	Octobre	5000	2026-10-13	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
331	458	Octobre	6000	2026-10-11	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
332	333	Octobre	5000	2026-10-11	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
333	953	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
334	953	Novembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
335	953	Decembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
336	208	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
337	34	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
338	34	Novembre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
339	34	Decembre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
340	875	Octobre	1000	2026-10-14	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
341	1169	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
342	222	Octobre	500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
343	222	Novembre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
344	232	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
345	899	Octobre	1000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
346	1122	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
347	1125	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
348	894	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
349	148	Octobre	500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
350	1126	Octobre	1000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
351	157	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
352	885	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
353	165	Octobre	1000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
354	166	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
355	1188	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
356	881	Octobre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
357	1187	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
358	920	Octobre	1000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
359	874	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
360	468	Octobre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
361	951	Octobre	1000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
362	917	Octobre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
363	889	Octobre	1000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
364	742	Octobre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
365	742	Novembre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
366	742	Decembre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
367	290	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
368	281	Octobre	3000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
369	910	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
370	1117	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
371	279	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
372	688	Octobre	1000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
373	1013	Octobre	3000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
374	1027	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
375	1027	Novembre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
376	907	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
377	153	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
378	238	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
379	1024	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
380	1019	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
381	901	Octobre	3000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
382	904	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
383	241	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
384	241	Novembre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
385	241	Decembre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
386	849	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
387	1014	Octobre	1500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
388	1017	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
397	820	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
389	1017	Novembre	1500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
398	1113	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
390	1022	Octobre	3000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
391	930	Octobre	3500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
392	926	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
393	926	Novembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
394	926	Decembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
395	974	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
396	913	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
399	1113	Novembre	500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
400	1114	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
401	1114	Novembre	500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
402	1175	Octobre	1500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
403	1128	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
404	326	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
405	77	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
406	410	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
407	410	Novembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
408	410	Decembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
409	911	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
410	911	Novembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
411	911	Decembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
412	201	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
413	201	Novembre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
414	201	Decembre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
415	471	Octobre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
416	471	Novembre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
417	471	Decembre	6000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
418	1071	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
419	1051	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
420	518	Octobre	2000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
421	323	Octobre	3000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
422	355	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
423	355	Novembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
424	355	Decembre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
425	337	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
426	347	Octobre	5000	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
427	529	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
428	1204	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
429	1201	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
430	940	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
431	1206	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
432	981	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
433	1092	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
434	1093	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
435	1207	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
436	1203	Octobre	500	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
437	1218	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
438	575	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
439	582	Novembre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
440	999	Octobre	1000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
441	571	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
442	598	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
443	534	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
444	597	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
445	934	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
446	937	Octobre	1000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
447	648	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
448	565	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
449	658	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
450	1077	Octobre	2500	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
451	960	Octobre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
454	1181	Octobre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
455	521	Octobre	8000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
456	509	Novembre	4000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
458	1074	Octobre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
459	1221	Octobre	8000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
460	515	Octobre	8000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
461	515	Novembre	8000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
462	515	Decembre	8000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
463	264	Octobre	3500	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
464	264	Novembre	3500	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
465	264	Decembre	3500	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
466	314	Octobre	3500	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
467	314	Novembre	3500	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
468	314	Decembre	3500	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
469	434	Octobre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
470	434	Novembre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
471	434	Decembre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
472	375	Octobre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
473	358	Octobre	3000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
474	1138	Octobre	2000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
475	397	Octobre	2000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
477	396	Octobre	2000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
478	324	Octobre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
479	324	Novembre	5000	2026-10-14	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
480	654	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
481	864	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
482	640	Octobre	1500	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
483	858	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
484	642	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
485	1080	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
486	941	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
487	606	Novembre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
488	996	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
489	942	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
490	1199	Octobre	1000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
491	660	Octobre	2500	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
492	1089	Octobre	1000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
493	993	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
494	838	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
495	610	Octobre	1500	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
496	1099	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
497	637	Octobre	4000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
498	619	Octobre	1500	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
499	1090	Octobre	3000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
500	548	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
501	553	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
502	948	Octobre	2000	2026-10-10	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
503	998	Octobre	4000	2026-10-15	Presentiel	1	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77
504	52	Octobre	2500	2026-10-15	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
505	470	Octobre	5000	2026-10-15	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
506	624	Octobre	3000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
507	624	Novembre	3000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
508	624	Decembre	3000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
509	600	Octobre	3000	2026-10-15	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
510	540	Octobre	2000	2026-10-15	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
511	573	Octobre	2000	2026-10-15	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
512	573	Novembre	1000	2026-10-15	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
513	662	Octobre	3000	2026-10-16	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
514	330	Octobre	5000	2026-10-16	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
515	1226	Octobre	1250	2026-10-16	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
516	1226	Octobre	1250	2026-10-16	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
517	1259	Octobre	1000	2026-10-17	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
518	1259	Octobre	1000	2026-10-17	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
519	1260	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
520	1260	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
521	1192	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
522	1192	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
523	1229	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
524	1229	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
525	1119	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
526	1243	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
527	1243	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
528	1252	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
529	1252	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
530	701	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
531	1105	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
532	1130	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
533	1124	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
534	1249	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
535	1249	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
536	1228	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
537	1228	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
538	1171	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
539	899	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
540	218	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
541	1126	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
542	162	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
543	148	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
544	927	Octobre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
545	927	Novembre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
546	927	Decembre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
547	167	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
548	167	Novembre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
549	167	Decembre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
550	1250	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
551	1250	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
552	851	Octobre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
553	851	Novembre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
554	851	Decembre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
555	844	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
556	844	Novembre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
557	844	Decembre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
558	1064	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
559	1178	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
560	294	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
561	286	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
562	216	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
563	1011	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
564	1027	Decembre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
565	1027	Janvier	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
566	1173	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
567	247	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
568	1242	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
569	1245	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
570	1255	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
571	1255	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
572	919	Octobre	6000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
573	916	Octobre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
574	918	Octobre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
575	734	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
576	485	Octobre	6000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
577	302	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
578	81	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
579	1187	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
580	1253	Octobre	6000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
581	890	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
582	891	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
583	58	Decembre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
584	245	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
585	252	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
586	1024	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
587	1023	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
588	1014	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
589	1172	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
590	914	Octobre	4000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
591	306	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
592	1036	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
593	1036	Octobre	750	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
594	1036	Octobre	1750	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
595	1033	Octobre	3500	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
596	1022	Octobre	500	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
597	1020	Octobre	500	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
598	733	Octobre	6000	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
599	1177	Octobre	1000	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
600	1052	Octobre	5000	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
601	1052	Novembre	5000	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
602	1052	Decembre	5000	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
603	1051	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
604	1054	Octobre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
605	384	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
606	384	Novembre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
607	499	Octobre	8000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
608	750	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
609	1006	Octobre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
610	339	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
611	345	Octobre	5000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
612	323	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
613	348	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
614	369	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
615	1217	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
616	1217	Novembre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
617	1217	Decembre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
618	1190	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
619	1190	Novembre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
620	1190	Decembre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
621	603	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
622	1079	Octobre	500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
623	859	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
624	1002	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
625	1001	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
626	660	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
627	602	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
628	587	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
629	982	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
630	982	Novembre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
631	1091	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
632	596	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
633	627	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
634	589	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
635	1089	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
636	1197	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
637	614	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
638	1266	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
639	1266	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
640	1267	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
641	1267	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
642	1267	Novembre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
643	552	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
644	1208	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
645	1209	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
646	1268	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
647	1268	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
648	559	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
649	557	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
650	987	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
651	1213	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
652	581	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
653	610	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
654	994	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
655	995	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
656	1081	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
657	1088	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
658	1088	Novembre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
659	651	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
660	644	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
661	984	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
662	1000	Octobre	4000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
663	649	Octobre	4000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
664	983	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
665	636	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
666	866	Octobre	4000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
667	937	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
668	653	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
669	1087	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
670	611	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
671	567	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
672	1264	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
673	1264	Octobre	1500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
674	601	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
675	1212	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
676	224	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
677	572	Octobre	2000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
679	845	Octobre	6000	2026-10-17	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
680	929	Octobre	3500	2026-10-18	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
681	300	Octobre	3500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
682	78	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
683	519	Octobre	4000	2026-10-17	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
684	1257	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
685	1256	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
686	1238	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
687	1239	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
688	1240	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
689	1241	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
690	1244	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
691	1246	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
692	1248	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
693	1227	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
694	1232	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
695	1254	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
696	1251	Octobre	2500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
697	1233	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
698	1233	Octobre	500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
699	1231	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
700	1230	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
701	1237	Octobre	1250	2026-10-20	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
702	1234	Octobre	1250	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
703	1262	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
704	1261	Octobre	1750	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
705	1263	Octobre	1000	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
706	1263	Octobre	3000	2026-10-18	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
707	1269	Octobre	1000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
708	1269	Octobre	500	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
709	365	Octobre	5000	2026-10-20	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
710	421	Octobre	5000	2026-10-17	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
711	879	Octobre	5000	2026-10-21	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
712	492	Octobre	10000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
713	492	Novembre	10000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
714	492	Decembre	10000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
715	952	Octobre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
716	1005	Octobre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
717	1057	Octobre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
718	1057	Novembre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
719	1057	Decembre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
720	1058	Octobre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
721	1058	Novembre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
722	1058	Decembre	5000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
723	1068	Octobre	3000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
724	1225	Octobre	3000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
725	504	Octobre	8000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
726	504	Novembre	8000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
727	504	Decembre	8000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
728	307	Octobre	3500	2026-10-22	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
729	49	Octobre	2500	2026-10-22	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
730	887	Octobre	2500	2026-10-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
731	903	Octobre	3500	2026-10-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
732	1273	Novembre	2500	2026-10-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
733	1118	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
734	186	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
735	964	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
736	896	Octobre	500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
737	148	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
738	900	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
739	1029	Octobre	3500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
740	1018	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
741	1014	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
742	906	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
743	906	Octobre	500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
744	276	Octobre	3500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
745	1039	Octobre	3500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
746	452	Octobre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
747	1254	Octobre	3000	2026-10-17	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
749	732	Octobre	4000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
750	1263	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
751	1047	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
752	734	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
753	454	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
754	1187	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
755	889	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
756	1239	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
757	1240	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
758	207	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
759	1238	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
760	1236	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
761	1236	Novembre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
762	1236	Decembre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
763	1179	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
764	285	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
765	1231	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
766	310	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
767	290	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
768	1262	Octobre	1750	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
769	56	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
770	56	Novembre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
771	56	Decembre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
772	77	Octobre	500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
773	64	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
774	142	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
775	1103	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
776	1104	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
777	1251	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
778	1251	Novembre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
779	1180	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
780	971	Octobre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
781	1261	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
782	1281	Novembre	6000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
783	1282	Novembre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
784	1279	Novembre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
785	1279	Decembre	500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
786	1173	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
787	1116	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
788	1272	Octobre	4000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
789	1272	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
790	1271	Octobre	4000	2026-10-21	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
791	1271	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
792	1265	Octobre	8000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
793	1065	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
794	518	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
795	526	Octobre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
796	494	Octobre	10000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
797	494	Novembre	10000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
798	494	Decembre	10000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
799	1053	Octobre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
800	389	Octobre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
801	358	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
802	364	Octobre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
803	364	Novembre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
804	364	Decembre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
805	339	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
806	348	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
807	1138	Octobre	3000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
808	1106	Octobre	6000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
809	1120	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
810	200	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
811	1055	Octobre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
812	1055	Novembre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
813	1055	Decembre	5000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
814	313	Octobre	3500	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
815	746	Octobre	8000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
816	746	Novembre	8000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
817	746	Decembre	8000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
818	391	Octobre	5000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
819	391	Novembre	5000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
820	391	Decembre	5000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
821	645	Octobre	4000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
822	645	Novembre	4000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
823	938	Novembre	3000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
824	403	Octobre	2000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
825	1059	Octobre	5000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
826	111	Octobre	2500	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
827	111	Novembre	2500	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
828	923	Octobre	5000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
829	923	Novembre	5000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
830	489	Octobre	6000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
831	488	Octobre	4000	2026-10-24	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
832	1291	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
833	1291	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
834	1293	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
835	1293	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
836	1294	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
837	1294	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
838	1295	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
839	1295	Octobre	1500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
840	1290	Novembre	4000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
841	1197	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
842	1198	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
843	987	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
844	947	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
845	1296	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
846	1296	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
847	1210	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
848	1269	Octobre	500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
849	988	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
850	596	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
851	1208	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
852	599	Octobre	3000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
853	1089	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
854	1209	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
855	614	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
856	1218	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
857	1216	Octobre	3000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
858	539	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
859	1079	Octobre	500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
860	1195	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
861	1100	Octobre	1000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
862	1205	Octobre	4000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
863	655	Octobre	4000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
864	656	Octobre	4000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
865	591	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
866	1191	Octobre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
867	575	Novembre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
868	575	Decembre	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
869	575	Janvier	2000	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
870	415	Octobre	5000	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
871	1077	Octobre	2500	2026-10-24	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
872	997	Octobre	4000	2026-10-28	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
873	380	Octobre	5000	2026-10-28	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
874	488	Octobre	2000	2026-10-29	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
875	1247	Octobre	1250	2026-10-29	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
876	128	Octobre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
877	128	Novembre	2500	2026-10-10	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
878	753	Octobre	8000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
879	753	Novembre	8000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
880	753	Decembre	8000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
881	1074	Octobre	3000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
882	509	Novembre	4000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
883	407	Octobre	5000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
884	1075	Octobre	5000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
885	369	Octobre	2000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
886	1137	Octobre	5000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
887	328	Octobre	1000	2026-10-28	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
888	1202	Octobre	3000	2026-10-30	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
889	519	Octobre	4000	2026-10-30	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
890	689	Octobre	2500	2026-10-31	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
891	689	Novembre	500	2026-10-31	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
892	1299	Novembre	4000	2026-10-31	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
\.


--
-- Data for Name: paiements_supprimes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements_supprimes (id, matricule, mois_souscription, montant_paye, date_paiement, mode_paiement, admin_id, date_suppression, motif) FROM stdin;
1	J09266010	Octobre	2500	2026-09-26	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:29:11.889364+00	Erreur de saisie du montant normal payé
2	J09261327	Octobre	5000	2026-09-26	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:36:39.443373+00	Erreur de saisie du montant payé
3	J08263005	Octobre	3000	2026-09-19	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 20:27:33.288702+00	Erreur de saisie du montant
4	J09265287	Octobre	4000	2026-09-26	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-14 20:36:19.573157+00	Erreur de saisie du montant
5	J08263684	Octobre	2000	2026-10-14	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-15 03:18:06.744392+00	Erreur de saisie du montant
6	J09264352	Novembre	5000	2026-10-14	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-22 03:25:39.37359+00	Erreur de saisie
7	J09269640	Novembre	5000	2026-10-14	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-22 03:26:24.675966+00	Erreur de saisie
8	J09269640	Octobre	5000	2026-10-03	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-22 03:29:58.637855+00	Erreur de saisie
9	J09264352	Octobre	5000	2026-10-03	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-22 03:30:22.826983+00	Erreur de saisie
10	J10268479	Novembre	3000	2026-10-24	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-25 12:50:19.252748+00	Erreur de saisie
11	J09268409	Octobre	5000	2026-10-17	MoMo	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 11:58:58.836095+00	Erreur de saisie
12	J08262890	Octobre	4000	2026-10-14	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-29 12:00:48.209174+00	Erreur de saisie
\.


--
-- Data for Name: penalites_reinscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.penalites_reinscription (id, eleve_id, montant, mode_paiement, date_paiement, enregistre_par, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: presences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.presences (id, eleve_id, date_presence, site_id, classe_id, present, annee_scolaire_id) FROM stdin;
2	557	2026-09-19	2	14	t	1
3	558	2026-09-19	2	14	t	1
4	559	2026-09-19	2	14	t	1
5	560	2026-09-19	2	14	t	1
8	563	2026-09-19	2	14	t	1
9	564	2026-09-19	2	14	t	1
10	565	2026-09-19	2	14	t	1
12	567	2026-09-19	2	14	t	1
13	568	2026-09-19	2	14	f	1
15	570	2026-09-19	2	14	f	1
16	571	2026-09-19	2	14	f	1
17	572	2026-09-19	2	14	t	1
18	573	2026-09-19	2	14	t	1
19	574	2026-09-19	2	14	f	1
20	575	2026-09-19	2	14	t	1
21	850	2026-09-19	2	14	t	1
26	580	2026-09-19	2	14	t	1
27	581	2026-09-19	2	14	f	1
28	582	2026-09-19	2	14	t	1
30	583	2026-09-19	2	15	f	1
31	585	2026-09-19	2	15	t	1
33	587	2026-09-19	2	15	t	1
2405	322	2026-10-21	1	4	t	1
35	589	2026-09-19	2	15	f	1
36	859	2026-09-19	2	15	t	1
37	590	2026-09-19	2	15	t	1
38	591	2026-09-19	2	15	t	1
41	594	2026-09-19	2	15	t	1
42	595	2026-09-19	2	15	t	1
43	596	2026-09-19	2	15	f	1
44	597	2026-09-19	2	15	f	1
45	598	2026-09-19	2	15	f	1
46	599	2026-09-19	2	15	f	1
47	601	2026-09-19	2	15	t	1
48	600	2026-09-19	2	15	t	1
50	602	2026-09-19	2	15	t	1
51	603	2026-09-19	2	15	t	1
52	604	2026-09-19	2	15	t	1
53	605	2026-09-19	2	15	t	1
54	606	2026-09-19	2	15	t	1
55	608	2026-09-19	2	15	t	1
56	607	2026-09-19	2	15	t	1
57	609	2026-09-19	2	15	t	1
58	610	2026-09-19	2	15	t	1
59	611	2026-09-19	2	15	t	1
61	612	2026-09-19	2	15	f	1
63	614	2026-09-19	2	15	f	1
64	615	2026-09-19	2	15	t	1
65	616	2026-09-19	2	15	f	1
67	618	2026-09-19	2	15	t	1
68	862	2026-09-19	2	15	t	1
69	619	2026-09-19	2	15	t	1
70	620	2026-09-19	2	15	t	1
71	621	2026-09-19	2	15	t	1
72	622	2026-09-19	2	15	f	1
73	623	2026-09-19	2	15	t	1
74	624	2026-09-19	2	15	t	1
75	625	2026-09-19	2	15	t	1
76	626	2026-09-19	2	15	t	1
77	627	2026-09-19	2	15	f	1
78	628	2026-09-19	2	15	t	1
80	630	2026-09-19	2	15	f	1
81	631	2026-09-19	2	15	t	1
83	633	2026-09-19	2	15	t	1
84	529	2026-09-19	2	13	f	1
85	530	2026-09-19	2	13	f	1
86	843	2026-09-19	2	13	t	1
2406	332	2026-10-21	1	4	t	1
2407	1007	2026-10-21	1	4	t	1
2408	323	2026-10-21	1	4	t	1
90	858	2026-09-19	2	13	t	1
91	534	2026-09-19	2	13	f	1
2409	324	2026-10-21	1	4	t	1
93	842	2026-09-19	2	13	t	1
2410	326	2026-10-21	1	4	t	1
2411	333	2026-10-21	1	4	t	1
2412	328	2026-10-21	1	4	t	1
97	539	2026-09-19	2	13	f	1
98	540	2026-09-19	2	13	t	1
2413	334	2026-10-21	1	4	t	1
2414	330	2026-10-21	1	4	t	1
101	543	2026-09-19	2	13	f	1
2858	41	2026-10-24	1	1	t	1
103	545	2026-09-19	2	13	f	1
2859	42	2026-10-24	1	1	t	1
105	548	2026-09-19	2	13	f	1
106	549	2026-09-19	2	13	f	1
2860	43	2026-10-24	1	1	f	1
108	550	2026-09-19	2	13	f	1
2861	5	2026-10-24	1	1	t	1
110	552	2026-09-19	2	13	f	1
2862	1242	2026-10-24	1	1	t	1
112	838	2026-09-19	2	13	f	1
113	553	2026-09-19	2	13	t	1
116	634	2026-09-19	2	16	t	1
119	637	2026-09-19	2	16	f	1
120	636	2026-09-19	2	16	f	1
122	639	2026-09-19	2	16	t	1
123	864	2026-09-19	2	16	t	1
124	640	2026-09-19	2	16	f	1
125	641	2026-09-19	2	16	f	1
126	642	2026-09-19	2	16	t	1
127	643	2026-09-19	2	16	f	1
128	644	2026-09-19	2	16	f	1
129	645	2026-09-19	2	16	f	1
133	866	2026-09-19	2	16	t	1
134	648	2026-09-19	2	16	t	1
136	649	2026-09-19	2	16	t	1
2863	7	2026-10-24	1	1	t	1
2864	48	2026-10-24	1	1	t	1
2865	8	2026-10-24	1	1	t	1
2866	887	2026-10-24	1	1	t	1
2867	1244	2026-10-24	1	1	t	1
2868	49	2026-10-24	1	1	t	1
2869	51	2026-10-24	1	1	t	1
2870	888	2026-10-24	1	1	t	1
2871	10	2026-10-24	1	1	f	1
2872	52	2026-10-24	1	1	t	1
2873	11	2026-10-24	1	1	f	1
2874	53	2026-10-24	1	1	t	1
2875	55	2026-10-24	1	1	f	1
2876	12	2026-10-24	1	1	t	1
2877	15	2026-10-24	1	1	t	1
2878	56	2026-10-24	1	1	t	1
2879	57	2026-10-24	1	1	t	1
2880	969	2026-10-24	1	1	t	1
2881	16	2026-10-24	1	1	t	1
2882	1133	2026-10-24	1	1	t	1
2883	58	2026-10-24	1	1	t	1
2884	762	2026-10-24	1	1	t	1
2885	1243	2026-10-24	1	1	t	1
2886	19	2026-10-24	1	1	t	1
2887	21	2026-10-24	1	1	f	1
2888	69	2026-10-24	1	1	t	1
137	650	2026-09-19	2	16	t	1
138	651	2026-09-19	2	16	t	1
140	653	2026-09-19	2	16	f	1
142	654	2026-09-19	2	16	t	1
143	655	2026-09-19	2	16	t	1
144	656	2026-09-19	2	16	t	1
146	658	2026-09-19	2	16	t	1
149	660	2026-09-19	2	16	t	1
151	662	2026-09-19	2	16	f	1
152	663	2026-09-19	2	16	f	1
153	664	2026-09-19	2	16	t	1
2415	335	2026-10-21	1	17	f	1
2416	884	2026-10-21	1	17	f	1
2417	337	2026-10-21	1	17	t	1
159	41	2026-09-19	1	1	t	1
160	42	2026-09-19	1	1	t	1
2418	339	2026-10-21	1	17	t	1
162	43	2026-09-19	1	1	t	1
163	5	2026-09-19	1	1	f	1
2419	708	2026-10-21	1	17	t	1
2420	397	2026-10-21	1	17	t	1
2421	847	2026-10-21	1	17	t	1
2422	710	2026-10-21	1	17	t	1
168	7	2026-09-19	1	1	t	1
169	48	2026-09-19	1	1	t	1
2423	344	2026-10-21	1	17	t	1
171	8	2026-09-19	1	1	t	1
172	49	2026-09-19	1	1	t	1
2424	345	2026-10-21	1	17	t	1
174	51	2026-09-19	1	1	t	1
2425	346	2026-10-21	1	17	t	1
176	10	2026-09-19	1	1	t	1
177	52	2026-09-19	1	1	t	1
178	11	2026-09-19	1	1	t	1
179	53	2026-09-19	1	1	t	1
2426	347	2026-10-21	1	17	t	1
181	55	2026-09-19	1	1	t	1
182	12	2026-09-19	1	1	t	1
2427	348	2026-10-21	1	17	t	1
2428	879	2026-10-21	1	17	t	1
185	15	2026-09-19	1	1	f	1
186	56	2026-09-19	1	1	f	1
187	57	2026-09-19	1	1	f	1
188	16	2026-09-19	1	1	t	1
189	58	2026-09-19	1	1	t	1
2429	355	2026-10-21	1	17	t	1
2430	358	2026-10-21	1	17	t	1
2431	954	2026-10-21	1	17	f	1
2432	416	2026-10-21	1	17	t	1
194	19	2026-09-19	1	1	f	1
2433	361	2026-10-21	1	17	t	1
196	21	2026-09-19	1	1	t	1
2434	364	2026-10-21	1	17	t	1
198	69	2026-09-19	1	1	t	1
2435	365	2026-10-21	1	17	f	1
2436	1138	2026-10-21	1	17	t	1
2437	369	2026-10-21	1	17	t	1
202	62	2026-09-19	1	1	t	1
2438	371	2026-10-21	1	17	t	1
2439	883	2026-10-21	1	17	t	1
205	64	2026-09-19	1	1	t	1
206	66	2026-09-19	1	1	f	1
2440	952	2026-10-21	1	17	t	1
208	26	2026-09-19	1	1	t	1
2441	717	2026-10-21	1	17	t	1
2442	375	2026-10-21	1	17	t	1
211	68	2026-09-19	1	1	t	1
2443	1137	2026-10-21	1	17	t	1
2444	379	2026-10-21	1	17	t	1
214	71	2026-09-19	1	1	t	1
215	72	2026-09-19	1	1	t	1
216	29	2026-09-19	1	1	t	1
2445	380	2026-10-21	1	17	t	1
218	30	2026-09-19	1	1	t	1
219	77	2026-09-19	1	1	t	1
2446	381	2026-10-21	1	17	t	1
2447	953	2026-10-21	1	17	t	1
2448	965	2026-10-21	1	17	t	1
223	78	2026-09-19	1	1	t	1
2449	912	2026-10-21	1	17	f	1
2450	385	2026-10-21	1	17	t	1
2889	62	2026-10-24	1	1	t	1
227	81	2026-09-19	1	1	t	1
228	32	2026-09-19	1	1	f	1
2890	959	2026-10-24	1	1	t	1
2891	64	2026-10-24	1	1	t	1
231	84	2026-09-19	1	1	t	1
2892	66	2026-10-24	1	1	t	1
233	873	2026-09-19	1	1	t	1
234	34	2026-09-19	1	1	f	1
2893	26	2026-10-24	1	1	f	1
2894	68	2026-10-24	1	1	t	1
237	37	2026-09-19	1	1	t	1
2895	71	2026-10-24	1	1	t	1
34	588	2026-09-19	2	15	t	1
2896	72	2026-10-24	1	1	t	1
2897	29	2026-10-24	1	1	t	1
2898	30	2026-10-24	1	1	t	1
2899	77	2026-10-24	1	1	t	1
2900	1246	2026-10-24	1	1	t	1
2901	133	2026-10-24	1	1	t	1
246	95	2026-09-19	1	20	t	1
247	96	2026-09-19	1	20	t	1
248	839	2026-09-19	1	20	t	1
249	97	2026-09-19	1	20	t	1
250	841	2026-09-19	1	20	f	1
2902	78	2026-10-24	1	1	t	1
2903	81	2026-10-24	1	1	t	1
2904	886	2026-10-24	1	1	t	1
2905	84	2026-10-24	1	1	t	1
2906	1245	2026-10-24	1	1	t	1
256	100	2026-09-19	1	20	f	1
257	101	2026-09-19	1	20	f	1
2907	873	2026-10-24	1	1	t	1
2908	34	2026-10-24	1	1	t	1
260	103	2026-09-19	1	20	f	1
2909	37	2026-10-24	1	1	t	1
2589	244	2026-10-24	1	3	t	1
3271	746	2026-10-28	1	12	t	1
3272	499	2026-10-28	1	12	t	1
3273	500	2026-10-28	1	12	t	1
3274	501	2026-10-28	1	12	t	1
3275	502	2026-10-28	1	12	t	1
3276	1271	2026-10-28	1	12	t	1
3277	507	2026-10-28	1	12	t	1
270	844	2026-09-19	1	20	t	1
3278	503	2026-10-28	1	12	t	1
3279	504	2026-10-28	1	12	t	1
3280	508	2026-10-28	1	12	t	1
3281	509	2026-10-28	1	12	t	1
3282	1077	2026-10-28	1	12	t	1
3283	750	2026-10-28	1	12	t	1
3284	514	2026-10-28	1	12	f	1
3285	515	2026-10-28	1	12	t	1
3286	1265	2026-10-28	1	12	t	1
273	111	2026-09-19	1	20	t	1
2451	490	2026-10-21	1	11	t	1
275	113	2026-09-19	1	20	t	1
2452	491	2026-10-21	1	11	f	1
277	876	2026-09-19	1	20	t	1
278	115	2026-09-19	1	20	t	1
279	116	2026-09-19	1	20	t	1
280	882	2026-09-19	1	20	t	1
2453	492	2026-10-21	1	11	t	1
2454	494	2026-10-21	1	11	t	1
2455	497	2026-10-21	1	11	t	1
2910	982	2026-10-24	2	15	t	1
285	120	2026-09-19	1	20	f	1
2911	583	2026-10-24	2	15	f	1
2912	585	2026-10-24	2	15	t	1
2913	1091	2026-10-24	2	15	t	1
289	87	2026-09-19	1	20	t	1
2914	1208	2026-10-24	2	15	t	1
2915	949	2026-10-24	2	15	t	1
2916	588	2026-10-24	2	15	t	1
2917	587	2026-10-24	2	15	t	1
2918	589	2026-10-24	2	15	t	1
2919	1090	2026-10-24	2	15	t	1
296	127	2026-09-19	1	20	t	1
297	128	2026-09-19	1	20	t	1
2920	590	2026-10-24	2	15	t	1
2921	591	2026-10-24	2	15	t	1
300	820	2026-09-19	1	20	t	1
2922	946	2026-10-24	2	15	t	1
2923	859	2026-10-24	2	15	t	1
303	133	2026-09-19	1	20	f	1
2924	594	2026-10-24	2	15	t	1
2925	595	2026-10-24	2	15	t	1
306	135	2026-09-19	1	20	t	1
2926	596	2026-10-24	2	15	t	1
2927	597	2026-10-24	2	15	t	1
309	137	2026-09-19	1	20	t	1
2928	1270	2026-10-24	2	15	f	1
2929	1089	2026-10-24	2	15	t	1
2930	1092	2026-10-24	2	15	t	1
313	840	2026-09-19	1	20	t	1
2931	1088	2026-10-24	2	15	t	1
2932	1207	2026-10-24	2	15	t	1
316	141	2026-09-19	1	20	t	1
317	837	2026-09-19	1	20	t	1
2933	599	2026-10-24	2	15	t	1
2934	1209	2026-10-24	2	15	t	1
320	682	2026-09-19	1	20	f	1
2935	989	2026-10-24	2	15	t	1
322	142	2026-09-19	1	20	t	1
323	143	2026-09-19	1	20	f	1
2936	600	2026-10-24	2	15	t	1
2937	601	2026-10-24	2	15	t	1
2938	602	2026-10-24	2	15	t	1
327	885	2026-09-19	1	2	t	1
2939	603	2026-10-24	2	15	t	1
2940	1216	2026-10-24	2	15	t	1
330	148	2026-09-19	1	2	t	1
2941	1094	2026-10-24	2	15	f	1
332	150	2026-09-19	1	2	t	1
333	151	2026-09-19	1	2	f	1
334	152	2026-09-19	1	2	f	1
335	153	2026-09-19	1	2	t	1
2942	604	2026-10-24	2	15	t	1
2943	605	2026-10-24	2	15	t	1
338	156	2026-09-19	1	2	f	1
2944	1264	2026-10-24	2	15	t	1
340	157	2026-09-19	1	2	t	1
341	158	2026-09-19	1	2	f	1
2945	606	2026-10-24	2	15	t	1
2946	607	2026-10-24	2	15	t	1
2947	608	2026-10-24	2	15	t	1
345	162	2026-09-19	1	2	t	1
346	872	2026-09-19	1	2	t	1
2948	609	2026-10-24	2	15	t	1
2949	610	2026-10-24	2	15	t	1
349	164	2026-09-19	1	2	t	1
350	165	2026-09-19	1	2	f	1
351	166	2026-09-19	1	2	t	1
352	167	2026-09-19	1	2	t	1
353	168	2026-09-19	1	2	f	1
2950	611	2026-10-24	2	15	t	1
2951	612	2026-10-24	2	15	t	1
2952	615	2026-10-24	2	15	t	1
2953	614	2026-10-24	2	15	t	1
358	173	2026-09-19	1	2	f	1
359	174	2026-09-19	1	2	f	1
2954	1203	2026-10-24	2	15	t	1
361	176	2026-09-19	1	2	f	1
362	177	2026-09-19	1	2	t	1
363	178	2026-09-19	1	2	t	1
2955	1192	2026-10-24	2	15	t	1
2956	1212	2026-10-24	2	15	t	1
2957	616	2026-10-24	2	15	t	1
2958	618	2026-10-24	2	15	t	1
2959	862	2026-10-24	2	15	t	1
369	184	2026-09-19	1	2	t	1
2960	619	2026-10-24	2	15	t	1
371	186	2026-09-19	1	2	f	1
2961	993	2026-10-24	2	15	t	1
373	187	2026-09-19	1	2	f	1
374	188	2026-09-19	1	2	t	1
375	189	2026-09-19	1	2	t	1
2962	620	2026-10-24	2	15	t	1
377	284	2026-09-19	1	18	t	1
378	285	2026-09-19	1	18	f	1
379	305	2026-09-19	1	18	f	1
380	306	2026-09-19	1	18	f	1
381	286	2026-09-19	1	18	t	1
382	287	2026-09-19	1	18	f	1
383	288	2026-09-19	1	18	t	1
2963	1218	2026-10-24	2	15	t	1
385	290	2026-09-19	1	18	f	1
2964	940	2026-10-24	2	15	t	1
387	307	2026-09-19	1	18	t	1
2965	621	2026-10-24	2	15	t	1
389	309	2026-09-19	1	18	f	1
2966	1093	2026-10-24	2	15	t	1
2967	1066	2026-10-24	2	15	t	1
2968	937	2026-10-24	2	15	t	1
393	293	2026-09-19	1	18	t	1
394	310	2026-09-19	1	18	f	1
2969	985	2026-10-24	2	15	t	1
396	312	2026-09-19	1	18	t	1
2970	979	2026-10-24	2	15	t	1
398	294	2026-09-19	1	18	t	1
399	295	2026-09-19	1	18	f	1
400	701	2026-09-19	1	18	f	1
401	313	2026-09-19	1	18	t	1
2971	622	2026-10-24	2	15	f	1
403	314	2026-09-19	1	18	t	1
2972	1095	2026-10-24	2	15	f	1
2973	623	2026-10-24	2	15	t	1
2974	1202	2026-10-24	2	15	t	1
2975	624	2026-10-24	2	15	t	1
2976	625	2026-10-24	2	15	t	1
2456	389	2026-10-21	1	22	t	1
410	300	2026-09-19	1	18	t	1
2457	1069	2026-10-21	1	22	f	1
412	302	2026-09-19	1	18	t	1
413	303	2026-09-19	1	18	f	1
2458	391	2026-10-21	1	22	t	1
415	317	2026-09-19	1	18	t	1
416	874	2026-09-19	1	18	t	1
417	318	2026-09-19	1	18	t	1
2459	1050	2026-10-21	1	22	t	1
2460	395	2026-10-21	1	22	t	1
2461	396	2026-10-21	1	22	t	1
421	255	2026-09-19	1	3	f	1
2462	399	2026-10-21	1	22	t	1
2463	1054	2026-10-21	1	22	t	1
2464	401	2026-10-21	1	22	f	1
2465	1052	2026-10-21	1	22	t	1
426	257	2026-09-19	1	3	t	1
427	238	2026-09-19	1	3	t	1
2466	402	2026-10-21	1	22	t	1
2467	1008	2026-10-21	1	22	t	1
2468	404	2026-10-21	1	22	t	1
2469	403	2026-10-21	1	22	t	1
432	241	2026-09-19	1	3	t	1
433	242	2026-09-19	1	3	t	1
2470	1072	2026-10-21	1	22	t	1
435	244	2026-09-19	1	3	t	1
436	243	2026-09-19	1	3	t	1
437	245	2026-09-19	1	3	f	1
2471	1181	2026-10-21	1	22	t	1
439	247	2026-09-19	1	3	t	1
2472	1051	2026-10-21	1	22	t	1
2473	960	2026-10-21	1	22	t	1
2474	407	2026-10-21	1	22	t	1
2475	1004	2026-10-21	1	22	t	1
2476	409	2026-10-21	1	22	t	1
2477	911	2026-10-21	1	22	t	1
2478	410	2026-10-21	1	22	t	1
447	262	2026-09-19	1	3	f	1
448	263	2026-09-19	1	3	t	1
449	251	2026-09-19	1	3	t	1
2479	1053	2026-10-21	1	22	t	1
451	264	2026-09-19	1	3	t	1
2480	1059	2026-10-21	1	22	t	1
2481	415	2026-10-21	1	22	t	1
2482	1055	2026-10-21	1	22	t	1
2483	418	2026-10-21	1	22	t	1
2484	419	2026-10-21	1	22	t	1
457	269	2026-09-19	1	3	f	1
458	252	2026-09-19	1	3	t	1
459	270	2026-09-19	1	3	t	1
2485	421	2026-10-21	1	22	t	1
2486	422	2026-10-21	1	22	t	1
462	849	2026-09-19	1	3	t	1
2487	423	2026-10-21	1	22	t	1
464	272	2026-09-19	1	3	t	1
2488	425	2026-10-21	1	22	t	1
466	846	2026-09-19	1	3	t	1
2489	1076	2026-10-21	1	22	t	1
468	275	2026-09-19	1	3	t	1
469	276	2026-09-19	1	3	f	1
2490	1005	2026-10-21	1	22	t	1
2491	1065	2026-10-21	1	22	f	1
472	279	2026-09-19	1	3	f	1
2492	1256	2026-10-21	1	22	t	1
2493	432	2026-10-21	1	22	t	1
475	281	2026-09-19	1	3	f	1
2494	1071	2026-10-21	1	22	t	1
477	190	2026-09-19	1	19	f	1
478	191	2026-09-19	1	19	f	1
2495	434	2026-10-21	1	22	t	1
480	193	2026-09-19	1	19	t	1
481	194	2026-09-19	1	19	f	1
482	195	2026-09-19	1	19	f	1
483	196	2026-09-19	1	19	f	1
2496	1225	2026-10-21	1	22	t	1
485	198	2026-09-19	1	19	t	1
2497	1068	2026-10-21	1	22	t	1
2498	1006	2026-10-21	1	22	t	1
488	200	2026-09-19	1	19	t	1
489	689	2026-09-19	1	19	t	1
490	202	2026-09-19	1	19	f	1
491	201	2026-09-19	1	19	t	1
492	203	2026-09-19	1	19	t	1
493	204	2026-09-19	1	19	f	1
2499	1073	2026-10-21	1	22	t	1
495	206	2026-09-19	1	19	t	1
496	207	2026-09-19	1	19	f	1
497	208	2026-09-19	1	19	f	1
498	209	2026-09-19	1	19	t	1
2500	1075	2026-10-21	1	22	t	1
2501	729	2026-10-21	1	22	t	1
2502	1057	2026-10-21	1	22	t	1
502	688	2026-09-19	1	19	f	1
2503	1058	2026-10-21	1	22	t	1
504	214	2026-09-19	1	19	f	1
2504	1112	2026-10-21	1	22	f	1
506	215	2026-09-19	1	19	t	1
507	216	2026-09-19	1	19	f	1
2505	1056	2026-10-21	1	22	t	1
509	218	2026-09-19	1	19	f	1
2506	443	2026-10-21	1	22	t	1
2507	1070	2026-10-21	1	22	f	1
512	221	2026-09-19	1	19	t	1
513	687	2026-09-19	1	19	t	1
514	222	2026-09-19	1	19	t	1
2508	384	2026-10-21	1	22	t	1
516	224	2026-09-19	1	19	f	1
2977	626	2026-10-24	2	15	t	1
518	226	2026-09-19	1	19	t	1
519	227	2026-09-19	1	19	t	1
2978	627	2026-10-24	2	15	t	1
2979	1002	2026-10-24	2	15	t	1
2980	628	2026-10-24	2	15	t	1
523	231	2026-09-19	1	19	t	1
524	232	2026-09-19	1	19	f	1
2981	630	2026-10-24	2	15	t	1
526	447	2026-09-19	1	24	t	1
2982	1217	2026-10-24	2	15	t	1
528	449	2026-09-19	1	24	t	1
529	450	2026-09-19	1	24	f	1
530	451	2026-09-19	1	24	f	1
531	452	2026-09-19	1	24	t	1
2983	631	2026-10-24	2	15	t	1
533	454	2026-09-19	1	24	f	1
2984	938	2026-10-24	2	15	t	1
535	456	2026-09-19	1	24	t	1
536	457	2026-09-19	1	24	t	1
537	458	2026-09-19	1	24	t	1
538	459	2026-09-19	1	8	f	1
2985	633	2026-10-24	2	15	t	1
3166	322	2026-10-28	1	4	t	1
541	462	2026-09-19	1	8	f	1
542	732	2026-09-19	1	8	t	1
543	733	2026-09-19	1	8	t	1
544	463	2026-09-19	1	8	f	1
545	464	2026-09-19	1	8	t	1
2509	746	2026-10-21	1	12	t	1
547	734	2026-09-19	1	8	f	1
2510	499	2026-10-21	1	12	t	1
549	467	2026-09-19	1	8	t	1
550	468	2026-09-19	1	8	f	1
551	845	2026-09-19	1	8	t	1
2511	500	2026-10-21	1	12	t	1
2512	501	2026-10-21	1	12	t	1
554	875	2026-09-19	1	8	t	1
555	469	2026-09-19	1	8	t	1
556	737	2026-09-19	1	8	t	1
557	471	2026-09-19	1	8	f	1
2513	502	2026-10-21	1	12	t	1
559	852	2026-09-19	1	8	t	1
2514	507	2026-10-21	1	12	t	1
561	474	2026-09-19	1	8	t	1
562	475	2026-09-19	1	8	f	1
2515	503	2026-10-21	1	12	f	1
2516	504	2026-10-21	1	12	t	1
565	478	2026-09-19	1	8	t	1
2517	508	2026-10-21	1	12	t	1
2518	509	2026-10-21	1	12	t	1
568	480	2026-09-19	1	8	f	1
2519	1077	2026-10-21	1	12	t	1
570	739	2026-09-19	1	8	t	1
2520	750	2026-10-21	1	12	t	1
2521	514	2026-10-21	1	12	f	1
573	742	2026-09-19	1	8	f	1
574	853	2026-09-19	1	8	t	1
575	482	2026-09-19	1	8	t	1
2522	515	2026-10-21	1	12	t	1
2523	1265	2026-10-21	1	12	t	1
578	485	2026-09-19	1	8	t	1
579	486	2026-09-19	1	8	t	1
580	487	2026-09-19	1	8	t	1
581	881	2026-09-19	1	8	t	1
582	488	2026-09-19	1	8	f	1
583	489	2026-09-19	1	8	f	1
2524	1221	2026-10-21	1	12	t	1
3988	389	2026-10-31	1	22	t	1
586	557	2026-09-26	2	14	t	1
587	558	2026-09-26	2	14	t	1
588	559	2026-09-26	2	14	t	1
589	560	2026-09-26	2	14	t	1
3989	1069	2026-10-31	1	22	f	1
3990	391	2026-10-31	1	22	t	1
592	947	2026-09-26	2	14	t	1
593	563	2026-09-26	2	14	f	1
594	564	2026-09-26	2	14	t	1
595	565	2026-09-26	2	14	t	1
3991	1050	2026-10-31	1	22	t	1
597	567	2026-09-26	2	14	t	1
598	568	2026-09-26	2	14	t	1
3992	395	2026-10-31	1	22	t	1
600	570	2026-09-26	2	14	t	1
601	571	2026-09-26	2	14	f	1
602	572	2026-09-26	2	14	t	1
603	573	2026-09-26	2	14	t	1
604	948	2026-09-26	2	14	f	1
605	575	2026-09-26	2	14	t	1
606	850	2026-09-26	2	14	t	1
3993	396	2026-10-31	1	22	t	1
3994	399	2026-10-31	1	22	f	1
3995	1054	2026-10-31	1	22	t	1
3996	401	2026-10-31	1	22	t	1
611	581	2026-09-26	2	14	t	1
612	580	2026-09-26	2	14	t	1
613	582	2026-09-26	2	14	t	1
614	583	2026-09-26	2	15	f	1
3997	1052	2026-10-31	1	22	t	1
616	585	2026-09-26	2	15	t	1
3998	402	2026-10-31	1	22	t	1
618	949	2026-09-26	2	15	t	1
619	588	2026-09-26	2	15	t	1
620	587	2026-09-26	2	15	t	1
621	589	2026-09-26	2	15	t	1
622	859	2026-09-26	2	15	t	1
623	590	2026-09-26	2	15	t	1
624	591	2026-09-26	2	15	t	1
3999	1008	2026-10-31	1	22	t	1
4000	404	2026-10-31	1	22	t	1
627	946	2026-09-26	2	15	t	1
628	594	2026-09-26	2	15	t	1
629	595	2026-09-26	2	15	t	1
630	596	2026-09-26	2	15	t	1
631	598	2026-09-26	2	15	f	1
632	597	2026-09-26	2	15	t	1
4001	403	2026-10-31	1	22	t	1
634	599	2026-09-26	2	15	f	1
635	600	2026-09-26	2	15	t	1
636	601	2026-09-26	2	15	t	1
4002	1072	2026-10-31	1	22	t	1
638	602	2026-09-26	2	15	t	1
639	603	2026-09-26	2	15	t	1
640	605	2026-09-26	2	15	t	1
641	604	2026-09-26	2	15	t	1
642	606	2026-09-26	2	15	t	1
643	608	2026-09-26	2	15	t	1
644	607	2026-09-26	2	15	t	1
645	609	2026-09-26	2	15	f	1
646	610	2026-09-26	2	15	t	1
647	611	2026-09-26	2	15	t	1
4003	1181	2026-10-31	1	22	t	1
649	612	2026-09-26	2	15	f	1
4004	1051	2026-10-31	1	22	t	1
651	614	2026-09-26	2	15	f	1
652	615	2026-09-26	2	15	t	1
653	616	2026-09-26	2	15	f	1
4005	960	2026-10-31	1	22	t	1
655	618	2026-09-26	2	15	t	1
656	619	2026-09-26	2	15	t	1
657	862	2026-09-26	2	15	t	1
658	620	2026-09-26	2	15	t	1
659	940	2026-09-26	2	15	t	1
660	621	2026-09-26	2	15	t	1
661	937	2026-09-26	2	15	t	1
662	622	2026-09-26	2	15	t	1
663	623	2026-09-26	2	15	t	1
664	624	2026-09-26	2	15	t	1
665	625	2026-09-26	2	15	t	1
666	626	2026-09-26	2	15	t	1
667	627	2026-09-26	2	15	t	1
668	628	2026-09-26	2	15	t	1
4006	407	2026-10-31	1	22	t	1
670	630	2026-09-26	2	15	f	1
671	631	2026-09-26	2	15	t	1
672	938	2026-09-26	2	15	t	1
4007	1004	2026-10-31	1	22	t	1
674	633	2026-09-26	2	15	t	1
675	529	2026-09-26	2	13	f	1
676	530	2026-09-26	2	13	t	1
2525	753	2026-10-21	1	12	t	1
678	843	2026-09-26	2	13	t	1
2526	518	2026-10-21	1	12	t	1
2527	519	2026-10-21	1	12	t	1
681	858	2026-09-26	2	13	t	1
682	534	2026-09-26	2	13	t	1
2528	521	2026-10-21	1	12	t	1
2529	523	2026-10-21	1	12	t	1
685	842	2026-09-26	2	13	t	1
2530	1074	2026-10-21	1	12	t	1
2531	528	2026-10-21	1	12	t	1
2532	526	2026-10-21	1	12	t	1
689	539	2026-09-26	2	13	t	1
690	540	2026-09-26	2	13	t	1
2986	784	2026-10-24	1	20	t	1
2987	1140	2026-10-24	1	20	t	1
693	543	2026-09-26	2	13	f	1
2988	892	2026-10-24	1	20	t	1
695	545	2026-09-26	2	13	t	1
2989	95	2026-10-24	1	20	t	1
697	935	2026-09-26	2	13	t	1
2990	96	2026-10-24	1	20	t	1
699	548	2026-09-26	2	13	f	1
700	549	2026-09-26	2	13	t	1
701	574	2026-09-26	2	13	t	1
702	550	2026-09-26	2	13	t	1
2991	839	2026-10-24	1	20	t	1
704	936	2026-09-26	2	13	t	1
2992	1128	2026-10-24	1	20	t	1
706	552	2026-09-26	2	13	f	1
2993	97	2026-10-24	1	20	t	1
708	838	2026-09-26	2	13	t	1
709	553	2026-09-26	2	13	t	1
4008	409	2026-10-31	1	22	t	1
4009	911	2026-10-31	1	22	t	1
712	634	2026-09-26	2	16	t	1
4010	410	2026-10-31	1	22	t	1
4011	1053	2026-10-31	1	22	t	1
715	636	2026-09-26	2	16	t	1
716	637	2026-09-26	2	16	f	1
717	933	2026-09-26	2	16	t	1
4012	1059	2026-10-31	1	22	f	1
719	639	2026-09-26	2	16	t	1
720	864	2026-09-26	2	16	t	1
721	640	2026-09-26	2	16	t	1
722	641	2026-09-26	2	16	t	1
723	939	2026-09-26	2	16	t	1
724	642	2026-09-26	2	16	t	1
725	643	2026-09-26	2	16	t	1
4013	415	2026-10-31	1	22	f	1
727	941	2026-09-26	2	16	t	1
728	644	2026-09-26	2	16	f	1
729	645	2026-09-26	2	16	f	1
4014	1055	2026-10-31	1	22	t	1
4015	418	2026-10-31	1	22	f	1
4016	419	2026-10-31	1	22	t	1
733	866	2026-09-26	2	16	t	1
734	648	2026-09-26	2	16	t	1
4017	1289	2026-10-31	1	22	t	1
736	958	2026-09-26	2	16	t	1
737	649	2026-09-26	2	16	t	1
738	650	2026-09-26	2	16	t	1
739	651	2026-09-26	2	16	t	1
740	942	2026-09-26	2	16	t	1
4018	421	2026-10-31	1	22	t	1
742	653	2026-09-26	2	16	t	1
4019	422	2026-10-31	1	22	t	1
744	654	2026-09-26	2	16	f	1
745	655	2026-09-26	2	16	t	1
746	656	2026-09-26	2	16	t	1
4020	423	2026-10-31	1	22	f	1
748	658	2026-09-26	2	16	t	1
749	943	2026-09-26	2	16	t	1
4021	425	2026-10-31	1	22	f	1
4022	1076	2026-10-31	1	22	f	1
752	660	2026-09-26	2	16	t	1
753	934	2026-09-26	2	16	t	1
4023	1005	2026-10-31	1	22	t	1
755	662	2026-09-26	2	16	t	1
756	663	2026-09-26	2	16	f	1
757	664	2026-09-26	2	16	t	1
4024	1065	2026-10-31	1	22	t	1
4025	1256	2026-10-31	1	22	f	1
2994	841	2026-10-24	1	20	t	1
2995	808	2026-10-24	1	20	t	1
2996	101	2026-10-24	1	20	t	1
763	41	2026-09-26	1	1	t	1
764	42	2026-09-26	1	1	t	1
2997	100	2026-10-24	1	20	t	1
766	43	2026-09-26	1	1	t	1
767	5	2026-09-26	1	1	f	1
2998	1132	2026-10-24	1	20	t	1
2999	103	2026-10-24	1	20	t	1
3000	844	2026-10-24	1	20	t	1
3001	111	2026-10-24	1	20	t	1
772	7	2026-09-26	1	1	t	1
773	48	2026-09-26	1	1	t	1
3002	815	2026-10-24	1	20	t	1
775	8	2026-09-26	1	1	t	1
776	887	2026-09-26	1	1	t	1
777	49	2026-09-26	1	1	t	1
3003	1131	2026-10-24	1	20	t	1
779	51	2026-09-26	1	1	t	1
780	888	2026-09-26	1	1	t	1
3004	1168	2026-10-24	1	20	t	1
782	10	2026-09-26	1	1	t	1
783	52	2026-09-26	1	1	t	1
784	11	2026-09-26	1	1	t	1
785	53	2026-09-26	1	1	t	1
3005	1247	2026-10-24	1	20	t	1
787	55	2026-09-26	1	1	t	1
788	12	2026-09-26	1	1	t	1
3006	113	2026-10-24	1	20	t	1
3007	876	2026-10-24	1	20	t	1
791	15	2026-09-26	1	1	f	1
792	56	2026-09-26	1	1	t	1
793	57	2026-09-26	1	1	f	1
794	969	2026-09-26	1	1	t	1
795	16	2026-09-26	1	1	t	1
796	58	2026-09-26	1	1	t	1
3008	116	2026-10-24	1	20	t	1
798	762	2026-09-26	1	1	t	1
3009	115	2026-10-24	1	20	t	1
3010	882	2026-10-24	1	20	t	1
3011	1027	2026-10-24	1	20	t	1
802	19	2026-09-26	1	1	f	1
3012	120	2026-10-24	1	20	f	1
804	21	2026-09-26	1	1	t	1
3013	1025	2026-10-24	1	20	t	1
806	69	2026-09-26	1	1	t	1
3014	828	2026-10-24	1	20	t	1
3015	87	2026-10-24	1	20	t	1
3016	1167	2026-10-24	1	20	t	1
810	62	2026-09-26	1	1	f	1
3017	890	2026-10-24	1	20	t	1
812	959	2026-09-26	1	1	t	1
3018	891	2026-10-24	1	20	t	1
814	64	2026-09-26	1	1	t	1
815	66	2026-09-26	1	1	t	1
3019	1248	2026-10-24	1	20	t	1
2533	885	2026-10-24	1	2	t	1
2534	896	2026-10-24	1	2	t	1
819	26	2026-09-26	1	1	f	1
820	68	2026-09-26	1	1	t	1
2535	148	2026-10-24	1	2	t	1
2536	150	2026-10-24	1	2	t	1
823	71	2026-09-26	1	1	t	1
824	72	2026-09-26	1	1	t	1
825	29	2026-09-26	1	1	t	1
2537	151	2026-10-24	1	2	f	1
827	30	2026-09-26	1	1	t	1
828	77	2026-09-26	1	1	t	1
2538	195	2026-10-24	1	2	t	1
2539	152	2026-10-24	1	2	t	1
2540	153	2026-10-24	1	2	f	1
832	78	2026-09-26	1	1	f	1
2541	1127	2026-10-24	1	2	t	1
2542	1146	2026-10-24	1	2	t	1
2543	156	2026-10-24	1	2	t	1
836	81	2026-09-26	1	1	t	1
837	886	2026-09-26	1	1	t	1
838	32	2026-09-26	1	1	f	1
2544	1126	2026-10-24	1	2	t	1
2545	1235	2026-10-24	1	2	f	1
841	84	2026-09-26	1	1	t	1
2546	157	2026-10-24	1	2	t	1
844	34	2026-09-26	1	1	t	1
2547	158	2026-10-24	1	2	t	1
2548	162	2026-10-24	1	2	t	1
847	37	2026-09-26	1	1	t	1
2549	872	2026-10-24	1	2	t	1
2550	895	2026-10-24	1	2	t	1
2551	164	2026-10-24	1	2	t	1
2552	165	2026-10-24	1	2	t	1
852	892	2026-09-26	1	20	t	1
2553	166	2026-10-24	1	2	t	1
2554	167	2026-10-24	1	2	t	1
2555	168	2026-10-24	1	2	t	1
856	95	2026-09-26	1	20	t	1
857	96	2026-09-26	1	20	t	1
858	839	2026-09-26	1	20	t	1
859	97	2026-09-26	1	20	t	1
860	841	2026-09-26	1	20	t	1
2556	688	2026-10-24	1	2	f	1
2557	173	2026-10-24	1	2	t	1
2558	1151	2026-10-24	1	2	t	1
2559	174	2026-10-24	1	2	t	1
865	808	2026-09-26	1	20	f	1
2560	1170	2026-10-24	1	2	t	1
2561	176	2026-10-24	1	2	t	1
868	100	2026-09-26	1	20	t	1
869	101	2026-09-26	1	20	t	1
2562	177	2026-10-24	1	2	t	1
2563	178	2026-10-24	1	2	t	1
872	103	2026-09-26	1	20	t	1
2564	1153	2026-10-24	1	2	t	1
2565	184	2026-10-24	1	2	t	1
2566	1234	2026-10-24	1	2	t	1
2567	186	2026-10-24	1	2	t	1
2568	1125	2026-10-24	1	2	t	1
2569	894	2026-10-24	1	2	f	1
2570	187	2026-10-24	1	2	t	1
2571	188	2026-10-24	1	2	t	1
2572	189	2026-10-24	1	2	t	1
882	844	2026-09-26	1	20	t	1
2573	1224	2026-10-24	1	2	t	1
3020	127	2026-10-24	1	20	t	1
885	111	2026-09-26	1	20	t	1
3021	128	2026-10-24	1	20	t	1
887	113	2026-09-26	1	20	t	1
3022	820	2026-10-24	1	20	t	1
889	876	2026-09-26	1	20	t	1
890	116	2026-09-26	1	20	t	1
891	115	2026-09-26	1	20	t	1
892	882	2026-09-26	1	20	t	1
3023	1026	2026-10-24	1	20	t	1
3024	1223	2026-10-24	1	20	t	1
3025	1104	2026-10-24	1	20	t	1
3026	1103	2026-10-24	1	20	t	1
897	120	2026-09-26	1	20	f	1
3027	135	2026-10-24	1	20	t	1
3028	137	2026-10-24	1	20	t	1
3029	840	2026-10-24	1	20	t	1
901	87	2026-09-26	1	20	t	1
3030	1164	2026-10-24	1	20	t	1
3031	1130	2026-10-24	1	20	t	1
3032	1062	2026-10-24	1	20	t	1
3033	32	2026-10-24	1	20	f	1
906	890	2026-09-26	1	20	t	1
907	891	2026-09-26	1	20	t	1
3034	970	2026-10-24	1	20	t	1
3035	1249	2026-10-24	1	20	t	1
910	127	2026-09-26	1	20	t	1
911	128	2026-09-26	1	20	t	1
3036	141	2026-10-24	1	20	t	1
3037	837	2026-10-24	1	20	t	1
914	820	2026-09-26	1	20	t	1
3038	682	2026-10-24	1	20	t	1
3039	142	2026-10-24	1	20	t	1
917	133	2026-09-26	1	20	f	1
3040	143	2026-10-24	1	20	f	1
3041	893	2026-10-24	1	20	t	1
920	135	2026-09-26	1	20	t	1
3042	889	2026-10-24	1	20	t	1
3167	332	2026-10-28	1	4	t	1
923	137	2026-09-26	1	20	t	1
3168	1007	2026-10-28	1	4	t	1
3169	323	2026-10-28	1	4	t	1
926	840	2026-09-26	1	20	t	1
3170	324	2026-10-28	1	4	t	1
3171	326	2026-10-28	1	4	t	1
3172	333	2026-10-28	1	4	t	1
930	141	2026-09-26	1	20	t	1
931	837	2026-09-26	1	20	t	1
3173	328	2026-10-28	1	4	t	1
3174	334	2026-10-28	1	4	t	1
934	682	2026-09-26	1	20	t	1
3175	330	2026-10-28	1	4	t	1
936	142	2026-09-26	1	20	t	1
937	143	2026-09-26	1	20	f	1
938	893	2026-09-26	1	20	t	1
3287	1221	2026-10-28	1	12	t	1
3288	753	2026-10-28	1	12	t	1
941	889	2026-09-26	1	20	t	1
3289	518	2026-10-28	1	12	t	1
943	970	2026-09-26	1	20	t	1
843	873	2026-09-26	1	1	t	1
945	880	2026-09-26	1	5	t	1
3290	519	2026-10-28	1	12	t	1
947	870	2026-09-26	1	5	t	1
948	877	2026-09-26	1	5	t	1
949	971	2026-09-26	1	5	t	1
950	878	2026-09-26	1	6	t	1
951	925	2026-09-26	1	6	t	1
952	926	2026-09-26	1	6	t	1
953	973	2026-09-26	1	6	t	1
954	924	2026-09-26	1	6	t	1
955	972	2026-09-26	1	6	t	1
956	913	2026-09-26	1	23	t	1
957	914	2026-09-26	1	23	t	1
958	855	2026-09-26	1	23	t	1
959	470	2026-09-26	1	23	t	1
960	848	2026-09-26	1	23	t	1
961	851	2026-09-26	1	23	t	1
962	923	2026-09-26	1	23	t	1
963	871	2026-09-26	1	23	t	1
964	915	2026-09-26	1	23	t	1
965	927	2026-09-26	1	23	t	1
966	974	2026-09-26	1	23	t	1
967	916	2026-09-26	1	23	t	1
2574	908	2026-10-24	1	3	t	1
969	284	2026-09-26	1	18	t	1
970	285	2026-09-26	1	18	t	1
971	305	2026-09-26	1	18	t	1
972	306	2026-09-26	1	18	f	1
973	286	2026-09-26	1	18	t	1
974	287	2026-09-26	1	18	t	1
975	288	2026-09-26	1	18	t	1
2575	930	2026-10-24	1	3	t	1
977	290	2026-09-26	1	18	t	1
2576	1018	2026-10-24	1	3	t	1
979	307	2026-09-26	1	18	t	1
2577	905	2026-10-24	1	3	t	1
981	309	2026-09-26	1	18	f	1
2578	1028	2026-10-24	1	3	t	1
2579	1031	2026-10-24	1	3	t	1
2580	257	2026-10-24	1	3	t	1
985	293	2026-09-26	1	18	t	1
986	962	2026-09-26	1	18	t	1
2581	238	2026-10-24	1	3	f	1
988	310	2026-09-26	1	18	t	1
989	312	2026-09-26	1	18	t	1
2582	1016	2026-10-24	1	3	f	1
2583	931	2026-10-24	1	3	f	1
992	294	2026-09-26	1	18	t	1
993	295	2026-09-26	1	18	t	1
994	701	2026-09-26	1	18	f	1
995	313	2026-09-26	1	18	t	1
2584	903	2026-10-24	1	3	t	1
997	314	2026-09-26	1	18	t	1
2585	1035	2026-10-24	1	3	t	1
2586	241	2026-10-24	1	3	t	1
2587	242	2026-10-24	1	3	t	1
2588	1024	2026-10-24	1	3	t	1
2590	243	2026-10-24	1	3	t	1
1004	300	2026-09-26	1	18	t	1
2591	245	2026-10-24	1	3	t	1
1006	302	2026-09-26	1	18	t	1
1007	303	2026-09-26	1	18	t	1
2592	906	2026-10-24	1	3	t	1
1009	910	2026-09-26	1	18	t	1
1010	874	2026-09-26	1	18	t	1
1011	317	2026-09-26	1	18	t	1
1012	318	2026-09-26	1	18	t	1
2593	968	2026-10-24	1	3	t	1
2594	1029	2026-10-24	1	3	t	1
1015	908	2026-09-26	1	3	t	1
1016	930	2026-09-26	1	3	t	1
2595	247	2026-10-24	1	3	t	1
1018	255	2026-09-26	1	3	f	1
2596	907	2026-10-24	1	3	t	1
2597	901	2026-10-24	1	3	t	1
1021	905	2026-09-26	1	3	t	1
2598	928	2026-10-24	1	3	t	1
2599	900	2026-10-24	1	3	t	1
1024	257	2026-09-26	1	3	t	1
1025	238	2026-09-26	1	3	t	1
1026	931	2026-09-26	1	3	t	1
2600	1021	2026-10-24	1	3	t	1
2601	929	2026-10-24	1	3	t	1
2602	1015	2026-10-24	1	3	f	1
1030	903	2026-09-26	1	3	t	1
2603	1039	2026-10-24	1	3	t	1
1032	241	2026-09-26	1	3	t	1
1033	242	2026-09-26	1	3	t	1
2604	263	2026-10-24	1	3	t	1
1035	243	2026-09-26	1	3	t	1
1036	244	2026-09-26	1	3	t	1
1037	245	2026-09-26	1	3	t	1
1038	906	2026-09-26	1	3	t	1
1039	968	2026-09-26	1	3	t	1
2605	1019	2026-10-24	1	3	t	1
1041	247	2026-09-26	1	3	t	1
2606	251	2026-10-24	1	3	t	1
2607	1017	2026-10-24	1	3	t	1
1044	907	2026-09-26	1	3	t	1
1045	901	2026-09-26	1	3	t	1
1046	928	2026-09-26	1	3	t	1
2608	1032	2026-10-24	1	3	t	1
2609	902	2026-10-24	1	3	t	1
1049	900	2026-09-26	1	3	t	1
2610	264	2026-10-24	1	3	t	1
2611	1022	2026-10-24	1	3	t	1
2612	269	2026-10-24	1	3	t	1
1053	262	2026-09-26	1	3	f	1
1054	929	2026-09-26	1	3	t	1
1055	263	2026-09-26	1	3	t	1
1056	251	2026-09-26	1	3	t	1
2613	252	2026-10-24	1	3	t	1
1058	902	2026-09-26	1	3	t	1
1059	264	2026-09-26	1	3	t	1
2614	1119	2026-10-24	1	3	t	1
2615	270	2026-10-24	1	3	t	1
2616	1040	2026-10-24	1	3	t	1
2617	1023	2026-10-24	1	3	t	1
2618	904	2026-10-24	1	3	t	1
1065	269	2026-09-26	1	3	t	1
1066	252	2026-09-26	1	3	t	1
1067	270	2026-09-26	1	3	t	1
2619	1037	2026-10-24	1	3	t	1
2620	849	2026-10-24	1	3	t	1
1070	904	2026-09-26	1	3	t	1
1071	849	2026-09-26	1	3	t	1
2621	1042	2026-10-24	1	3	t	1
1073	272	2026-09-26	1	3	t	1
1074	728	2026-09-26	1	3	t	1
2622	1033	2026-10-24	1	3	t	1
2623	1038	2026-10-24	1	3	t	1
1077	846	2026-09-26	1	3	t	1
2624	1030	2026-10-24	1	3	t	1
1079	275	2026-09-26	1	3	f	1
1080	276	2026-09-26	1	3	t	1
2625	1034	2026-10-24	1	3	f	1
2626	272	2026-10-24	1	3	t	1
1083	279	2026-09-26	1	3	f	1
2627	728	2026-10-24	1	3	t	1
2628	846	2026-10-24	1	3	t	1
1086	281	2026-09-26	1	3	f	1
2629	1041	2026-10-24	1	3	f	1
1088	975	2026-09-26	1	3	t	1
1089	447	2026-09-26	1	24	t	1
2630	275	2026-10-24	1	3	t	1
1091	449	2026-09-26	1	24	t	1
1092	450	2026-09-26	1	24	f	1
1093	452	2026-09-26	1	24	t	1
2631	975	2026-10-24	1	3	t	1
1095	454	2026-09-26	1	24	f	1
1096	739	2026-09-26	1	24	t	1
1097	456	2026-09-26	1	24	t	1
1098	457	2026-09-26	1	24	t	1
1099	458	2026-09-26	1	24	t	1
1100	459	2026-09-26	1	8	f	1
2632	276	2026-10-24	1	3	t	1
2633	1014	2026-10-24	1	3	t	1
1103	462	2026-09-26	1	8	t	1
1104	732	2026-09-26	1	8	t	1
1105	733	2026-09-26	1	8	t	1
1106	463	2026-09-26	1	8	t	1
1107	464	2026-09-26	1	8	t	1
2634	1020	2026-10-24	1	3	t	1
1109	734	2026-09-26	1	8	f	1
3043	880	2026-10-24	1	5	t	1
1111	467	2026-09-26	1	8	t	1
1112	468	2026-09-26	1	8	t	1
1113	845	2026-09-26	1	8	t	1
3044	870	2026-10-24	1	5	t	1
3045	877	2026-10-24	1	5	t	1
1116	875	2026-09-26	1	8	t	1
1117	469	2026-09-26	1	8	t	1
1118	737	2026-09-26	1	8	t	1
1119	471	2026-09-26	1	8	t	1
3046	1060	2026-10-24	1	5	t	1
1121	852	2026-09-26	1	8	t	1
1122	451	2026-09-26	1	8	t	1
3047	971	2026-10-24	1	5	t	1
1124	474	2026-09-26	1	8	t	1
1125	920	2026-09-26	1	8	t	1
1126	475	2026-09-26	1	8	t	1
1127	919	2026-09-26	1	8	f	1
3176	335	2026-10-28	1	17	t	1
3177	884	2026-10-28	1	17	t	1
1130	478	2026-09-26	1	8	t	1
3178	337	2026-10-28	1	17	t	1
3179	339	2026-10-28	1	17	t	1
1133	480	2026-09-26	1	8	t	1
3180	708	2026-10-28	1	17	t	1
1135	918	2026-09-26	1	8	t	1
3181	397	2026-10-28	1	17	t	1
3182	847	2026-10-28	1	17	t	1
3183	710	2026-10-28	1	17	t	1
1139	742	2026-09-26	1	8	t	1
1140	853	2026-09-26	1	8	t	1
1141	482	2026-09-26	1	8	t	1
3184	344	2026-10-28	1	17	t	1
1143	951	2026-09-26	1	8	f	1
3185	345	2026-10-28	1	17	t	1
1145	485	2026-09-26	1	8	t	1
1146	486	2026-09-26	1	8	t	1
1147	487	2026-09-26	1	8	t	1
1148	881	2026-09-26	1	8	t	1
1149	488	2026-09-26	1	8	t	1
1150	489	2026-09-26	1	8	t	1
3186	346	2026-10-28	1	17	t	1
1152	917	2026-09-26	1	8	t	1
1153	964	2026-09-26	1	19	t	1
1154	897	2026-09-26	1	19	t	1
1155	190	2026-09-26	1	19	f	1
1156	191	2026-09-26	1	19	t	1
3187	347	2026-10-28	1	17	t	1
1158	193	2026-09-26	1	19	t	1
1159	194	2026-09-26	1	19	t	1
1160	195	2026-09-26	1	19	f	1
1161	196	2026-09-26	1	19	t	1
3188	348	2026-10-28	1	17	t	1
1163	198	2026-09-26	1	19	t	1
3189	879	2026-10-28	1	17	t	1
3190	355	2026-10-28	1	17	t	1
1166	200	2026-09-26	1	19	t	1
1167	689	2026-09-26	1	19	t	1
1168	202	2026-09-26	1	19	t	1
1169	966	2026-09-26	1	19	t	1
1170	201	2026-09-26	1	19	t	1
1171	203	2026-09-26	1	19	t	1
1172	204	2026-09-26	1	19	f	1
3191	358	2026-10-28	1	17	t	1
1174	206	2026-09-26	1	19	t	1
1175	207	2026-09-26	1	19	f	1
1176	208	2026-09-26	1	19	t	1
1177	209	2026-09-26	1	19	t	1
3192	954	2026-10-28	1	17	f	1
1179	967	2026-09-26	1	19	t	1
3193	416	2026-10-28	1	17	f	1
3194	361	2026-10-28	1	17	f	1
1182	688	2026-09-26	1	19	f	1
3195	364	2026-10-28	1	17	t	1
1184	214	2026-09-26	1	19	f	1
3196	365	2026-10-28	1	17	t	1
1186	215	2026-09-26	1	19	t	1
1187	899	2026-09-26	1	19	f	1
1188	216	2026-09-26	1	19	f	1
3197	1138	2026-10-28	1	17	t	1
1190	218	2026-09-26	1	19	t	1
1191	932	2026-09-26	1	19	t	1
3198	369	2026-10-28	1	17	t	1
3199	371	2026-10-28	1	17	f	1
1194	221	2026-09-26	1	19	t	1
1195	898	2026-09-26	1	19	t	1
1196	687	2026-09-26	1	19	t	1
1197	222	2026-09-26	1	19	t	1
3200	883	2026-10-28	1	17	t	1
1199	224	2026-09-26	1	19	t	1
3201	952	2026-10-28	1	17	t	1
1201	226	2026-09-26	1	19	t	1
1202	227	2026-09-26	1	19	t	1
3202	717	2026-10-28	1	17	t	1
3203	375	2026-10-28	1	17	t	1
3204	1137	2026-10-28	1	17	t	1
1206	231	2026-09-26	1	19	t	1
1207	232	2026-09-26	1	19	f	1
3205	379	2026-10-28	1	17	t	1
1209	885	2026-09-26	1	2	t	1
1210	896	2026-09-26	1	2	t	1
3206	380	2026-10-28	1	17	f	1
3207	381	2026-10-28	1	17	t	1
1213	148	2026-09-26	1	2	t	1
3208	953	2026-10-28	1	17	t	1
1215	150	2026-09-26	1	2	t	1
1216	151	2026-09-26	1	2	t	1
1217	152	2026-09-26	1	2	f	1
1218	153	2026-09-26	1	2	t	1
3209	965	2026-10-28	1	17	t	1
3210	912	2026-10-28	1	17	f	1
1221	156	2026-09-26	1	2	f	1
3211	385	2026-10-28	1	17	t	1
1223	157	2026-09-26	1	2	t	1
1224	158	2026-09-26	1	2	t	1
3212	389	2026-10-28	1	22	t	1
2635	1046	2026-10-24	1	8	t	1
2636	459	2026-10-24	1	8	t	1
1228	162	2026-09-26	1	2	t	1
1229	872	2026-09-26	1	2	t	1
2637	462	2026-10-24	1	8	f	1
2638	1105	2026-10-24	1	8	t	1
1232	895	2026-09-26	1	2	t	1
1233	164	2026-09-26	1	2	t	1
1234	165	2026-09-26	1	2	t	1
1235	166	2026-09-26	1	2	t	1
1236	167	2026-09-26	1	2	t	1
1237	168	2026-09-26	1	2	t	1
2639	732	2026-10-24	1	8	t	1
2640	733	2026-10-24	1	8	t	1
2641	463	2026-10-24	1	8	t	1
2642	464	2026-10-24	1	8	t	1
1242	173	2026-09-26	1	2	t	1
1243	174	2026-09-26	1	2	f	1
2643	1254	2026-10-24	1	8	t	1
1245	176	2026-09-26	1	2	t	1
1246	177	2026-09-26	1	2	t	1
1247	178	2026-09-26	1	2	t	1
2644	1136	2026-10-24	1	8	t	1
2645	1063	2026-10-24	1	8	t	1
2646	734	2026-10-24	1	8	t	1
2647	1012	2026-10-24	1	8	f	1
2648	1188	2026-10-24	1	8	t	1
1253	184	2026-09-26	1	2	t	1
2649	467	2026-10-24	1	8	t	1
1255	186	2026-09-26	1	2	f	1
2650	468	2026-10-24	1	8	t	1
1257	894	2026-09-26	1	2	t	1
1258	187	2026-09-26	1	2	t	1
1259	188	2026-09-26	1	2	t	1
1260	189	2026-09-26	1	2	t	1
1261	976	2026-09-26	1	19	t	1
1262	490	2026-09-26	1	11	t	1
1263	491	2026-09-26	1	11	t	1
1264	492	2026-09-26	1	11	t	1
2651	1047	2026-10-24	1	8	t	1
2652	845	2026-10-24	1	8	t	1
2653	1107	2026-10-24	1	8	t	1
1268	494	2026-09-26	1	11	t	1
2654	875	2026-10-24	1	8	t	1
2655	469	2026-10-24	1	8	t	1
1271	497	2026-09-26	1	11	t	1
2656	737	2026-10-24	1	8	t	1
1273	746	2026-09-26	1	12	t	1
2657	471	2026-10-24	1	8	t	1
1275	499	2026-09-26	1	12	t	1
1276	500	2026-09-26	1	12	t	1
1277	501	2026-09-26	1	12	t	1
1278	502	2026-09-26	1	12	t	1
2658	852	2026-10-24	1	8	t	1
2659	451	2026-10-24	1	8	t	1
1281	507	2026-09-26	1	12	t	1
1282	503	2026-09-26	1	12	t	1
2660	1263	2026-10-24	1	8	t	1
1284	504	2026-09-26	1	12	t	1
2661	1187	2026-10-24	1	8	t	1
1286	508	2026-09-26	1	12	t	1
2662	1048	2026-10-24	1	8	t	1
1288	509	2026-09-26	1	12	t	1
2663	474	2026-10-24	1	8	t	1
2664	1255	2026-10-24	1	8	t	1
1291	750	2026-09-26	1	12	t	1
2665	920	2026-10-24	1	8	t	1
2666	475	2026-10-24	1	8	f	1
2667	1134	2026-10-24	1	8	f	1
1295	514	2026-09-26	1	12	t	1
1296	515	2026-09-26	1	12	t	1
2668	919	2026-10-24	1	8	t	1
2669	478	2026-10-24	1	8	f	1
1299	753	2026-09-26	1	12	t	1
1300	518	2026-09-26	1	12	t	1
2670	480	2026-10-24	1	8	t	1
1302	519	2026-09-26	1	12	t	1
2671	918	2026-10-24	1	8	t	1
1304	521	2026-09-26	1	12	t	1
2672	1013	2026-10-24	1	8	t	1
1306	523	2026-09-26	1	12	t	1
2673	742	2026-10-24	1	8	t	1
2674	853	2026-10-24	1	8	t	1
2675	482	2026-10-24	1	8	t	1
1310	526	2026-09-26	1	12	t	1
1311	528	2026-09-26	1	12	t	1
2676	951	2026-10-24	1	8	t	1
2677	485	2026-10-24	1	8	t	1
1314	389	2026-09-26	1	22	t	1
1315	391	2026-09-26	1	22	t	1
2678	1106	2026-10-24	1	8	t	1
2679	486	2026-10-24	1	8	t	1
2680	1186	2026-10-24	1	8	t	1
1319	395	2026-09-26	1	22	t	1
2681	487	2026-10-24	1	8	t	1
2682	977	2026-10-24	1	8	t	1
1323	960	2026-09-26	1	22	t	1
2683	881	2026-10-24	1	8	t	1
1325	399	2026-09-26	1	22	f	1
2684	489	2026-10-24	1	8	t	1
1327	401	2026-09-26	1	22	f	1
1328	402	2026-09-26	1	22	t	1
2685	488	2026-10-24	1	8	t	1
2686	917	2026-10-24	1	8	t	1
1331	403	2026-09-26	1	22	t	1
1332	404	2026-09-26	1	22	t	1
3048	878	2026-10-24	1	6	t	1
3049	925	2026-10-24	1	6	t	1
3050	1251	2026-10-24	1	6	t	1
3051	1250	2026-10-24	1	6	t	1
1337	407	2026-09-26	1	22	f	1
3052	926	2026-10-24	1	6	t	1
1339	409	2026-09-26	1	22	f	1
1340	911	2026-09-26	1	22	t	1
1341	410	2026-09-26	1	22	t	1
3053	1180	2026-10-24	1	6	t	1
3054	973	2026-10-24	1	6	t	1
3055	924	2026-10-24	1	6	t	1
3056	972	2026-10-24	1	6	t	1
3213	1069	2026-10-28	1	22	f	1
3214	391	2026-10-28	1	22	t	1
3215	1050	2026-10-28	1	22	t	1
1349	415	2026-09-26	1	22	t	1
1350	416	2026-09-26	1	22	f	1
3216	395	2026-10-28	1	22	t	1
1352	418	2026-09-26	1	22	t	1
1353	419	2026-09-26	1	22	t	1
3217	396	2026-10-28	1	22	t	1
3218	399	2026-10-28	1	22	t	1
1356	421	2026-09-26	1	22	t	1
1357	422	2026-09-26	1	22	t	1
1358	423	2026-09-26	1	22	t	1
3219	1054	2026-10-28	1	22	t	1
3220	401	2026-10-28	1	22	f	1
1361	425	2026-09-26	1	22	t	1
1321	397	2026-09-26	1	22	t	1
2687	447	2026-10-24	1	24	t	1
2688	1253	2026-10-24	1	24	t	1
2689	449	2026-10-24	1	24	t	1
2690	450	2026-10-24	1	24	t	1
2691	452	2026-10-24	1	24	t	1
2692	454	2026-10-24	1	24	t	1
2693	739	2026-10-24	1	24	t	1
1369	432	2026-09-26	1	22	f	1
2694	1108	2026-10-24	1	24	t	1
1371	434	2026-09-26	1	22	t	1
2695	1185	2026-10-24	1	24	f	1
2696	457	2026-10-24	1	24	t	1
1374	729	2026-09-26	1	22	f	1
2697	456	2026-10-24	1	24	t	1
2698	458	2026-10-24	1	24	t	1
3057	991	2026-10-24	2	13	t	1
3058	529	2026-10-24	2	13	t	1
3059	988	2026-10-24	2	13	t	1
3060	530	2026-10-24	2	13	t	1
3061	843	2026-10-24	2	13	t	1
3062	1193	2026-10-24	2	13	f	1
1383	443	2026-09-26	1	22	t	1
3063	858	2026-10-24	2	13	f	1
1385	965	2026-09-26	1	22	f	1
3064	534	2026-10-24	2	13	t	1
1387	912	2026-09-26	1	22	f	1
3065	1079	2026-10-24	2	13	t	1
3066	1082	2026-10-24	2	13	t	1
3067	842	2026-10-24	2	13	t	1
3068	1081	2026-10-24	2	13	t	1
1392	322	2026-09-26	1	4	t	1
1393	332	2026-09-26	1	4	t	1
1394	323	2026-09-26	1	4	t	1
1395	324	2026-09-26	1	4	t	1
3069	995	2026-10-24	2	13	t	1
1397	326	2026-09-26	1	4	t	1
3070	994	2026-10-24	2	13	t	1
1399	333	2026-09-26	1	4	t	1
1400	328	2026-09-26	1	4	t	1
1401	334	2026-09-26	1	4	t	1
3071	539	2026-10-24	2	13	t	1
1403	330	2026-09-26	1	4	f	1
1404	335	2026-09-26	1	17	f	1
1405	884	2026-09-26	1	17	t	1
3072	540	2026-10-24	2	13	t	1
1407	337	2026-09-26	1	17	t	1
3073	1189	2026-10-24	2	13	t	1
1409	339	2026-09-26	1	17	t	1
3074	543	2026-10-24	2	13	t	1
1411	708	2026-09-26	1	17	f	1
3075	545	2026-10-24	2	13	t	1
3076	1226	2026-10-24	2	13	t	1
1414	847	2026-09-26	1	17	t	1
3077	1200	2026-10-24	2	13	t	1
1416	710	2026-09-26	1	17	f	1
3078	935	2026-10-24	2	13	t	1
3079	548	2026-10-24	2	13	t	1
1419	344	2026-09-26	1	17	t	1
1420	345	2026-09-26	1	17	t	1
1421	346	2026-09-26	1	17	f	1
1422	347	2026-09-26	1	17	t	1
1423	348	2026-09-26	1	17	t	1
3080	549	2026-10-24	2	13	t	1
1425	879	2026-09-26	1	17	t	1
3081	574	2026-10-24	2	13	t	1
3082	550	2026-10-24	2	13	t	1
3083	936	2026-10-24	2	13	t	1
3084	1195	2026-10-24	2	13	t	1
3085	552	2026-10-24	2	13	t	1
1431	355	2026-09-26	1	17	t	1
3086	1001	2026-10-24	2	13	t	1
3087	838	2026-10-24	2	13	t	1
3088	1078	2026-10-24	2	13	t	1
1435	358	2026-09-26	1	17	t	1
3089	553	2026-10-24	2	13	t	1
3090	1080	2026-10-24	2	13	t	1
1438	954	2026-09-26	1	17	t	1
3091	1190	2026-10-24	2	13	t	1
1440	361	2026-09-26	1	17	t	1
3221	1052	2026-10-28	1	22	t	1
3222	402	2026-10-28	1	22	t	1
3223	1008	2026-10-28	1	22	t	1
3224	404	2026-10-28	1	22	f	1
1445	364	2026-09-26	1	17	t	1
1446	365	2026-09-26	1	17	t	1
3225	403	2026-10-28	1	22	t	1
3226	1072	2026-10-28	1	22	t	1
3227	1181	2026-10-28	1	22	t	1
3228	1051	2026-10-28	1	22	t	1
3229	960	2026-10-28	1	22	t	1
1452	369	2026-09-26	1	17	f	1
3230	407	2026-10-28	1	22	t	1
1454	371	2026-09-26	1	17	t	1
3231	1004	2026-10-28	1	22	t	1
1456	883	2026-09-26	1	17	t	1
3232	409	2026-10-28	1	22	t	1
1458	952	2026-09-26	1	17	t	1
3233	911	2026-10-28	1	22	t	1
3234	410	2026-10-28	1	22	t	1
3235	1053	2026-10-28	1	22	t	1
1462	717	2026-09-26	1	17	t	1
1463	375	2026-09-26	1	17	t	1
3236	1059	2026-10-28	1	22	f	1
3237	415	2026-10-28	1	22	f	1
3238	1055	2026-10-28	1	22	t	1
3239	418	2026-10-28	1	22	t	1
1468	379	2026-09-26	1	17	t	1
1469	380	2026-09-26	1	17	t	1
1470	381	2026-09-26	1	17	t	1
1471	953	2026-09-26	1	17	t	1
3240	419	2026-10-28	1	22	t	1
3241	1289	2026-10-28	1	22	t	1
1474	384	2026-09-26	1	17	f	1
1475	385	2026-09-26	1	17	t	1
3242	421	2026-10-28	1	22	t	1
3243	422	2026-10-28	1	22	t	1
1320	396	2026-09-26	1	22	t	1
4026	432	2026-10-31	1	22	t	1
1481	557	2026-10-03	2	14	t	1
1482	987	2026-10-03	2	14	t	1
1483	558	2026-10-03	2	14	t	1
1484	559	2026-10-03	2	14	t	1
1485	560	2026-10-03	2	14	t	1
4027	1071	2026-10-31	1	22	t	1
1487	598	2026-10-03	2	14	t	1
4028	434	2026-10-31	1	22	t	1
1489	999	2026-10-03	2	14	t	1
1490	947	2026-10-03	2	14	t	1
1491	563	2026-10-03	2	14	t	1
1492	564	2026-10-03	2	14	t	1
1493	565	2026-10-03	2	14	t	1
1494	983	2026-10-03	2	14	t	1
4029	1225	2026-10-31	1	22	t	1
1496	567	2026-10-03	2	14	t	1
1497	568	2026-10-03	2	14	t	1
4030	1068	2026-10-31	1	22	t	1
1499	570	2026-10-03	2	14	t	1
1500	571	2026-10-03	2	14	f	1
1501	572	2026-10-03	2	14	t	1
1502	573	2026-10-03	2	14	t	1
1503	948	2026-10-03	2	14	t	1
1504	575	2026-10-03	2	14	t	1
1505	850	2026-10-03	2	14	t	1
4031	1006	2026-10-31	1	22	t	1
4032	1073	2026-10-31	1	22	t	1
4033	1075	2026-10-31	1	22	t	1
4034	729	2026-10-31	1	22	t	1
1510	580	2026-10-03	2	14	t	1
1511	581	2026-10-03	2	14	t	1
1512	582	2026-10-03	2	14	t	1
1513	982	2026-10-03	2	15	t	1
1514	583	2026-10-03	2	15	f	1
4035	1057	2026-10-31	1	22	t	1
1516	585	2026-10-03	2	15	t	1
4036	1058	2026-10-31	1	22	t	1
1518	949	2026-10-03	2	15	t	1
1519	588	2026-10-03	2	15	t	1
1520	587	2026-10-03	2	15	t	1
1521	589	2026-10-03	2	15	t	1
1522	859	2026-10-03	2	15	t	1
1523	590	2026-10-03	2	15	t	1
1524	591	2026-10-03	2	15	f	1
4037	1112	2026-10-31	1	22	f	1
4038	1056	2026-10-31	1	22	t	1
1527	946	2026-10-03	2	15	t	1
1528	594	2026-10-03	2	15	t	1
1529	595	2026-10-03	2	15	t	1
1530	596	2026-10-03	2	15	t	1
1531	597	2026-10-03	2	15	t	1
4039	443	2026-10-31	1	22	t	1
1533	599	2026-10-03	2	15	f	1
1534	989	2026-10-03	2	15	t	1
1535	601	2026-10-03	2	15	f	1
1536	600	2026-10-03	2	15	t	1
4040	1070	2026-10-31	1	22	f	1
1538	602	2026-10-03	2	15	t	1
1539	603	2026-10-03	2	15	t	1
1540	605	2026-10-03	2	15	t	1
1541	604	2026-10-03	2	15	t	1
1542	606	2026-10-03	2	15	t	1
1543	607	2026-10-03	2	15	t	1
1544	608	2026-10-03	2	15	t	1
1545	609	2026-10-03	2	15	t	1
1546	610	2026-10-03	2	15	t	1
1547	611	2026-10-03	2	15	t	1
4041	384	2026-10-31	1	22	t	1
1549	612	2026-10-03	2	15	t	1
1551	614	2026-10-03	2	15	t	1
1552	615	2026-10-03	2	15	t	1
1553	616	2026-10-03	2	15	f	1
1555	618	2026-10-03	2	15	t	1
1556	619	2026-10-03	2	15	t	1
1557	862	2026-10-03	2	15	t	1
1558	993	2026-10-03	2	15	t	1
1559	620	2026-10-03	2	15	t	1
1560	940	2026-10-03	2	15	t	1
1561	621	2026-10-03	2	15	t	1
1562	1066	2026-10-03	2	15	t	1
1563	937	2026-10-03	2	15	t	1
1564	985	2026-10-03	2	15	t	1
1565	979	2026-10-03	2	15	t	1
1566	622	2026-10-03	2	15	f	1
1567	623	2026-10-03	2	15	t	1
1568	624	2026-10-03	2	15	t	1
1569	625	2026-10-03	2	15	f	1
1570	626	2026-10-03	2	15	t	1
1571	627	2026-10-03	2	15	t	1
1572	1002	2026-10-03	2	15	t	1
1573	628	2026-10-03	2	15	t	1
1575	630	2026-10-03	2	15	t	1
1576	631	2026-10-03	2	15	t	1
1577	633	2026-10-03	2	15	t	1
1578	938	2026-10-03	2	15	t	1
1580	991	2026-10-03	2	13	t	1
1581	529	2026-10-03	2	13	f	1
1582	988	2026-10-03	2	13	t	1
1583	530	2026-10-03	2	13	t	1
1584	843	2026-10-03	2	13	t	1
2699	964	2026-10-24	1	19	t	1
2700	897	2026-10-24	1	19	t	1
2701	190	2026-10-24	1	19	t	1
1588	858	2026-10-03	2	13	t	1
1589	534	2026-10-03	2	13	t	1
2702	191	2026-10-24	1	19	t	1
2703	193	2026-10-24	1	19	t	1
1592	842	2026-10-03	2	13	t	1
2704	194	2026-10-24	1	19	f	1
2705	196	2026-10-24	1	19	t	1
1595	994	2026-10-03	2	13	t	1
1596	995	2026-10-03	2	13	t	1
2706	1043	2026-10-24	1	19	t	1
1598	539	2026-10-03	2	13	t	1
1599	540	2026-10-03	2	13	t	1
2707	980	2026-10-24	1	19	t	1
2708	198	2026-10-24	1	19	t	1
1602	543	2026-10-03	2	13	f	1
2709	200	2026-10-24	1	19	t	1
1604	545	2026-10-03	2	13	t	1
2710	689	2026-10-24	1	19	t	1
1606	935	2026-10-03	2	13	t	1
1607	549	2026-10-03	2	13	t	1
1608	548	2026-10-03	2	13	f	1
2711	202	2026-10-24	1	19	f	1
1610	574	2026-10-03	2	13	t	1
1611	550	2026-10-03	2	13	t	1
2712	966	2026-10-24	1	19	t	1
1613	936	2026-10-03	2	13	t	1
2713	201	2026-10-24	1	19	t	1
1615	552	2026-10-03	2	13	f	1
2714	1009	2026-10-24	1	19	t	1
1617	1001	2026-10-03	2	13	t	1
1618	838	2026-10-03	2	13	t	1
1619	553	2026-10-03	2	13	t	1
1622	634	2026-10-03	2	16	t	1
1623	996	2026-10-03	2	16	t	1
1626	997	2026-10-03	2	16	t	1
1627	637	2026-10-03	2	16	t	1
1628	636	2026-10-03	2	16	t	1
1629	933	2026-10-03	2	16	t	1
1631	639	2026-10-03	2	16	t	1
1632	1000	2026-10-03	2	16	t	1
1633	864	2026-10-03	2	16	t	1
1634	640	2026-10-03	2	16	t	1
1635	641	2026-10-03	2	16	t	1
1636	939	2026-10-03	2	16	t	1
1637	642	2026-10-03	2	16	t	1
1638	643	2026-10-03	2	16	t	1
4042	322	2026-10-31	1	4	t	1
1640	981	2026-10-03	2	16	t	1
1641	941	2026-10-03	2	16	t	1
1642	644	2026-10-03	2	16	t	1
1643	645	2026-10-03	2	16	t	1
1644	990	2026-10-03	2	16	t	1
4043	332	2026-10-31	1	4	t	1
4044	1007	2026-10-31	1	4	t	1
4045	323	2026-10-31	1	4	t	1
1648	992	2026-10-03	2	16	t	1
4046	324	2026-10-31	1	4	t	1
1650	866	2026-10-03	2	16	t	1
4047	326	2026-10-31	1	4	t	1
1652	998	2026-10-03	2	16	t	1
1653	648	2026-10-03	2	16	t	1
4048	333	2026-10-31	1	4	t	1
1655	958	2026-10-03	2	16	t	1
1656	650	2026-10-03	2	16	t	1
1657	649	2026-10-03	2	16	t	1
1658	651	2026-10-03	2	16	t	1
1659	942	2026-10-03	2	16	t	1
4049	328	2026-10-31	1	4	t	1
1661	653	2026-10-03	2	16	t	1
4050	334	2026-10-31	1	4	t	1
1663	654	2026-10-03	2	16	t	1
1664	656	2026-10-03	2	16	t	1
1665	655	2026-10-03	2	16	t	1
4051	330	2026-10-31	1	4	t	1
1667	1003	2026-10-03	2	16	t	1
1668	658	2026-10-03	2	16	t	1
1669	943	2026-10-03	2	16	t	1
1672	660	2026-10-03	2	16	t	1
1673	934	2026-10-03	2	16	t	1
1675	984	2026-10-03	2	16	t	1
1676	662	2026-10-03	2	16	t	1
1677	663	2026-10-03	2	16	t	1
1678	664	2026-10-03	2	16	t	1
1681	908	2026-10-03	1	3	t	1
1682	930	2026-10-03	1	3	t	1
1683	1018	2026-10-03	1	3	t	1
1684	905	2026-10-03	1	3	t	1
1685	1028	2026-10-03	1	3	t	1
1686	1031	2026-10-03	1	3	t	1
1687	257	2026-10-03	1	3	t	1
1688	238	2026-10-03	1	3	t	1
1689	1016	2026-10-03	1	3	t	1
1690	931	2026-10-03	1	3	t	1
1691	903	2026-10-03	1	3	t	1
1692	1035	2026-10-03	1	3	t	1
1693	241	2026-10-03	1	3	t	1
1694	242	2026-10-03	1	3	t	1
1695	1024	2026-10-03	1	3	t	1
1696	243	2026-10-03	1	3	t	1
1697	244	2026-10-03	1	3	t	1
1698	245	2026-10-03	1	3	t	1
1699	906	2026-10-03	1	3	t	1
1700	968	2026-10-03	1	3	t	1
1701	1029	2026-10-03	1	3	t	1
1702	247	2026-10-03	1	3	t	1
1703	907	2026-10-03	1	3	t	1
1704	901	2026-10-03	1	3	t	1
1705	928	2026-10-03	1	3	t	1
1706	900	2026-10-03	1	3	t	1
1707	1021	2026-10-03	1	3	t	1
1708	929	2026-10-03	1	3	t	1
1709	1015	2026-10-03	1	3	t	1
1710	1039	2026-10-03	1	3	t	1
1711	263	2026-10-03	1	3	t	1
1712	1019	2026-10-03	1	3	t	1
1713	251	2026-10-03	1	3	t	1
1714	1017	2026-10-03	1	3	t	1
1715	1032	2026-10-03	1	3	t	1
1716	902	2026-10-03	1	3	t	1
1717	264	2026-10-03	1	3	t	1
1718	1022	2026-10-03	1	3	t	1
1719	269	2026-10-03	1	3	t	1
1720	252	2026-10-03	1	3	t	1
1721	270	2026-10-03	1	3	t	1
1722	1040	2026-10-03	1	3	t	1
1723	1023	2026-10-03	1	3	t	1
1724	904	2026-10-03	1	3	t	1
1725	1037	2026-10-03	1	3	t	1
1726	849	2026-10-03	1	3	t	1
1727	1042	2026-10-03	1	3	t	1
1728	1033	2026-10-03	1	3	t	1
1729	1030	2026-10-03	1	3	t	1
1730	1038	2026-10-03	1	3	t	1
1731	1034	2026-10-03	1	3	t	1
1732	272	2026-10-03	1	3	t	1
1733	728	2026-10-03	1	3	t	1
1734	846	2026-10-03	1	3	t	1
1735	275	2026-10-03	1	3	t	1
1736	975	2026-10-03	1	3	t	1
1737	276	2026-10-03	1	3	t	1
1738	1014	2026-10-03	1	3	t	1
1739	1020	2026-10-03	1	3	t	1
1740	1036	2026-10-03	1	3	f	1
2715	203	2026-10-24	1	19	t	1
2716	204	2026-10-24	1	19	t	1
1743	284	2026-10-03	1	18	t	1
2717	1010	2026-10-24	1	19	t	1
1745	255	2026-10-03	1	18	f	1
1746	285	2026-10-03	1	18	t	1
2718	206	2026-10-24	1	19	t	1
2719	207	2026-10-24	1	19	t	1
1749	305	2026-10-03	1	18	t	1
1750	306	2026-10-03	1	18	f	1
1751	286	2026-10-03	1	18	t	1
1752	287	2026-10-03	1	18	f	1
2720	208	2026-10-24	1	19	t	1
2721	1237	2026-10-24	1	19	t	1
1755	288	2026-10-03	1	18	t	1
2722	209	2026-10-24	1	19	t	1
2723	967	2026-10-24	1	19	t	1
2724	1236	2026-10-24	1	19	t	1
1759	290	2026-10-03	1	18	t	1
2725	1241	2026-10-24	1	19	t	1
2726	1045	2026-10-24	1	19	t	1
1762	307	2026-10-03	1	18	t	1
2727	1169	2026-10-24	1	19	f	1
2728	1238	2026-10-24	1	19	t	1
2729	214	2026-10-24	1	19	t	1
1766	309	2026-10-03	1	18	f	1
2730	215	2026-10-24	1	19	t	1
2731	899	2026-10-24	1	19	f	1
2732	216	2026-10-24	1	19	f	1
2733	1240	2026-10-24	1	19	t	1
2734	1239	2026-10-24	1	19	t	1
2735	218	2026-10-24	1	19	t	1
2736	932	2026-10-24	1	19	t	1
2737	1123	2026-10-24	1	19	t	1
1775	293	2026-10-03	1	18	t	1
2738	1121	2026-10-24	1	19	t	1
2739	221	2026-10-24	1	19	f	1
1778	262	2026-10-03	1	18	f	1
1779	962	2026-10-03	1	18	t	1
2740	898	2026-10-24	1	19	t	1
1781	310	2026-10-03	1	18	t	1
1782	312	2026-10-03	1	18	t	1
2741	687	2026-10-24	1	19	t	1
2742	222	2026-10-24	1	19	t	1
1785	294	2026-10-03	1	18	t	1
1786	295	2026-10-03	1	18	t	1
2743	224	2026-10-24	1	19	t	1
1788	701	2026-10-03	1	18	f	1
1789	1064	2026-10-03	1	18	t	1
1790	313	2026-10-03	1	18	t	1
2744	1124	2026-10-24	1	19	t	1
1792	314	2026-10-03	1	18	t	1
2745	1011	2026-10-24	1	19	t	1
2746	226	2026-10-24	1	19	t	1
2747	227	2026-10-24	1	19	t	1
2748	1061	2026-10-24	1	19	t	1
2749	976	2026-10-24	1	19	t	1
2750	1122	2026-10-24	1	19	t	1
2751	1049	2026-10-24	1	19	f	1
2752	231	2026-10-24	1	19	t	1
2753	232	2026-10-24	1	19	f	1
3092	1183	2026-10-24	1	23	t	1
3093	1184	2026-10-24	1	23	t	1
3094	913	2026-10-24	1	23	t	1
3095	914	2026-10-24	1	23	t	1
3096	855	2026-10-24	1	23	t	1
1807	300	2026-10-03	1	18	t	1
3097	470	2026-10-24	1	23	t	1
3098	848	2026-10-24	1	23	t	1
1810	302	2026-10-03	1	18	t	1
1811	1041	2026-10-03	1	18	t	1
1812	303	2026-10-03	1	18	t	1
3099	851	2026-10-24	1	23	t	1
3100	923	2026-10-24	1	23	t	1
3101	871	2026-10-24	1	23	t	1
1816	279	2026-10-03	1	18	t	1
3102	915	2026-10-24	1	23	t	1
3103	1182	2026-10-24	1	23	t	1
1819	910	2026-10-03	1	18	t	1
3104	927	2026-10-24	1	23	t	1
1821	874	2026-10-03	1	18	t	1
1822	317	2026-10-03	1	18	t	1
1823	281	2026-10-03	1	18	t	1
3105	974	2026-10-24	1	23	t	1
1825	318	2026-10-03	1	18	t	1
3106	916	2026-10-24	1	23	t	1
3244	423	2026-10-28	1	22	f	1
1828	892	2026-10-03	1	20	t	1
3245	425	2026-10-28	1	22	f	1
1830	95	2026-10-03	1	20	t	1
1831	96	2026-10-03	1	20	t	1
1832	839	2026-10-03	1	20	t	1
1833	97	2026-10-03	1	20	t	1
1834	841	2026-10-03	1	20	t	1
3246	1076	2026-10-28	1	22	t	1
3247	1005	2026-10-28	1	22	t	1
1837	808	2026-10-03	1	20	f	1
3248	1065	2026-10-28	1	22	t	1
3249	1256	2026-10-28	1	22	t	1
1840	101	2026-10-03	1	20	t	1
1841	100	2026-10-03	1	20	t	1
1842	103	2026-10-03	1	20	t	1
3250	432	2026-10-28	1	22	t	1
3251	1071	2026-10-28	1	22	t	1
3252	434	2026-10-28	1	22	t	1
3253	1225	2026-10-28	1	22	t	1
3254	1068	2026-10-28	1	22	t	1
1848	844	2026-10-03	1	20	t	1
1849	111	2026-10-03	1	20	t	1
1850	815	2026-10-03	1	20	t	1
1851	113	2026-10-03	1	20	t	1
1852	876	2026-10-03	1	20	t	1
1853	115	2026-10-03	1	20	t	1
1854	116	2026-10-03	1	20	t	1
1855	882	2026-10-03	1	20	t	1
3255	1006	2026-10-28	1	22	t	1
1857	1027	2026-10-03	1	20	t	1
1858	120	2026-10-03	1	20	t	1
3256	1073	2026-10-28	1	22	t	1
1860	1025	2026-10-03	1	20	t	1
1861	87	2026-10-03	1	20	t	1
1862	891	2026-10-03	1	20	t	1
1863	890	2026-10-03	1	20	t	1
3257	1075	2026-10-28	1	22	t	1
3258	729	2026-10-28	1	22	t	1
1866	127	2026-10-03	1	20	t	1
1867	128	2026-10-03	1	20	f	1
3259	1057	2026-10-28	1	22	t	1
1869	820	2026-10-03	1	20	t	1
1870	1026	2026-10-03	1	20	t	1
1871	135	2026-10-03	1	20	t	1
1872	137	2026-10-03	1	20	t	1
3260	1058	2026-10-28	1	22	t	1
1874	840	2026-10-03	1	20	t	1
1875	1062	2026-10-03	1	20	t	1
3261	1112	2026-10-28	1	22	f	1
1877	970	2026-10-03	1	20	t	1
1878	141	2026-10-03	1	20	t	1
1879	837	2026-10-03	1	20	t	1
3262	1056	2026-10-28	1	22	t	1
1881	682	2026-10-03	1	20	t	1
3263	443	2026-10-28	1	22	t	1
1883	142	2026-10-03	1	20	t	1
1884	143	2026-10-03	1	20	f	1
1885	893	2026-10-03	1	20	t	1
3264	1070	2026-10-28	1	22	f	1
1887	889	2026-10-03	1	20	t	1
3265	384	2026-10-28	1	22	t	1
3291	1272	2026-10-28	1	12	t	1
3292	521	2026-10-28	1	12	t	1
1891	41	2026-10-03	1	1	t	1
3293	523	2026-10-28	1	12	t	1
1893	42	2026-10-03	1	1	t	1
1894	43	2026-10-03	1	1	t	1
1895	5	2026-10-03	1	1	t	1
3294	1074	2026-10-28	1	12	t	1
3295	528	2026-10-28	1	12	t	1
3296	526	2026-10-28	1	12	t	1
1899	7	2026-10-03	1	1	t	1
1900	48	2026-10-03	1	1	t	1
3341	908	2026-10-31	1	3	t	1
1902	8	2026-10-03	1	1	t	1
1903	887	2026-10-03	1	1	t	1
1904	49	2026-10-03	1	1	t	1
1905	51	2026-10-03	1	1	t	1
1906	888	2026-10-03	1	1	t	1
2754	1257	2026-10-24	1	18	t	1
1908	10	2026-10-03	1	1	f	1
1909	52	2026-10-03	1	1	t	1
1910	11	2026-10-03	1	1	t	1
1911	53	2026-10-03	1	1	t	1
1912	55	2026-10-03	1	1	t	1
2755	284	2026-10-24	1	18	t	1
1914	12	2026-10-03	1	1	t	1
2756	1261	2026-10-24	1	18	t	1
1916	15	2026-10-03	1	1	t	1
1917	56	2026-10-03	1	1	t	1
1918	57	2026-10-03	1	1	t	1
1919	969	2026-10-03	1	1	t	1
1920	16	2026-10-03	1	1	t	1
1921	58	2026-10-03	1	1	t	1
2757	255	2026-10-24	1	18	t	1
1923	762	2026-10-03	1	1	t	1
2758	1116	2026-10-24	1	18	t	1
2759	285	2026-10-24	1	18	t	1
1926	19	2026-10-03	1	1	t	1
2760	1117	2026-10-24	1	18	t	1
1928	21	2026-10-03	1	1	t	1
1929	69	2026-10-03	1	1	f	1
2761	305	2026-10-24	1	18	t	1
1931	62	2026-10-03	1	1	t	1
2762	306	2026-10-24	1	18	t	1
1933	959	2026-10-03	1	1	t	1
1934	64	2026-10-03	1	1	t	1
1935	66	2026-10-03	1	1	t	1
2763	286	2026-10-24	1	18	t	1
1937	26	2026-10-03	1	1	t	1
1938	68	2026-10-03	1	1	t	1
2764	287	2026-10-24	1	18	t	1
1940	71	2026-10-03	1	1	t	1
1941	72	2026-10-03	1	1	t	1
1942	29	2026-10-03	1	1	t	1
1943	30	2026-10-03	1	1	t	1
1944	77	2026-10-03	1	1	t	1
2765	288	2026-10-24	1	18	t	1
1946	78	2026-10-03	1	1	t	1
2766	1171	2026-10-24	1	18	t	1
1948	81	2026-10-03	1	1	t	1
1949	886	2026-10-03	1	1	t	1
1950	32	2026-10-03	1	1	f	1
1951	84	2026-10-03	1	1	t	1
1952	873	2026-10-03	1	1	t	1
1953	34	2026-10-03	1	1	t	1
2767	1173	2026-10-24	1	18	t	1
1955	37	2026-10-03	1	1	t	1
1956	880	2026-10-03	1	5	t	1
2768	1229	2026-10-24	1	18	t	1
1958	870	2026-10-03	1	5	t	1
1959	877	2026-10-03	1	5	t	1
1960	1060	2026-10-03	1	5	t	1
1961	971	2026-10-03	1	5	t	1
1962	961	2026-10-03	1	7	t	1
1963	921	2026-10-03	1	7	t	1
1964	885	2026-10-03	1	2	t	1
1965	896	2026-10-03	1	2	t	1
2769	1233	2026-10-24	1	18	t	1
2770	290	2026-10-24	1	18	t	1
1968	148	2026-10-03	1	2	t	1
2771	307	2026-10-24	1	18	t	1
1970	150	2026-10-03	1	2	t	1
1971	151	2026-10-03	1	2	f	1
1972	152	2026-10-03	1	2	f	1
1973	153	2026-10-03	1	2	t	1
2772	309	2026-10-24	1	18	t	1
2773	1175	2026-10-24	1	18	f	1
1976	156	2026-10-03	1	2	t	1
2774	1120	2026-10-24	1	18	t	1
1978	157	2026-10-03	1	2	t	1
1979	158	2026-10-03	1	2	t	1
2775	1135	2026-10-24	1	18	t	1
2776	293	2026-10-24	1	18	t	1
2777	262	2026-10-24	1	18	t	1
1983	162	2026-10-03	1	2	t	1
1984	872	2026-10-03	1	2	t	1
2778	962	2026-10-24	1	18	t	1
2779	310	2026-10-24	1	18	t	1
1987	895	2026-10-03	1	2	t	1
1988	164	2026-10-03	1	2	t	1
1989	165	2026-10-03	1	2	t	1
1990	166	2026-10-03	1	2	t	1
1991	167	2026-10-03	1	2	t	1
1992	168	2026-10-03	1	2	t	1
2780	1113	2026-10-24	1	18	t	1
2781	1114	2026-10-24	1	18	t	1
2782	312	2026-10-24	1	18	t	1
2783	1230	2026-10-24	1	18	t	1
1997	173	2026-10-03	1	2	t	1
1998	174	2026-10-03	1	2	f	1
2784	294	2026-10-24	1	18	t	1
2000	176	2026-10-03	1	2	t	1
2001	177	2026-10-03	1	2	t	1
2002	178	2026-10-03	1	2	t	1
2785	295	2026-10-24	1	18	t	1
2786	1178	2026-10-24	1	18	t	1
2787	701	2026-10-24	1	18	t	1
2788	1064	2026-10-24	1	18	t	1
2789	313	2026-10-24	1	18	t	1
2008	184	2026-10-03	1	2	t	1
2790	314	2026-10-24	1	18	t	1
2010	186	2026-10-03	1	2	t	1
2791	1172	2026-10-24	1	18	t	1
2012	894	2026-10-03	1	2	t	1
2013	187	2026-10-03	1	2	t	1
2014	188	2026-10-03	1	2	t	1
2015	189	2026-10-03	1	2	t	1
2016	964	2026-10-03	1	19	t	1
2017	897	2026-10-03	1	19	t	1
2018	190	2026-10-03	1	19	t	1
2019	191	2026-10-03	1	19	t	1
2792	1231	2026-10-24	1	18	t	1
2021	193	2026-10-03	1	19	t	1
2022	194	2026-10-03	1	19	f	1
2023	195	2026-10-03	1	19	f	1
2024	196	2026-10-03	1	19	t	1
2025	1043	2026-10-03	1	19	t	1
2793	1179	2026-10-24	1	18	t	1
2027	980	2026-10-03	1	19	t	1
2028	198	2026-10-03	1	19	t	1
2794	1118	2026-10-24	1	18	t	1
2795	1232	2026-10-24	1	18	t	1
2031	200	2026-10-03	1	19	t	1
2032	689	2026-10-03	1	19	t	1
2033	202	2026-10-03	1	19	t	1
2034	966	2026-10-03	1	19	t	1
2035	201	2026-10-03	1	19	t	1
2036	1009	2026-10-03	1	19	t	1
2037	203	2026-10-03	1	19	t	1
2038	204	2026-10-03	1	19	f	1
2796	1176	2026-10-24	1	18	t	1
2040	1010	2026-10-03	1	19	t	1
2041	206	2026-10-03	1	19	t	1
2042	207	2026-10-03	1	19	f	1
2043	208	2026-10-03	1	19	t	1
2044	209	2026-10-03	1	19	t	1
2797	1262	2026-10-24	1	18	t	1
2046	967	2026-10-03	1	19	t	1
2798	1115	2026-10-24	1	18	t	1
2799	1220	2026-10-24	1	18	t	1
2049	1045	2026-10-03	1	19	f	1
2800	1219	2026-10-24	1	18	t	1
2051	688	2026-10-03	1	19	f	1
2801	300	2026-10-24	1	18	t	1
2053	214	2026-10-03	1	19	f	1
2802	302	2026-10-24	1	18	t	1
2055	215	2026-10-03	1	19	t	1
2056	899	2026-10-03	1	19	f	1
2057	216	2026-10-03	1	19	f	1
2803	303	2026-10-24	1	18	t	1
2059	218	2026-10-03	1	19	f	1
2060	932	2026-10-03	1	19	t	1
2804	1174	2026-10-24	1	18	t	1
2805	1177	2026-10-24	1	18	t	1
2063	221	2026-10-03	1	19	t	1
2064	898	2026-10-03	1	19	t	1
2065	687	2026-10-03	1	19	t	1
2066	222	2026-10-03	1	19	t	1
2806	279	2026-10-24	1	18	t	1
2807	1228	2026-10-24	1	18	t	1
2069	224	2026-10-03	1	19	t	1
2808	1227	2026-10-24	1	18	f	1
2071	1011	2026-10-03	1	19	t	1
2072	226	2026-10-03	1	19	f	1
2073	227	2026-10-03	1	19	f	1
2074	1061	2026-10-03	1	19	t	1
2075	976	2026-10-03	1	19	t	1
2076	1049	2026-10-03	1	19	f	1
2809	910	2026-10-24	1	18	t	1
2810	874	2026-10-24	1	18	t	1
2811	317	2026-10-24	1	18	t	1
2080	231	2026-10-03	1	19	t	1
2081	232	2026-10-03	1	19	f	1
2812	1036	2026-10-24	1	18	f	1
2083	447	2026-10-03	1	24	t	1
2813	281	2026-10-24	1	18	t	1
2085	449	2026-10-03	1	24	t	1
2086	450	2026-10-03	1	24	t	1
2087	452	2026-10-03	1	24	t	1
2814	318	2026-10-24	1	18	t	1
2089	454	2026-10-03	1	24	t	1
2090	739	2026-10-03	1	24	t	1
2091	456	2026-10-03	1	24	t	1
2092	457	2026-10-03	1	24	t	1
2093	458	2026-10-03	1	24	t	1
2094	1046	2026-10-03	1	8	t	1
2095	459	2026-10-03	1	8	t	1
3107	634	2026-10-24	2	16	t	1
3108	1100	2026-10-24	2	16	t	1
2098	462	2026-10-03	1	8	f	1
2099	732	2026-10-03	1	8	t	1
2100	733	2026-10-03	1	8	t	1
2101	463	2026-10-03	1	8	f	1
2102	464	2026-10-03	1	8	t	1
3109	996	2026-10-24	2	16	t	1
2104	1063	2026-10-03	1	8	t	1
2105	734	2026-10-03	1	8	t	1
2106	1012	2026-10-03	1	8	t	1
3110	1267	2026-10-24	2	16	f	1
2108	467	2026-10-03	1	8	t	1
2109	468	2026-10-03	1	8	t	1
2110	1047	2026-10-03	1	8	t	1
2111	845	2026-10-03	1	8	t	1
3111	997	2026-10-24	2	16	t	1
3112	637	2026-10-24	2	16	t	1
2114	875	2026-10-03	1	8	t	1
2115	469	2026-10-03	1	8	t	1
2116	737	2026-10-03	1	8	t	1
2117	471	2026-10-03	1	8	t	1
3113	636	2026-10-24	2	16	t	1
2119	852	2026-10-03	1	8	t	1
2120	451	2026-10-03	1	8	f	1
3114	933	2026-10-24	2	16	f	1
2122	1048	2026-10-03	1	8	t	1
2123	474	2026-10-03	1	8	t	1
2124	920	2026-10-03	1	8	t	1
2125	475	2026-10-03	1	8	t	1
2126	919	2026-10-03	1	8	t	1
3115	1191	2026-10-24	2	16	t	1
3116	1099	2026-10-24	2	16	t	1
2129	478	2026-10-03	1	8	t	1
3117	1268	2026-10-24	2	16	t	1
3118	639	2026-10-24	2	16	t	1
2132	480	2026-10-03	1	8	t	1
3119	1214	2026-10-24	2	16	f	1
2134	918	2026-10-03	1	8	t	1
3120	1000	2026-10-24	2	16	t	1
2136	1013	2026-10-03	1	8	t	1
3121	864	2026-10-24	2	16	t	1
3122	640	2026-10-24	2	16	t	1
2139	742	2026-10-03	1	8	t	1
2140	853	2026-10-03	1	8	t	1
2141	482	2026-10-03	1	8	t	1
3123	641	2026-10-24	2	16	t	1
2143	951	2026-10-03	1	8	t	1
3124	939	2026-10-24	2	16	t	1
2145	485	2026-10-03	1	8	t	1
2146	486	2026-10-03	1	8	t	1
2147	487	2026-10-03	1	8	t	1
2148	977	2026-10-03	1	8	t	1
2149	881	2026-10-03	1	8	t	1
2150	489	2026-10-03	1	8	t	1
2151	488	2026-10-03	1	8	t	1
3125	642	2026-10-24	2	16	t	1
2153	917	2026-10-03	1	8	t	1
2154	913	2026-10-03	1	23	t	1
2155	914	2026-10-03	1	23	t	1
2156	855	2026-10-03	1	23	t	1
2157	470	2026-10-03	1	23	t	1
2158	848	2026-10-03	1	23	t	1
2159	851	2026-10-03	1	23	t	1
2160	923	2026-10-03	1	23	t	1
2161	871	2026-10-03	1	23	t	1
2162	915	2026-10-03	1	23	t	1
2163	927	2026-10-03	1	23	t	1
2164	974	2026-10-03	1	23	f	1
2165	916	2026-10-03	1	23	t	1
2166	878	2026-10-03	1	6	t	1
2167	925	2026-10-03	1	6	t	1
2168	926	2026-10-03	1	6	t	1
2169	973	2026-10-03	1	6	t	1
2170	924	2026-10-03	1	6	t	1
2171	972	2026-10-03	1	6	t	1
3126	1197	2026-10-24	2	16	t	1
3127	643	2026-10-24	2	16	t	1
3128	981	2026-10-24	2	16	t	1
2175	322	2026-10-03	1	4	t	1
2176	332	2026-10-03	1	4	t	1
2177	1007	2026-10-03	1	4	t	1
2178	323	2026-10-03	1	4	t	1
2179	324	2026-10-03	1	4	t	1
2815	1086	2026-10-24	2	14	t	1
2181	326	2026-10-03	1	4	t	1
2816	1198	2026-10-24	2	14	t	1
2183	333	2026-10-03	1	4	t	1
2184	328	2026-10-03	1	4	t	1
2185	334	2026-10-03	1	4	t	1
2817	987	2026-10-24	2	14	t	1
2187	330	2026-10-03	1	4	t	1
2188	335	2026-10-03	1	17	f	1
2189	884	2026-10-03	1	17	t	1
2818	557	2026-10-24	2	14	t	1
2191	337	2026-10-03	1	17	t	1
2819	558	2026-10-24	2	14	t	1
2193	339	2026-10-03	1	17	t	1
2820	559	2026-10-24	2	14	t	1
2195	708	2026-10-03	1	17	f	1
2821	560	2026-10-24	2	14	t	1
2822	598	2026-10-24	2	14	t	1
2198	847	2026-10-03	1	17	t	1
2823	999	2026-10-24	2	14	t	1
2200	710	2026-10-03	1	17	f	1
2824	1211	2026-10-24	2	14	t	1
2825	947	2026-10-24	2	14	t	1
2203	344	2026-10-03	1	17	t	1
2204	345	2026-10-03	1	17	t	1
2205	346	2026-10-03	1	17	t	1
2206	347	2026-10-03	1	17	t	1
2207	348	2026-10-03	1	17	f	1
2826	563	2026-10-24	2	14	t	1
2209	879	2026-10-03	1	17	t	1
2827	1199	2026-10-24	2	14	t	1
2828	1087	2026-10-24	2	14	t	1
2829	564	2026-10-24	2	14	t	1
2830	1213	2026-10-24	2	14	t	1
2831	565	2026-10-24	2	14	t	1
2215	355	2026-10-03	1	17	t	1
2832	983	2026-10-24	2	14	t	1
2833	1083	2026-10-24	2	14	t	1
2834	567	2026-10-24	2	14	t	1
2835	568	2026-10-24	2	14	f	1
2836	1084	2026-10-24	2	14	t	1
2222	954	2026-10-03	1	17	t	1
2837	1210	2026-10-24	2	14	t	1
2224	361	2026-10-03	1	17	t	1
2838	1269	2026-10-24	2	14	t	1
2839	570	2026-10-24	2	14	f	1
2840	571	2026-10-24	2	14	f	1
2841	572	2026-10-24	2	14	t	1
2229	364	2026-10-03	1	17	t	1
2230	365	2026-10-03	1	17	t	1
2842	573	2026-10-24	2	14	t	1
2843	948	2026-10-24	2	14	f	1
2844	1266	2026-10-24	2	14	t	1
2845	575	2026-10-24	2	14	t	1
2846	850	2026-10-24	2	14	t	1
2236	369	2026-10-03	1	17	t	1
2847	1085	2026-10-24	2	14	t	1
2238	371	2026-10-03	1	17	t	1
2848	1259	2026-10-24	2	14	t	1
2240	883	2026-10-03	1	17	t	1
2849	1196	2026-10-24	2	14	t	1
2242	952	2026-10-03	1	17	t	1
2850	581	2026-10-24	2	14	t	1
2851	580	2026-10-24	2	14	t	1
2852	1260	2026-10-24	2	14	t	1
2246	717	2026-10-03	1	17	t	1
2247	375	2026-10-03	1	17	t	1
2853	582	2026-10-24	2	14	t	1
3129	941	2026-10-24	2	16	t	1
3130	644	2026-10-24	2	16	t	1
3131	645	2026-10-24	2	16	t	1
2252	379	2026-10-03	1	17	t	1
2253	380	2026-10-03	1	17	t	1
2254	381	2026-10-03	1	17	t	1
2255	953	2026-10-03	1	17	t	1
3132	990	2026-10-24	2	16	t	1
3133	992	2026-10-24	2	16	t	1
2258	384	2026-10-03	1	17	f	1
2259	385	2026-10-03	1	17	t	1
3134	1163	2026-10-24	2	16	t	1
3135	866	2026-10-24	2	16	t	1
2219	358	2026-10-03	1	17	t	1
3136	998	2026-10-24	2	16	t	1
3137	648	2026-10-24	2	16	t	1
2265	389	2026-10-03	1	22	t	1
2266	391	2026-10-03	1	22	t	1
3138	958	2026-10-24	2	16	f	1
3139	1206	2026-10-24	2	16	t	1
3140	1201	2026-10-24	2	16	t	1
2270	1050	2026-10-03	1	22	t	1
2271	395	2026-10-03	1	22	t	1
2272	397	2026-10-03	1	22	t	1
2273	396	2026-10-03	1	22	t	1
3141	650	2026-10-24	2	16	t	1
2275	960	2026-10-03	1	22	t	1
3142	649	2026-10-24	2	16	t	1
2277	1054	2026-10-03	1	22	t	1
2278	399	2026-10-03	1	22	t	1
3143	651	2026-10-24	2	16	t	1
2280	401	2026-10-03	1	22	t	1
2281	1052	2026-10-03	1	22	t	1
2282	402	2026-10-03	1	22	t	1
2283	1008	2026-10-03	1	22	t	1
3144	942	2026-10-24	2	16	t	1
3145	653	2026-10-24	2	16	t	1
2286	404	2026-10-03	1	22	t	1
2287	403	2026-10-03	1	22	t	1
3146	654	2026-10-24	2	16	t	1
3147	1205	2026-10-24	2	16	t	1
2290	1051	2026-10-03	1	22	t	1
3148	655	2026-10-24	2	16	t	1
3149	656	2026-10-24	2	16	t	1
2293	407	2026-10-03	1	22	t	1
3150	1215	2026-10-24	2	16	t	1
2295	1004	2026-10-03	1	22	t	1
2296	409	2026-10-03	1	22	t	1
2297	911	2026-10-03	1	22	t	1
2298	410	2026-10-03	1	22	t	1
3151	1003	2026-10-24	2	16	t	1
2300	1053	2026-10-03	1	22	t	1
3152	658	2026-10-24	2	16	t	1
2302	1059	2026-10-03	1	22	t	1
3153	943	2026-10-24	2	16	t	1
3154	1258	2026-10-24	2	16	t	1
3155	660	2026-10-24	2	16	t	1
3156	934	2026-10-24	2	16	t	1
3157	1097	2026-10-24	2	16	t	1
2308	415	2026-10-03	1	22	t	1
2309	416	2026-10-03	1	22	f	1
3158	1101	2026-10-24	2	16	t	1
2311	1055	2026-10-03	1	22	t	1
2312	418	2026-10-03	1	22	t	1
2313	419	2026-10-03	1	22	t	1
3159	1204	2026-10-24	2	16	t	1
3160	984	2026-10-24	2	16	t	1
2854	1109	2026-10-24	1	7	t	1
2316	421	2026-10-03	1	22	t	1
2317	422	2026-10-03	1	22	t	1
2318	423	2026-10-03	1	22	t	1
2855	961	2026-10-24	1	7	t	1
2856	1252	2026-10-24	1	7	t	1
2321	425	2026-10-03	1	22	t	1
2857	921	2026-10-24	1	7	t	1
3161	662	2026-10-24	2	16	f	1
3162	663	2026-10-24	2	16	t	1
2325	1005	2026-10-03	1	22	t	1
3163	664	2026-10-24	2	16	t	1
3164	1102	2026-10-24	2	16	f	1
2328	1065	2026-10-03	1	22	t	1
3266	490	2026-10-28	1	11	t	1
3267	491	2026-10-28	1	11	f	1
2331	432	2026-10-03	1	22	t	1
3268	492	2026-10-28	1	11	t	1
2333	434	2026-10-03	1	22	t	1
2334	1006	2026-10-03	1	22	t	1
3269	494	2026-10-28	1	11	t	1
3270	497	2026-10-28	1	11	t	1
2337	729	2026-10-03	1	22	t	1
3297	885	2026-10-31	1	2	t	1
3298	896	2026-10-31	1	2	t	1
3299	148	2026-10-31	1	2	t	1
2341	1057	2026-10-03	1	22	t	1
2342	1058	2026-10-03	1	22	t	1
3300	150	2026-10-31	1	2	t	1
3301	151	2026-10-31	1	2	f	1
3302	195	2026-10-31	1	2	t	1
3303	152	2026-10-31	1	2	t	1
3304	153	2026-10-31	1	2	t	1
2348	1056	2026-10-03	1	22	t	1
2349	443	2026-10-03	1	22	t	1
3305	1127	2026-10-31	1	2	t	1
2351	965	2026-10-03	1	22	f	1
3306	1146	2026-10-31	1	2	t	1
2353	912	2026-10-03	1	22	f	1
3307	156	2026-10-31	1	2	t	1
3308	1126	2026-10-31	1	2	t	1
2356	746	2026-10-03	1	12	t	1
2358	499	2026-10-03	1	12	t	1
2359	500	2026-10-03	1	12	t	1
2360	501	2026-10-03	1	12	f	1
2361	502	2026-10-03	1	12	t	1
3310	157	2026-10-31	1	2	t	1
3311	158	2026-10-31	1	2	t	1
2364	507	2026-10-03	1	12	t	1
2365	503	2026-10-03	1	12	t	1
3312	162	2026-10-31	1	2	t	1
2367	504	2026-10-03	1	12	t	1
3313	872	2026-10-31	1	2	t	1
2369	508	2026-10-03	1	12	t	1
3314	895	2026-10-31	1	2	t	1
2371	509	2026-10-03	1	12	t	1
3315	164	2026-10-31	1	2	t	1
3316	165	2026-10-31	1	2	t	1
2374	750	2026-10-03	1	12	t	1
3317	166	2026-10-31	1	2	t	1
3318	1278	2026-10-31	1	2	t	1
3319	167	2026-10-31	1	2	t	1
2378	514	2026-10-03	1	12	t	1
2379	515	2026-10-03	1	12	t	1
3320	168	2026-10-31	1	2	t	1
3321	688	2026-10-31	1	2	f	1
2382	753	2026-10-03	1	12	t	1
2383	518	2026-10-03	1	12	t	1
3322	1280	2026-10-31	1	2	t	1
2385	519	2026-10-03	1	12	t	1
3323	173	2026-10-31	1	2	t	1
2387	521	2026-10-03	1	12	t	1
3324	1151	2026-10-31	1	2	t	1
2389	523	2026-10-03	1	12	f	1
3325	174	2026-10-31	1	2	t	1
3326	1170	2026-10-31	1	2	t	1
3327	176	2026-10-31	1	2	t	1
2393	526	2026-10-03	1	12	f	1
2394	528	2026-10-03	1	12	t	1
2395	490	2026-10-03	1	11	t	1
2396	491	2026-10-03	1	11	t	1
2397	492	2026-10-03	1	11	t	1
3328	177	2026-10-31	1	2	t	1
3329	178	2026-10-31	1	2	t	1
3330	1153	2026-10-31	1	2	t	1
2401	494	2026-10-03	1	11	t	1
3331	184	2026-10-31	1	2	t	1
3332	1279	2026-10-31	1	2	t	1
2404	497	2026-10-03	1	11	t	1
3333	1234	2026-10-31	1	2	t	1
3334	186	2026-10-31	1	2	t	1
3335	1125	2026-10-31	1	2	t	1
3336	894	2026-10-31	1	2	t	1
3337	187	2026-10-31	1	2	t	1
3338	188	2026-10-31	1	2	t	1
3339	189	2026-10-31	1	2	t	1
3340	1224	2026-10-31	1	2	f	1
3342	930	2026-10-31	1	3	t	1
3343	1018	2026-10-31	1	3	t	1
3344	1261	2026-10-31	1	3	t	1
3345	905	2026-10-31	1	3	t	1
3346	1028	2026-10-31	1	3	t	1
3347	1031	2026-10-31	1	3	t	1
3348	257	2026-10-31	1	3	t	1
3349	238	2026-10-31	1	3	t	1
3350	1016	2026-10-31	1	3	f	1
3351	931	2026-10-31	1	3	f	1
3352	903	2026-10-31	1	3	t	1
3353	1035	2026-10-31	1	3	t	1
3354	241	2026-10-31	1	3	t	1
3355	242	2026-10-31	1	3	t	1
3356	1024	2026-10-31	1	3	t	1
3357	243	2026-10-31	1	3	t	1
3358	244	2026-10-31	1	3	t	1
3359	245	2026-10-31	1	3	t	1
3360	968	2026-10-31	1	3	t	1
3361	1029	2026-10-31	1	3	t	1
3362	247	2026-10-31	1	3	t	1
3363	907	2026-10-31	1	3	t	1
3364	901	2026-10-31	1	3	t	1
3365	928	2026-10-31	1	3	t	1
3366	900	2026-10-31	1	3	t	1
3367	1021	2026-10-31	1	3	t	1
3368	929	2026-10-31	1	3	t	1
3369	1015	2026-10-31	1	3	f	1
3370	1039	2026-10-31	1	3	t	1
3371	263	2026-10-31	1	3	t	1
3372	1019	2026-10-31	1	3	t	1
3373	251	2026-10-31	1	3	t	1
3374	1017	2026-10-31	1	3	t	1
3375	1032	2026-10-31	1	3	t	1
3376	902	2026-10-31	1	3	t	1
3377	264	2026-10-31	1	3	t	1
3378	1022	2026-10-31	1	3	t	1
3379	1287	2026-10-31	1	3	f	1
3380	269	2026-10-31	1	3	t	1
3381	252	2026-10-31	1	3	t	1
3382	1119	2026-10-31	1	3	t	1
3383	270	2026-10-31	1	3	t	1
3384	1023	2026-10-31	1	3	t	1
3385	1040	2026-10-31	1	3	t	1
3386	904	2026-10-31	1	3	t	1
3387	1037	2026-10-31	1	3	t	1
3388	849	2026-10-31	1	3	t	1
3389	1042	2026-10-31	1	3	t	1
3390	1033	2026-10-31	1	3	t	1
3391	1038	2026-10-31	1	3	t	1
3392	1030	2026-10-31	1	3	t	1
3393	1034	2026-10-31	1	3	f	1
3394	272	2026-10-31	1	3	t	1
3395	728	2026-10-31	1	3	t	1
3396	846	2026-10-31	1	3	t	1
3397	1041	2026-10-31	1	3	t	1
3398	275	2026-10-31	1	3	t	1
3399	975	2026-10-31	1	3	t	1
3400	276	2026-10-31	1	3	t	1
3401	906	2026-10-31	1	3	t	1
3402	1227	2026-10-31	1	3	t	1
3403	1014	2026-10-31	1	3	t	1
3404	1020	2026-10-31	1	3	t	1
3405	1036	2026-10-31	1	3	t	1
3406	447	2026-10-31	1	24	t	1
3407	1253	2026-10-31	1	24	t	1
3408	449	2026-10-31	1	24	f	1
3409	450	2026-10-31	1	24	t	1
3410	452	2026-10-31	1	24	t	1
3411	454	2026-10-31	1	24	f	1
3412	1281	2026-10-31	1	24	t	1
3413	739	2026-10-31	1	24	t	1
3414	1108	2026-10-31	1	24	t	1
3415	1185	2026-10-31	1	24	f	1
3416	457	2026-10-31	1	24	t	1
3417	456	2026-10-31	1	24	t	1
3418	458	2026-10-31	1	24	t	1
3419	1046	2026-10-31	1	8	t	1
3420	459	2026-10-31	1	8	t	1
3421	462	2026-10-31	1	8	f	1
3422	1105	2026-10-31	1	8	t	1
3423	732	2026-10-31	1	8	t	1
3424	733	2026-10-31	1	8	t	1
3425	463	2026-10-31	1	8	f	1
3426	464	2026-10-31	1	8	t	1
3427	1254	2026-10-31	1	8	t	1
3428	1136	2026-10-31	1	8	f	1
3429	1063	2026-10-31	1	8	t	1
3430	734	2026-10-31	1	8	t	1
3431	1012	2026-10-31	1	8	f	1
3432	1188	2026-10-31	1	8	t	1
3433	467	2026-10-31	1	8	t	1
3434	468	2026-10-31	1	8	t	1
3435	1047	2026-10-31	1	8	t	1
3436	845	2026-10-31	1	8	t	1
3437	1107	2026-10-31	1	8	f	1
3438	875	2026-10-31	1	8	t	1
3439	469	2026-10-31	1	8	t	1
3440	737	2026-10-31	1	8	t	1
3441	471	2026-10-31	1	8	t	1
3442	852	2026-10-31	1	8	t	1
3443	451	2026-10-31	1	8	t	1
3444	1263	2026-10-31	1	8	t	1
3445	1187	2026-10-31	1	8	t	1
3446	1048	2026-10-31	1	8	f	1
3447	474	2026-10-31	1	8	t	1
3448	1255	2026-10-31	1	8	t	1
3449	920	2026-10-31	1	8	f	1
3450	475	2026-10-31	1	8	t	1
3451	1134	2026-10-31	1	8	f	1
3452	919	2026-10-31	1	8	t	1
3453	478	2026-10-31	1	8	f	1
3454	480	2026-10-31	1	8	t	1
3455	918	2026-10-31	1	8	t	1
3456	1013	2026-10-31	1	8	t	1
3457	742	2026-10-31	1	8	t	1
3458	853	2026-10-31	1	8	t	1
3459	482	2026-10-31	1	8	t	1
3460	951	2026-10-31	1	8	f	1
3461	485	2026-10-31	1	8	t	1
3462	1106	2026-10-31	1	8	t	1
3463	486	2026-10-31	1	8	t	1
3464	1186	2026-10-31	1	8	t	1
3465	487	2026-10-31	1	8	t	1
3466	977	2026-10-31	1	8	t	1
3467	881	2026-10-31	1	8	t	1
3468	489	2026-10-31	1	8	t	1
3469	488	2026-10-31	1	8	t	1
3470	917	2026-10-31	1	8	t	1
3471	964	2026-10-31	1	19	t	1
3472	897	2026-10-31	1	19	t	1
3473	190	2026-10-31	1	19	t	1
3474	191	2026-10-31	1	19	t	1
3475	193	2026-10-31	1	19	t	1
3476	194	2026-10-31	1	19	f	1
3477	196	2026-10-31	1	19	t	1
3478	1043	2026-10-31	1	19	t	1
3479	980	2026-10-31	1	19	t	1
3480	198	2026-10-31	1	19	t	1
3481	200	2026-10-31	1	19	t	1
3482	689	2026-10-31	1	19	t	1
3483	202	2026-10-31	1	19	t	1
3484	966	2026-10-31	1	19	t	1
3485	201	2026-10-31	1	19	t	1
3486	1009	2026-10-31	1	19	t	1
3487	203	2026-10-31	1	19	t	1
3488	204	2026-10-31	1	19	t	1
3489	1010	2026-10-31	1	19	t	1
3490	206	2026-10-31	1	19	f	1
3491	207	2026-10-31	1	19	t	1
3492	208	2026-10-31	1	19	t	1
3493	1237	2026-10-31	1	19	t	1
3494	209	2026-10-31	1	19	t	1
3495	967	2026-10-31	1	19	t	1
3496	1236	2026-10-31	1	19	t	1
3497	1241	2026-10-31	1	19	t	1
3498	1169	2026-10-31	1	19	f	1
3499	1045	2026-10-31	1	19	t	1
3500	1238	2026-10-31	1	19	t	1
3501	214	2026-10-31	1	19	t	1
3502	215	2026-10-31	1	19	t	1
3503	899	2026-10-31	1	19	t	1
3504	216	2026-10-31	1	19	t	1
3505	1239	2026-10-31	1	19	t	1
3506	1240	2026-10-31	1	19	t	1
3507	218	2026-10-31	1	19	t	1
3508	932	2026-10-31	1	19	t	1
3509	1123	2026-10-31	1	19	t	1
3510	1121	2026-10-31	1	19	t	1
3511	221	2026-10-31	1	19	t	1
3512	898	2026-10-31	1	19	t	1
3513	687	2026-10-31	1	19	t	1
3514	222	2026-10-31	1	19	f	1
3515	224	2026-10-31	1	19	t	1
3516	1124	2026-10-31	1	19	t	1
3517	1011	2026-10-31	1	19	t	1
3518	226	2026-10-31	1	19	f	1
3520	1061	2026-10-31	1	19	t	1
3521	976	2026-10-31	1	19	t	1
3522	1122	2026-10-31	1	19	t	1
3523	1049	2026-10-31	1	19	t	1
3524	231	2026-10-31	1	19	t	1
3525	232	2026-10-31	1	19	t	1
3309	1235	2026-10-31	1	2	t	1
3527	880	2026-10-31	1	5	f	1
3528	870	2026-10-31	1	5	t	1
3529	877	2026-10-31	1	5	t	1
3530	1060	2026-10-31	1	5	t	1
3531	971	2026-10-31	1	5	t	1
3532	1109	2026-10-31	1	7	t	1
3533	961	2026-10-31	1	7	t	1
3534	1252	2026-10-31	1	7	t	1
3535	921	2026-10-31	1	7	t	1
3537	1274	2026-10-31	1	1	t	1
3538	1275	2026-10-31	1	1	t	1
3539	41	2026-10-31	1	1	t	1
3540	42	2026-10-31	1	1	t	1
3541	43	2026-10-31	1	1	f	1
3542	5	2026-10-31	1	1	t	1
3543	1242	2026-10-31	1	1	t	1
3544	7	2026-10-31	1	1	t	1
3545	48	2026-10-31	1	1	t	1
3546	8	2026-10-31	1	1	t	1
3547	887	2026-10-31	1	1	t	1
3548	1244	2026-10-31	1	1	t	1
3549	49	2026-10-31	1	1	t	1
3550	51	2026-10-31	1	1	t	1
3551	888	2026-10-31	1	1	t	1
3552	10	2026-10-31	1	1	f	1
3553	52	2026-10-31	1	1	t	1
3554	11	2026-10-31	1	1	t	1
3555	53	2026-10-31	1	1	t	1
3556	55	2026-10-31	1	1	t	1
3557	12	2026-10-31	1	1	t	1
3558	15	2026-10-31	1	1	t	1
3559	56	2026-10-31	1	1	t	1
3560	57	2026-10-31	1	1	t	1
3561	969	2026-10-31	1	1	f	1
3562	16	2026-10-31	1	1	t	1
3563	1133	2026-10-31	1	1	t	1
3564	58	2026-10-31	1	1	t	1
3565	762	2026-10-31	1	1	f	1
3566	1243	2026-10-31	1	1	t	1
3567	19	2026-10-31	1	1	t	1
3568	21	2026-10-31	1	1	t	1
3569	69	2026-10-31	1	1	t	1
3570	62	2026-10-31	1	1	t	1
3571	959	2026-10-31	1	1	t	1
3572	64	2026-10-31	1	1	t	1
3573	66	2026-10-31	1	1	t	1
3574	26	2026-10-31	1	1	f	1
3575	68	2026-10-31	1	1	t	1
3576	71	2026-10-31	1	1	t	1
3577	72	2026-10-31	1	1	t	1
3578	29	2026-10-31	1	1	t	1
3579	30	2026-10-31	1	1	t	1
3580	77	2026-10-31	1	1	t	1
3581	1246	2026-10-31	1	1	f	1
3582	133	2026-10-31	1	1	t	1
3583	78	2026-10-31	1	1	t	1
3584	81	2026-10-31	1	1	t	1
3585	886	2026-10-31	1	1	t	1
3586	84	2026-10-31	1	1	t	1
3587	1245	2026-10-31	1	1	t	1
3588	873	2026-10-31	1	1	t	1
3589	34	2026-10-31	1	1	t	1
3590	37	2026-10-31	1	1	t	1
3591	1086	2026-10-31	2	14	t	1
3592	1198	2026-10-31	2	14	t	1
3593	557	2026-10-31	2	14	t	1
3594	987	2026-10-31	2	14	f	1
3595	558	2026-10-31	2	14	t	1
3596	559	2026-10-31	2	14	t	1
3597	560	2026-10-31	2	14	t	1
3598	598	2026-10-31	2	14	t	1
3599	999	2026-10-31	2	14	t	1
3600	1211	2026-10-31	2	14	t	1
3601	947	2026-10-31	2	14	t	1
3602	563	2026-10-31	2	14	t	1
3603	1199	2026-10-31	2	14	t	1
3604	1087	2026-10-31	2	14	f	1
3605	564	2026-10-31	2	14	t	1
3606	1213	2026-10-31	2	14	t	1
3607	565	2026-10-31	2	14	t	1
3608	983	2026-10-31	2	14	t	1
3609	1083	2026-10-31	2	14	t	1
3610	567	2026-10-31	2	14	t	1
3611	568	2026-10-31	2	14	t	1
3612	1210	2026-10-31	2	14	t	1
3613	1084	2026-10-31	2	14	t	1
3614	1269	2026-10-31	2	14	t	1
3615	570	2026-10-31	2	14	t	1
3616	571	2026-10-31	2	14	f	1
3617	572	2026-10-31	2	14	t	1
3618	573	2026-10-31	2	14	f	1
3619	948	2026-10-31	2	14	t	1
3620	1266	2026-10-31	2	14	t	1
3621	575	2026-10-31	2	14	t	1
3622	850	2026-10-31	2	14	t	1
3623	1085	2026-10-31	2	14	t	1
3624	1294	2026-10-31	2	14	t	1
3625	1259	2026-10-31	2	14	t	1
3626	1196	2026-10-31	2	14	f	1
3627	580	2026-10-31	2	14	t	1
3628	581	2026-10-31	2	14	t	1
3629	1296	2026-10-31	2	14	t	1
3630	1260	2026-10-31	2	14	t	1
3631	582	2026-10-31	2	14	t	1
3536	1276	2026-10-31	1	1	t	1
3633	784	2026-10-31	1	20	f	1
3634	1140	2026-10-31	1	20	t	1
3635	892	2026-10-31	1	20	t	1
3636	95	2026-10-31	1	20	t	1
3637	96	2026-10-31	1	20	t	1
3638	839	2026-10-31	1	20	t	1
3639	1128	2026-10-31	1	20	t	1
3640	97	2026-10-31	1	20	t	1
3641	841	2026-10-31	1	20	t	1
3642	808	2026-10-31	1	20	t	1
3643	100	2026-10-31	1	20	t	1
3644	101	2026-10-31	1	20	t	1
3645	1132	2026-10-31	1	20	t	1
3646	103	2026-10-31	1	20	f	1
3647	1277	2026-10-31	1	20	t	1
3648	844	2026-10-31	1	20	t	1
3649	111	2026-10-31	1	20	t	1
3650	815	2026-10-31	1	20	t	1
3651	1131	2026-10-31	1	20	t	1
3519	227	2026-10-31	1	19	t	1
3652	1168	2026-10-31	1	20	t	1
3653	1247	2026-10-31	1	20	t	1
3654	113	2026-10-31	1	20	t	1
3655	876	2026-10-31	1	20	t	1
3656	116	2026-10-31	1	20	t	1
3657	115	2026-10-31	1	20	t	1
3658	882	2026-10-31	1	20	t	1
3659	1027	2026-10-31	1	20	t	1
3660	120	2026-10-31	1	20	f	1
3661	1025	2026-10-31	1	20	t	1
3662	828	2026-10-31	1	20	t	1
3663	87	2026-10-31	1	20	t	1
3664	1167	2026-10-31	1	20	t	1
3665	890	2026-10-31	1	20	f	1
3666	891	2026-10-31	1	20	t	1
3667	1248	2026-10-31	1	20	t	1
3668	127	2026-10-31	1	20	t	1
3669	1273	2026-10-31	1	20	t	1
3670	128	2026-10-31	1	20	t	1
3671	820	2026-10-31	1	20	t	1
3672	1026	2026-10-31	1	20	t	1
3673	1223	2026-10-31	1	20	t	1
3674	1104	2026-10-31	1	20	t	1
3675	1103	2026-10-31	1	20	t	1
3676	135	2026-10-31	1	20	t	1
3677	137	2026-10-31	1	20	t	1
3678	840	2026-10-31	1	20	t	1
3679	1164	2026-10-31	1	20	t	1
3680	1130	2026-10-31	1	20	t	1
3681	1062	2026-10-31	1	20	t	1
3682	32	2026-10-31	1	20	t	1
3683	970	2026-10-31	1	20	t	1
3684	1249	2026-10-31	1	20	t	1
3685	141	2026-10-31	1	20	t	1
3686	837	2026-10-31	1	20	t	1
3687	682	2026-10-31	1	20	t	1
3688	142	2026-10-31	1	20	f	1
3689	143	2026-10-31	1	20	f	1
3690	893	2026-10-31	1	20	f	1
3691	889	2026-10-31	1	20	t	1
3692	878	2026-10-31	1	6	t	1
3693	925	2026-10-31	1	6	t	1
3694	1251	2026-10-31	1	6	t	1
3695	1250	2026-10-31	1	6	t	1
3696	926	2026-10-31	1	6	t	1
3697	1282	2026-10-31	1	6	t	1
3698	1180	2026-10-31	1	6	t	1
3699	973	2026-10-31	1	6	t	1
3700	924	2026-10-31	1	6	t	1
3701	972	2026-10-31	1	6	t	1
3702	982	2026-10-31	2	15	t	1
3703	583	2026-10-31	2	15	t	1
3704	585	2026-10-31	2	15	t	1
3705	1091	2026-10-31	2	15	t	1
3706	1208	2026-10-31	2	15	t	1
3707	949	2026-10-31	2	15	t	1
3708	587	2026-10-31	2	15	t	1
3709	588	2026-10-31	2	15	t	1
3710	589	2026-10-31	2	15	t	1
3711	1090	2026-10-31	2	15	t	1
3712	590	2026-10-31	2	15	t	1
3713	591	2026-10-31	2	15	t	1
3714	946	2026-10-31	2	15	t	1
3715	859	2026-10-31	2	15	t	1
3716	594	2026-10-31	2	15	t	1
3717	595	2026-10-31	2	15	t	1
3718	596	2026-10-31	2	15	t	1
3719	597	2026-10-31	2	15	t	1
3720	1270	2026-10-31	2	15	f	1
3721	1089	2026-10-31	2	15	t	1
3722	1092	2026-10-31	2	15	t	1
3723	1088	2026-10-31	2	15	t	1
3724	1207	2026-10-31	2	15	t	1
3725	599	2026-10-31	2	15	t	1
3726	1209	2026-10-31	2	15	t	1
3727	989	2026-10-31	2	15	t	1
3728	1297	2026-10-31	2	15	t	1
3729	600	2026-10-31	2	15	t	1
3730	601	2026-10-31	2	15	t	1
3731	602	2026-10-31	2	15	t	1
3732	603	2026-10-31	2	15	t	1
3733	1216	2026-10-31	2	15	t	1
3734	1094	2026-10-31	2	15	t	1
3735	605	2026-10-31	2	15	t	1
3736	604	2026-10-31	2	15	t	1
3737	1264	2026-10-31	2	15	t	1
3738	606	2026-10-31	2	15	t	1
3739	608	2026-10-31	2	15	t	1
3740	607	2026-10-31	2	15	t	1
3741	609	2026-10-31	2	15	t	1
3742	610	2026-10-31	2	15	t	1
3743	611	2026-10-31	2	15	t	1
3744	612	2026-10-31	2	15	t	1
3745	615	2026-10-31	2	15	t	1
3746	614	2026-10-31	2	15	t	1
3747	1203	2026-10-31	2	15	t	1
3748	1192	2026-10-31	2	15	t	1
3749	1212	2026-10-31	2	15	t	1
3750	616	2026-10-31	2	15	t	1
3751	1293	2026-10-31	2	15	t	1
3752	618	2026-10-31	2	15	t	1
3753	619	2026-10-31	2	15	t	1
3754	862	2026-10-31	2	15	t	1
3755	993	2026-10-31	2	15	t	1
3756	620	2026-10-31	2	15	t	1
3757	1218	2026-10-31	2	15	t	1
3758	940	2026-10-31	2	15	t	1
3759	621	2026-10-31	2	15	t	1
3760	1093	2026-10-31	2	15	t	1
3761	1066	2026-10-31	2	15	t	1
3762	937	2026-10-31	2	15	t	1
3763	985	2026-10-31	2	15	f	1
3764	979	2026-10-31	2	15	t	1
3765	622	2026-10-31	2	15	t	1
3766	1095	2026-10-31	2	15	t	1
3767	623	2026-10-31	2	15	t	1
3768	1202	2026-10-31	2	15	t	1
3769	624	2026-10-31	2	15	t	1
3770	1295	2026-10-31	2	15	t	1
3771	625	2026-10-31	2	15	t	1
3772	626	2026-10-31	2	15	t	1
3773	627	2026-10-31	2	15	t	1
3774	1002	2026-10-31	2	15	t	1
3775	628	2026-10-31	2	15	t	1
3776	630	2026-10-31	2	15	f	1
3777	1217	2026-10-31	2	15	t	1
3778	631	2026-10-31	2	15	t	1
3779	633	2026-10-31	2	15	t	1
3780	938	2026-10-31	2	15	t	1
3781	1183	2026-10-31	1	23	t	1
3782	1184	2026-10-31	1	23	t	1
3783	913	2026-10-31	1	23	t	1
3784	914	2026-10-31	1	23	t	1
3785	1286	2026-10-31	1	23	f	1
3786	855	2026-10-31	1	23	t	1
3787	470	2026-10-31	1	23	t	1
3788	848	2026-10-31	1	23	t	1
3789	851	2026-10-31	1	23	t	1
3790	923	2026-10-31	1	23	t	1
3791	871	2026-10-31	1	23	t	1
3792	915	2026-10-31	1	23	t	1
3793	1182	2026-10-31	1	23	t	1
3794	927	2026-10-31	1	23	t	1
3795	974	2026-10-31	1	23	f	1
3796	916	2026-10-31	1	23	t	1
3797	991	2026-10-31	2	13	t	1
3798	529	2026-10-31	2	13	t	1
3799	988	2026-10-31	2	13	t	1
3800	530	2026-10-31	2	13	t	1
3801	843	2026-10-31	2	13	t	1
3802	1292	2026-10-31	2	13	t	1
3803	1291	2026-10-31	2	13	t	1
3804	1193	2026-10-31	2	13	t	1
3805	858	2026-10-31	2	13	t	1
3806	534	2026-10-31	2	13	t	1
3807	1079	2026-10-31	2	13	t	1
3808	1082	2026-10-31	2	13	t	1
3809	842	2026-10-31	2	13	t	1
3810	1081	2026-10-31	2	13	t	1
3811	995	2026-10-31	2	13	t	1
3812	994	2026-10-31	2	13	t	1
3813	539	2026-10-31	2	13	t	1
3814	540	2026-10-31	2	13	t	1
3815	543	2026-10-31	2	13	f	1
3816	1189	2026-10-31	2	13	f	1
3817	545	2026-10-31	2	13	t	1
3818	1226	2026-10-31	2	13	t	1
3819	1200	2026-10-31	2	13	f	1
3820	935	2026-10-31	2	13	t	1
3821	549	2026-10-31	2	13	t	1
3822	548	2026-10-31	2	13	t	1
3823	574	2026-10-31	2	13	t	1
3824	550	2026-10-31	2	13	t	1
3825	936	2026-10-31	2	13	t	1
3826	1195	2026-10-31	2	13	t	1
3827	552	2026-10-31	2	13	t	1
3828	1001	2026-10-31	2	13	t	1
3829	838	2026-10-31	2	13	t	1
3830	1078	2026-10-31	2	13	t	1
3831	553	2026-10-31	2	13	t	1
3832	1080	2026-10-31	2	13	t	1
3833	1190	2026-10-31	2	13	t	1
3834	634	2026-10-31	2	16	t	1
3835	1100	2026-10-31	2	16	t	1
3836	996	2026-10-31	2	16	t	1
3837	1267	2026-10-31	2	16	f	1
3838	997	2026-10-31	2	16	t	1
3839	636	2026-10-31	2	16	t	1
3840	637	2026-10-31	2	16	t	1
3841	933	2026-10-31	2	16	f	1
3842	1191	2026-10-31	2	16	t	1
3843	1099	2026-10-31	2	16	t	1
3844	1268	2026-10-31	2	16	f	1
3845	639	2026-10-31	2	16	t	1
3846	1214	2026-10-31	2	16	f	1
3847	1000	2026-10-31	2	16	f	1
3848	864	2026-10-31	2	16	t	1
3849	640	2026-10-31	2	16	t	1
3850	641	2026-10-31	2	16	t	1
3851	939	2026-10-31	2	16	t	1
3852	642	2026-10-31	2	16	t	1
3853	1197	2026-10-31	2	16	t	1
3854	643	2026-10-31	2	16	t	1
3855	981	2026-10-31	2	16	t	1
3856	941	2026-10-31	2	16	t	1
3857	644	2026-10-31	2	16	t	1
3858	645	2026-10-31	2	16	t	1
3859	990	2026-10-31	2	16	t	1
3860	1290	2026-10-31	2	16	t	1
3861	992	2026-10-31	2	16	t	1
3862	1163	2026-10-31	2	16	t	1
3863	866	2026-10-31	2	16	t	1
3864	998	2026-10-31	2	16	t	1
3865	648	2026-10-31	2	16	t	1
3866	958	2026-10-31	2	16	t	1
3867	1206	2026-10-31	2	16	t	1
3868	1201	2026-10-31	2	16	t	1
3869	649	2026-10-31	2	16	t	1
3870	650	2026-10-31	2	16	t	1
3871	651	2026-10-31	2	16	f	1
3872	942	2026-10-31	2	16	t	1
3873	653	2026-10-31	2	16	t	1
3874	654	2026-10-31	2	16	t	1
3875	1205	2026-10-31	2	16	t	1
3876	655	2026-10-31	2	16	t	1
3877	656	2026-10-31	2	16	t	1
3878	1215	2026-10-31	2	16	f	1
3879	1003	2026-10-31	2	16	f	1
3880	658	2026-10-31	2	16	t	1
3881	943	2026-10-31	2	16	t	1
3882	1258	2026-10-31	2	16	t	1
3883	660	2026-10-31	2	16	t	1
3884	934	2026-10-31	2	16	t	1
3885	1097	2026-10-31	2	16	t	1
3886	1101	2026-10-31	2	16	t	1
3887	1204	2026-10-31	2	16	t	1
3888	984	2026-10-31	2	16	t	1
3889	662	2026-10-31	2	16	t	1
3890	663	2026-10-31	2	16	t	1
3891	664	2026-10-31	2	16	t	1
3892	1102	2026-10-31	2	16	f	1
3893	1257	2026-10-31	1	18	t	1
3894	284	2026-10-31	1	18	t	1
3895	255	2026-10-31	1	18	t	1
3896	1116	2026-10-31	1	18	t	1
3897	285	2026-10-31	1	18	f	1
3898	1117	2026-10-31	1	18	t	1
3899	305	2026-10-31	1	18	f	1
3900	306	2026-10-31	1	18	t	1
3901	286	2026-10-31	1	18	t	1
3902	287	2026-10-31	1	18	t	1
3903	1284	2026-10-31	1	18	t	1
3904	288	2026-10-31	1	18	t	1
3905	1298	2026-10-31	1	18	t	1
3906	1171	2026-10-31	1	18	t	1
3907	1173	2026-10-31	1	18	t	1
3908	1229	2026-10-31	1	18	t	1
3909	1233	2026-10-31	1	18	t	1
3910	290	2026-10-31	1	18	t	1
3911	307	2026-10-31	1	18	t	1
3912	1288	2026-10-31	1	18	t	1
3913	309	2026-10-31	1	18	t	1
3914	1175	2026-10-31	1	18	f	1
3915	1135	2026-10-31	1	18	t	1
3916	1120	2026-10-31	1	18	t	1
3917	293	2026-10-31	1	18	t	1
3918	262	2026-10-31	1	18	t	1
3919	962	2026-10-31	1	18	t	1
3920	310	2026-10-31	1	18	t	1
3921	1113	2026-10-31	1	18	t	1
3922	1114	2026-10-31	1	18	t	1
3923	1283	2026-10-31	1	18	t	1
3924	312	2026-10-31	1	18	t	1
3925	1230	2026-10-31	1	18	t	1
3926	294	2026-10-31	1	18	t	1
3927	295	2026-10-31	1	18	t	1
3928	1178	2026-10-31	1	18	f	1
3929	701	2026-10-31	1	18	f	1
3930	1064	2026-10-31	1	18	t	1
3931	313	2026-10-31	1	18	t	1
3932	314	2026-10-31	1	18	t	1
3933	1172	2026-10-31	1	18	t	1
3934	1231	2026-10-31	1	18	f	1
3935	1285	2026-10-31	1	18	t	1
3936	1179	2026-10-31	1	18	t	1
3937	1118	2026-10-31	1	18	t	1
3938	1232	2026-10-31	1	18	t	1
3939	1176	2026-10-31	1	18	t	1
3940	1262	2026-10-31	1	18	t	1
3941	1115	2026-10-31	1	18	t	1
3942	1219	2026-10-31	1	18	t	1
3943	1220	2026-10-31	1	18	t	1
3944	300	2026-10-31	1	18	t	1
3945	302	2026-10-31	1	18	t	1
3946	303	2026-10-31	1	18	t	1
3947	1174	2026-10-31	1	18	t	1
3948	1177	2026-10-31	1	18	t	1
3949	279	2026-10-31	1	18	t	1
3950	1228	2026-10-31	1	18	t	1
3951	910	2026-10-31	1	18	t	1
3952	874	2026-10-31	1	18	t	1
3953	317	2026-10-31	1	18	t	1
3954	281	2026-10-31	1	18	t	1
3955	318	2026-10-31	1	18	t	1
3957	746	2026-10-31	1	12	t	1
3958	499	2026-10-31	1	12	t	1
3959	500	2026-10-31	1	12	t	1
3960	501	2026-10-31	1	12	t	1
3961	502	2026-10-31	1	12	t	1
3962	1271	2026-10-31	1	12	t	1
3963	507	2026-10-31	1	12	t	1
3964	503	2026-10-31	1	12	t	1
3965	504	2026-10-31	1	12	t	1
3966	508	2026-10-31	1	12	t	1
3967	509	2026-10-31	1	12	t	1
3968	1077	2026-10-31	1	12	f	1
3969	750	2026-10-31	1	12	t	1
3970	514	2026-10-31	1	12	f	1
3971	515	2026-10-31	1	12	t	1
3972	1265	2026-10-31	1	12	t	1
3973	1221	2026-10-31	1	12	t	1
3974	753	2026-10-31	1	12	t	1
3975	518	2026-10-31	1	12	t	1
3976	519	2026-10-31	1	12	t	1
3977	1272	2026-10-31	1	12	t	1
3978	521	2026-10-31	1	12	t	1
3979	523	2026-10-31	1	12	t	1
3980	1074	2026-10-31	1	12	t	1
3981	528	2026-10-31	1	12	t	1
3982	526	2026-10-31	1	12	t	1
3983	490	2026-10-31	1	11	t	1
3984	491	2026-10-31	1	11	t	1
3985	492	2026-10-31	1	11	t	1
3986	494	2026-10-31	1	11	t	1
3987	497	2026-10-31	1	11	t	1
4052	335	2026-10-31	1	17	t	1
4053	884	2026-10-31	1	17	t	1
4054	337	2026-10-31	1	17	t	1
4055	339	2026-10-31	1	17	t	1
4056	708	2026-10-31	1	17	t	1
4057	397	2026-10-31	1	17	t	1
4058	847	2026-10-31	1	17	t	1
4059	710	2026-10-31	1	17	t	1
4060	344	2026-10-31	1	17	t	1
4061	345	2026-10-31	1	17	t	1
4062	346	2026-10-31	1	17	t	1
4063	347	2026-10-31	1	17	t	1
4064	348	2026-10-31	1	17	t	1
4065	879	2026-10-31	1	17	t	1
4066	355	2026-10-31	1	17	t	1
4067	358	2026-10-31	1	17	t	1
4068	954	2026-10-31	1	17	f	1
4069	416	2026-10-31	1	17	f	1
4070	361	2026-10-31	1	17	f	1
4071	364	2026-10-31	1	17	t	1
4072	365	2026-10-31	1	17	t	1
4073	1138	2026-10-31	1	17	t	1
4074	369	2026-10-31	1	17	t	1
4075	371	2026-10-31	1	17	f	1
4076	883	2026-10-31	1	17	t	1
4077	952	2026-10-31	1	17	t	1
4078	717	2026-10-31	1	17	t	1
4079	375	2026-10-31	1	17	t	1
4080	1137	2026-10-31	1	17	f	1
4081	379	2026-10-31	1	17	t	1
4082	380	2026-10-31	1	17	t	1
4083	381	2026-10-31	1	17	t	1
4084	953	2026-10-31	1	17	t	1
4085	965	2026-10-31	1	17	t	1
4086	912	2026-10-31	1	17	f	1
4087	385	2026-10-31	1	17	f	1
\.


--
-- Data for Name: recompenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recompenses (id, note_id, eleve_id, annee_scolaire_id, mois, type_gain, montant, depense_id, paye_par, date_paiement, created_at) FROM stdin;
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, nom_site, initiale) FROM stdin;
2	Yagbé	Y
1	Jéricho	J
\.


--
-- Data for Name: user_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sites (user_id, site_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, role, site_id, actif) FROM stdin;
55899634-2a3d-4d0c-a169-c883ddd3b72f	jealexhouegbe	jucaljealexhouegbe@gmail.com	coordonnateur	\N	t
7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	urielhouegbe	urielaxelhouegbe@gmail.com	comptable	\N	t
576e1d68-860c-4ef9-bd53-773709e47df0	yetbaginn	yetohoubago@gmail.com	chef_site	1	t
bbef52c8-3a68-4d24-9714-7563440edc56	quenumparfait	parfaitquenum91@gmail.com	chef_site	2	t
13c39ada-704c-4adc-a3c7-cf2569fc3780	usergsr	usergsr@gmail.com	secretaire	1	t
09e8ed62-944e-4095-b524-a9e8ecdf138f	andersondoliveira	doliveiraanderson6@gmail.com	chef_site	1	t
\.


--
-- Data for Name: creneaux; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.creneaux (id, semaine_id, classe_id, matiere_id, date_td, heure_debut, heure_fin, montant_prevu, statut_creneau) FROM stdin;
21	13	1	5	2026-09-19	08:30:00	11:30:00	4500.00	cloture
23	13	2	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
25	13	3	4	2026-09-19	08:30:00	11:30:00	4500.00	cloture
26	13	18	4	2026-09-19	08:30:00	11:30:00	4500.00	cloture
30	13	8	3	2026-09-19	08:30:00	11:30:00	5100.00	cloture
27	13	17	2	2026-09-19	15:30:00	18:30:00	4500.00	cloture
28	13	22	2	2026-09-19	15:30:00	18:30:00	4500.00	cloture
31	13	12	5	2026-09-19	15:30:00	18:30:00	6000.00	cloture
34	13	15	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
35	13	16	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
32	13	13	3	2026-09-19	08:30:00	11:30:00	4500.00	cloture
33	13	14	4	2026-09-19	08:30:00	11:30:00	4500.00	cloture
24	13	19	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
29	13	23	1	2026-09-19	08:30:00	11:30:00	5100.00	cloture
22	13	20	5	2026-09-19	08:30:00	11:30:00	4500.00	cloture
38	14	2	4	2026-09-26	08:30:00	11:30:00	4500.00	cloture
39	14	19	4	2026-09-26	08:30:00	11:30:00	4500.00	cloture
40	14	3	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
41	14	18	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
44	14	17	2	2026-09-26	15:30:00	18:30:00	4500.00	cloture
43	14	22	2	2026-09-26	15:30:00	18:30:00	4500.00	cloture
46	14	23	5	2026-09-26	08:30:00	11:30:00	5100.00	cloture
49	14	13	5	2026-09-26	08:30:00	11:30:00	4500.00	cloture
51	14	15	4	2026-09-26	08:30:00	11:30:00	4500.00	cloture
52	14	16	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
50	14	14	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
36	14	1	3	2026-09-26	08:30:00	11:30:00	4500.00	cloture
48	14	12	4	2026-09-26	15:30:00	18:30:00	6000.00	cloture
37	14	20	3	2026-09-26	08:30:00	11:30:00	4500.00	cloture
47	14	8	4	2026-09-26	08:30:00	11:30:00	5100.00	cloture
119	16	18	4	2026-10-10	07:30:00	09:30:00	3000.00	cloture
105	16	15	2	2026-10-10	07:30:00	09:30:00	3000.00	cloture
103	16	14	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
101	16	13	2	2026-10-10	07:30:00	09:30:00	3000.00	cloture
123	16	22	2	2026-10-10	14:50:00	16:50:00	3000.00	cloture
125	16	6	2	2026-10-10	07:00:00	09:45:00	5100.00	cloture
113	16	2	4	2026-10-10	07:30:00	09:30:00	3000.00	cloture
127	16	8	5	2026-10-10	07:00:00	09:45:00	5100.00	cloture
115	16	19	2	2026-10-10	07:30:00	09:30:00	3000.00	cloture
117	16	3	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
107	16	16	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
129	16	12	1	2026-10-10	14:00:00	16:50:00	6000.00	cloture
121	16	17	11	2026-10-10	14:50:00	16:50:00	3000.00	cloture
111	16	20	3	2026-10-10	07:30:00	09:30:00	3000.00	cloture
109	16	1	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
132	17	17	3	2026-10-14	17:00:00	19:00:00	3000.00	cloture
133	17	22	3	2026-10-14	14:50:00	16:50:00	3000.00	cloture
131	17	17	4	2026-10-14	14:50:00	16:50:00	3000.00	cloture
134	17	22	4	2026-10-14	17:00:00	19:00:00	3000.00	cloture
79	15	22	2	2026-10-03	14:50:00	16:50:00	3000.00	cloture
78	15	17	2	2026-10-03	17:00:00	19:00:00	3000.00	cloture
66	15	16	4	2026-10-04	15:00:00	18:00:00	4500.00	cloture
70	15	19	3	2026-10-03	10:00:00	12:00:00	3000.00	cloture
67	15	2	3	2026-10-03	07:30:00	09:30:00	3000.00	cloture
65	15	15	4	2026-10-04	15:00:00	18:00:00	4500.00	cloture
74	15	18	4	2026-10-03	10:00:00	12:00:00	3000.00	cloture
71	15	3	4	2026-10-03	07:30:00	09:30:00	3000.00	cloture
63	15	20	4	2026-10-03	07:30:00	09:30:00	3000.00	cloture
84	15	23	4	2026-10-03	10:15:00	13:00:00	5100.00	cloture
69	15	19	5	2026-10-03	07:30:00	09:30:00	3000.00	cloture
68	15	2	5	2026-10-03	10:00:00	12:00:00	3000.00	cloture
64	15	20	2	2026-10-03	10:00:00	12:00:00	3000.00	cloture
81	15	5	2	2026-10-03	07:00:00	09:45:00	5100.00	cloture
85	15	5	8	2026-10-04	15:00:00	18:00:00	5100.00	cloture
75	15	3	2	2026-10-04	15:00:00	18:00:00	4500.00	cloture
77	15	17	1	2026-10-03	14:50:00	16:50:00	3000.00	cloture
80	15	22	1	2026-10-03	17:00:00	19:00:00	3000.00	cloture
83	15	23	6	2026-10-03	07:00:00	09:45:00	5100.00	cloture
72	15	3	1	2026-10-03	10:00:00	12:00:00	3000.00	cloture
73	15	18	1	2026-10-03	07:30:00	09:30:00	3000.00	cloture
82	15	5	1	2026-10-03	10:15:00	13:00:00	5100.00	cloture
76	15	18	2	2026-10-04	15:00:00	18:00:00	4500.00	cloture
157	17	5	8	2026-10-18	15:00:00	18:00:00	5100.00	cloture
151	17	17	2	2026-10-17	17:00:00	19:00:00	3000.00	cloture
163	17	12	5	2026-10-17	14:00:00	16:50:00	6000.00	cloture
170	17	15	2	2026-10-17	10:00:00	12:00:00	3000.00	cloture
150	17	17	4	2026-10-17	14:50:00	16:50:00	3000.00	cloture
153	17	22	4	2026-10-17	17:00:00	19:00:00	3000.00	cloture
142	17	19	2	2026-10-17	07:30:00	09:30:00	3000.00	cloture
136	17	1	2	2026-10-17	07:30:00	09:30:00	3000.00	cloture
140	17	2	5	2026-10-17	07:30:00	09:30:00	3000.00	cloture
137	17	1	4	2026-10-17	10:00:00	12:00:00	3000.00	cloture
173	17	15	4	2026-10-18	15:00:00	18:00:00	4500.00	cloture
166	17	13	4	2026-10-17	10:00:00	12:00:00	3000.00	cloture
144	17	3	3	2026-10-17	07:30:00	09:30:00	3000.00	cloture
155	17	5	1	2026-10-17	10:15:00	13:00:00	5100.00	cloture
165	17	13	3	2026-10-17	07:30:00	09:30:00	3000.00	cloture
168	17	14	3	2026-10-17	10:00:00	12:00:00	3000.00	cloture
159	17	7	1	2026-10-17	07:00:00	09:45:00	5100.00	cloture
146	17	18	4	2026-10-17	07:30:00	09:30:00	3000.00	cloture
148	17	3	2	2026-10-18	15:00:00	18:00:00	4500.00	cloture
60	15	16	2	2026-10-03	10:00:00	12:00:00	3000.00	cloture
57	15	15	2	2026-10-03	07:30:00	09:30:00	3000.00	cloture
89	15	8	4	2026-10-03	07:00:00	09:45:00	5100.00	cloture
62	15	1	4	2026-10-03	10:00:00	12:00:00	3000.00	cloture
53	15	13	4	2026-10-03	07:30:00	09:30:00	3000.00	cloture
56	15	14	4	2026-10-03	10:00:00	12:00:00	3000.00	cloture
54	15	13	3	2026-10-03	10:00:00	12:00:00	3000.00	cloture
55	15	14	3	2026-10-03	07:30:00	09:30:00	3000.00	cloture
61	15	1	2	2026-10-03	07:30:00	09:30:00	3000.00	cloture
94	15	12	3	2026-10-03	17:00:00	19:00:00	4000.00	cloture
93	15	12	5	2026-10-03	14:00:00	16:50:00	6000.00	cloture
88	15	7	2	2026-10-03	10:15:00	13:00:00	5100.00	cloture
86	15	23	2	2026-10-04	15:00:00	18:00:00	5100.00	cloture
92	15	8	2	2026-10-04	15:00:00	18:00:00	5100.00	cloture
58	15	15	1	2026-10-03	10:00:00	12:00:00	3000.00	cloture
59	15	16	1	2026-10-03	07:30:00	09:30:00	3000.00	cloture
90	15	8	6	2026-10-03	10:15:00	13:00:00	5100.00	cloture
91	15	7	8	2026-10-04	15:00:00	18:00:00	5100.00	cloture
87	15	7	1	2026-10-03	07:00:00	09:45:00	5100.00	cloture
174	17	16	4	2026-10-18	15:00:00	18:00:00	4500.00	cloture
158	17	6	2	2026-10-18	15:00:00	18:00:00	5100.00	cloture
97	16	22	4	2026-10-07	14:50:00	16:50:00	3000.00	cloture
96	16	17	4	2026-10-07	17:00:00	19:00:00	3000.00	cloture
162	17	8	2	2026-10-18	15:00:00	18:00:00	5100.00	cloture
152	17	22	2	2026-10-17	14:50:00	16:50:00	3000.00	cloture
99	16	11	2	2026-10-07	15:00:00	18:00:00	6000.00	cloture
118	16	3	4	2026-10-10	10:00:00	12:00:00	3000.00	cloture
171	17	16	2	2026-10-17	07:30:00	09:30:00	3000.00	cloture
108	16	16	2	2026-10-10	10:00:00	12:00:00	3000.00	cloture
102	16	13	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
104	16	14	2	2026-10-10	10:00:00	12:00:00	3000.00	cloture
122	16	17	2	2026-10-10	17:00:00	19:00:00	3000.00	cloture
116	16	19	4	2026-10-10	10:00:00	12:00:00	3000.00	cloture
130	16	12	7	2026-10-10	17:00:00	19:00:00	4000.00	cloture
126	16	23	5	2026-10-10	10:15:00	13:00:00	5100.00	cloture
100	16	12	2	2026-10-07	15:00:00	18:00:00	6000.00	cloture
128	16	24	2	2026-10-10	10:15:00	13:00:00	5100.00	cloture
141	17	2	2	2026-10-17	10:00:00	12:00:00	3000.00	cloture
139	17	20	2	2026-10-17	10:00:00	12:00:00	3000.00	cloture
143	17	19	5	2026-10-17	10:00:00	12:00:00	3000.00	cloture
95	16	17	5	2026-10-07	14:50:00	16:50:00	3000.00	cloture
98	16	22	5	2026-10-07	17:00:00	19:00:00	3000.00	cloture
120	16	18	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
106	16	15	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
124	16	22	11	2026-10-10	17:00:00	19:00:00	3000.00	cloture
110	16	1	3	2026-10-10	10:00:00	12:00:00	3000.00	cloture
112	16	20	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
138	17	20	4	2026-10-17	07:30:00	09:30:00	3000.00	cloture
167	17	14	4	2026-10-17	07:30:00	09:30:00	3000.00	cloture
114	16	2	2	2026-10-10	10:00:00	12:00:00	3000.00	cloture
160	17	7	3	2026-10-17	10:15:00	13:00:00	5100.00	cloture
135	17	12	4	2026-10-14	14:50:00	19:00:00	8000.00	cloture
154	17	5	3	2026-10-17	07:00:00	09:45:00	5100.00	cloture
147	17	18	3	2026-10-17	10:00:00	12:00:00	3000.00	cloture
169	17	15	3	2026-10-17	07:30:00	09:30:00	3000.00	cloture
172	17	16	3	2026-10-17	10:00:00	12:00:00	3000.00	cloture
145	17	3	4	2026-10-17	10:00:00	12:00:00	3000.00	cloture
161	17	24	4	2026-10-17	10:15:00	13:00:00	5100.00	cloture
164	17	12	3	2026-10-17	17:00:00	19:00:00	4000.00	cloture
156	17	23	4	2026-10-17	07:00:00	09:45:00	5100.00	cloture
149	17	18	2	2026-10-18	15:00:00	18:00:00	4500.00	cloture
178	18	22	4	2026-10-21	17:00:00	19:00:00	3000.00	cloture
179	18	11	2	2026-10-21	15:00:00	18:00:00	6000.00	cloture
176	18	17	5	2026-10-21	17:00:00	19:00:00	3000.00	cloture
177	18	22	5	2026-10-21	14:50:00	16:50:00	3000.00	cloture
180	18	12	2	2026-10-21	15:00:00	18:00:00	6000.00	cloture
188	18	17	2	2026-10-24	17:00:00	19:00:00	3000.00	cloture
189	18	22	2	2026-10-24	14:50:00	16:50:00	3000.00	cloture
206	18	16	5	2026-10-24	07:30:00	09:30:00	3000.00	cloture
201	18	13	5	2026-10-24	10:00:00	12:00:00	3000.00	cloture
202	18	14	5	2026-10-24	07:30:00	09:30:00	3000.00	cloture
200	18	13	2	2026-10-24	07:30:00	09:30:00	3000.00	cloture
203	18	14	2	2026-10-24	10:00:00	12:00:00	3000.00	cloture
198	18	12	5	2026-10-24	14:00:00	17:00:00	6000.00	cloture
199	18	12	4	2026-10-24	17:00:00	19:00:00	4000.00	cloture
195	18	7	7	2026-10-24	10:15:00	13:00:00	5100.00	cloture
191	18	23	5	2026-10-24	07:00:00	09:45:00	5100.00	cloture
196	18	8	5	2026-10-24	10:15:00	12:15:00	3400.00	cloture
192	18	5	2	2026-10-24	10:15:00	12:15:00	3400.00	cloture
194	18	7	2	2026-10-24	07:45:00	09:45:00	3400.00	cloture
190	18	22	1	2026-10-24	17:00:00	19:00:00	3000.00	cloture
187	18	17	1	2026-10-24	14:50:00	16:50:00	3000.00	cloture
185	18	3	5	2026-10-24	07:30:00	09:30:00	3000.00	cloture
186	18	18	5	2026-10-24	10:00:00	12:00:00	3000.00	cloture
184	18	19	3	2026-10-24	10:00:00	12:00:00	3000.00	cloture
183	18	2	3	2026-10-24	07:30:00	09:30:00	3000.00	cloture
181	18	1	5	2026-10-24	07:30:00	09:30:00	3000.00	cloture
182	18	20	5	2026-10-24	10:00:00	12:00:00	3000.00	cloture
204	18	15	2	2026-10-24	07:30:00	09:30:00	3000.00	cloture
193	18	6	4	2026-10-24	10:15:00	13:00:00	5100.00	cloture
197	18	24	4	2026-10-24	07:00:00	09:45:00	5100.00	cloture
175	18	17	4	2026-10-21	14:50:00	16:50:00	3000.00	cloture
205	18	15	5	2026-10-24	10:00:00	12:00:00	3000.00	cloture
207	18	16	2	2026-10-24	10:00:00	12:00:00	3000.00	cloture
209	18	18	2	2026-10-24	07:30:00	09:30:00	3000.00	cloture
210	18	3	2	2026-10-24	10:00:00	12:00:00	3000.00	cloture
215	19	11	2	2026-10-28	15:00:00	18:00:00	6000.00	cloture
216	19	12	2	2026-10-28	15:00:00	19:00:00	8000.00	cloture
213	19	17	5	2026-10-28	14:50:00	16:50:00	3000.00	cloture
212	19	22	5	2026-10-28	17:00:00	19:00:00	3000.00	cloture
211	19	22	4	2026-10-28	14:50:00	16:50:00	3000.00	cloture
214	19	17	4	2026-10-28	17:00:00	19:00:00	3000.00	cloture
230	19	1	2	2026-10-31	07:30:00	09:30:00	3000.00	cloture
232	19	2	2	2026-10-31	10:00:00	12:00:00	3000.00	cloture
231	19	20	2	2026-10-31	07:30:00	09:30:00	3000.00	cloture
233	19	19	2	2026-10-31	10:00:00	12:00:00	3000.00	cloture
239	19	3	4	2026-10-31	07:30:00	08:30:00	1500.00	cloture
240	19	18	4	2026-10-31	08:30:00	09:30:00	1500.00	cloture
238	19	16	4	2026-10-31	10:00:00	12:00:00	3000.00	cloture
226	19	22	2	2026-10-31	14:50:00	16:50:00	3000.00	cloture
225	19	17	2	2026-10-31	17:00:00	19:00:00	3000.00	cloture
229	19	12	2	2026-10-31	17:00:00	19:00:00	4000.00	cloture
220	19	5	6	2026-10-31	07:00:00	09:45:00	5100.00	cloture
224	19	17	7	2026-10-31	14:50:00	16:50:00	3000.00	cloture
227	19	22	7	2026-10-31	17:00:00	19:00:00	3000.00	cloture
217	19	8	4	2026-10-31	07:00:00	09:45:00	5100.00	cloture
222	19	6	2	2026-10-31	07:00:00	09:45:00	5100.00	cloture
221	19	5	2	2026-10-31	10:15:00	12:15:00	3400.00	cloture
228	19	12	5	2026-10-31	14:00:00	16:50:00	6000.00	cloture
219	19	7	5	2026-10-31	07:30:00	09:30:00	3400.00	cloture
236	19	15	3	2026-10-31	07:30:00	09:30:00	3000.00	cloture
237	19	14	3	2026-10-31	10:00:00	12:00:00	3000.00	cloture
235	19	18	1	2026-10-31	07:30:00	09:30:00	3000.00	cloture
234	19	3	1	2026-10-31	10:00:00	12:00:00	3000.00	cloture
223	19	6	4	2026-10-31	10:15:00	13:00:00	5100.00	cloture
218	19	7	1	2026-10-31	10:15:00	13:00:00	5100.00	cloture
\.


--
-- Data for Name: demandes_retrait; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.demandes_retrait (id, code_demande, professeur_id, mois, montant_demande, reseau_momo, numero_momo, statut, date_demande, ip_demande, date_paiement, paye_par, reference_paiement, commentaire_admin, date_rejet, rejete_par) FROM stdin;
5	PAY-202610-005	1	2026-10	5000.00	celtis	+2290141232201	paye	2026-10-28 06:50:42.863883+00	154.66.139.32	2026-10-28 12:42:58.29+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	DJS8Q7A154	Paiement n⁰1	\N	\N
9	PAY-202610-009	9	2026-10	9000.00	mtn	+2290166448873	paye	2026-10-28 09:15:41.228798+00	137.255.139.242	2026-10-28 13:02:44.36+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13231347288	Versement émoluments	\N	\N
8	PAY-202610-008	17	2026-10	24000.00	mtn	+2290197262346	paye	2026-10-28 08:47:26.576292+00	137.255.16.88	2026-10-28 13:10:52.766+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13231404039	Versement émoluments	\N	\N
7	PAY-202610-007	4	2026-10	24000.00	celtis	+2290140311507	paye	2026-10-28 08:43:09.311565+00	137.255.170.84	2026-10-28 13:14:05.448+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	DJS8Q7A154	Versement émoluments	\N	\N
2	PAY-202610-002	10	2026-10	9000.00	celtis	+2290144152614	paye	2026-10-28 04:42:10.775415+00	102.202.111.176	2026-10-28 13:16:52.533+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	DJS9Q7FFVP	Versement émoluments	\N	\N
4	PAY-202610-004	28	2026-10	46500.00	mtn	+2290166243602	paye	2026-10-28 05:15:46.750254+00	137.255.193.31	2026-10-28 13:19:01.894+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13231473571	Versement émoluments	\N	\N
6	PAY-202610-006	36	2026-10	27000.00	mtn	+2290154031211	paye	2026-10-28 07:00:49.721751+00	102.202.111.190	2026-10-28 13:23:45.039+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13231506289	Versement émoluments	\N	\N
10	PAY-202610-010	21	2026-10	25500.00	mtn	+2290166879680	paye	2026-10-28 12:33:42.533526+00	41.79.217.119	2026-10-28 13:25:58.864+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13231521781	Versement émoluments	\N	\N
11	PAY-202610-011	22	2026-10	16500.00	celtis	+2290140041365	paye	2026-10-28 13:24:10.992481+00	41.85.162.109	2026-10-28 13:31:47.771+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	DJS6Q7HDIU	Versement émoluments	\N	\N
1	PAY-202610-001	52	2026-10	21000.00	mtn	+2290161335492	paye	2026-10-28 04:10:32.026918+00	102.202.111.28	2026-10-28 13:37:44.689+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13231606430	Versement émoluments	\N	\N
3	PAY-202610-003	18	2026-10	19500.00	mtn	+2290197860770	paye	2026-10-28 04:56:28.9008+00	41.85.163.241	2026-10-28 13:40:10.386+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13231623040	Versement émoluments	\N	\N
14	PAY-202610-014	26	2026-10	38500.00	mtn	+2290196684830	paye	2026-10-28 19:13:42.706954+00	197.234.223.223	2026-10-29 02:04:38.592+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13235967592	Versement émoluments	\N	\N
13	PAY-202610-013	19	2026-10	54000.00	celtis	+2290141981698	paye	2026-10-28 15:58:47.841125+00	102.202.111.221	2026-10-29 02:08:11.67+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	DJT4QA6WJ6	Versement émoluments	\N	\N
15	PAY-202610-015	58	2026-10	5000.00	celtis	+2290192161396	paye	2026-10-28 21:38:00.873001+00	41.85.163.231	2026-10-29 02:12:18.083+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	DJT2QA6Z9G	Versement émoluments	\N	\N
12	PAY-202610-012	23	2026-10	6000.00	mtn	+2290197276352	paye	2026-10-28 15:08:48.325565+00	137.255.192.118	2026-10-29 02:15:50.759+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13235974089	Versement émoluments	\N	\N
19	PAY-202610-019	15	2026-10	18000.00	mtn	+2290197307394	paye	2026-10-29 21:00:06.112123+00	41.216.54.231	2026-10-29 21:28:15.928+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13243302270	Versement émoluments	\N	\N
18	PAY-202610-018	13	2026-10	21000.00	mtn	+2290166934654	paye	2026-10-29 18:55:43.754349+00	197.234.223.223	2026-10-29 21:29:27.831+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13243316627	Versement émoluments	\N	\N
17	PAY-202610-017	51	2026-10	24000.00	mtn	+2290167290755	paye	2026-10-29 09:07:37.594863+00	197.234.223.213	2026-10-29 21:30:22.776+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13243322517	Versement émoluments	\N	\N
16	PAY-202610-016	53	2026-10	10000.00	mtn	+2290197243191	paye	2026-10-29 06:23:57.633991+00	197.234.219.222	2026-10-29 21:31:30.605+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13243327817	Versement émoluments	\N	\N
24	PAY-202610-024	33	2026-10	5000.00	mtn	+2290196383411	rejete	2026-10-31 18:00:46.372764+00	41.138.89.201	\N	\N	\N	Erreur de saisie	2026-10-31 19:00:16.859+00	55899634-2a3d-4d0c-a169-c883ddd3b72f
26	PAY-202610-026	33	2026-10	15000.00	mtn	+2290196383411	rejete	2026-10-31 19:08:45.207897+00	41.138.89.201	\N	\N	\N	Erreur de saisie	2026-10-31 19:30:15.791+00	55899634-2a3d-4d0c-a169-c883ddd3b72f
20	PAY-202610-020	29	2026-10	22500.00	mtn	+2290166890982	paye	2026-10-29 22:23:13.194466+00	102.202.111.230	2026-10-31 19:37:20.566+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13258987991	Versement émoluments	\N	\N
21	PAY-202610-021	25	2026-10	10500.00	mtn	+2290190401100	paye	2026-10-30 19:03:56.817771+00	154.66.134.70	2026-10-31 19:38:56.874+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13258899435	Versement émoluments	\N	\N
22	PAY-202610-022	20	2026-10	45000.00	mtn	+2290167681156	paye	2026-10-30 19:47:20.800044+00	137.255.73.207	2026-10-31 19:40:18.234+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13258892382	Versement émoluments	\N	\N
25	PAY-202610-025	7	2026-10	22000.00	mtn	+2290196236082	paye	2026-10-31 18:59:33.211291+00	154.72.113.37	2026-10-31 19:41:41.732+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13258858759	Versement émoluments	\N	\N
23	PAY-202610-023	44	2026-10	10000.00	mtn	+2290167361065	paye	2026-10-30 20:29:46.367956+00	102.202.111.220	2026-10-31 19:42:36.983+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13258883952	Versement émoluments	\N	\N
27	PAY-202610-027	60	2026-10	5000.00	moov	+2290194737866	paye	2026-10-31 19:20:19.403251+00	156.0.213.190	2026-10-31 22:02:34.131+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	032419120034	Versement émoluments	\N	\N
28	PAY-202610-028	33	2026-10	17000.00	moov	+2290195932270	paye	2026-10-31 19:32:18.879758+00	41.138.89.201	2026-10-31 22:03:10.264+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	032419110987	Versement EM	\N	\N
29	PAY-202610-029	27	2026-10	71000.00	mtn	+2290169264439	paye	2026-10-31 20:58:33.405703+00	102.202.111.121	2026-10-31 22:09:58.345+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13260204811	Versement émoluments	\N	\N
32	PAY-202610-032	12	2026-10	6000.00	mtn	+2290197843025	paye	2026-10-31 22:08:03.380215+00	41.216.54.91	2026-10-31 22:23:57.939+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	13260278658	Versement émoluments	\N	\N
30	PAY-202610-030	61	2026-10	21000.00	celtis	+2290140167020	paye	2026-10-31 21:26:21.616268+00	154.72.113.118	2026-10-31 22:34:37.869+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	DJV4QOPAQ8	Versement émoluments	\N	\N
31	PAY-202610-031	57	2026-10	5000.00	moov	+2290164234947	paye	2026-10-31 21:26:45.701193+00	41.138.90.79	2026-10-31 22:36:00.974+00	55899634-2a3d-4d0c-a169-c883ddd3b72f	0324192530	Versement émoluments	\N	\N
\.


--
-- Data for Name: matieres_td; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.matieres_td (id, nom_matiere) FROM stdin;
1	Francais
2	Mathematiques
3	Anglais
5	SVT
6	Philosophie
7	Histoire-Geographie
8	Economie
9	Espagnol
10	Allemand
11	Communication écrite
4	PCT
\.


--
-- Data for Name: postulations; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.postulations (id, creneau_id, professeur_id, statut_validation, date_postulation, motif_retrait) FROM stdin;
24	34	26	Valide	2026-09-14 07:55:27.94048+00	\N
33	34	1	Refuse	2026-09-14 08:46:32.228351+00	\N
23	24	26	Refuse	2026-09-14 07:55:15.793452+00	\N
25	35	26	Refuse	2026-09-14 07:55:34.725746+00	\N
40	35	18	Valide	2026-09-14 13:56:33.631836+00	\N
52	35	27	Refuse	2026-09-15 00:42:59.700917+00	\N
21	32	25	Valide	2026-09-14 07:52:43.094525+00	\N
45	33	19	Valide	2026-09-14 20:30:43.45198+00	\N
53	24	45	Valide	2026-09-15 10:22:38.683524+00	\N
54	24	36	Refuse	2026-09-15 10:23:56.475103+00	\N
32	24	1	Refuse	2026-09-14 08:46:19.175797+00	\N
56	29	7	Valide	2026-09-15 20:34:49.077562+00	\N
57	22	22	Valide	2026-09-16 05:51:10.896145+00	\N
20	22	6	Refuse	2026-09-14 06:42:27.657757+00	\N
36	21	13	Valide	2026-09-14 10:13:47.61354+00	\N
18	21	6	Refuse	2026-09-14 06:40:09.294897+00	\N
37	22	13	Refuse	2026-09-14 10:13:51.013178+00	\N
27	23	20	Valide	2026-09-14 07:58:54.847394+00	\N
22	23	26	Refuse	2026-09-14 07:55:06.354792+00	\N
31	23	1	Refuse	2026-09-14 08:46:15.159058+00	\N
39	25	33	Valide	2026-09-14 12:03:06.386845+00	\N
29	25	52	Refuse	2026-09-14 08:17:41.232102+00	\N
35	25	9	Refuse	2026-09-14 09:14:44.95257+00	\N
43	25	19	Refuse	2026-09-14 20:30:29.09114+00	\N
47	25	8	Refuse	2026-09-14 21:37:36.500733+00	\N
30	26	52	Valide	2026-09-14 08:17:51.032422+00	\N
44	26	19	Refuse	2026-09-14 20:30:38.948733+00	\N
49	30	21	Valide	2026-09-14 22:22:26.036596+00	\N
48	32	21	Refuse	2026-09-14 22:21:03.98771+00	\N
51	27	27	Valide	2026-09-15 00:42:52.91367+00	\N
42	27	18	Refuse	2026-09-14 14:00:57.269771+00	\N
50	27	20	Refuse	2026-09-14 22:31:42.009517+00	\N
34	28	1	Valide	2026-09-14 08:46:54.2162+00	\N
19	31	6	Valide	2026-09-14 06:40:28.365589+00	\N
71	38	52	Valide	2026-09-21 11:13:54.968875+00	\N
58	38	19	Refuse	2026-09-21 09:47:41.63285+00	\N
72	39	52	Refuse	2026-09-21 11:13:58.659186+00	\N
73	51	52	Refuse	2026-09-21 11:14:48.434891+00	\N
85	39	33	Valide	2026-09-22 11:09:25.699564+00	\N
60	39	19	Refuse	2026-09-21 09:48:11.882132+00	\N
59	40	20	Valide	2026-09-21 09:47:59.158184+00	\N
76	40	29	Refuse	2026-09-21 11:40:12.054843+00	\N
77	41	29	Valide	2026-09-21 11:40:36.510158+00	\N
75	44	27	Valide	2026-09-21 11:19:21.806645+00	\N
68	44	18	Refuse	2026-09-21 10:10:18.781645+00	\N
81	44	29	Refuse	2026-09-21 11:45:09.398764+00	\N
67	43	18	Valide	2026-09-21 10:10:04.765107+00	\N
80	43	29	Refuse	2026-09-21 11:45:08.276877+00	\N
64	46	6	Valide	2026-09-21 09:51:42.464998+00	\N
69	46	13	Refuse	2026-09-21 10:36:31.798984+00	\N
65	49	6	Refuse	2026-09-21 09:51:47.983176+00	\N
70	49	13	Valide	2026-09-21 10:36:39.067731+00	\N
61	51	19	Valide	2026-09-21 09:48:33.440835+00	\N
66	52	18	Valide	2026-09-21 10:09:55.639792+00	\N
86	50	45	Valide	2026-09-22 19:13:37.838915+00	\N
78	36	21	Valide	2026-09-21 11:43:17.994973+00	\N
79	37	21	Refuse	2026-09-21 11:43:19.291009+00	\N
82	48	28	Valide	2026-09-21 12:31:25.839137+00	\N
88	37	37	Valide	2026-09-24 10:23:10.234128+00	\N
90	47	54	Valide	2026-09-25 17:21:27.420101+00	\N
83	47	28	Refuse	2026-09-21 12:31:29.631687+00	\N
87	47	8	Refuse	2026-09-24 08:45:17.010898+00	\N
138	60	29	Valide	2026-09-28 13:11:19.660736+00	\N
152	60	26	Refuse	2026-09-28 17:26:05.553999+00	\N
137	57	29	Valide	2026-09-28 13:11:01.936381+00	\N
150	57	26	Refuse	2026-09-28 17:25:37.13087+00	\N
109	79	27	Valide	2026-09-28 12:10:12.150182+00	\N
108	78	27	Valide	2026-09-28 12:10:06.845444+00	\N
145	66	19	Valide	2026-09-28 14:07:07.092581+00	\N
164	66	9	Refuse	2026-09-28 20:16:14.761766+00	\N
104	66	52	Refuse	2026-09-28 12:07:58.605313+00	\N
107	70	17	Valide	2026-09-28 12:09:27.474939+00	\N
133	70	21	Refuse	2026-09-28 12:57:39.485741+00	\N
130	70	25	Refuse	2026-09-28 12:51:29.411403+00	\N
99	67	17	Valide	2026-09-28 12:06:02.865616+00	\N
132	67	21	Refuse	2026-09-28 12:56:27.540837+00	\N
131	67	25	Refuse	2026-09-28 12:51:34.856851+00	\N
165	65	9	Valide	2026-09-28 20:16:32.005069+00	\N
102	65	52	Refuse	2026-09-28 12:07:19.926134+00	\N
106	89	28	Valide	2026-09-28 12:08:29.81752+00	\N
147	89	36	Refuse	2026-09-28 17:03:30.430284+00	\N
166	74	28	Valide	2026-09-28 23:08:56.95161+00	\N
142	74	19	Refuse	2026-09-28 14:05:13.000929+00	\N
139	71	19	Refuse	2026-09-28 13:58:13.022433+00	\N
127	71	33	Refuse	2026-09-28 12:32:28.215651+00	\N
95	71	52	Refuse	2026-09-28 12:04:51.178726+00	\N
144	62	19	Refuse	2026-09-28 14:05:31.831552+00	\N
101	62	52	Refuse	2026-09-28 12:06:52.049587+00	\N
140	63	19	Refuse	2026-09-28 13:58:46.416606+00	\N
96	63	52	Refuse	2026-09-28 12:05:21.30514+00	\N
126	84	33	Valide	2026-09-28 12:31:42.301727+00	\N
115	69	4	Valide	2026-09-28 12:17:03.68576+00	\N
91	69	6	Refuse	2026-09-28 11:57:28.793072+00	\N
118	69	22	Refuse	2026-09-28 12:20:55.411791+00	\N
114	68	4	Valide	2026-09-28 12:16:07.381757+00	\N
92	68	6	Refuse	2026-09-28 11:57:51.647021+00	\N
123	68	13	Refuse	2026-09-28 12:24:51.623536+00	\N
141	53	19	Valide	2026-09-28 14:04:40.662615+00	\N
97	53	52	Refuse	2026-09-28 12:05:32.525329+00	\N
143	56	19	Valide	2026-09-28 14:05:19.212541+00	\N
100	56	52	Refuse	2026-09-28 12:06:43.427252+00	\N
136	54	21	Valide	2026-09-28 13:06:49.501885+00	\N
163	54	37	Refuse	2026-09-28 20:02:28.736473+00	\N
135	55	21	Valide	2026-09-28 13:06:39.786139+00	\N
160	55	37	Refuse	2026-09-28 19:16:39.721423+00	\N
151	64	26	Valide	2026-09-28 17:25:55.813837+00	\N
117	64	27	Refuse	2026-09-28 12:20:10.894047+00	\N
149	61	26	Valide	2026-09-28 17:25:33.235352+00	\N
116	61	27	Refuse	2026-09-28 12:19:42.159364+00	\N
161	94	37	Valide	2026-09-28 19:18:02.905469+00	\N
134	94	21	Refuse	2026-09-28 12:59:15.788148+00	\N
93	93	6	Valide	2026-09-28 11:58:06.501797+00	\N
113	93	4	Refuse	2026-09-28 12:15:37.500074+00	\N
125	93	13	Refuse	2026-09-28 12:27:54.856467+00	\N
124	81	27	Valide	2026-09-28 12:25:08.124102+00	\N
122	81	20	Refuse	2026-09-28 12:24:33.056296+00	\N
120	88	20	Valide	2026-09-28 12:23:59.831463+00	\N
121	88	27	Refuse	2026-09-28 12:24:32.381234+00	\N
159	88	45	Refuse	2026-09-28 18:51:56.428949+00	\N
110	86	27	Valide	2026-09-28 12:11:29.309013+00	\N
119	92	27	Refuse	2026-09-28 12:23:07.755712+00	\N
155	82	7	Refuse	2026-09-28 17:56:09.330164+00	\N
154	73	7	Refuse	2026-09-28 17:55:44.848521+00	\N
146	74	36	Refuse	2026-09-28 17:01:07.669468+00	\N
98	74	52	Refuse	2026-09-28 12:05:51.66951+00	\N
105	84	28	Refuse	2026-09-28 12:08:13.761246+00	\N
167	71	36	Valide	2026-09-28 23:10:26.590243+00	\N
168	62	36	Valide	2026-09-28 23:11:34.152657+00	\N
169	63	33	Valide	2026-09-28 23:12:40.357285+00	\N
158	61	45	Refuse	2026-09-28 18:51:39.550732+00	\N
148	81	26	Refuse	2026-09-28 17:25:23.500226+00	\N
171	85	53	Valide	2026-09-29 06:44:24.523175+00	\N
170	91	53	Refuse	2026-09-29 06:44:21.773715+00	\N
173	92	44	Valide	2026-09-29 08:22:56.079104+00	\N
172	92	20	Refuse	2026-09-29 07:12:47.28487+00	\N
174	75	20	Valide	2026-09-29 12:44:53.603344+00	\N
175	76	20	Refuse	2026-09-29 12:44:58.617775+00	\N
178	77	15	Valide	2026-09-29 17:12:27.041491+00	\N
179	80	15	Valide	2026-09-29 17:13:20.688174+00	\N
182	58	7	Valide	2026-09-29 18:30:55.322723+00	\N
181	59	7	Valide	2026-09-29 18:30:27.585481+00	\N
184	83	56	Valide	2026-09-30 07:18:18.384756+00	\N
183	90	56	Valide	2026-09-30 07:18:11.931424+00	\N
186	91	57	Valide	2026-09-30 12:52:14.264177+00	\N
187	72	48	Valide	2026-09-30 14:31:33.254397+00	\N
176	82	48	Refuse	2026-09-29 13:16:30.500104+00	\N
177	73	48	Valide	2026-09-29 13:17:42.384279+00	\N
188	82	60	Valide	2026-09-30 17:19:07.44251+00	\N
190	87	61	Valide	2026-10-01 12:47:50.428148+00	\N
185	87	7	Refuse	2026-09-30 12:35:37.887189+00	\N
191	76	36	Valide	2026-10-03 22:27:28.551201+00	\N
189	76	8	Refuse	2026-09-30 19:43:56.128943+00	\N
197	97	19	Valide	2026-10-05 09:19:53.687298+00	\N
241	97	52	Refuse	2026-10-05 11:36:02.801817+00	\N
198	96	19	Valide	2026-10-05 09:20:03.011539+00	\N
242	96	52	Refuse	2026-10-05 11:36:10.54856+00	\N
267	117	51	Valide	2026-10-06 08:24:39.654397+00	\N
228	109	51	Refuse	2026-10-05 11:14:04.130675+00	\N
268	120	51	Valide	2026-10-06 08:24:46.863834+00	\N
270	120	6	Refuse	2026-10-06 08:30:21.772821+00	\N
227	112	51	Refuse	2026-10-05 11:13:31.875526+00	\N
251	99	20	Valide	2026-10-05 11:50:26.530009+00	\N
217	99	26	Refuse	2026-10-05 10:57:46.390062+00	\N
261	100	20	Refuse	2026-10-05 19:20:48.331756+00	\N
250	118	36	Valide	2026-10-05 11:37:19.863444+00	\N
257	118	19	Refuse	2026-10-05 16:32:08.436618+00	\N
244	119	36	Valide	2026-10-05 11:36:35.015132+00	\N
255	119	19	Refuse	2026-10-05 16:31:42.02923+00	\N
235	102	13	Refuse	2026-10-05 11:26:30.929633+00	\N
280	129	61	Valide	2026-10-06 20:37:32.325212+00	\N
237	112	13	Refuse	2026-10-05 11:26:46.569699+00	\N
238	126	13	Refuse	2026-10-05 11:26:59.421184+00	\N
231	103	13	Refuse	2026-10-05 11:26:01.664533+00	\N
253	129	60	Refuse	2026-10-05 16:24:55.504524+00	\N
233	109	13	Refuse	2026-10-05 11:26:13.527966+00	\N
229	127	13	Refuse	2026-10-05 11:25:05.712595+00	\N
265	105	29	Valide	2026-10-05 21:52:40.000876+00	\N
208	105	26	Refuse	2026-10-05 10:56:17.903531+00	\N
264	108	29	Valide	2026-10-05 21:52:18.060699+00	\N
211	108	26	Refuse	2026-10-05 10:56:44.691716+00	\N
263	103	4	Valide	2026-10-05 21:37:53.617604+00	\N
262	102	4	Valide	2026-10-05 21:36:45.483784+00	\N
210	104	26	Valide	2026-10-05 10:56:39.191708+00	\N
212	114	26	Refuse	2026-10-05 10:56:50.514997+00	\N
213	128	26	Refuse	2026-10-05 10:57:03.846706+00	\N
207	101	26	Valide	2026-10-05 10:56:01.926824+00	\N
209	115	26	Refuse	2026-10-05 10:56:28.281775+00	\N
219	125	26	Refuse	2026-10-05 10:58:43.402102+00	\N
222	123	27	Valide	2026-10-05 11:01:39.481616+00	\N
214	123	26	Refuse	2026-10-05 10:57:16.138691+00	\N
221	122	27	Valide	2026-10-05 11:01:38.356706+00	\N
215	122	26	Refuse	2026-10-05 10:57:23.938496+00	\N
220	125	27	Valide	2026-10-05 11:00:10.94946+00	\N
245	125	20	Refuse	2026-10-05 11:36:50.600486+00	\N
256	113	19	Valide	2026-10-05 16:32:00.244943+00	\N
258	116	19	Valide	2026-10-05 16:32:33.984521+00	\N
226	130	10	Valide	2026-10-05 11:13:22.878226+00	\N
252	126	58	Valide	2026-10-05 13:18:02.23499+00	\N
225	126	6	Refuse	2026-10-05 11:11:58.225314+00	\N
224	127	6	Valide	2026-10-05 11:11:03.322368+00	\N
216	100	26	Valide	2026-10-05 10:57:45.303928+00	\N
196	100	4	Refuse	2026-10-05 09:16:48.794927+00	\N
249	128	20	Valide	2026-10-05 11:37:18.623572+00	\N
199	95	51	Retiree	2026-10-05 10:04:35.306032+00	Indisponibilité de dernière minute
232	107	13	Valide	2026-10-05 11:26:10.444769+00	\N
273	107	1	Refuse	2026-10-06 12:24:43.182832+00	\N
200	98	51	Retiree	2026-10-05 10:04:49.325266+00	Indisponibilité de dernière minute
236	106	13	Valide	2026-10-05 11:26:40.488052+00	\N
272	106	1	Refuse	2026-10-06 12:24:32.912568+00	\N
230	117	13	Retiree	2026-10-05 11:25:44.78057+00	Indisponibilité de dernière minute du professeur
234	120	13	Retiree	2026-10-05 11:26:28.528447+00	Indisponibilité de dernière minute du professeur
193	95	6	Valide	2026-10-05 07:52:53.812015+00	\N
195	95	13	Refuse	2026-10-05 08:07:06.655038+00	\N
192	98	6	Valide	2026-10-05 07:48:52.506936+00	\N
194	98	13	Refuse	2026-10-05 08:07:00.212971+00	\N
276	121	15	Valide	2026-10-06 15:24:14.620736+00	\N
277	124	15	Valide	2026-10-06 15:24:15.753378+00	\N
254	124	60	Refuse	2026-10-05 16:26:24.286911+00	\N
203	110	17	Valide	2026-10-05 10:23:09.333568+00	\N
240	110	21	Refuse	2026-10-05 11:33:35.047106+00	\N
260	110	25	Refuse	2026-10-05 18:23:16.736784+00	\N
223	111	17	Valide	2026-10-05 11:06:16.919246+00	\N
239	111	21	Refuse	2026-10-05 11:33:17.178253+00	\N
259	111	25	Refuse	2026-10-05 18:23:00.466728+00	\N
271	112	22	Valide	2026-10-06 10:33:36.246804+00	\N
269	112	6	Refuse	2026-10-06 08:30:13.188288+00	\N
281	109	22	Valide	2026-10-07 13:16:51.515975+00	\N
283	115	9	Retiree	2026-10-07 18:38:24.328837+00	Le professeur n'est plus disponible
282	114	9	Retiree	2026-10-07 18:37:38.094181+00	Le professeur n'est plus disponible
278	115	20	Refuse	2026-10-06 18:15:22.08837+00	\N
293	132	23	Valide	2026-10-12 06:54:03.439753+00	\N
291	135	28	Valide	2026-10-11 17:58:37.071738+00	\N
292	133	23	Valide	2026-10-12 06:53:41.194425+00	\N
286	131	19	Valide	2026-10-11 11:24:53.169267+00	\N
288	131	52	Refuse	2026-10-11 13:28:47.464686+00	\N
287	134	19	Valide	2026-10-11 11:24:58.436726+00	\N
289	134	52	Refuse	2026-10-11 13:29:19.479413+00	\N
298	142	26	Valide	2026-10-12 10:07:44.226659+00	\N
300	141	26	Valide	2026-10-12 10:07:57.858301+00	\N
301	139	26	Refuse	2026-10-12 10:08:02.696936+00	\N
295	138	36	Refuse	2026-10-12 09:05:28.568736+00	\N
296	144	17	Valide	2026-10-12 09:10:52.46822+00	\N
297	147	17	Valide	2026-10-12 09:14:30.85793+00	\N
294	145	36	Valide	2026-10-12 09:04:46.74263+00	\N
325	174	19	Valide	2026-10-12 10:53:29.632274+00	\N
326	174	9	Refuse	2026-10-12 10:53:45.143576+00	\N
341	174	52	Refuse	2026-10-12 11:21:41.819797+00	\N
305	158	27	Valide	2026-10-12 10:32:21.688022+00	\N
354	162	44	Valide	2026-10-12 18:00:17.595889+00	\N
357	157	53	Valide	2026-10-12 20:11:47.310046+00	\N
306	152	27	Valide	2026-10-12 10:33:09.643921+00	\N
329	152	20	Refuse	2026-10-12 10:56:18.221146+00	\N
309	151	27	Valide	2026-10-12 10:35:19.687488+00	\N
351	163	51	Valide	2026-10-12 11:45:36.082923+00	\N
302	163	6	Refuse	2026-10-12 10:29:09.014176+00	\N
359	170	29	Valide	2026-10-12 22:17:57.351478+00	\N
316	170	26	Refuse	2026-10-12 10:45:58.383308+00	\N
358	171	29	Valide	2026-10-12 22:17:50.930375+00	\N
315	171	26	Refuse	2026-10-12 10:45:42.369786+00	\N
337	150	52	Valide	2026-10-12 11:15:53.240866+00	\N
323	150	9	Refuse	2026-10-12 10:48:28.841718+00	\N
339	153	52	Valide	2026-10-12 11:15:59.82414+00	\N
328	142	20	Refuse	2026-10-12 10:55:59.698324+00	\N
299	136	26	Refuse	2026-10-12 10:07:50.409589+00	\N
327	139	20	Valide	2026-10-12 10:54:41.722633+00	\N
360	136	20	Valide	2026-10-13 07:00:26.377956+00	\N
338	140	4	Valide	2026-10-12 11:15:57.495067+00	\N
304	140	6	Refuse	2026-10-12 10:29:30.192074+00	\N
307	140	13	Refuse	2026-10-12 10:34:36.533245+00	\N
333	143	4	Valide	2026-10-12 11:15:29.143311+00	\N
303	143	6	Refuse	2026-10-12 10:29:20.002197+00	\N
308	143	13	Refuse	2026-10-12 10:34:50.981901+00	\N
336	137	52	Valide	2026-10-12 11:15:41.393924+00	\N
322	137	19	Refuse	2026-10-12 10:47:19.765776+00	\N
335	145	52	Refuse	2026-10-12 11:15:36.437396+00	\N
334	166	52	Refuse	2026-10-12 11:15:31.031241+00	\N
331	138	52	Valide	2026-10-12 11:15:15.326612+00	\N
318	138	19	Refuse	2026-10-12 10:46:22.350282+00	\N
332	167	52	Refuse	2026-10-12 11:15:18.424793+00	\N
330	146	52	Refuse	2026-10-12 11:14:54.610493+00	\N
324	173	9	Valide	2026-10-12 10:50:08.190637+00	\N
340	173	52	Refuse	2026-10-12 11:16:17.756735+00	\N
319	167	19	Valide	2026-10-12 10:46:34.083054+00	\N
353	167	33	Refuse	2026-10-12 11:54:31.360391+00	\N
317	146	19	Refuse	2026-10-12 10:46:14.391262+00	\N
320	166	19	Valide	2026-10-12 10:46:53.804027+00	\N
352	166	33	Refuse	2026-10-12 11:54:19.984058+00	\N
321	145	19	Refuse	2026-10-12 10:47:01.577229+00	\N
349	160	21	Valide	2026-10-12 11:30:39.747301+00	\N
346	147	21	Refuse	2026-10-12 11:30:21.243984+00	\N
347	168	21	Refuse	2026-10-12 11:30:28.753653+00	\N
348	172	21	Refuse	2026-10-12 11:30:33.630032+00	\N
342	154	21	Valide	2026-10-12 11:28:31.097414+00	\N
343	144	21	Refuse	2026-10-12 11:29:34.451848+00	\N
344	165	21	Refuse	2026-10-12 11:30:10.604695+00	\N
345	169	21	Refuse	2026-10-12 11:30:12.526906+00	\N
310	144	25	Refuse	2026-10-12 10:43:12.7785+00	\N
312	147	25	Refuse	2026-10-12 10:43:42.592634+00	\N
355	155	7	Valide	2026-10-12 18:13:05.859959+00	\N
311	165	25	Valide	2026-10-12 10:43:29.848348+00	\N
313	169	25	Refuse	2026-10-12 10:43:54.45044+00	\N
314	168	25	Valide	2026-10-12 10:44:23.379337+00	\N
362	159	61	Valide	2026-10-13 08:39:18.131418+00	\N
356	159	7	Refuse	2026-10-12 18:20:14.764628+00	\N
366	169	37	Valide	2026-10-13 09:35:37.448101+00	\N
363	172	37	Valide	2026-10-13 08:41:38.065307+00	\N
361	146	36	Valide	2026-10-13 07:37:17.000702+00	\N
365	161	28	Valide	2026-10-13 09:19:35.180169+00	\N
364	164	37	Valide	2026-10-13 08:41:46.512304+00	\N
350	164	21	Refuse	2026-10-12 11:30:57.739671+00	\N
368	156	28	Valide	2026-10-16 13:20:03.553324+00	\N
369	148	36	Valide	2026-10-16 21:11:48.226944+00	\N
367	149	36	Refuse	2026-10-15 19:52:35.132278+00	\N
376	175	19	Valide	2026-10-19 07:42:23.550159+00	\N
374	175	36	Refuse	2026-10-19 07:11:44.759063+00	\N
370	175	52	Refuse	2026-10-19 06:50:01.654022+00	\N
377	178	19	Valide	2026-10-19 07:42:29.769899+00	\N
375	178	36	Refuse	2026-10-19 07:12:03.064296+00	\N
371	178	52	Refuse	2026-10-19 06:50:02.872354+00	\N
373	177	6	Valide	2026-10-19 06:58:04.559855+00	\N
372	176	6	Valide	2026-10-19 06:57:50.830546+00	\N
385	179	20	Valide	2026-10-19 08:42:49.869971+00	\N
380	179	26	Refuse	2026-10-19 08:29:34.916144+00	\N
379	180	26	Valide	2026-10-19 08:29:31.339206+00	\N
401	188	27	Valide	2026-10-19 09:23:23.075684+00	\N
400	189	27	Valide	2026-10-19 09:23:21.175972+00	\N
418	206	13	Valide	2026-10-19 10:07:31.373993+00	\N
419	205	13	Valide	2026-10-19 10:07:33.685757+00	\N
423	196	13	Refuse	2026-10-19 10:07:54.822421+00	\N
422	186	13	Refuse	2026-10-19 10:07:51.101392+00	\N
421	201	13	Refuse	2026-10-19 10:07:47.382794+00	\N
406	200	26	Valide	2026-10-19 09:30:04.267556+00	\N
407	194	26	Refuse	2026-10-19 09:30:35.942265+00	\N
405	204	26	Refuse	2026-10-19 09:30:01.956132+00	\N
409	203	26	Valide	2026-10-19 09:30:38.972338+00	\N
408	207	26	Refuse	2026-10-19 09:30:37.627181+00	\N
410	192	26	Refuse	2026-10-19 09:30:40.524342+00	\N
425	198	51	Valide	2026-10-19 10:20:36.090527+00	\N
390	198	6	Refuse	2026-10-19 09:01:47.498315+00	\N
435	199	8	Refuse	2026-10-19 17:07:57.297827+00	\N
403	199	36	Refuse	2026-10-19 09:25:11.814678+00	\N
394	195	10	Valide	2026-10-19 09:20:01.937653+00	\N
388	191	6	Valide	2026-10-19 08:53:16.191974+00	\N
382	185	6	Refuse	2026-10-19 08:35:00.501899+00	\N
381	181	6	Refuse	2026-10-19 08:34:56.078045+00	\N
389	196	6	Valide	2026-10-19 09:01:46.515616+00	\N
384	186	6	Refuse	2026-10-19 08:35:09.219367+00	\N
383	182	6	Refuse	2026-10-19 08:35:07.392619+00	\N
392	192	20	Valide	2026-10-19 09:16:40.987267+00	\N
404	194	27	Valide	2026-10-19 09:26:29.788816+00	\N
393	194	20	Refuse	2026-10-19 09:16:46.541268+00	\N
431	190	7	Refuse	2026-10-19 11:32:59.728268+00	\N
430	187	7	Refuse	2026-10-19 11:32:57.756544+00	\N
427	185	51	Valide	2026-10-19 11:11:53.730623+00	\N
426	186	51	Valide	2026-10-19 11:11:47.497991+00	\N
396	184	17	Valide	2026-10-19 09:20:44.896297+00	\N
433	184	21	Refuse	2026-10-19 12:52:13.504781+00	\N
395	183	17	Valide	2026-10-19 09:20:44.062659+00	\N
432	183	21	Refuse	2026-10-19 12:52:12.203669+00	\N
413	181	22	Valide	2026-10-19 09:46:37.90541+00	\N
412	182	22	Valide	2026-10-19 09:44:13.144446+00	\N
428	204	18	Valide	2026-10-19 11:22:50.170334+00	\N
429	207	18	Valide	2026-10-19 11:23:25.198765+00	\N
391	193	52	Refuse	2026-10-19 09:15:32.322323+00	\N
437	197	28	Valide	2026-10-19 19:25:18.396569+00	\N
398	197	36	Refuse	2026-10-19 09:22:48.456781+00	\N
399	193	36	Retiree	2026-10-19 09:22:51.907364+00	Le professeur n'a pas respecté les exigences en matière de délai de dépôt des sujets
416	202	13	Refuse	2026-10-19 10:07:24.393774+00	\N
414	191	13	Refuse	2026-10-19 10:07:14.976735+00	\N
415	185	13	Refuse	2026-10-19 10:07:19.55827+00	\N
417	181	13	Refuse	2026-10-19 10:07:28.473279+00	\N
420	182	13	Refuse	2026-10-19 10:07:40.798899+00	\N
441	201	4	Valide	2026-10-19 22:23:56.132936+00	\N
440	202	4	Valide	2026-10-19 22:23:12.422186+00	\N
442	198	4	Refuse	2026-10-19 22:56:59.351954+00	\N
439	199	28	Valide	2026-10-19 19:25:25.127369+00	\N
444	190	15	Valide	2026-10-20 09:19:42.155279+00	\N
443	187	15	Valide	2026-10-20 09:19:40.866746+00	\N
446	209	1	Valide	2026-10-22 12:05:15.025998+00	\N
445	210	1	Valide	2026-10-22 12:05:14.141943+00	\N
438	193	28	Valide	2026-10-19 19:25:23.976158+00	\N
453	215	20	Valide	2026-10-26 08:21:32.901806+00	\N
448	215	26	Refuse	2026-10-26 06:58:00.417743+00	\N
447	216	26	Valide	2026-10-26 06:57:58.923688+00	\N
449	213	6	Valide	2026-10-26 07:07:18.137899+00	\N
456	213	4	Refuse	2026-10-26 09:32:33.380106+00	\N
451	213	13	Refuse	2026-10-26 07:32:02.369507+00	\N
450	212	6	Valide	2026-10-26 07:07:22.267323+00	\N
457	212	4	Refuse	2026-10-26 09:32:34.489235+00	\N
452	212	13	Refuse	2026-10-26 07:32:03.42838+00	\N
458	211	19	Valide	2026-10-26 13:24:31.853949+00	\N
454	211	52	Refuse	2026-10-26 09:06:03.383972+00	\N
459	214	19	Valide	2026-10-26 13:24:33.066197+00	\N
455	214	52	Refuse	2026-10-26 09:06:04.306133+00	\N
461	230	26	Valide	2026-10-27 02:08:45.192631+00	\N
472	230	29	Refuse	2026-10-27 05:30:13.672466+00	\N
460	222	26	Refuse	2026-10-27 02:08:41.731266+00	\N
462	231	26	Refuse	2026-10-27 02:08:47.147245+00	\N
463	232	26	Valide	2026-10-27 02:08:48.247901+00	\N
474	232	29	Refuse	2026-10-27 05:30:17.199977+00	\N
465	221	26	Refuse	2026-10-27 02:08:50.274711+00	\N
464	233	26	Refuse	2026-10-27 02:08:49.340047+00	\N
473	231	29	Valide	2026-10-27 05:30:15.038222+00	\N
475	233	29	Valide	2026-10-27 05:30:18.363569+00	\N
482	239	19	Valide	2026-10-27 06:38:10.648828+00	\N
478	239	36	Refuse	2026-10-27 05:50:55.38781+00	\N
483	240	19	Valide	2026-10-27 06:38:14.116946+00	\N
479	240	36	Refuse	2026-10-27 05:50:59.769783+00	\N
484	238	19	Valide	2026-10-27 06:38:18.217071+00	\N
476	238	9	Refuse	2026-10-27 05:41:16.676968+00	\N
495	226	27	Valide	2026-10-27 07:08:27.248972+00	\N
496	225	27	Valide	2026-10-27 07:08:32.18285+00	\N
467	229	26	Valide	2026-10-27 02:11:33.474166+00	\N
499	220	56	Valide	2026-10-27 08:12:09.818569+00	\N
500	224	12	Valide	2026-10-27 09:11:25.308549+00	\N
501	227	12	Valide	2026-10-27 09:11:28.299341+00	\N
471	217	28	Valide	2026-10-27 04:31:50.893771+00	\N
477	217	9	Refuse	2026-10-27 05:42:44.566245+00	\N
489	217	33	Refuse	2026-10-27 06:48:47.912789+00	\N
493	222	27	Valide	2026-10-27 07:08:01.837283+00	\N
497	222	20	Refuse	2026-10-27 07:16:32.902898+00	\N
494	221	27	Valide	2026-10-27 07:08:03.191732+00	\N
469	228	6	Valide	2026-10-27 03:54:32.485539+00	\N
485	228	51	Refuse	2026-10-27 06:43:17.857361+00	\N
486	228	58	Refuse	2026-10-27 06:46:11.822502+00	\N
498	219	13	Valide	2026-10-27 07:43:43.569158+00	\N
468	219	6	Refuse	2026-10-27 03:54:27.410156+00	\N
490	236	25	Valide	2026-10-27 06:53:41.856444+00	\N
491	237	25	Valide	2026-10-27 06:53:45.387669+00	\N
502	235	7	Valide	2026-10-27 10:31:08.633596+00	\N
506	234	7	Valide	2026-10-27 11:21:20.513941+00	\N
488	223	33	Retiree	2026-10-27 06:48:45.724837+00	Indisponibilité du professeur
507	223	56	Valide	2026-10-29 10:30:46.276595+00	\N
470	223	28	Refuse	2026-10-27 04:31:41.621203+00	\N
480	223	36	Refuse	2026-10-27 05:51:10.528822+00	\N
509	218	61	Valide	2026-10-29 21:43:38.477561+00	\N
508	218	1	Refuse	2026-10-29 21:42:26.802229+00	\N
\.


--
-- Data for Name: professeurs; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.professeurs (id, nom, prenom, telephone, email, mot_de_passe, zone_id, matiere_principale_id, actif, date_inscription, valide, reset_token_hash, reset_token_expires_at) FROM stdin;
6	HOUNKANRIN	Yélignan Charlie	+2290140753552	charliehounkanrin@gmail.com	$2b$10$r1foxUzvsAXyOk7f.9VK2ejCifzvT9h1dshzNd0oCpmgvcSTu84z.	1	5	t	2026-09-07 15:30:45.251101+00	t	\N	\N
10	CHANGODELE	Léopold	+2290144152614	leopoldchangodele@gmail.com	$2b$10$DVOIIPh9QL8ep4RCL.sti.Cld.kUX7..WCmgZDXuU0IwMUFKfWStK	1	7	t	2026-09-07 16:09:39.14622+00	t	\N	\N
5	DAH HELOKONON	Pierre Padam	+2290161645378	padampierre@gmail.com	$2b$10$4IsqUEYwNHCTp53p9LgmUOUEyPS9Mt.RB01VtbMPne6fYc0wUmSyC	1	2	t	2026-09-07 15:20:07.03306+00	t	\N	\N
3	ZADJI	BIDOSSESSI ARNAUD	+2290166554564	arnaudzadji066@gmail.com	$2b$10$MdonLvpwbxKOt9uglF/db.8hQqgieTlmNai5cKfmk5eXx7rktFzwi	1	5	t	2026-09-07 15:09:05.591699+00	t	\N	\N
4	TOGBE	FINAGNON JOSEPH	+2290166452845	viptomtogbe@gmail.com	$2b$10$xxQgRaWKfkMIm8n8VIQ7sOoswkNCtQFOumKuW5wkOreT/eOZJBopi	1	5	t	2026-09-07 15:16:43.116863+00	t	\N	\N
7	ASSOGBA	Urbain	+2290196236082	piomedesse@gmail.com	$2b$10$Ou536r4hD.VP5tUKswtU1u2rOd8sFoE7R1CZ8aJYgkORZ/Q2Z11Zy	1	1	t	2026-09-07 15:37:54.254276+00	t	\N	\N
8	NOUTAÏ	Louis	+2290162701029	louislucnou@gmail.com	$2b$10$HfMzrB9Jz8VMb7wNmD.UEOPMD.ko1ms7AdiKhOX/fj7AHFQ9gnjA2	1	4	t	2026-09-07 15:47:20.464196+00	t	\N	\N
9	HINNOU	Florent	+2290166448873	florenthinnou@gmail.com	$2b$10$uwCZhDpx/bRNzn28gHgiXeb9Imu2TXcu9eXsbUYNazseNLEklTew2	1	4	t	2026-09-07 16:04:01.597518+00	t	\N	\N
11	FASSINOU	Auxence	+2290197778213	fauxence1994@gmail.com	$2b$10$9MTSxYbg9fTo2BfLqmkkxuEOZbc7VET0igMsdpZcoMWwPTX7hLWpa	1	5	t	2026-09-07 16:22:49.585802+00	t	\N	\N
12	ZOUTOUNNOU	A. Francis	+2290197843025	zoutounnouf@gmail.com	$2b$10$uWzL5ec5kKSvTK/IxmuFcO9jrV.AuJg5nPRGXpi.RFY8NAGo62gry	1	7	t	2026-09-07 16:26:55.709301+00	t	\N	\N
13	TOHON	Gaël	+2290166934654	mawougnongael91@gmail.com	$2b$10$VnupuCco55fmXRjV0gmJpuVfMio3GD/KnLqcObhL8CYcZXikw.kay	1	5	t	2026-09-07 16:33:23.410967+00	t	\N	\N
15	HOUETO	Olou Dayo Fabrice	+2290197307394	angekarson1@gmail.com	$2b$10$QR0f2.B7tWfZmHz40Iblm.ZDgJGlKpmBIFeYtZFey/VHXzNuMLMh.	1	1	t	2026-09-07 16:40:45.166297+00	t	\N	\N
14	KINNOUMIN	Sagbo William	+2290196777101	sagbowilliam@gmail.com	$2b$10$HF9LXbY6lUEw6t0KqQMN4eDYPkkz051bRsx0IPey0RQOXmyfsC0am	1	3	t	2026-09-07 16:39:31.016318+00	t	\N	\N
20	AKAKPO	CHARBEL ENOCK GERRY COMLAN	+2290155128706	akakpoenock00@gmail.com	$2b$10$TDGISQTfKwPIx48SmRevKOjyO6JinUpWR2IsAuQJfBvXXvlApmSuK	1	2	t	2026-09-07 17:50:27.251345+00	t	\N	\N
16	HOUNZANDJI	Franck M.	+2290162209623	ricoferno@gmail.com	$2b$10$dW5PllkUYnVYjrJvYrToxOz0N60KyFC9S3M6zHaPJYp5B/O5cN1OC	1	1	t	2026-09-07 16:51:13.100552+00	t	\N	\N
17	DAASSI	Médesssè Ghislain	+2290197262346	ghics2000@yahoo.fr	$2b$10$YAMGptZYqPxCKZa/p4yd7Of07/LX75i27eKjJHkKbHEfubvfA0wsi	1	3	t	2026-09-07 16:59:02.36753+00	t	\N	\N
19	TOVITCHEDE	Gédéon	+2290167740109	gedeonfintovitchede@gmail.com	$2b$10$dAtyaDKOBBMEC.MqO67HKOEUPDDeCKircgaFkQop9Ga1ht18nf022	1	4	t	2026-09-07 17:16:05.838767+00	t	\N	\N
18	AGBO	ALDO GERANCE	+2290197860770	aldolalumiere80@gmail.com	$2b$10$r63GiFspBvXC9YTwlpP8vOMccqIj9CF2GzEo0od3jQE8JBqRcZhF2	1	2	t	2026-09-07 17:16:00.073685+00	t	\N	\N
22	AGOSSOU	Ferdinand Virgile	+2290161654101	ferdinandagossou03@gmail.com	$2b$10$5hMOkA8AXzTeziZzmzLLOegWNOPzYwoz/a/NMeKhLmbqK/CGbtOP.	1	5	t	2026-09-07 19:30:57.180675+00	t	\N	\N
21	KINNINNON	Claude	+2290166879680	claudekinninnon@gmail.com	$2b$10$.L6Tx/VUxqKBoThhgm013ese5/oN9h/FHvroJTKjuuxDxZkvn8jLG	1	3	t	2026-09-07 18:53:08.382903+00	t	\N	\N
23	BOKONONHOUI	Eddy Carlos	+2290194259272	carlosbokononhoui@gmail.com	$2b$10$4VHjI5OOFmYdWEGH.YeMsOrIJN0RYwaxbO8/prB/ygHBRljcGcC56	1	3	t	2026-09-07 19:54:56.654117+00	t	\N	\N
24	Noutahi	Augustin	+2290196346526	enagnonaugustinnoutahi@gmail.com	$2b$10$V2.cPe76c7/.38fsbguRf.ed7lS858x.yzwPBAjpAbeImoATlmtoi	1	7	t	2026-09-07 20:08:08.23039+00	t	\N	\N
25	AREMOU	Ramziath	+2290140566832	aremouramziath@gmail.com	$2b$10$CzZJc1rMNsnOumuw7kTSIOGm/kmZn4YkzMC0IRbZ/MAWKUjwRbepy	1	3	t	2026-09-07 20:33:07.194578+00	t	\N	\N
26	Aremou	Farouk	+2290196684830	faroukaremou5@gmail.com	$2b$10$QCeLd.Y7lETDpHSy/Yry2uRllU9T./THbVuhGfoa5M6c/Cp89bkxq	1	2	t	2026-09-07 20:57:10.268132+00	t	\N	\N
30	AZANKPO	Aurel Godfrid	+2290196753761	aurelgodfrid2@gmail.com	$2b$10$yea0eflWIT0ctpBgzdWra.XtDH3iC2fXU006OuHIsHMC1hjiFXroO	1	3	t	2026-09-08 11:33:12.545915+00	t	\N	\N
29	DOSSA	Koba Hubert	+2290166890982	dkobahubert@gmail.com	$2b$10$5cT6jt5..Zf3QV4flbu4/ONTyvTkfzvfyz20t9Z9CbKyCyvauay3y	1	2	t	2026-09-08 00:28:39.3725+00	t	\N	\N
28	EKPONNATON	Comalan Jean-Claude	+2290166243602	ekponnatonjeanclaude@gmail.com	$2b$10$ETcYHDbK1pdCbv57ut.HPexsKMq6HCCEWSceShPXRD7il3Qb05Ts.	1	4	t	2026-09-07 22:51:24.68692+00	t	\N	\N
32	HOUNKPONOU	Horus	+2290167190204	hounkponouhorus@gmail.com	$2b$10$oksIl8RT8TrmV3eQ278avOOdazZKZLysNZpI4haZCopLA27AsF2n.	1	4	t	2026-09-08 17:24:50.376996+00	t	\N	\N
31	Lassissi	Saïbou Adéhoumi	+2290197477948	lassissisaibouadehoumi@gmail.com	$2b$10$zbNRVhUvwIGKV0VdsEso.uOwQwwgzJ5AwH1YcmHXk3bX8YOedKdZ.	1	2	t	2026-09-08 17:15:32.395144+00	t	\N	\N
34	HOUNKOKOE	Saho paul	+2290196979325	sahopaulh@gmail.com	$2b$10$LxKQYrPcoleDMv6GOUl4mOUCZpLFLUEnwBN5QT20Rp82qhMHRsJEG	1	4	t	2026-09-08 17:38:02.222383+00	t	\N	\N
33	ABIDEGBE KPONOU	Jérémie	+2290195932270	jeremieabidegbekponou@gmail.com	$2b$10$TDZbm4d4MMr3o8JAL2wlcOFOVdcFqlnnTkR9sR5ck3YgMsTOst4c6	1	4	t	2026-09-08 17:36:35.177963+00	t	\N	\N
35	ADJOVI	Romaric Cédrick	+2290156848593	romaricadjovi12@gmail.com	$2b$10$1JOrDSN.GwBC0tFvKFqVZO9MVgexr3fxX02g.C.V9l0CurQsWz3dK	1	7	t	2026-09-08 17:50:25.484868+00	t	\N	\N
36	MAGBONDE	Samson	+2290169002846	magbondejerome@gmail.com	$2b$10$.VDc2YJMS.LWzLj0/3XEEOb9cfHq/DH3GkKxKKZwWdf9j.8As0zzm	1	4	t	2026-09-08 17:53:11.112175+00	t	\N	\N
41	HOUESSOU	Evance Samuel	+2290196535520	houess86@gmail.com	$2b$10$vT2ED/UCpqr9zlp9ETSUG.qdTcpuDICI5pK.cY6cCBjFeQi.bB8Zu	1	5	t	2026-09-08 19:30:31.281232+00	t	\N	\N
40	Avocevou	Emmanuel	+2290154916157	avocevouemmanuel5@gmail.com	$2b$10$kWrvQlHex6kv9Z93e2AXmOpzejxeeHGTrVyr8T9/zQoqAqOv9mCci	1	10	t	2026-09-08 19:26:44.260507+00	t	\N	\N
39	NOUDOFININ	ARMEL	+2290167814221	armelnou@gmail.com	$2b$10$T9/gKmTE8PnrcEXRrtE6senSL5jAlabjkg5OxLyixoOTzg0DnIWhC	1	4	t	2026-09-08 18:36:37.661067+00	t	\N	\N
38	SOGLOHOUN	Fortuné	+2290161221159	soglohounfortun93@gmail.com	$2b$10$jhjqqcq7e3X2EpLUfw5E7uVZ4JtffeUxIfmwq7yhSiVYVO.beauIW	1	4	t	2026-09-08 18:28:36.420445+00	t	\N	\N
37	KIKI	S. Siméon	+2290197300324	simkiki30@gmail.com	$2b$10$XCoAcD5U91s6Vsw5MxH48.3i9N8Qd7EFaOG6bG/J.lNlKq3V.EhUi	1	3	t	2026-09-08 18:12:30.520562+00	t	\N	\N
42	DOMESSI	LEON	+2290161366184	leondomessi04@gmail.com	$2b$10$3EtkWHQ5uCMUeV4dhlGlreFdAO1DzLmPfNda5z0rzK/gE545AiGYK	1	5	t	2026-09-08 21:07:27.12653+00	t	\N	\N
43	KOUTON	Jesugnon Anicet	+2290196058903	anicetjesougnon@gmail.com	$2b$10$fW5tR00i6aEu2smXwGHGouYNgBdS8JxUmgRNIlxhG8KPL0o.yOOiG	1	2	t	2026-09-08 21:16:12.672996+00	t	\N	\N
27	AMANKPE	Modeste	+2290169264439	amankpemodeste761@gmail.com	$2b$10$eQPgW/zir60GII0LFG1EyOiwec8VNHZe7Eth/saTeh0a69NFjXY0a	1	2	t	2026-09-07 21:05:16.709715+00	t	\N	\N
60	BOSSOU	Kossoun Raoul	+2290194737866	bossouraoul82@gmail.com	$2b$10$e2u07LvxMbGLJ3mOTICRtOdMQqqxPoHF2RADPzESlmQQMRi25BeHe	1	1	t	2026-09-30 17:04:27.540989+00	t	\N	\N
45	HOLONOU	Maougnon Bienvenu	+2290161111852	holonoubienvenu@gmail.com	$2b$10$fHsjJeEr9x3lzdVk9Bk.mO4QvSnUGcqXNkhmzc8NCNBDz861u0COu	1	2	t	2026-09-08 21:49:05.914602+00	t	\N	\N
44	Dansou	Mika	+2290167361065	dansoumika8@gmail.com	$2b$10$l7/KgSOdNoLEPWSh8x1Zrumyj/dzBeNZfJM9NSKKP6R.Gp.KAfn9O	1	2	t	2026-09-08 21:38:33.941449+00	t	\N	\N
58	HLANNON	Yévèdo Paulin	+2290196023399	nistani21@gmail.com	$2b$10$AQgmGwHMYjDhhG3ASl3t.e5q5DEU/3vjHwRSaiL2LRUMgf68iKTAa	1	5	t	2026-09-30 14:45:48.918509+00	t	\N	\N
46	AHOUNHOSSE	Merveille	+2290190830964	merveilleahounhosse54@gmail.com	$2b$10$VIRoeiFptU5JJalxkoVxy.ndQwqyHonWQ9QfuBofpeisd6waQelMK	1	1	t	2026-09-08 22:54:00.098572+00	t	\N	\N
61	AZANDOHOUNSI	Luc	+2290140167020	lucazandohounsi65@gmail.com	$2b$10$A1/xrUl0OWkYNSHQJBI4iORgyAz6pUV2WoMaFlzQY8PR6PIzX2kXa	1	1	t	2026-10-01 11:27:50.341128+00	t	\N	\N
51	SEDODE	Godfroy	+2290167290755	sedodeconstant@gmail.com	$2b$10$iDRpD3wOcQ1bLWNJJsK0eefJRg0XDvjy2Fiol.FOLfluyU.T6OlD.	1	5	t	2026-09-09 15:53:54.532273+00	t	\N	\N
62	KPOGBA	Gislain Sètondji	+2290166823701	kpogbagislain323@gmail.com	$2b$10$7g0Z0wfUROaRsv4YYjqRQuWFL260TiKoqpfsRa7/1aFUt3ksmqx4G	1	5	t	2026-10-17 08:50:45.452903+00	t	\N	\N
50	TODE	Kouami Mauriéna	+2290166052359	kouamitode@gmail.com	$2b$10$SvHi.h25LbKxtssJdJabPOiAKegHzxMa.FpXlQ27Aln.8Pxoa6pDq	1	4	t	2026-09-09 10:34:32.483812+00	t	\N	\N
49	DOSSOU	Brice	+2290197186706	doskice@gmail.com	$2b$10$Z4tnxUMEx82Gq0REEHWSCeKzo0p1czDxZ2sdwzmfQ7n4J3RedHtKa	1	9	t	2026-09-09 07:58:53.677396+00	t	\N	\N
47	DJOSSOU	GERMAIN	+2290166583113	djossougermain0@gmail.com	$2b$10$bLLFCJvxryVygRBV3XAhr.K4aJpyixpglBm5/raNBiAYDJ5vpLbfO	1	4	t	2026-09-09 06:05:16.756917+00	t	\N	\N
1	HOUEGBE	Uriel	+2290169974527	urielaxelhouegbe@gmail.com	$2b$10$kTFT24SIP1kiTHh.450jdepLCViUKeP/iN8GqsSu7snvTAROKciG.	1	2	t	2026-08-09 23:16:20.976307+00	t	fa7685ecbcb7d019415c65057ab028c8421ac020ae27edd245f1fcd9abd6f367	2026-10-29 06:31:36.685+00
52	SEFAN	Dègnon Frédéric	+2290161335492	degnonfrederics@gmail.com	$2b$10$u9g9RH41q1k05DcN39E6aOetO6A70c1SPdNOEEEm.zSH4mowBJpMO	1	4	t	2026-09-09 18:22:50.704256+00	t	\N	\N
53	TOTIN	MARIANO	+2290197243191	marianototin@gmail.com	$2b$10$Fqbd8hRT2tVmJbNFeldk1ehe2hCOT8vlj9h.9saSNyMoTxVkPn7ei	1	8	t	2026-09-11 07:17:19.032568+00	t	\N	\N
48	YESSOUFOU	Assiath	+2290194001802	yessoufouassiath@gmail.com	$2b$10$w3THhZeA8Hig0Tf.sqL5jutQBBBN/TchGYnql5NrYkzXRn9cU328m	1	1	t	2026-09-09 06:50:20.100978+00	t	\N	\N
54	Codjo	Jean Eudes	+2290196386249	codjoabel00@gmail.com	$2b$10$cSehywwb.ASIbmpIBvU7cefzCMgzU3Z6QO6OiAzIjf4uxaHfF8GwG	1	4	t	2026-09-25 17:05:04.634948+00	t	\N	\N
56	EDOU	Louis Bienvenu	+2290152266712	bienvenuedou112@gmail.com	$2b$10$lgs580QoOWHKWG7YHYLXgOXDxqLMnD98AzJQy9prX3izH9TZGurEC	1	6	t	2026-09-29 08:40:33.51473+00	t	\N	\N
57	DOVENON	Cossi Marcellin	+2290164234947	marcepepe@gmail.com	$2b$10$40eSYDYjjZHugTfDF4u7lenEViSuSnedAbr/YrKHkumwqUMJM7d/2	1	8	t	2026-09-30 12:45:06.666461+00	t	\N	\N
59	HOTO	Jules Akpé	+2290196976220	hotojules@gmail.com	$2b$10$V3vxVdjfYgxu8gfGR0Wz/e5KKJDReN3tLcGuha1/IabPtp0mx2lvi	1	1	t	2026-09-30 16:35:46.604622+00	t	\N	\N
55	Adjaho	Camille	+2290155963714	adjahocamille249@gmail.com	$2b$10$GKuBfsr/h9Qi3ZsSsdjOaOJg9TPZyypDviAbzB68tVVxsvU7kNQ7q	1	4	t	2026-09-28 13:45:14.1173+00	t	\N	\N
\.


--
-- Data for Name: semaines; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.semaines (id, libelle, date_debut, date_fin, statut, date_creation, date_cloture) FROM stdin;
13	Semaine 1	2026-09-14	2026-09-20	cloturee	2026-09-14 02:28:21.066135+00	2026-09-20 09:11:44.09+00
14	Semaine 2	2026-09-21	2026-09-27	cloturee	2026-09-21 09:09:35.939759+00	2026-09-27 06:26:54.599+00
15	Semaine 3	2026-09-28	2026-10-04	cloturee	2026-09-28 10:12:52.58795+00	2026-10-05 07:02:01.277+00
16	Semaine 4	2026-10-05	2026-10-11	cloturee	2026-10-05 07:04:46.486298+00	2026-10-11 04:30:17.788+00
17	Semaine 5	2026-10-12	2026-10-18	cloturee	2026-10-11 10:48:13.156178+00	2026-10-19 05:44:03.981+00
18	Semaine 6	2026-10-19	2026-10-25	cloturee	2026-10-19 05:48:52.696139+00	2026-10-25 19:38:14.056+00
19	Semaine 7	2026-10-26	2026-11-01	cloturee	2026-10-26 06:26:53.170438+00	2026-10-31 18:45:09.678+00
\.


--
-- Data for Name: zones; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.zones (id, nom_zone) FROM stdin;
1	Cotonou 
3	Parakou 
\.


--
-- Name: actualites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_id_seq', 3, true);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_images_id_seq', 3, true);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.annees_scolaires_id_seq', 1, true);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_depenses_id_seq', 12, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.classes_id_seq', 28, true);


--
-- Name: coefficients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.coefficients_id_seq', 186, true);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comptes_parents_id_seq', 1, false);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.decisions_passage_id_seq', 2, true);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.depenses_annexes_id_seq', 41, true);


--
-- Name: eleves_exonerations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_exonerations_id_seq', 63, true);


--
-- Name: eleves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_id_seq', 1299, true);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_suspendus_id_seq', 324, true);


--
-- Name: frais_td_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frais_td_id_seq', 28, true);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_admin_id_seq', 2, true);


--
-- Name: galerie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_id_seq', 1, false);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_whatsapp_id_seq', 13, true);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_attempts_id_seq', 2517, true);


--
-- Name: matieres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matieres_id_seq', 11, true);


--
-- Name: mfa_backup_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mfa_backup_codes_id_seq', 5, true);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mois_exoneres_id_seq', 238, true);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.moyennes_semestrielles_id_seq', 2, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_id_seq', 749, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 746, true);


--
-- Name: paiements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_id_seq', 892, true);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_supprimes_id_seq', 12, true);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.penalites_reinscription_id_seq', 1, false);


--
-- Name: presences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.presences_id_seq', 4087, true);


--
-- Name: recompenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recompenses_id_seq', 1, false);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 2, true);


--
-- Name: creneaux_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.creneaux_id_seq', 240, true);


--
-- Name: demandes_retrait_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.demandes_retrait_id_seq', 32, true);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.matieres_td_id_seq', 11, true);


--
-- Name: postulations_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.postulations_id_seq', 509, true);


--
-- Name: professeurs_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.professeurs_id_seq', 62, true);


--
-- Name: semaines_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.semaines_id_seq', 19, true);


--
-- Name: zones_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.zones_id_seq', 3, true);


--
-- Name: actualites_images actualites_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_pkey PRIMARY KEY (id);


--
-- Name: actualites actualites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_pkey PRIMARY KEY (id);


--
-- Name: annees_scolaires annees_scolaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires
    ADD CONSTRAINT annees_scolaires_pkey PRIMARY KEY (id);


--
-- Name: categories_depenses categories_depenses_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_nom_key UNIQUE (nom);


--
-- Name: categories_depenses categories_depenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_pkey PRIMARY KEY (id);


--
-- Name: classes classes_nom_classe_site_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_nom_classe_site_id_key UNIQUE (nom_classe, site_id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: coefficients coefficients_classe_id_matiere_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_matiere_id_key UNIQUE (classe_id, matiere_id);


--
-- Name: coefficients coefficients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_pkey PRIMARY KEY (id);


--
-- Name: comptes_parents comptes_parents_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_matricule_key UNIQUE (matricule);


--
-- Name: comptes_parents comptes_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_pkey PRIMARY KEY (id);


--
-- Name: decisions_passage decisions_passage_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_key UNIQUE (eleve_id);


--
-- Name: decisions_passage decisions_passage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_pkey PRIMARY KEY (id);


--
-- Name: depenses_annexes depenses_annexes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_pkey PRIMARY KEY (id);


--
-- Name: eleves_exonerations eleves_exonerations_eleve_id_annee_scolaire_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_eleve_id_annee_scolaire_id_key UNIQUE (eleve_id, annee_scolaire_id);


--
-- Name: eleves_exonerations eleves_exonerations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_pkey PRIMARY KEY (id);


--
-- Name: eleves eleves_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_matricule_key UNIQUE (matricule);


--
-- Name: eleves eleves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_pkey PRIMARY KEY (id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_key UNIQUE (eleve_id);


--
-- Name: eleves_suspendus eleves_suspendus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_pkey PRIMARY KEY (id);


--
-- Name: frais_td frais_td_classe_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_key UNIQUE (classe_id);


--
-- Name: frais_td frais_td_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_pkey PRIMARY KEY (id);


--
-- Name: galerie_admin galerie_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_pkey PRIMARY KEY (id);


--
-- Name: galerie galerie_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie
    ADD CONSTRAINT galerie_pkey PRIMARY KEY (id);


--
-- Name: log_whatsapp log_whatsapp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: matieres matieres_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_code_key UNIQUE (code);


--
-- Name: matieres matieres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_pkey PRIMARY KEY (id);


--
-- Name: mfa_backup_codes mfa_backup_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_backup_codes
    ADD CONSTRAINT mfa_backup_codes_pkey PRIMARY KEY (id);


--
-- Name: mois_exoneres mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key UNIQUE (eleve_id, mois_souscription, annee_scolaire_id);


--
-- Name: mois_exoneres mois_exoneres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_pkey PRIMARY KEY (id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key UNIQUE (eleve_id, annee_scolaire_id, semestre);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_pkey PRIMARY KEY (id);


--
-- Name: notes notes_eleve_matiere_type_annee_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_matiere_type_annee_semestre_key UNIQUE (eleve_id, matiere_id, type_note, annee_scolaire_id, semestre);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: paiements paiements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_pkey PRIMARY KEY (id);


--
-- Name: paiements_supprimes paiements_supprimes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_pkey PRIMARY KEY (id);


--
-- Name: penalites_reinscription penalites_reinscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_pkey PRIMARY KEY (id);


--
-- Name: presences presences_eleve_id_date_presence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_date_presence_key UNIQUE (eleve_id, date_presence);


--
-- Name: presences presences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_pkey PRIMARY KEY (id);


--
-- Name: recompenses recompenses_note_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_key UNIQUE (note_id);


--
-- Name: recompenses recompenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_pkey PRIMARY KEY (id);


--
-- Name: sites sites_initiale_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_initiale_key UNIQUE (initiale);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: user_sites user_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_pkey PRIMARY KEY (user_id, site_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: creneaux creneaux_classe_id_date_td_heure_debut_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_date_td_heure_debut_key UNIQUE (classe_id, date_td, heure_debut);


--
-- Name: creneaux creneaux_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_pkey PRIMARY KEY (id);


--
-- Name: demandes_retrait demandes_retrait_code_demande_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.demandes_retrait
    ADD CONSTRAINT demandes_retrait_code_demande_key UNIQUE (code_demande);


--
-- Name: demandes_retrait demandes_retrait_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.demandes_retrait
    ADD CONSTRAINT demandes_retrait_pkey PRIMARY KEY (id);


--
-- Name: matieres_td matieres_td_nom_matiere_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_nom_matiere_key UNIQUE (nom_matiere);


--
-- Name: matieres_td matieres_td_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_pkey PRIMARY KEY (id);


--
-- Name: postulations postulations_creneau_id_professeur_id_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_professeur_id_key UNIQUE (creneau_id, professeur_id);


--
-- Name: postulations postulations_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_email_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_email_key UNIQUE (email);


--
-- Name: professeurs professeurs_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_telephone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_telephone_key UNIQUE (telephone);


--
-- Name: semaines semaines_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines
    ADD CONSTRAINT semaines_pkey PRIMARY KEY (id);


--
-- Name: zones zones_nom_zone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_nom_zone_key UNIQUE (nom_zone);


--
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id);


--
-- Name: idx_login_attempts_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_attempts_lookup ON public.login_attempts USING btree (identifiant, portail, date_tentative);


--
-- Name: idx_mfa_backup_codes_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mfa_backup_codes_user ON public.mfa_backup_codes USING btree (user_id, utilise);


--
-- Name: idx_demandes_retrait_code; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_demandes_retrait_code ON td.demandes_retrait USING btree (code_demande);


--
-- Name: idx_demandes_retrait_mois; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_demandes_retrait_mois ON td.demandes_retrait USING btree (mois);


--
-- Name: idx_demandes_retrait_prof; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_demandes_retrait_prof ON td.demandes_retrait USING btree (professeur_id);


--
-- Name: idx_demandes_retrait_statut; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_demandes_retrait_statut ON td.demandes_retrait USING btree (statut);


--
-- Name: idx_professeurs_reset_token_hash; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_professeurs_reset_token_hash ON td.professeurs USING btree (reset_token_hash) WHERE (reset_token_hash IS NOT NULL);


--
-- Name: idx_professeurs_valide; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_professeurs_valide ON td.professeurs USING btree (valide) WHERE (valide = false);


--
-- Name: idx_retrait_prof_mois_actif; Type: INDEX; Schema: td; Owner: -
--

CREATE UNIQUE INDEX idx_retrait_prof_mois_actif ON td.demandes_retrait USING btree (professeur_id, mois) WHERE (statut = ANY (ARRAY['en_attente'::text, 'paye'::text]));


--
-- Name: frais_td trg_frais_td_lock_period; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_frais_td_lock_period BEFORE UPDATE OF montant ON public.frais_td FOR EACH ROW EXECUTE FUNCTION public.trg_frais_td_lock_period_fn();


--
-- Name: annees_scolaires trg_unique_annee_en_cours; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_unique_annee_en_cours BEFORE INSERT OR UPDATE ON public.annees_scolaires FOR EACH ROW EXECUTE FUNCTION public.trg_unique_annee_en_cours_fn();


--
-- Name: users trg_users_scope_coherence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_scope_coherence BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.trg_users_scope_coherence_fn();


--
-- Name: postulations trg_check_max_postulations; Type: TRIGGER; Schema: td; Owner: -
--

CREATE TRIGGER trg_check_max_postulations BEFORE INSERT ON td.postulations FOR EACH ROW EXECUTE FUNCTION td.check_max_postulations();


--
-- Name: actualites actualites_cree_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_cree_par_fkey FOREIGN KEY (cree_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: actualites_images actualites_images_actualite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_actualite_id_fkey FOREIGN KEY (actualite_id) REFERENCES public.actualites(id) ON DELETE CASCADE;


--
-- Name: classes classes_classe_suivante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_classe_suivante_id_fkey FOREIGN KEY (classe_suivante_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: classes classes_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: decisions_passage decisions_passage_decide_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_decide_par_fkey FOREIGN KEY (decide_par) REFERENCES public.users(id);


--
-- Name: decisions_passage decisions_passage_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_nouvelle_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_nouvelle_classe_id_fkey FOREIGN KEY (nouvelle_classe_id) REFERENCES public.classes(id);


--
-- Name: depenses_annexes depenses_annexes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_categorie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_categorie_id_fkey FOREIGN KEY (categorie_id) REFERENCES public.categories_depenses(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_saisi_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_saisi_par_fkey FOREIGN KEY (saisi_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: eleves eleves_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: eleves_exonerations eleves_exonerations_accorde_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_accorde_par_fkey FOREIGN KEY (accorde_par) REFERENCES public.users(id);


--
-- Name: eleves_exonerations eleves_exonerations_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: eleves_exonerations eleves_exonerations_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_suspendu_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_suspendu_par_fkey FOREIGN KEY (suspendu_par) REFERENCES public.users(id);


--
-- Name: frais_td frais_td_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: galerie_admin galerie_admin_ajoute_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_ajoute_par_fkey FOREIGN KEY (ajoute_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: log_whatsapp log_whatsapp_envoye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_envoye_par_fkey FOREIGN KEY (envoye_par) REFERENCES public.users(id);


--
-- Name: mfa_backup_codes mfa_backup_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_backup_codes
    ADD CONSTRAINT mfa_backup_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_exonere_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_exonere_par_fkey FOREIGN KEY (exonere_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: moyennes_semestrielles moyennes_semestrielles_cloture_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_cloture_par_fkey FOREIGN KEY (cloture_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: notes notes_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: paiements_supprimes paiements_supprimes_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: penalites_reinscription penalites_reinscription_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id);


--
-- Name: presences presences_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: presences presences_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: presences presences_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: presences presences_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_depense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_depense_id_fkey FOREIGN KEY (depense_id) REFERENCES public.depenses_annexes(id) ON DELETE SET NULL;


--
-- Name: recompenses recompenses_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_paye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_paye_par_fkey FOREIGN KEY (paye_par) REFERENCES public.users(id);


--
-- Name: user_sites user_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: user_sites user_sites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users users_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: creneaux creneaux_classe_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_matiere_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_semaine_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_semaine_id_fkey FOREIGN KEY (semaine_id) REFERENCES td.semaines(id) ON DELETE CASCADE;


--
-- Name: demandes_retrait demandes_retrait_paye_par_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.demandes_retrait
    ADD CONSTRAINT demandes_retrait_paye_par_fkey FOREIGN KEY (paye_par) REFERENCES public.users(id);


--
-- Name: demandes_retrait demandes_retrait_professeur_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.demandes_retrait
    ADD CONSTRAINT demandes_retrait_professeur_id_fkey FOREIGN KEY (professeur_id) REFERENCES td.professeurs(id) ON DELETE RESTRICT;


--
-- Name: demandes_retrait demandes_retrait_rejete_par_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.demandes_retrait
    ADD CONSTRAINT demandes_retrait_rejete_par_fkey FOREIGN KEY (rejete_par) REFERENCES public.users(id);


--
-- Name: postulations postulations_creneau_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_fkey FOREIGN KEY (creneau_id) REFERENCES td.creneaux(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_professeur_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_professeur_id_fkey FOREIGN KEY (professeur_id) REFERENCES td.professeurs(id) ON DELETE CASCADE;


--
-- Name: professeurs professeurs_matiere_principale_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_matiere_principale_id_fkey FOREIGN KEY (matiere_principale_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: professeurs professeurs_zone_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES td.zones(id) ON DELETE RESTRICT;


--
-- Name: actualites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites_images ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images actualites_images_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_images_lecture_publique ON public.actualites_images FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.actualites a
  WHERE ((a.id = actualites_images.actualite_id) AND (a.statut = 'publie'::text)))));


--
-- Name: actualites actualites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_lecture_publique ON public.actualites FOR SELECT USING ((statut = 'publie'::text));


--
-- Name: annees_scolaires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.annees_scolaires ENABLE ROW LEVEL SECURITY;

--
-- Name: annees_scolaires annees_scolaires_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY annees_scolaires_lecture_staff ON public.annees_scolaires FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: categories_depenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.categories_depenses ENABLE ROW LEVEL SECURITY;

--
-- Name: categories_depenses categories_depenses_lecture_global; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY categories_depenses_lecture_global ON public.categories_depenses FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: classes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;

--
-- Name: classes classes_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_publique ON public.classes FOR SELECT TO anon USING (true);


--
-- Name: classes classes_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_staff ON public.classes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: coefficients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coefficients ENABLE ROW LEVEL SECURITY;

--
-- Name: coefficients coefficients_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY coefficients_lecture_staff ON public.coefficients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: comptes_parents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.comptes_parents ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decisions_passage ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage decisions_passage_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY decisions_passage_lecture ON public.decisions_passage FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: depenses_annexes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.depenses_annexes ENABLE ROW LEVEL SECURITY;

--
-- Name: depenses_annexes depenses_annexes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY depenses_annexes_lecture ON public.depenses_annexes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: eleves; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves eleves_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_acces ON public.eleves USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM (public.user_sites us
             JOIN public.classes c ON ((c.id = eleves.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM public.classes c
          WHERE ((c.id = eleves.classe_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: eleves_exonerations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves_exonerations ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves_exonerations eleves_exonerations_ecriture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_exonerations_ecriture ON public.eleves_exonerations USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: eleves_exonerations eleves_exonerations_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_exonerations_lecture ON public.eleves_exonerations FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = eleves_exonerations.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: eleves_suspendus; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves_suspendus ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves_suspendus eleves_suspendus_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_suspendus_acces ON public.eleves_suspendus USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = eleves_suspendus.site_id))))))))));


--
-- Name: frais_td; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.frais_td ENABLE ROW LEVEL SECURITY;

--
-- Name: frais_td frais_td_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY frais_td_lecture_staff ON public.frais_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: galerie; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie_admin ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin galerie_admin_ajout; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_ajout ON public.galerie_admin FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_lecture ON public.galerie_admin FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_suppression; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_suppression ON public.galerie_admin FOR DELETE USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text])) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (galerie_admin.ajoute_par = auth.uid())))))));


--
-- Name: galerie galerie_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_lecture_publique ON public.galerie FOR SELECT USING (true);


--
-- Name: log_whatsapp; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.log_whatsapp ENABLE ROW LEVEL SECURITY;

--
-- Name: log_whatsapp log_whatsapp_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY log_whatsapp_acces ON public.log_whatsapp FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON (((e.matricule)::text = (log_whatsapp.matricule)::text)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: login_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.matieres ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres matieres_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY matieres_lecture_staff ON public.matieres FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: mfa_backup_codes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mfa_backup_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_backup_codes mfa_backup_codes_lecture_soi; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mfa_backup_codes_lecture_soi ON public.mfa_backup_codes FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: mois_exoneres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mois_exoneres ENABLE ROW LEVEL SECURITY;

--
-- Name: mois_exoneres mois_exoneres_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mois_exoneres_acces ON public.mois_exoneres USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = mois_exoneres.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: moyennes_semestrielles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.moyennes_semestrielles ENABLE ROW LEVEL SECURITY;

--
-- Name: moyennes_semestrielles moyennes_semestrielles_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY moyennes_semestrielles_acces ON public.moyennes_semestrielles USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = moyennes_semestrielles.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = moyennes_semestrielles.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: notes notes_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notes_acces ON public.notes USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = notes.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = notes.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_acces ON public.notifications FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((notifications.roles_cibles IS NULL) OR (u.role = ANY (notifications.roles_cibles))) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = notifications.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = notifications.site_id)))))));


--
-- Name: paiements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements paiements_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_acces ON public.paiements USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = paiements.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: paiements_supprimes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements_supprimes ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements_supprimes paiements_supprimes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_supprimes_lecture ON public.paiements_supprimes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: penalites_reinscription; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.penalites_reinscription ENABLE ROW LEVEL SECURITY;

--
-- Name: penalites_reinscription penalites_reinscription_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY penalites_reinscription_acces ON public.penalites_reinscription USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = penalites_reinscription.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: presences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.presences ENABLE ROW LEVEL SECURITY;

--
-- Name: presences presences_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY presences_acces ON public.presences USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = presences.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = presences.site_id)))))));


--
-- Name: recompenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recompenses ENABLE ROW LEVEL SECURITY;

--
-- Name: recompenses recompenses_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY recompenses_acces ON public.recompenses USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = recompenses.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: sites sites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_publique ON public.sites FOR SELECT TO anon USING (true);


--
-- Name: sites sites_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_staff ON public.sites FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: user_sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_sites ENABLE ROW LEVEL SECURITY;

--
-- Name: user_sites user_sites_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_sites_lecture_soi_meme ON public.user_sites FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_soi_meme ON public.users FOR SELECT USING ((id = auth.uid()));


--
-- Name: users users_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_staff ON public.users FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: creneaux; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.creneaux ENABLE ROW LEVEL SECURITY;

--
-- Name: demandes_retrait; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.demandes_retrait ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres_td; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.matieres_td ENABLE ROW LEVEL SECURITY;

--
-- Name: postulations; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.postulations ENABLE ROW LEVEL SECURITY;

--
-- Name: professeurs; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.professeurs ENABLE ROW LEVEL SECURITY;

--
-- Name: semaines; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.semaines ENABLE ROW LEVEL SECURITY;

--
-- Name: creneaux td_creneaux_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_coordonnateur ON td.creneaux FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: creneaux td_creneaux_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_publique ON td.creneaux FOR SELECT TO anon USING (((statut_creneau = ANY (ARRAY['public'::text, 'cloture'::text])) AND (EXISTS ( SELECT 1
   FROM td.semaines s
  WHERE ((s.id = creneaux.semaine_id) AND (s.statut = 'publiee'::text))))));


--
-- Name: demandes_retrait td_demandes_retrait_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_demandes_retrait_lecture_coordonnateur ON td.demandes_retrait FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: matieres_td td_matieres_td_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_coordonnateur ON td.matieres_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: matieres_td td_matieres_td_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_publique ON td.matieres_td FOR SELECT TO anon USING (true);


--
-- Name: postulations td_postulations_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_postulations_lecture_coordonnateur ON td.postulations FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: professeurs td_professeurs_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_professeurs_lecture_coordonnateur ON td.professeurs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_coordonnateur ON td.semaines FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_publique ON td.semaines FOR SELECT TO anon USING ((statut = 'publiee'::text));


--
-- Name: zones td_zones_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_zones_lecture_coordonnateur ON td.zones FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: zones; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.zones ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict t2zpMM0CAX9uKD9k9o8bw2FbOz5tmyWr3WnZ0EVA8RPvdTwgzyiYa5qsVme8IS5


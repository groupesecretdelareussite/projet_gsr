--
-- PostgreSQL database dump
--

\restrict 1T5YapyQewArz5g7mRs8CiV4uNA9v8JWC45EtAFq6FY9L5XVzRRGIdE5pVYV4iU

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS td_zones_lecture_coordonnateur ON td.zones;
DROP POLICY IF EXISTS td_semaines_lecture_publique ON td.semaines;
DROP POLICY IF EXISTS td_semaines_lecture_coordonnateur ON td.semaines;
DROP POLICY IF EXISTS td_professeurs_lecture_coordonnateur ON td.professeurs;
DROP POLICY IF EXISTS td_postulations_lecture_coordonnateur ON td.postulations;
DROP POLICY IF EXISTS td_matieres_td_lecture_publique ON td.matieres_td;
DROP POLICY IF EXISTS td_matieres_td_lecture_coordonnateur ON td.matieres_td;
DROP POLICY IF EXISTS td_creneaux_lecture_publique ON td.creneaux;
DROP POLICY IF EXISTS td_creneaux_lecture_coordonnateur ON td.creneaux;
DROP POLICY IF EXISTS users_lecture_staff ON public.users;
DROP POLICY IF EXISTS users_lecture_soi_meme ON public.users;
DROP POLICY IF EXISTS user_sites_lecture_soi_meme ON public.user_sites;
DROP POLICY IF EXISTS sites_lecture_staff ON public.sites;
DROP POLICY IF EXISTS sites_lecture_publique ON public.sites;
DROP POLICY IF EXISTS recompenses_acces ON public.recompenses;
DROP POLICY IF EXISTS presences_acces ON public.presences;
DROP POLICY IF EXISTS penalites_reinscription_acces ON public.penalites_reinscription;
DROP POLICY IF EXISTS paiements_supprimes_lecture ON public.paiements_supprimes;
DROP POLICY IF EXISTS paiements_acces ON public.paiements;
DROP POLICY IF EXISTS notifications_acces ON public.notifications;
DROP POLICY IF EXISTS notes_acces ON public.notes;
DROP POLICY IF EXISTS moyennes_semestrielles_acces ON public.moyennes_semestrielles;
DROP POLICY IF EXISTS mois_exoneres_acces ON public.mois_exoneres;
DROP POLICY IF EXISTS matieres_lecture_staff ON public.matieres;
DROP POLICY IF EXISTS log_whatsapp_acces ON public.log_whatsapp;
DROP POLICY IF EXISTS galerie_lecture_publique ON public.galerie;
DROP POLICY IF EXISTS galerie_admin_suppression ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_lecture ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_ajout ON public.galerie_admin;
DROP POLICY IF EXISTS frais_td_lecture_staff ON public.frais_td;
DROP POLICY IF EXISTS eleves_suspendus_acces ON public.eleves_suspendus;
DROP POLICY IF EXISTS eleves_acces ON public.eleves;
DROP POLICY IF EXISTS depenses_annexes_lecture ON public.depenses_annexes;
DROP POLICY IF EXISTS decisions_passage_lecture ON public.decisions_passage;
DROP POLICY IF EXISTS coefficients_lecture_staff ON public.coefficients;
DROP POLICY IF EXISTS classes_lecture_staff ON public.classes;
DROP POLICY IF EXISTS classes_lecture_publique ON public.classes;
DROP POLICY IF EXISTS categories_depenses_lecture_global ON public.categories_depenses;
DROP POLICY IF EXISTS annees_scolaires_lecture_staff ON public.annees_scolaires;
DROP POLICY IF EXISTS actualites_lecture_publique ON public.actualites;
DROP POLICY IF EXISTS actualites_images_lecture_publique ON public.actualites_images;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_zone_id_fkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_matiere_principale_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_professeur_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_semaine_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_paye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_depense_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_admin_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_cloture_par_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_exonere_par_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_envoye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_ajoute_par_fkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_suspendu_par_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_saisi_par_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_categorie_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_nouvelle_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_decide_par_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_classe_suivante_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_actualite_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_cree_par_fkey;
DROP TRIGGER IF EXISTS trg_users_scope_coherence ON public.users;
DROP TRIGGER IF EXISTS trg_unique_annee_en_cours ON public.annees_scolaires;
DROP TRIGGER IF EXISTS trg_frais_td_lock_period ON public.frais_td;
DROP INDEX IF EXISTS public.idx_login_attempts_lookup;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_pkey;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_nom_zone_key;
ALTER TABLE IF EXISTS ONLY td.semaines DROP CONSTRAINT IF EXISTS semaines_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_telephone_key;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_email_key;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_pkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_professeur_id_key;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_pkey;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_nom_matiere_key;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_pkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_date_td_heure_debut_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_initiale_key;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_pkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_key;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_pkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_date_presence_key;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_matiere_type_annee_semestre_key;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_pkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_pkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_pkey;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_code_key;
ALTER TABLE IF EXISTS ONLY public.login_attempts DROP CONSTRAINT IF EXISTS login_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie DROP CONSTRAINT IF EXISTS galerie_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_matricule_key;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_pkey;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_matricule_key;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_pkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_matiere_id_key;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_pkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_nom_classe_site_id_key;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_pkey;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_nom_key;
ALTER TABLE IF EXISTS ONLY public.annees_scolaires DROP CONSTRAINT IF EXISTS annees_scolaires_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_pkey;
ALTER TABLE IF EXISTS td.zones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.semaines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.professeurs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.postulations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.matieres_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.creneaux ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.recompenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.presences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.penalites_reinscription ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements_supprimes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.moyennes_semestrielles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mois_exoneres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matieres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.login_attempts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.log_whatsapp ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie_admin ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.frais_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves_suspendus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.depenses_annexes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.decisions_passage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comptes_parents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.coefficients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories_depenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.annees_scolaires ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS td.zones_id_seq;
DROP TABLE IF EXISTS td.zones;
DROP SEQUENCE IF EXISTS td.semaines_id_seq;
DROP TABLE IF EXISTS td.semaines;
DROP SEQUENCE IF EXISTS td.professeurs_id_seq;
DROP TABLE IF EXISTS td.professeurs;
DROP SEQUENCE IF EXISTS td.postulations_id_seq;
DROP TABLE IF EXISTS td.postulations;
DROP SEQUENCE IF EXISTS td.matieres_td_id_seq;
DROP TABLE IF EXISTS td.matieres_td;
DROP SEQUENCE IF EXISTS td.creneaux_id_seq;
DROP TABLE IF EXISTS td.creneaux;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sites;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.recompenses_id_seq;
DROP TABLE IF EXISTS public.recompenses;
DROP SEQUENCE IF EXISTS public.presences_id_seq;
DROP TABLE IF EXISTS public.presences;
DROP SEQUENCE IF EXISTS public.penalites_reinscription_id_seq;
DROP TABLE IF EXISTS public.penalites_reinscription;
DROP SEQUENCE IF EXISTS public.paiements_supprimes_id_seq;
DROP TABLE IF EXISTS public.paiements_supprimes;
DROP SEQUENCE IF EXISTS public.paiements_id_seq;
DROP TABLE IF EXISTS public.paiements;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notes_id_seq;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.moyennes_semestrielles_id_seq;
DROP TABLE IF EXISTS public.moyennes_semestrielles;
DROP SEQUENCE IF EXISTS public.mois_exoneres_id_seq;
DROP TABLE IF EXISTS public.mois_exoneres;
DROP SEQUENCE IF EXISTS public.matieres_id_seq;
DROP TABLE IF EXISTS public.matieres;
DROP SEQUENCE IF EXISTS public.login_attempts_id_seq;
DROP TABLE IF EXISTS public.login_attempts;
DROP SEQUENCE IF EXISTS public.log_whatsapp_id_seq;
DROP TABLE IF EXISTS public.log_whatsapp;
DROP SEQUENCE IF EXISTS public.galerie_id_seq;
DROP SEQUENCE IF EXISTS public.galerie_admin_id_seq;
DROP TABLE IF EXISTS public.galerie_admin;
DROP TABLE IF EXISTS public.galerie;
DROP SEQUENCE IF EXISTS public.frais_td_id_seq;
DROP TABLE IF EXISTS public.frais_td;
DROP SEQUENCE IF EXISTS public.eleves_suspendus_id_seq;
DROP TABLE IF EXISTS public.eleves_suspendus;
DROP SEQUENCE IF EXISTS public.eleves_id_seq;
DROP TABLE IF EXISTS public.eleves;
DROP SEQUENCE IF EXISTS public.depenses_annexes_id_seq;
DROP TABLE IF EXISTS public.depenses_annexes;
DROP SEQUENCE IF EXISTS public.decisions_passage_id_seq;
DROP TABLE IF EXISTS public.decisions_passage;
DROP SEQUENCE IF EXISTS public.comptes_parents_id_seq;
DROP TABLE IF EXISTS public.comptes_parents;
DROP SEQUENCE IF EXISTS public.coefficients_id_seq;
DROP TABLE IF EXISTS public.coefficients;
DROP SEQUENCE IF EXISTS public.classes_id_seq;
DROP TABLE IF EXISTS public.classes;
DROP SEQUENCE IF EXISTS public.categories_depenses_id_seq;
DROP TABLE IF EXISTS public.categories_depenses;
DROP SEQUENCE IF EXISTS public.annees_scolaires_id_seq;
DROP TABLE IF EXISTS public.annees_scolaires;
DROP SEQUENCE IF EXISTS public.actualites_images_id_seq;
DROP TABLE IF EXISTS public.actualites_images;
DROP SEQUENCE IF EXISTS public.actualites_id_seq;
DROP TABLE IF EXISTS public.actualites;
DROP FUNCTION IF EXISTS td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer);
DROP FUNCTION IF EXISTS public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date);
DROP FUNCTION IF EXISTS public.trg_users_scope_coherence_fn();
DROP FUNCTION IF EXISTS public.trg_unique_annee_en_cours_fn();
DROP FUNCTION IF EXISTS public.trg_frais_td_lock_period_fn();
DROP FUNCTION IF EXISTS public.rls_auto_enable();
DROP FUNCTION IF EXISTS public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]);
DROP SCHEMA IF EXISTS td;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: td; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA td;


--
-- Name: assigner_sites_superviseur(uuid, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  delete from public.user_sites where user_id = p_user_id;
  insert into public.user_sites (user_id, site_id)
  select p_user_id, unnest(p_site_ids);
end;
$$;


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rls_auto_enable() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: trg_frais_td_lock_period_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_frais_td_lock_period_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_debut date;
  v_fin   date;
begin
  select date_debut, date_fin into v_debut, v_fin
  from public.annees_scolaires where statut = 'en_cours';

  if v_debut is not null and current_date between v_debut and v_fin then
    raise exception 'Modification du montant interdite pendant l''année scolaire en cours — uniquement en période de vacances, après l''arbitrage de fin d''année';
  end if;

  return new;
end;
$$;


--
-- Name: trg_unique_annee_en_cours_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_unique_annee_en_cours_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.statut = 'en_cours' and exists (
    select 1 from public.annees_scolaires
    where statut = 'en_cours' and id <> new.id
  ) then
    raise exception 'Une année scolaire est déjà en_cours';
  end if;

  return new;
end;
$$;


--
-- Name: trg_users_scope_coherence_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_users_scope_coherence_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.role in ('chef_site', 'secretaire') and new.site_id is null then
    raise exception 'site_id obligatoire pour le rôle %', new.role;
  end if;

  if new.role in ('coordonnateur','comptable','superviseur') and new.site_id is not null then
    raise exception 'site_id doit être NULL pour le rôle %', new.role;
  end if;

  return new;
end;
$$;


--
-- Name: valider_fin_annee(text, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  -- 1. Créer la nouvelle année scolaire
  insert into public.annees_scolaires (libelle, date_debut, date_fin, statut)
  values (p_nouvelle_libelle, p_nouvelle_date_debut, p_nouvelle_date_fin, 'en_cours');

  -- 2. Clôturer l'ancienne
  update public.annees_scolaires set statut = 'terminee' where statut = 'en_pause';

  -- 3. Appliquer les décisions "passe"
  update public.eleves e
  set classe_id = d.nouvelle_classe_id
  from public.decisions_passage d
  where d.eleve_id = e.id
    and d.decision = 'passe'
    and d.nouvelle_classe_id is not null;

  -- 4. Supprimer définitivement les élèves sortant / encore suspendus
  delete from public.eleves e
  where e.id in (select eleve_id from public.decisions_passage where decision = 'sortant')
     or e.statut = 'suspendu';

  -- 5. Purger les logs applicatifs des élèves désormais absents de `eleves`
  delete from public.log_whatsapp
  where matricule not in (select matricule from public.eleves);

  delete from public.paiements_supprimes
  where matricule not in (select matricule from public.eleves);

  -- 6. Purger la table tampon des décisions
  truncate public.decisions_passage;

exception when others then
  raise;
end;
$$;


--
-- Name: arbitrer_creneau(integer, integer); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  if exists (
    select 1
    from td.postulations p_autre
    join td.creneaux c_autre on c_autre.id = p_autre.creneau_id
    join td.creneaux c_ref on c_ref.id = p_creneau_id
    where p_autre.professeur_id = p_professeur_id
      and p_autre.statut_validation = 'Valide'
      and c_autre.id != p_creneau_id
      and c_autre.date_td = c_ref.date_td
      and c_autre.heure_debut < c_ref.heure_fin
      and c_autre.heure_fin > c_ref.heure_debut
  ) then
    raise exception 'Ce professeur est déjà validé sur un créneau qui chevauche celui-ci.';
  end if;

  update td.postulations set statut_validation = 'Valide'
  where creneau_id = p_creneau_id and professeur_id = p_professeur_id;

  update td.postulations set statut_validation = 'Refuse'
  where creneau_id = p_creneau_id and professeur_id != p_professeur_id
    and statut_validation = 'En attente';

  -- Règle A : vrai chevauchement, pas juste même heure_debut (sql/016).
  update td.postulations
  set statut_validation = 'Refuse'
  where professeur_id = p_professeur_id
    and statut_validation = 'En attente'
    and creneau_id in (
      select c_autre.id
      from td.creneaux c_autre
      join td.creneaux c_ref on c_ref.id = p_creneau_id
      where c_autre.id != p_creneau_id
        and c_autre.date_td = c_ref.date_td
        and c_autre.heure_debut < c_ref.heure_fin
        and c_autre.heure_fin > c_ref.heure_debut
    );

  update td.creneaux set statut_creneau = 'cloture' where id = p_creneau_id;

exception when others then
  raise;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actualites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites (
    id integer NOT NULL,
    titre character varying(200) NOT NULL,
    categorie text NOT NULL,
    extrait text NOT NULL,
    contenu text NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    a_la_une_jusqu_au date,
    date_publication timestamp with time zone DEFAULT now() NOT NULL,
    cree_par uuid,
    CONSTRAINT actualites_categorie_check CHECK ((categorie = ANY (ARRAY['Vie scolaire'::text, 'Événement'::text, 'Réussite'::text, 'Cours'::text, 'Examens/Contrôle'::text]))),
    CONSTRAINT actualites_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publie'::text])))
);


--
-- Name: actualites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_id_seq OWNED BY public.actualites.id;


--
-- Name: actualites_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites_images (
    id integer NOT NULL,
    actualite_id integer NOT NULL,
    storage_path text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL
);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_images_id_seq OWNED BY public.actualites_images.id;


--
-- Name: annees_scolaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.annees_scolaires (
    id integer NOT NULL,
    libelle character varying(10) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'en_cours'::text NOT NULL,
    CONSTRAINT annees_scolaires_statut_check CHECK ((statut = ANY (ARRAY['en_cours'::text, 'en_pause'::text, 'terminee'::text])))
);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.annees_scolaires_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.annees_scolaires_id_seq OWNED BY public.annees_scolaires.id;


--
-- Name: categories_depenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories_depenses (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    systeme boolean DEFAULT false NOT NULL
);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_depenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_depenses_id_seq OWNED BY public.categories_depenses.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id integer NOT NULL,
    nom_classe character varying(50) NOT NULL,
    site_id integer NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    classe_suivante_id integer
);


--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: coefficients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coefficients (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    coefficient numeric(4,2) NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT coefficients_coefficient_check CHECK ((coefficient > (0)::numeric))
);


--
-- Name: coefficients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coefficients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coefficients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coefficients_id_seq OWNED BY public.coefficients.id;


--
-- Name: comptes_parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comptes_parents (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mot_de_passe text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    derniere_connexion timestamp with time zone
);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comptes_parents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comptes_parents_id_seq OWNED BY public.comptes_parents.id;


--
-- Name: decisions_passage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decisions_passage (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    decision text NOT NULL,
    nouvelle_classe_id integer,
    annee_scolaire_id integer NOT NULL,
    date_decision timestamp with time zone DEFAULT now() NOT NULL,
    decide_par uuid NOT NULL,
    CONSTRAINT decisions_passage_decision_check CHECK ((decision = ANY (ARRAY['passe'::text, 'redouble'::text, 'sortant'::text])))
);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.decisions_passage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.decisions_passage_id_seq OWNED BY public.decisions_passage.id;


--
-- Name: depenses_annexes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.depenses_annexes (
    id integer NOT NULL,
    categorie_id integer NOT NULL,
    libelle character varying(255) NOT NULL,
    montant numeric(10,2) NOT NULL,
    date_depense date NOT NULL,
    saisi_par uuid NOT NULL,
    date_saisie timestamp with time zone DEFAULT now() NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.depenses_annexes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.depenses_annexes_id_seq OWNED BY public.depenses_annexes.id;


--
-- Name: eleves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    nom character varying(100) NOT NULL,
    prenoms character varying(150) NOT NULL,
    contact_parent character varying(15),
    classe_id integer NOT NULL,
    college character varying(150) NOT NULL,
    option_m character varying(10),
    statut text DEFAULT 'actif'::text NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL,
    contact_parent_2 character varying(15),
    CONSTRAINT eleves_au_moins_un_contact CHECK (((contact_parent IS NOT NULL) OR (contact_parent_2 IS NOT NULL))),
    CONSTRAINT eleves_statut_check CHECK ((statut = ANY (ARRAY['actif'::text, 'suspendu'::text])))
);


--
-- Name: eleves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_id_seq OWNED BY public.eleves.id;


--
-- Name: eleves_suspendus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves_suspendus (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    site_id integer NOT NULL,
    raison text NOT NULL,
    motif text NOT NULL,
    montant_du integer DEFAULT 0 NOT NULL,
    date_suspension timestamp with time zone DEFAULT now() NOT NULL,
    suspendu_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois_souscription character varying(20),
    CONSTRAINT eleves_suspendus_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[]))),
    CONSTRAINT eleves_suspendus_raison_check CHECK ((raison = ANY (ARRAY['maladie'::text, 'renvoi'::text, 'defaut_paiement'::text, 'autre'::text])))
);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_suspendus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_suspendus_id_seq OWNED BY public.eleves_suspendus.id;


--
-- Name: frais_td; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frais_td (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    montant numeric(10,2) NOT NULL
);


--
-- Name: frais_td_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frais_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frais_td_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frais_td_id_seq OWNED BY public.frais_td.id;


--
-- Name: galerie; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie (
    id integer NOT NULL,
    storage_path text NOT NULL,
    date_insertion timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie_admin (
    id integer NOT NULL,
    storage_path text NOT NULL,
    nom_fichier text NOT NULL,
    taille_octets integer,
    ajoute_par uuid NOT NULL,
    date_ajout timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_admin_id_seq OWNED BY public.galerie_admin.id;


--
-- Name: galerie_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_id_seq OWNED BY public.galerie.id;


--
-- Name: log_whatsapp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_whatsapp (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_restant integer NOT NULL,
    contact_parent character varying(25) NOT NULL,
    envoye_par uuid NOT NULL,
    date_envoi timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_whatsapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_whatsapp_id_seq OWNED BY public.log_whatsapp.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id integer NOT NULL,
    identifiant text NOT NULL,
    portail text NOT NULL,
    reussi boolean NOT NULL,
    ip inet,
    date_tentative timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT login_attempts_portail_check CHECK ((portail = ANY (ARRAY['admin'::text, 'parent'::text, 'td'::text])))
);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_attempts_id_seq OWNED BY public.login_attempts.id;


--
-- Name: matieres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matieres (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL
);


--
-- Name: matieres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matieres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matieres_id_seq OWNED BY public.matieres.id;


--
-- Name: mois_exoneres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mois_exoneres (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    motif text DEFAULT 'Absence totale durant le mois suspendu — dispense du montant dû à la réinscription'::text NOT NULL,
    exonere_par uuid NOT NULL,
    date_exoneration timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mois_exoneres_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mois_exoneres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mois_exoneres_id_seq OWNED BY public.mois_exoneres.id;


--
-- Name: moyennes_semestrielles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.moyennes_semestrielles (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    semestre smallint NOT NULL,
    moyenne_generale numeric(4,2),
    cloture_par uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT moyennes_semestrielles_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2])))
);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.moyennes_semestrielles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.moyennes_semestrielles_id_seq OWNED BY public.moyennes_semestrielles.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    matiere_id integer NOT NULL,
    type_note text NOT NULL,
    valeur numeric(4,2) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    semestre smallint DEFAULT 1 NOT NULL,
    CONSTRAINT notes_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2]))),
    CONSTRAINT notes_type_note_check CHECK ((type_note = ANY (ARRAY['I1'::text, 'I2'::text, 'I3'::text, 'D1'::text, 'D2'::text, 'Ctrl'::text]))),
    CONSTRAINT notes_valeur_check CHECK (((valeur >= (0)::numeric) AND (valeur <= (20)::numeric)))
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    site_id integer NOT NULL,
    contenu text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: paiements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    enregistre_par uuid,
    CONSTRAINT paiements_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[]))),
    CONSTRAINT paiements_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: paiements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_id_seq OWNED BY public.paiements.id;


--
-- Name: paiements_supprimes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements_supprimes (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    admin_id uuid NOT NULL,
    date_suppression timestamp with time zone DEFAULT now() NOT NULL,
    motif text NOT NULL
);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_supprimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_supprimes_id_seq OWNED BY public.paiements_supprimes.id;


--
-- Name: penalites_reinscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.penalites_reinscription (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    montant integer DEFAULT 500 NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    date_paiement date NOT NULL,
    enregistre_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    CONSTRAINT penalites_reinscription_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[])))
);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.penalites_reinscription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.penalites_reinscription_id_seq OWNED BY public.penalites_reinscription.id;


--
-- Name: presences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.presences (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    date_presence date NOT NULL,
    site_id integer NOT NULL,
    classe_id integer NOT NULL,
    present boolean DEFAULT true NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: presences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.presences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: presences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.presences_id_seq OWNED BY public.presences.id;


--
-- Name: recompenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recompenses (
    id integer NOT NULL,
    note_id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois character varying(20) NOT NULL,
    type_gain text NOT NULL,
    montant integer NOT NULL,
    depense_id integer,
    paye_par uuid NOT NULL,
    date_paiement date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recompenses_montant_check CHECK ((montant = ANY (ARRAY[200, 500]))),
    CONSTRAINT recompenses_type_gain_check CHECK ((type_gain = ANY (ARRAY['interro'::text, 'devoir'::text])))
);


--
-- Name: recompenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recompenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recompenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recompenses_id_seq OWNED BY public.recompenses.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    nom_site character varying(100) NOT NULL,
    initiale character(1) NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: user_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sites (
    user_id uuid NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    site_id integer,
    actif boolean DEFAULT true NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text])))
);


--
-- Name: creneaux; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.creneaux (
    id integer NOT NULL,
    semaine_id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    date_td date NOT NULL,
    heure_debut time without time zone NOT NULL,
    heure_fin time without time zone NOT NULL,
    montant_prevu numeric(10,2) DEFAULT 0 NOT NULL,
    statut_creneau text DEFAULT 'brouillon'::text NOT NULL,
    CONSTRAINT creneaux_statut_creneau_check CHECK ((statut_creneau = ANY (ARRAY['brouillon'::text, 'public'::text, 'cloture'::text])))
);


--
-- Name: creneaux_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.creneaux_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: creneaux_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.creneaux_id_seq OWNED BY td.creneaux.id;


--
-- Name: matieres_td; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.matieres_td (
    id integer NOT NULL,
    nom_matiere character varying(100) NOT NULL
);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.matieres_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_td_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.matieres_td_id_seq OWNED BY td.matieres_td.id;


--
-- Name: postulations; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.postulations (
    id integer NOT NULL,
    creneau_id integer NOT NULL,
    professeur_id integer NOT NULL,
    statut_validation text DEFAULT 'En attente'::text NOT NULL,
    date_postulation timestamp with time zone DEFAULT now() NOT NULL,
    motif_retrait text,
    CONSTRAINT postulations_statut_validation_check CHECK ((statut_validation = ANY (ARRAY['En attente'::text, 'Valide'::text, 'Refuse'::text, 'Retiree'::text])))
);


--
-- Name: postulations_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.postulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: postulations_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.postulations_id_seq OWNED BY td.postulations.id;


--
-- Name: professeurs; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.professeurs (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100) NOT NULL,
    telephone character varying(25) NOT NULL,
    email character varying(150) NOT NULL,
    mot_de_passe text NOT NULL,
    zone_id integer NOT NULL,
    matiere_principale_id integer NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: professeurs_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.professeurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professeurs_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.professeurs_id_seq OWNED BY td.professeurs.id;


--
-- Name: semaines; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.semaines (
    id integer NOT NULL,
    libelle character varying(100) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    date_cloture timestamp with time zone,
    CONSTRAINT semaines_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publiee'::text, 'cloturee'::text])))
);


--
-- Name: semaines_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.semaines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semaines_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.semaines_id_seq OWNED BY td.semaines.id;


--
-- Name: zones; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.zones (
    id integer NOT NULL,
    nom_zone character varying(100) NOT NULL
);


--
-- Name: zones_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.zones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zones_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.zones_id_seq OWNED BY td.zones.id;


--
-- Name: actualites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites ALTER COLUMN id SET DEFAULT nextval('public.actualites_id_seq'::regclass);


--
-- Name: actualites_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images ALTER COLUMN id SET DEFAULT nextval('public.actualites_images_id_seq'::regclass);


--
-- Name: annees_scolaires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires ALTER COLUMN id SET DEFAULT nextval('public.annees_scolaires_id_seq'::regclass);


--
-- Name: categories_depenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses ALTER COLUMN id SET DEFAULT nextval('public.categories_depenses_id_seq'::regclass);


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: coefficients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients ALTER COLUMN id SET DEFAULT nextval('public.coefficients_id_seq'::regclass);


--
-- Name: comptes_parents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents ALTER COLUMN id SET DEFAULT nextval('public.comptes_parents_id_seq'::regclass);


--
-- Name: decisions_passage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage ALTER COLUMN id SET DEFAULT nextval('public.decisions_passage_id_seq'::regclass);


--
-- Name: depenses_annexes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes ALTER COLUMN id SET DEFAULT nextval('public.depenses_annexes_id_seq'::regclass);


--
-- Name: eleves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves ALTER COLUMN id SET DEFAULT nextval('public.eleves_id_seq'::regclass);


--
-- Name: eleves_suspendus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus ALTER COLUMN id SET DEFAULT nextval('public.eleves_suspendus_id_seq'::regclass);


--
-- Name: frais_td id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td ALTER COLUMN id SET DEFAULT nextval('public.frais_td_id_seq'::regclass);


--
-- Name: galerie id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie ALTER COLUMN id SET DEFAULT nextval('public.galerie_id_seq'::regclass);


--
-- Name: galerie_admin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin ALTER COLUMN id SET DEFAULT nextval('public.galerie_admin_id_seq'::regclass);


--
-- Name: log_whatsapp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp ALTER COLUMN id SET DEFAULT nextval('public.log_whatsapp_id_seq'::regclass);


--
-- Name: login_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN id SET DEFAULT nextval('public.login_attempts_id_seq'::regclass);


--
-- Name: matieres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres ALTER COLUMN id SET DEFAULT nextval('public.matieres_id_seq'::regclass);


--
-- Name: mois_exoneres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres ALTER COLUMN id SET DEFAULT nextval('public.mois_exoneres_id_seq'::regclass);


--
-- Name: moyennes_semestrielles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles ALTER COLUMN id SET DEFAULT nextval('public.moyennes_semestrielles_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: paiements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements ALTER COLUMN id SET DEFAULT nextval('public.paiements_id_seq'::regclass);


--
-- Name: paiements_supprimes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes ALTER COLUMN id SET DEFAULT nextval('public.paiements_supprimes_id_seq'::regclass);


--
-- Name: penalites_reinscription id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription ALTER COLUMN id SET DEFAULT nextval('public.penalites_reinscription_id_seq'::regclass);


--
-- Name: presences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences ALTER COLUMN id SET DEFAULT nextval('public.presences_id_seq'::regclass);


--
-- Name: recompenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses ALTER COLUMN id SET DEFAULT nextval('public.recompenses_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: creneaux id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux ALTER COLUMN id SET DEFAULT nextval('td.creneaux_id_seq'::regclass);


--
-- Name: matieres_td id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td ALTER COLUMN id SET DEFAULT nextval('td.matieres_td_id_seq'::regclass);


--
-- Name: postulations id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations ALTER COLUMN id SET DEFAULT nextval('td.postulations_id_seq'::regclass);


--
-- Name: professeurs id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs ALTER COLUMN id SET DEFAULT nextval('td.professeurs_id_seq'::regclass);


--
-- Name: semaines id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines ALTER COLUMN id SET DEFAULT nextval('td.semaines_id_seq'::regclass);


--
-- Name: zones id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones ALTER COLUMN id SET DEFAULT nextval('td.zones_id_seq'::regclass);


--
-- Data for Name: actualites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites (id, titre, categorie, extrait, contenu, statut, a_la_une_jusqu_au, date_publication, cree_par) FROM stdin;
1	Démarrage des Cours Intensifs Préparatoires — Édition 2026	Cours	Le GSR lance sa nouvelle édition des Cours Intensifs Préparatoires sur ses 3 sites. Un programme pensé pour combler les lacunes et aborder la suite de l'année en confiance.	Le Groupe Secret de la Réussite ouvre officiellement sa nouvelle édition des Cours Intensifs Préparatoires, sur ses trois sites de Jéricho, Yagbé et Vèdoko. Ce programme, pensé pour la période de vacances, s'adresse à tous les élèves de la 6ème à la Terminale qui souhaitent consolider leurs acquis avant la reprise.\r\n\r\nL'objectif est simple : aborder en douceur les nouvelles notions du programme à venir. Chaque séance s'appuie sur des documents de cours structurés et des évaluations ciblées, pour que chaque élève progresse à son rythme sans se sentir dépassé.\r\n\r\nNos enseignants sont sélectionnés pour leur rigueur et leur pédagogie. Les tarifs, accessibles et adaptés à chaque niveau, sont disponibles en détail sur notre page Tarifs.\r\n\r\nLes places étant limitées sur chaque site, nous invitons les parents à inscrire rapidement leurs enfants en se rendant directement sur l'un de nos trois centres, ou en nous contactant par téléphone pour toute question sur le programme et les horaires.	publie	2026-08-22	2026-08-08 06:48:05.408897+00	\N
2	Démarrage des séances de révision BEPC 2026	Examens/Contrôle	À l'approche des examens, le GSR met en place un dispositif de révision intensif et méthodique dédié aux candidats.	À quelques mois d'une échéance décisive, le Groupe Secret de la Réussite lance ses séances de révision dédiées aux candidats au BEPC 2026. Ce dispositif vise à consolider les acquis sur l'ensemble du programme dans toutes les matières, avec un accent particulier sur les matières fondamentales : Mathématiques, PCT et SVT.\r\n\r\nLe format retenu combine rappels de cours structurés et exercices ciblés chacun suivi d'une correction méthodique en groupe. Cette approche permet à chaque candidat de mesurer précisément ses progrès et d'identifier les points qui demandent encore du travail avant le jour J.\r\n\r\nNos enseignants, habitués aux exigences de l'examen, accompagnent les élèves avec des conseils pratiques de gestion du temps et de méthodologie de rédaction, deux facteurs qui font souvent la différence le jour de l'épreuve.\r\n\r\nLes séances se déroulent sur nos sites de Jéricho et Yagbé, selon un calendrier communiqué aux familles inscrites. Pour rejoindre le dispositif ou obtenir plus d'informations, contactez-nous ou rendez-vous directement sur l'un de nos centres.	publie	\N	2026-08-01 06:48:05.408897+00	\N
3	Séance de Coaching et de Motivation des candidats aux examens 2026	Vie scolaire	Au-delà des révisions académiques, le GSR accompagne aussi ses candidats sur le plan psychologique avec une séance de coaching et de motivation.	La réussite aux examens ne se joue pas uniquement sur les connaissances académiques : la confiance en soi, la gestion du stress et la discipline personnelle jouent un rôle tout aussi déterminant. C'est dans cet esprit que le Groupe Secret de la Réussite a organisé une séance de coaching et de motivation dédiée à ses candidats aux examens 2026.\r\n\r\nAnimée par notre équipe pédagogique, cette rencontre a permis d'aborder des sujets essentiels à l'approche des épreuves : techniques de gestion du stress, organisation efficace du temps de révision, et surtout, comment garder confiance face à la pression des examens.\r\n\r\nLes élèves ont pu échanger librement sur leurs appréhensions et repartir avec des outils concrets pour aborder sereinement les semaines à venir. Cette dimension d'accompagnement humain fait partie intégrante de notre philosophie : préparer nos élèves non seulement académiquement, mais aussi mentalement, à affronter les moments décisifs de leur parcours scolaire.	publie	\N	2026-07-25 06:48:05.408897+00	\N
\.


--
-- Data for Name: actualites_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites_images (id, actualite_id, storage_path, ordre) FROM stdin;
1	1	vitrine/accueil/img_cip.jpg	0
2	2	vitrine/accueil/img_prepa.jpg	0
\.


--
-- Data for Name: annees_scolaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.annees_scolaires (id, libelle, date_debut, date_fin, statut) FROM stdin;
1	2026-2027	2026-10-01	2027-05-31	en_cours
\.


--
-- Data for Name: categories_depenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories_depenses (id, nom, systeme) FROM stdin;
1	Location Site	t
2	Paiement Prof	t
3	Fournitures	t
4	Transport	t
5	Communication	t
6	Maintenance	t
7	Frais bancaires	t
8	Autre	t
9	Récompense	f
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, nom_classe, site_id, ordre, classe_suivante_id) FROM stdin;
12	Terminale D	1	7	\N
13	6ème	2	1	14
15	4ème	2	3	16
4	3ème A	1	4	\N
17	3ème B	1	4	\N
1	6ème A	1	1	2
20	6ème B	1	1	19
2	5ème A	1	2	3
19	5ème B	1	2	18
3	4ème A	1	3	4
18	4ème B	1	3	17
11	Terminale C	1	7	\N
5	Seconde B	1	5	7
7	Première B	1	6	10
10	Terminale B	1	7	\N
22	3ème C	1	4	\N
8	Première D	1	6	12
6	Seconde C	1	5	24
24	Première C	1	6	11
23	Seconde D	1	5	8
14	5ème	2	2	15
16	3ème	2	4	\N
\.


--
-- Data for Name: coefficients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coefficients (id, classe_id, matiere_id, coefficient, updated_at) FROM stdin;
1	1	1	1.00	2026-08-09 22:33:29.272+00
2	1	2	1.00	2026-08-09 22:33:38.434+00
3	1	3	1.00	2026-08-09 22:33:42.435+00
4	1	4	1.00	2026-08-09 22:33:50.941+00
5	1	5	1.00	2026-08-09 22:33:53.754+00
7	1	7	1.00	2026-08-09 22:34:02.071+00
11	20	1	1.00	2026-08-09 22:35:23.232+00
12	20	2	1.00	2026-08-09 22:35:26.587+00
13	20	3	1.00	2026-08-09 22:35:29.64+00
14	20	4	1.00	2026-08-09 22:35:32.733+00
15	20	5	1.00	2026-08-09 22:35:36.384+00
17	20	7	1.00	2026-08-09 22:36:21.475+00
21	2	1	1.00	2026-08-09 22:38:19.883+00
22	2	2	1.00	2026-08-09 22:38:23.389+00
23	2	3	1.00	2026-08-09 22:38:28.759+00
24	2	4	1.00	2026-08-09 22:38:33.558+00
25	2	5	1.00	2026-08-09 22:38:37.453+00
124	22	1	2.00	2026-08-20 21:47:51.364+00
29	2	7	1.00	2026-08-09 22:39:47.027+00
32	19	1	1.00	2026-08-09 22:41:11.023+00
33	19	2	1.00	2026-08-09 22:41:15.097+00
34	19	3	1.00	2026-08-09 22:41:19.274+00
35	19	4	1.00	2026-08-09 22:41:25.689+00
36	19	5	1.00	2026-08-09 22:41:29.795+00
38	19	7	1.00	2026-08-09 22:42:13.316+00
42	13	1	1.00	2026-08-09 22:43:48.04+00
43	13	2	1.00	2026-08-09 22:43:55.083+00
44	13	3	1.00	2026-08-09 22:44:00.208+00
45	13	4	1.00	2026-08-09 22:44:05.903+00
46	13	5	1.00	2026-08-09 22:44:11.06+00
47	13	6	1.00	2026-08-09 22:44:31.404+00
48	13	7	1.00	2026-08-09 22:44:42.046+00
49	13	8	1.00	2026-08-09 22:44:52.513+00
50	13	9	1.00	2026-08-09 22:45:02.407+00
51	13	10	1.00	2026-08-09 22:45:13.351+00
52	14	1	1.00	2026-08-09 22:46:19.228+00
53	14	2	1.00	2026-08-09 22:46:23.192+00
54	14	3	1.00	2026-08-09 22:46:28.257+00
55	14	4	1.00	2026-08-09 22:46:32.856+00
56	14	5	1.00	2026-08-09 22:46:37.237+00
57	14	6	1.00	2026-08-09 22:47:00.854+00
58	14	7	1.00	2026-08-09 22:47:10.978+00
59	14	8	1.00	2026-08-09 22:47:24.397+00
60	14	9	1.00	2026-08-09 22:47:35.053+00
61	14	10	1.00	2026-08-09 22:47:46.279+00
63	3	1	2.00	2026-08-09 22:57:20.66+00
64	3	2	3.00	2026-08-09 22:57:22.919+00
65	3	3	2.00	2026-08-09 22:57:25.385+00
66	3	4	2.00	2026-08-09 22:57:27.442+00
67	3	5	2.00	2026-08-09 22:57:29.779+00
69	3	7	2.00	2026-08-09 22:57:33.838+00
72	3	10	2.00	2026-08-09 22:57:40.597+00
74	1	11	1.00	2026-08-20 20:53:48.029+00
75	20	11	1.00	2026-08-20 20:58:22.005+00
76	2	11	1.00	2026-08-20 21:02:33.637+00
77	19	11	1.00	2026-08-20 21:03:58.459+00
78	3	9	2.00	2026-08-20 21:05:58.431+00
79	3	11	2.00	2026-08-20 21:06:13.081+00
80	18	1	2.00	2026-08-20 21:07:05.907+00
81	18	2	3.00	2026-08-20 21:07:12.194+00
82	18	3	2.00	2026-08-20 21:07:19.585+00
83	18	4	2.00	2026-08-20 21:07:30.287+00
84	18	5	2.00	2026-08-20 21:07:38.124+00
85	18	7	2.00	2026-08-20 21:07:47.063+00
86	18	9	2.00	2026-08-20 21:07:57.975+00
87	18	10	2.00	2026-08-20 21:08:05.342+00
88	18	11	2.00	2026-08-20 21:08:10.38+00
89	4	1	2.00	2026-08-20 21:09:54.018+00
91	4	3	2.00	2026-08-20 21:10:05.73+00
90	4	2	3.00	2026-08-20 21:10:10.801+00
93	4	4	2.00	2026-08-20 21:10:19.65+00
94	4	5	2.00	2026-08-20 21:10:37.474+00
95	4	7	2.00	2026-08-20 21:10:51.068+00
96	4	9	2.00	2026-08-20 21:10:59.718+00
97	4	10	2.00	2026-08-20 21:11:04.992+00
98	4	11	2.00	2026-08-20 21:11:10.35+00
99	17	1	2.00	2026-08-20 21:11:35.157+00
100	17	2	3.00	2026-08-20 21:11:41.091+00
101	17	3	2.00	2026-08-20 21:11:47.24+00
102	17	4	2.00	2026-08-20 21:11:54.935+00
103	17	5	2.00	2026-08-20 21:12:02.594+00
104	17	7	2.00	2026-08-20 21:12:42.877+00
105	17	11	2.00	2026-08-20 21:12:52.309+00
106	17	10	2.00	2026-08-20 21:12:57.798+00
107	17	9	2.00	2026-08-20 21:13:03.305+00
108	5	1	2.00	2026-08-20 21:16:35.619+00
109	5	6	2.00	2026-08-20 21:18:10.993+00
110	5	7	2.00	2026-08-20 21:18:47.551+00
111	5	9	2.00	2026-08-20 21:19:00.825+00
112	5	10	2.00	2026-08-20 21:19:03.931+00
113	5	8	2.00	2026-08-20 21:19:21.803+00
114	5	2	1.00	2026-08-20 21:19:44.393+00
115	5	5	1.00	2026-08-20 21:20:08.798+00
117	6	1	1.00	2026-08-20 21:23:29.97+00
118	6	3	2.00	2026-08-20 21:23:35.617+00
119	6	6	2.00	2026-08-20 21:24:11.632+00
120	6	7	1.00	2026-08-20 21:24:16.308+00
121	6	2	3.00	2026-08-20 21:25:08.492+00
122	6	4	3.00	2026-08-20 21:26:06.809+00
123	6	5	3.00	2026-08-20 21:26:11.502+00
125	22	2	3.00	2026-08-20 21:47:55.724+00
126	22	3	2.00	2026-08-20 21:48:06.475+00
127	22	4	2.00	2026-08-20 21:48:12.505+00
128	22	5	2.00	2026-08-20 21:48:19.214+00
129	22	7	2.00	2026-08-20 21:48:31.284+00
130	22	9	2.00	2026-08-20 21:48:38.832+00
131	22	10	2.00	2026-08-20 21:48:44.799+00
132	22	11	2.00	2026-08-20 21:48:52.642+00
116	5	3	2.00	2026-08-20 21:51:19.858+00
134	23	1	1.00	2026-08-20 22:46:51.427+00
135	23	3	2.00	2026-08-20 22:46:58.666+00
136	23	6	2.00	2026-08-20 22:47:16.311+00
137	23	7	1.00	2026-08-20 22:47:38.451+00
138	23	4	3.00	2026-08-20 22:48:20.759+00
139	23	5	3.00	2026-08-20 22:48:25.28+00
140	23	2	3.00	2026-08-20 22:48:33.194+00
141	8	2	4.00	2026-08-20 22:55:08.233+00
142	8	4	4.00	2026-08-20 22:55:16.977+00
143	8	5	5.00	2026-08-20 22:55:20.283+00
144	8	1	2.00	2026-08-20 22:55:33.318+00
145	8	3	2.00	2026-08-20 22:55:37.662+00
146	8	6	2.00	2026-08-20 22:55:41.973+00
147	8	7	2.00	2026-08-20 22:55:49.107+00
148	24	7	2.00	2026-08-20 22:59:21.262+00
149	24	6	2.00	2026-08-20 22:59:24.671+00
150	24	5	2.00	2026-08-20 22:59:28.71+00
151	24	4	5.00	2026-08-20 22:59:34.997+00
152	24	3	2.00	2026-08-20 22:59:39.451+00
153	24	2	5.00	2026-08-20 22:59:46.135+00
154	24	1	2.00	2026-08-20 22:59:49.919+00
155	7	10	1.00	2026-08-20 23:03:01.782+00
156	7	9	1.00	2026-08-20 23:03:26.481+00
157	7	8	4.00	2026-08-20 23:03:30.625+00
158	7	7	4.00	2026-08-20 23:03:34.118+00
159	7	6	3.00	2026-08-20 23:03:37.839+00
163	7	1	4.00	2026-08-20 23:03:56.335+00
160	7	5	2.00	2026-08-20 23:03:41.992+00
161	7	3	3.00	2026-08-20 23:03:48.955+00
162	7	2	2.00	2026-08-20 23:03:52.106+00
164	12	7	2.00	2026-08-20 23:05:03.142+00
165	12	6	2.00	2026-08-20 23:05:06.21+00
166	12	5	5.00	2026-08-20 23:05:11.855+00
167	12	4	4.00	2026-08-20 23:05:18.934+00
168	12	3	2.00	2026-08-20 23:05:22.5+00
169	12	2	4.00	2026-08-20 23:05:29.37+00
170	12	1	2.00	2026-08-20 23:05:32.335+00
171	11	7	2.00	2026-08-20 23:07:58.54+00
172	11	6	2.00	2026-08-20 23:08:02.077+00
173	11	5	2.00	2026-08-20 23:08:09.04+00
174	11	4	5.00	2026-08-20 23:08:17.229+00
175	11	3	2.00	2026-08-20 23:08:23.15+00
176	11	2	6.00	2026-08-20 23:08:27.895+00
177	11	1	2.00	2026-08-20 23:09:00.712+00
178	10	10	1.00	2026-08-20 23:11:25.359+00
179	10	9	1.00	2026-08-20 23:11:28.377+00
180	10	8	4.00	2026-08-20 23:11:33.319+00
181	10	7	4.00	2026-08-20 23:11:37.508+00
182	10	6	3.00	2026-08-20 23:11:40.834+00
183	10	5	2.00	2026-08-20 23:11:44.256+00
184	10	3	3.00	2026-08-20 23:11:52.313+00
185	10	2	2.00	2026-08-20 23:12:05.25+00
186	10	1	4.00	2026-08-20 23:12:11.515+00
\.


--
-- Data for Name: comptes_parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comptes_parents (id, matricule, mot_de_passe, date_creation, derniere_connexion) FROM stdin;
\.


--
-- Data for Name: decisions_passage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.decisions_passage (id, eleve_id, decision, nouvelle_classe_id, annee_scolaire_id, date_decision, decide_par) FROM stdin;
\.


--
-- Data for Name: depenses_annexes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.depenses_annexes (id, categorie_id, libelle, montant, date_depense, saisi_par, date_saisie, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: eleves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves (id, matricule, nom, prenoms, contact_parent, classe_id, college, option_m, statut, date_inscription, contact_parent_2) FROM stdin;
62	J08262797	HOUESSINON	Océane	+2290195192360	1	CEG DU LAC	\N	actif	2026-08-25 20:08:51.955924+00	\N
3	J08268022	ADANMAHO	Ruth	+2290141428811	1	CEG DU LAC	\N	actif	2026-08-25 20:08:12.287334+00	\N
4	J08262268	AGOSSOU	Gael	+2290192174008	1	CEG DU LAC	\N	actif	2026-08-25 20:08:12.750321+00	\N
5	J08268267	AHOTON	Aristide	+2290199245666	1	CEG DU LAC	\N	actif	2026-08-25 20:08:13.202517+00	\N
6	J08261730	AHOUANDJINOU	Mitricia	+2290166458411	1	CEG DU LAC	\N	actif	2026-08-25 20:08:13.849166+00	\N
7	J08267548	ALI KPONOU	Barnabé	+2290149231863	1	CEG DU LAC	\N	actif	2026-08-25 20:08:14.629668+00	\N
8	J08263106	AMOUSSOU	Angéline Tété	+2290147001102	1	CEG DU LAC	\N	actif	2026-08-25 20:08:15.145837+00	\N
9	J08263536	BODJOSSOU	Chimène	+2290160623544	1	CEG DU LAC	\N	actif	2026-08-25 20:08:15.816509+00	\N
10	J08264473	BONOU	Andréa	+2290167569601	1	CEG DU LAC	\N	actif	2026-08-25 20:08:16.409862+00	\N
11	J08267444	BOUSSARI	Aemane	+2290197832325	1	CEG DU LAC	\N	actif	2026-08-25 20:08:16.849956+00	\N
12	J08268911	DANNOUDO	Belvine	+2290197149708	1	CEG DU LAC	\N	actif	2026-08-25 20:08:17.309641+00	\N
13	J08266999	DANNOUDO	Joanita	+2290151510388	1	CEG DU LAC	\N	actif	2026-08-25 20:08:18.070132+00	\N
14	J08262951	DANSOU	René	+2290197301151	1	CEG DU LAC	\N	actif	2026-08-25 20:08:21.971968+00	\N
15	J08261500	DEGBO	Abel	+2290169008428	1	CEG DU LAC	\N	actif	2026-08-25 20:08:23.804393+00	\N
16	J08264569	DJOHA	Fridaouce	+2290144989378	1	CEG DU LAC	\N	actif	2026-08-25 20:08:24.29167+00	\N
17	J08262766	EDIBO	Haidou	+2290148069124	1	CEG DU LAC	\N	actif	2026-08-25 20:08:24.716298+00	\N
18	J08263543	GANGNON	Abidémi Mourana	+2290197311903	1	CEG DU LAC	\N	actif	2026-08-25 20:08:25.172258+00	\N
19	J08264361	GODONOU	Gloria Merveille	+2290197328732	1	CEG DU LAC	\N	actif	2026-08-25 20:08:26.430749+00	\N
20	J08262550	HAROUNA	Hamza	+2290161360409	1	CEG DU LAC	\N	actif	2026-08-25 20:08:27.76559+00	\N
21	J08264212	HASSANE	Abdoul Razack	+2290196124155	1	CEG DU LAC	\N	actif	2026-08-25 20:08:28.782043+00	\N
22	J08262551	HONVOU	Josué Norbert	+2290166095595	1	CEG DU LAC	\N	actif	2026-08-25 20:08:30.227764+00	\N
23	J08268178	HOUADJETO	Rose	+2290148152298	1	CEG DU LAC	\N	actif	2026-08-25 20:08:31.134829+00	\N
24	J08265291	HOUADJETO	Jéhovany	+2290197766388	1	CEG DU LAC	\N	actif	2026-08-25 20:08:32.219574+00	\N
25	J08264295	HOUESSOU	Prince	+2290196044502	1	CEG DU LAC	\N	actif	2026-08-25 20:08:32.667205+00	\N
26	J08264348	HOUNGBO	Kafui Belle	+2290161958178	1	CEG DU LAC	\N	actif	2026-08-25 20:08:33.099597+00	\N
27	J08268757	HOUNGBO	Urielle	+2290161958178	1	CEG DU LAC	\N	actif	2026-08-25 20:08:33.817155+00	\N
28	J08262703	HOUNSOU	Béni	+2290197166900	1	CEG DU LAC	\N	actif	2026-08-25 20:08:34.488511+00	\N
29	J08269137	KOUKPAKI	Habiguel	+2290147104032	1	CEG DU LAC	\N	actif	2026-08-25 20:08:34.966879+00	\N
30	J08267246	KPLAKOTCHA	Bignon Pascaline	+2290197161718	1	CEG DU LAC	\N	actif	2026-08-25 20:08:35.393318+00	\N
31	J08269413	OLOUGBADE	Fèmi Ruthe	+2290166234656	1	CEG DU LAC	\N	actif	2026-08-25 20:08:35.850566+00	\N
32	J08269042	SIMENOU	M. Jérôme	+2290166098259	1	CEG DU LAC	\N	actif	2026-08-25 20:08:36.525755+00	\N
33	J08264309	THON	Elians	+2290142323537	1	CEG DU LAC	\N	actif	2026-08-25 20:08:36.961589+00	\N
34	J08267043	TOSSAVI	Eurielle	+2290196145763	1	CEG DU LAC	\N	actif	2026-08-25 20:08:37.573351+00	\N
35	J08265282	TRAORE	Azizé	+2290140629303	1	CEG DU LAC	\N	actif	2026-08-25 20:08:38.005556+00	\N
36	J08263772	YEHOUENOU	Elisabeth	+2290196357947	1	CEG DU LAC	\N	actif	2026-08-25 20:08:38.477267+00	\N
37	J08265784	ZANNOU	Charles	+2290197833912	1	CEG DU LAC	\N	actif	2026-08-25 20:08:38.913405+00	\N
38	J08267089	ZINHO	Edwige	+2290196965912	1	CEG DU LAC	\N	actif	2026-08-25 20:08:39.362039+00	\N
39	J08263259	ADEYEMON	Alphé	+2290197327899	1	CEG DU LAC	\N	actif	2026-08-25 20:08:39.817428+00	\N
40	J08266080	ADJOVI	Gilles-Christ	+2290197987658	1	CEG DU LAC	\N	actif	2026-08-25 20:08:40.498962+00	\N
41	J08268546	AFFO	Régina	+2290197618574	1	CEG DU LAC	\N	actif	2026-08-25 20:08:40.957883+00	\N
42	J08268517	AGOSSOU	Diane Christiane	+2290197860677	1	CEG DU LAC	\N	actif	2026-08-25 20:08:41.492241+00	\N
43	J08263823	AHEHEHINNOU	Princesse	+2290143979537	1	CEG DU LAC	\N	actif	2026-08-25 20:08:42.640039+00	\N
44	J08263759	AKINOCHO	Espérancia	+2290196820635	1	CEG DU LAC	\N	actif	2026-08-25 20:08:43.37113+00	\N
45	J08264362	ALANGBOKINTO	Christ-fort	+2290152241099	1	CEG DU LAC	\N	actif	2026-08-25 20:08:43.822812+00	\N
46	J08266596	ALI NABILATH	Nabilath	+2290197234996	1	CEG DU LAC	\N	actif	2026-08-25 20:08:44.262153+00	\N
47	J08265636	ALOSSE	Mahutin	+2290144225320	1	CEG DU LAC	\N	actif	2026-08-25 20:08:44.716053+00	\N
48	J08267893	ALLOSSE	Merveil	+2290166027811	1	CEG DU LAC	\N	actif	2026-08-25 20:08:45.350018+00	\N
49	J08264584	AWAZE	Rosalie	+2290197939840	1	CEG DU LAC	\N	actif	2026-08-25 20:08:45.778327+00	\N
50	J08268975	AZOUASSI	Arielle	+2290194666556	1	CEG DU LAC	\N	actif	2026-08-25 20:08:46.181513+00	\N
51	J08269366	BALA	Nabil	+2290140357078	1	CEG DU LAC	\N	actif	2026-08-25 20:08:46.59036+00	\N
52	J08262516	BOUKARI	Majoie	+2290196915692	1	CEG DU LAC	\N	actif	2026-08-25 20:08:47.016333+00	\N
53	J08262940	CHOGOLOU	Naomie	+2290195319539	1	CEG DU LAC	\N	actif	2026-08-25 20:08:47.65703+00	\N
54	J08266460	COUMASSOU	Fifamè	+2290197080003	1	CEG DU LAC	\N	actif	2026-08-25 20:08:48.334516+00	\N
55	J08265035	DAGA	Ella	+2290157527662	1	CEG DU LAC	\N	actif	2026-08-25 20:08:48.755396+00	\N
56	J08267543	DELE	Astride	+2290196144429	1	CEG DU LAC	\N	actif	2026-08-25 20:08:49.188918+00	\N
57	J08268114	DENAKPO	Samuel	+2290196009792	1	CEG DU LAC	\N	actif	2026-08-25 20:08:49.731717+00	\N
58	J08268391	DOUDJI	Thierry	+2290166237408	1	CEG DU LAC	\N	actif	2026-08-25 20:08:50.188168+00	\N
59	J08266111	GNONLONFOUN	Elisabeth	+2290166696627	1	CEG DU LAC	\N	actif	2026-08-25 20:08:50.585842+00	\N
60	J08268706	GNONLONFOUN	Majoie	+2290197117984	1	CEG DU LAC	\N	actif	2026-08-25 20:08:50.997934+00	\N
61	J08269126	HESSOU	Inès	+2290192279414	1	CEG DU LAC	\N	actif	2026-08-25 20:08:51.552828+00	\N
63	J08262289	HOUESSOU	Brice	+2290143868500	1	CEG DU LAC	\N	actif	2026-08-25 20:08:52.590268+00	\N
64	J08269872	HOUNDO	Urbain	+2290163357881	1	CEG DU LAC	\N	actif	2026-08-25 20:08:53.094261+00	\N
65	J08266301	HOUNGBEDJI	Christian	+2290159951859	1	CEG DU LAC	\N	actif	2026-08-25 20:08:53.52506+00	\N
66	J08262719	HOUNGA	Romuald	+2290157606352	1	CEG DU LAC	\N	actif	2026-08-25 20:08:54.143593+00	\N
67	J08264399	HOUNGBO	Emannuel	+2290166552204	1	CEG DU LAC	\N	actif	2026-08-25 20:08:54.584899+00	\N
68	J08264253	HOUNNOU	Rachelle Fèmi	+2290140577316	1	CEG DU LAC	\N	actif	2026-08-25 20:08:55.004408+00	\N
69	J08269764	HONFOGA	Juliette	+2290197338328	1	CEG DU LAC	\N	actif	2026-08-25 20:08:55.537954+00	\N
70	J08263486	IMOROU	Arafat	+2290197690110	1	CEG DU LAC	\N	actif	2026-08-25 20:08:56.184621+00	\N
71	J08268667	KEITA	Aminata	+2290197314371	1	CEG DU LAC	\N	actif	2026-08-25 20:08:57.16069+00	\N
73	J08261761	KOUMA	Patricia	+2290196285600	1	CEG DU LAC	\N	actif	2026-08-25 20:08:58.480465+00	\N
75	J08262583	NASSARA	Firmin Tobias	+2290197746868	1	CEG DU LAC	\N	actif	2026-08-25 20:09:02.918057+00	\N
77	J08265783	KPODJI	Néhémie	+2290167221243	1	CEG DU LAC	\N	actif	2026-08-25 20:09:04.385038+00	\N
80	J08264530	QUENUM	Wahib	+2290167156231	1	CEG DU LAC	\N	actif	2026-08-25 20:09:06.597571+00	\N
82	J08265267	SOUNOUVOU	Christophe	+2290153841388	1	CEG DU LAC	\N	actif	2026-08-25 20:09:08.191075+00	\N
84	J08264180	TCHEWENOU	Arsène	+2290166035605	1	CEG DU LAC	\N	actif	2026-08-25 20:09:10.199278+00	\N
72	J08267215	KODJO	Abdiel	+2290197984238	1	CEG DU LAC	\N	actif	2026-08-25 20:08:57.791864+00	\N
74	J08262790	MEGNIZIN	Melvine	+2290151005574	1	CEG DU LAC	\N	actif	2026-08-25 20:09:02.392539+00	\N
76	J08264701	NASSARA	Augustin	+2290197746868	1	CEG DU LAC	\N	actif	2026-08-25 20:09:03.943786+00	\N
78	J08268262	OKE	Henriette	+2290197442195	1	CEG DU LAC	\N	actif	2026-08-25 20:09:05.120007+00	\N
79	J08266095	OTCHRAN	Micheline	+2290197695346	1	CEG DU LAC	\N	actif	2026-08-25 20:09:05.686255+00	\N
81	J08268561	RADJI	Raoudath	+2290196789444	1	CEG DU LAC	\N	actif	2026-08-25 20:09:07.022291+00	\N
83	J08263178	SOVIGUIDI	Nadège	+2290166292136	1	CEG DU LAC	\N	actif	2026-08-25 20:09:08.96418+00	\N
85	J08269178	AMEVONOUKE	Maeva	+2290197615288	20	CEG DU LAC	\N	actif	2026-08-25 20:15:07.072103+00	\N
86	J08264120	COSSE	Florentine	+2290144160724	20	CEG DU LAC	\N	actif	2026-08-25 20:15:07.837595+00	\N
87	J08264552	HOUNGBO	Delphin	+2290196688515	20	CEG DU LAC	\N	actif	2026-08-25 20:15:08.675427+00	\N
88	J08264951	NOUGBODJI	Chantale	+2290167025464	20	CEG DU LAC	\N	actif	2026-08-25 20:15:09.297982+00	\N
89	J08261282	OYACHIDI	Amed	+2290144509057	20	CEG DU LAC	\N	actif	2026-08-25 20:15:09.824213+00	\N
90	J08268492	ABDOULAYE	Anas	+2290162900495	20	CEG DU LAC	\N	actif	2026-08-25 20:15:10.277646+00	\N
91	J08262251	ADAM	Hamirath	+2290140582104	20	CEG DU LAC	\N	actif	2026-08-25 20:15:10.754545+00	\N
92	J08268011	ADAN	Ginette	+2290162787297	20	CEG DU LAC	\N	actif	2026-08-25 20:15:11.682561+00	\N
93	J08264206	ADINGNI	Espoir	+2290140356215	20	CEG DU LAC	\N	actif	2026-08-25 20:15:12.342674+00	\N
94	J08266648	ADONON	Agathe	+2290147881027	20	CEG DU LAC	\N	actif	2026-08-25 20:15:12.762012+00	\N
95	J08269363	ADOUNVO	Jennifer	+2290197594007	20	CEG DU LAC	\N	actif	2026-08-25 20:15:13.188926+00	\N
96	J08263763	AGBODJINOU	Mariale	+2290167663696	20	CEG DU LAC	\N	actif	2026-08-25 20:15:13.647296+00	\N
97	J08268080	AGOSSOU	Emmanuella Théodora	+2290197055133	20	CEG DU LAC	\N	actif	2026-08-25 20:15:14.205934+00	\N
98	J08267514	AGUEGUE	Osée	+2290195781077	20	CEG DU LAC	\N	actif	2026-08-25 20:15:14.878921+00	\N
99	J08262485	AHOUMENOU	Jephte	+2290154559145	20	CEG DU LAC	\N	actif	2026-08-25 20:15:15.538523+00	\N
100	J08269537	AHOUSSINOU	Ariane	+2290197419771	20	CEG DU LAC	\N	actif	2026-08-25 20:15:16.172653+00	\N
101	J08267211	AHOUSSINOU	Trésora	+2290197419771	20	CEG DU LAC	\N	actif	2026-08-25 20:15:16.629155+00	\N
102	J08264234	AKOWE	Roméo	+2290162049568	20	CEG DU LAC	\N	actif	2026-08-25 20:15:17.583852+00	\N
103	J08267273	AMADOU	Yasmine	+2290154066389	20	CEG DU LAC	\N	actif	2026-08-25 20:15:18.87951+00	\N
104	J08261768	AYIVODJI	Bernice	+2290197956392	20	CEG DU LAC	\N	actif	2026-08-25 20:15:19.351894+00	\N
105	J08263579	AZOGA	Ibrahim Prince	+2290197589978	20	CEG DU LAC	\N	actif	2026-08-25 20:15:20.660217+00	\N
106	J08269030	BEAHENOU	Luchrist	+2290197728001	20	CEG DU LAC	\N	actif	2026-08-25 20:15:21.360524+00	\N
107	J08265020	BONI	Gloire	+2290196012335	20	CEG DU LAC	\N	actif	2026-08-25 20:15:23.150309+00	\N
108	J08261340	CHOGOLOU	Géovani	+2290166767956	20	CEG DU LAC	\N	actif	2026-08-25 20:15:24.901272+00	\N
109	J08268419	DAVI	Elysée	+2290162810417	20	CEG DU LAC	\N	actif	2026-08-25 20:15:27.614585+00	\N
110	J08262136	DANSOU	Constantin	+2290160321132	20	CEG DU LAC	\N	actif	2026-08-25 20:15:29.896947+00	\N
111	J08265923	DEDEWANOU	Antoine Karl	+2290166035959	20	CEG DU LAC	\N	actif	2026-08-25 20:15:30.321026+00	\N
112	J08269531	DIAWARA	Aicha	+2290151013401	20	CEG DU LAC	\N	actif	2026-08-25 20:15:31.239653+00	\N
113	J08264655	FANOU	Daniel	+2290197476899	20	CEG DU LAC	\N	actif	2026-08-25 20:15:35.193329+00	\N
114	J08261370	GANDJI	Donald	+2290197271442	20	CEG DU LAC	\N	actif	2026-08-25 20:15:36.577634+00	\N
115	J08268220	GANTIN	Sandrine	+2290166752832	20	CEG DU LAC	\N	actif	2026-08-25 20:15:37.004969+00	\N
116	J08265269	GANTIN	Jean Marie Vianney	+2290166752832	20	CEG DU LAC	\N	actif	2026-08-25 20:15:38.133241+00	\N
117	J08263929	GBETCHOEVI	Ornela	+2290162892348	20	CEG DU LAC	\N	actif	2026-08-25 20:15:39.912646+00	\N
118	J08268290	GNANSOUNOU	Angelo	+2290147468030	20	CEG DU LAC	\N	actif	2026-08-25 20:15:40.531851+00	\N
119	J08263073	GNITABOU	Pierrette	+2290168614988	20	CEG DU LAC	\N	actif	2026-08-25 20:15:41.281183+00	\N
120	J08262823	HONFO	Irène	+2290197278334	20	CEG DU LAC	\N	actif	2026-08-25 20:15:42.182296+00	\N
121	J08265639	HOUENOU	Chrismel	+2290195261961	20	CEG DU LAC	\N	actif	2026-08-25 20:15:43.839733+00	\N
122	J08268864	HOUNGUE	Huguette	+2290140594592	20	CEG DU LAC	\N	actif	2026-08-25 20:15:44.976962+00	\N
123	J08262013	HOUNGUIEVI	Firmin	+2290140594592	20	CEG DU LAC	\N	actif	2026-08-25 20:15:45.713205+00	\N
124	J08265471	HOUNMENOU	Urielle	+2290165753530	20	CEG DU LAC	\N	actif	2026-08-25 20:15:46.164498+00	\N
125	J08261749	IBRAHIM	Moustékim	+2290197125758	20	CEG DU LAC	\N	actif	2026-08-25 20:15:46.741241+00	\N
126	J08261886	KINTOKONOU	Miracle	+2290167580440	20	CEG DU LAC	\N	actif	2026-08-25 20:15:47.647946+00	\N
127	J08264575	KONGNON	Délia	+2290197735776	20	CEG DU LAC	\N	actif	2026-08-25 20:15:48.490539+00	\N
128	J08265578	KOUNNI	Ferdinand	+2290161714247	20	CEG DU LAC	\N	actif	2026-08-25 20:15:49.298866+00	\N
129	J08262492	LATEDJOU	Arafat	+2290166522471	20	CEG DU LAC	\N	actif	2026-08-25 20:15:50.007937+00	\N
130	J08264113	LINDE	Houeffa	+2290196847244	20	CEG DU LAC	\N	actif	2026-08-25 20:15:50.43672+00	\N
131	J08261580	MEGNIHA	Darius	+2290197323982	20	CEG DU LAC	\N	actif	2026-08-25 20:15:50.8644+00	\N
132	J08264738	MONNOU	Mariam	+2290197523980	20	CEG DU LAC	\N	actif	2026-08-25 20:15:51.315888+00	\N
133	J08265910	MOUSSA	Souraimou	+2290196097248	20	CEG DU LAC	\N	actif	2026-08-25 20:15:51.779213+00	\N
134	J08265457	MOUTAIROU	Sékinath	+2290197258357	20	CEG DU LAC	\N	actif	2026-08-25 20:15:52.410892+00	\N
135	J08269085	NOUHOU	Abdoul Malick	+2290153544001	20	CEG DU LAC	\N	actif	2026-08-25 20:15:52.848805+00	\N
136	J08268253	ODOUTAN	Florent	+2290196490961	20	CEG DU LAC	\N	actif	2026-08-25 20:15:53.892276+00	\N
137	J08265347	OSSE	Rodiath	+2290196214481	20	CEG DU LAC	\N	actif	2026-08-25 20:15:54.922733+00	\N
138	J08263689	OUSSA	Soubela	+2290197673649	20	CEG DU LAC	\N	actif	2026-08-25 20:15:55.421293+00	\N
139	J08262611	SODEDJI	Florence	+2290147795712	20	CEG DU LAC	\N	actif	2026-08-25 20:15:56.055523+00	\N
140	J08268798	SOKE	Elisée	+2290197278334	20	CEG DU LAC	\N	actif	2026-08-25 20:15:56.771367+00	\N
141	J08265266	TCHOUTCHOU	Julien	+2290197640248	20	CEG DU LAC	\N	actif	2026-08-25 20:15:57.638412+00	\N
142	J08268635	VODOUNON	Abigael	+2290161473452	20	CEG DU LAC	\N	actif	2026-08-25 20:15:58.139998+00	\N
143	J08262675	VOITAN	Mirabelle	+2290191122266	20	CEG DU LAC	\N	actif	2026-08-25 20:15:59.165779+00	\N
144	J08264158	ZANNOU	Hervé	+2290197327392	20	CEG DU LAC	\N	actif	2026-08-25 20:15:59.908548+00	\N
145	J08269788	ZOUNDJIEKPON	Clément	+2290157571197	20	CEG DU LAC	\N	actif	2026-08-25 20:16:00.345965+00	\N
146	J08267193	ADANDE	Fifamè	+2290147278817	2	CEG DU LAC	\N	actif	2026-08-25 20:17:53.410659+00	\N
147	J08268357	AGBO	Bénédicte	+2290166637510	2	CEG DU LAC	\N	actif	2026-08-25 20:17:54.054576+00	\N
149	J08263105	AGOGNON	Junior	+2290162795215	2	CEG DU LAC	\N	actif	2026-08-25 20:17:54.987945+00	\N
151	J08265785	AGOSSOU	Victorine	+2290167476339	2	CEG DU LAC	\N	actif	2026-08-25 20:17:55.946261+00	\N
153	J08266287	AKPO	Mirabelle	+2290197312358	2	CEG DU LAC	\N	actif	2026-08-25 20:17:57.307348+00	\N
155	J08263879	ATCHONDE	Fednand	+2290196610899	2	CEG SURU LÉRÉ	\N	actif	2026-08-25 20:17:58.426979+00	\N
157	J08266313	COUMASSOU	Prince	+2290197080003	2	CEG DU LAC	\N	actif	2026-08-25 20:17:59.305607+00	\N
159	J08266153	DE CAMPOS	Lionel	+2290197195343	2	CEG STE RITA	\N	actif	2026-08-25 20:18:00.330067+00	\N
161	J08263996	DJOTCHOU	Arnaud	+2290152240834	2	CEG DU LAC	\N	actif	2026-08-25 20:18:03.104742+00	\N
163	J08265816	FOHOU	Eunice	+2290167066737	2	CEG DU LAC	\N	actif	2026-08-25 20:18:06.996572+00	\N
165	J08261302	GNANMLIN	Miracle	+2290190467078	2	CEG DU LAC	\N	actif	2026-08-25 20:18:08.05419+00	\N
167	J08262389	HINVI	Ziad	+2290197037460	2	CEG DU LAC	\N	actif	2026-08-25 20:18:09.138801+00	\N
169	J08265404	HOUNSOU	Grâce	+2290197166900	2	CEG STE RITA	\N	actif	2026-08-25 20:18:09.95982+00	\N
171	J08269582	KABADE DOREIL	Doreil	+2290145287197	2	CEG DU LAC	\N	actif	2026-08-25 20:18:11.092859+00	\N
173	J08269254	KOULIHO	Esther	+2290197255177	2	CEG DU LAC	\N	actif	2026-08-25 20:18:12.453726+00	\N
175	J08262887	LAWANI	Nourou Dine	+2290160472979	2	PAVELO MISÉRICORDE	\N	actif	2026-08-25 20:18:13.355407+00	\N
177	J08265692	MOUSSA	Housna	+2290197349831	2	CEG STE RITA	\N	actif	2026-08-25 20:18:14.80965+00	\N
179	J08268326	OLADELE	Mukaram	+2290196527675	2	CEG DU LAC	\N	actif	2026-08-25 20:18:16.453348+00	\N
181	J08263282	PADONOU	Chancelle	+2290151901775	2	CEG DU LAC	\N	actif	2026-08-25 20:18:17.3188+00	\N
183	J08264312	SEDJRO	Abiba Fifamè	+2290158395794	2	CEG STE RITA	\N	actif	2026-08-25 20:18:20.561534+00	\N
185	J08263674	TIDJANI	Imraan	+2290197146509	2	LA RÉFÉRENCE	\N	actif	2026-08-25 20:18:22.894576+00	\N
187	J08267645	YEDIYETON	Bénoit	+2290161997615	2	CEG DU LAC	\N	actif	2026-08-25 20:18:27.07848+00	\N
189	J08266477	ZOUMENOU	Kenneth	+2290166767937	2	LA RÉFÉRENCE	\N	actif	2026-08-25 20:18:28.651564+00	\N
148	J08261306	AGLI	Marie Grâce	+2290196727958	2	CEG DU LAC	\N	actif	2026-08-25 20:17:54.508992+00	\N
150	J08262276	AGOSSOU	Lorice	+2290197860677	2	CEG DU LAC	\N	actif	2026-08-25 20:17:55.462522+00	\N
152	J08269605	AHISSOU	Exaucé	+2290197826116	2	CEG DU LAC	\N	actif	2026-08-25 20:17:56.653392+00	\N
154	J08264017	ALLOSSE	Charafath	+2290167258787	2	CEG DU LAC	\N	actif	2026-08-25 20:17:57.753864+00	\N
156	J08262999	AYONOU	Samuel	+2290166901887	2	CEG DU LAC	\N	actif	2026-08-25 20:17:58.840807+00	\N
158	J08269052	DANSI-GAH	Sèdjro Assuerus	+2290197261814	2	CEG DANTOKPA	\N	actif	2026-08-25 20:17:59.923184+00	\N
160	J08264331	DHESSIN	Ingrid	+2290166379901	2	LA PAIX	\N	actif	2026-08-25 20:18:02.478379+00	\N
162	J08268276	DOSSA	Ifè Edwige M.	+2290196610899	2	CEG DU LAC	\N	actif	2026-08-25 20:18:04.591692+00	\N
164	J08266507	GBAMMADO	Marie Guillaumine	+2290197226046	2	CEG DU LAC	\N	actif	2026-08-25 20:18:07.439743+00	\N
166	J08266025	GOUNFLE	Fréjuste	+2290169685526	2	CEG DU LAC	\N	actif	2026-08-25 20:18:08.705773+00	\N
168	J08265768	HOUETCHOU	Boris	+2290166765769	2	CEG DU LAC	\N	actif	2026-08-25 20:18:09.536271+00	\N
170	J08267821	HOYETON	Diane	+2290191394417	2	CEG DU LAC	\N	actif	2026-08-25 20:18:10.358704+00	\N
172	J08265429	KAKPO	Précieuse	+2290197189428	2	CEG DU LAC	\N	actif	2026-08-25 20:18:11.523899+00	\N
174	J08267855	KPIKPONSOUHOU	Chérif	+2290157369995	2	CEG DANTOKPA	\N	actif	2026-08-25 20:18:12.914535+00	\N
176	J08267340	MIGNONTODE	Flora	+2290197217601	2	CEG DU LAC	\N	actif	2026-08-25 20:18:13.815287+00	\N
178	J08261650	NANDANAN	Harvey	+2290166759633	2	CEG DU LAC	\N	actif	2026-08-25 20:18:15.636598+00	\N
180	J08269233	OLOUGBADE	Anne Yémissi	+2290166234656	2	CEG STE RITA	\N	actif	2026-08-25 20:18:16.872952+00	\N
182	J08267573	SALAMI	Mourtador	+2290166991407	2	CEG STE RITA	\N	actif	2026-08-25 20:18:18.821198+00	\N
184	J08265037	SOUNOUVO	Exaucé Nadège	+2290190182835	2	CEG DU LAC	\N	actif	2026-08-25 20:18:22.432022+00	\N
186	J08267188	TOSSA	Kasmi	+2290145408425	2	CEG DU LAC	\N	actif	2026-08-25 20:18:25.753843+00	\N
188	J08262689	YESSOUFOU	Ambidath	+2290196757912	2	CEG DU LAC	\N	actif	2026-08-25 20:18:28.21583+00	\N
190	J08269360	ADJIWANOU	Gérade	+2290195506360	19	CEG DU LAC	\N	actif	2026-08-25 20:21:06.754093+00	\N
191	J08264547	AGBO ZINSOU	Anick	+2290166011707	19	CEG DU LAC	\N	actif	2026-08-25 20:21:08.054005+00	\N
192	J08265248	AGLO-HOUNGA	Fèmi	+2290196927722	19	CEG DU LAC	\N	actif	2026-08-25 20:21:08.530436+00	\N
193	J08263232	AGOGNON	Légende	+2290166775177	19	CEG DU LAC	\N	actif	2026-08-25 20:21:09.043323+00	\N
194	J08263499	AGOSSOU	Victoria	+2290167476339	19	CEG DU LAC	\N	actif	2026-08-25 20:21:09.554304+00	\N
195	J08268059	AGUE	Dolorès	+2290169473256	19	CEG DU LAC	\N	actif	2026-08-25 20:21:10.326029+00	\N
196	J08263082	AHOUHENOU	Trésor	+2290148501864	19	CEG DU LAC	\N	actif	2026-08-25 20:21:10.794834+00	\N
197	J08267899	AKPOVI	Freshnelle	+2290167801676	19	CEG STE RITA	\N	actif	2026-08-25 20:21:11.217474+00	\N
198	J08264964	ARIORI	Sagesse	+2290197893687	19	CEG DU LAC	\N	actif	2026-08-25 20:21:11.762538+00	\N
199	J08264845	ATEDJI	Fernand	+2290166524763	19	CEG DU LAC	\N	actif	2026-08-25 20:21:13.439039+00	\N
200	J08263509	BOTON FATCHE	Etienne	+2290165566653	19	CEG DU LAC	\N	actif	2026-08-25 20:21:13.991351+00	\N
201	J08263520	DAGA	Rosalma	+2290157527662	19	CEG STE RITA	\N	actif	2026-08-25 20:21:15.344264+00	\N
202	J08266547	DA SILVA	Peace Joy	+2290197379738	19	CEG STE RITA	\N	actif	2026-08-25 20:21:16.923281+00	\N
203	J08266148	DEGBOGBAHOUN	Aldonie	+2290196315585	19	CEG DU LAC	\N	actif	2026-08-25 20:21:17.358207+00	\N
204	J08265241	DJIGBE	Bernadin	+2290147278964	19	CEG DU LAC	\N	actif	2026-08-25 20:21:18.399457+00	\N
205	J08266725	DJOWADAN	Christine	+2290169802591	19	CEG DU LAC	\N	actif	2026-08-25 20:21:19.342817+00	\N
206	J08269627	DOSSOU	Urielle Alfreda	+2290166889076	19	CEG DU LAC	\N	actif	2026-08-25 20:21:19.96175+00	\N
207	J08264321	GANHOUNOUTO	Marie Thérèse	+2290196125479	19	CEG DU LAC	\N	actif	2026-08-25 20:21:20.392061+00	\N
208	J08261310	GLELE	David Junior	+2290167077126	19	CEG DU LAC	\N	actif	2026-08-25 20:21:20.883773+00	\N
209	J08266177	GOUGBE	Yvette	+2290167258787	19	CEG DU LAC	\N	actif	2026-08-25 20:21:21.38959+00	\N
210	J08268159	GUELIFO	Romuald	+2290197866174	19	CEG STE RITA	\N	actif	2026-08-25 20:21:21.8343+00	\N
211	J08263744	HOUENOU	Abdias	+2290166288729	19	LA RÉFÉRENCE	\N	actif	2026-08-25 20:21:22.237327+00	\N
212	J08266932	HOUNSOU	Adéline	+2290197029777	19	CEG STE RITA	\N	actif	2026-08-25 20:21:22.72532+00	\N
213	J08264360	HOYETON	Daniel	+2290191394417	19	CEG DU LAC	\N	actif	2026-08-25 20:21:23.347821+00	\N
214	J08263025	IBRAHIM	Mohamed	+2290153547976	19	CEG DU LAC	\N	actif	2026-08-25 20:21:23.746714+00	\N
215	J08265764	KODJO	Abimael	+2290197984238	19	SAINT MICHEL	\N	actif	2026-08-25 20:21:24.190851+00	\N
216	J08268081	KOUTON	Dorcas Mahugnon	+2290155414875	19	CEG DU LAC	\N	actif	2026-08-25 20:21:24.669724+00	\N
217	J08268611	LAHADE	Christelle	+2290196803007	19	CEG DU LAC	\N	actif	2026-08-25 20:21:25.075425+00	\N
218	J08265895	MEGOTIN	Inecia Gloria	+2290197610834	19	CEG STE RITA	\N	actif	2026-08-25 20:21:25.725845+00	\N
219	J08266524	MUIDEEN	Adidjathou	+2290147346708	19	CEG STE RITA	\N	actif	2026-08-25 20:21:26.118675+00	\N
220	J08267191	MOUKAILA	Adidjath	+2290153023124	19	LA SONNETTE	\N	actif	2026-08-25 20:21:26.54022+00	\N
221	J08263831	NOUVOESSI	Fortuné T.	+2290197084300	19	CEG DU LAC	\N	actif	2026-08-25 20:21:26.941801+00	\N
222	J08263037	OLAWOMI	Anne marie	+2290151517544	19	CEG DU LAC	\N	actif	2026-08-25 20:21:27.591132+00	\N
223	J08262732	OUSSENI	Ramdia	+2290155557481	19	CEG DU LAC	\N	actif	2026-08-25 20:21:28.024848+00	\N
224	J08262449	SAGBO	Exaucé	+2290197779418	19	CEG ZOGBO	\N	actif	2026-08-25 20:21:28.438895+00	\N
225	J08263366	SAVIAKO	Achille	+2290194576237	19	CEG DU LAC	\N	actif	2026-08-25 20:21:28.871734+00	\N
226	J08265047	SOTON	Williams	+2290169193199	19	CEG DU LAC	\N	actif	2026-08-25 20:21:29.285542+00	\N
227	J08262359	SOUNOUVO	Ezéchiel	+2290166119513	19	CEG DANTOKPA	\N	actif	2026-08-25 20:21:29.705505+00	\N
228	J08265715	TOKPANOU	Osé	+2290161161748	19	CEG STE RITA	\N	actif	2026-08-25 20:21:30.152565+00	\N
229	J08264817	TOUNAOU	Mohamed	+2290190317491	19	CEG DU LAC	\N	actif	2026-08-25 20:21:30.643041+00	\N
230	J08264526	VIGAN	Horsman	+2290160474607	19	CEG STE RITA	\N	actif	2026-08-25 20:21:31.125334+00	\N
231	J08267962	YESSOUFOU	Himayath	+2290157577890	19	CEG DU LAC	\N	actif	2026-08-25 20:21:32.536467+00	\N
232	J08269533	YEVO EDO	Bénédicte	+2290191311563	19	CEG DU LAC	\N	actif	2026-08-25 20:21:32.964158+00	\N
233	J08264376	ZOUNDJI	Inès	+2290143799412	19	CEG DU LAC	\N	actif	2026-08-25 20:21:33.790518+00	\N
234	J08263316	ABOUDOU	Enock	+2290144373544	3	CEG STE RITA	\N	actif	2026-08-25 20:23:11.050842+00	\N
235	J08269590	ADJOVI	Dylane	+2290197987658	3	CEG DU LAC	\N	actif	2026-08-25 20:23:11.768278+00	\N
236	J08261424	AGONYE	Monique	+2290144025590	3	CEG DU LAC	\N	actif	2026-08-25 20:23:12.428888+00	\N
237	J08262029	AHOUAGA	Fabrice	+2290197187377	3	CEG STE RITA	\N	actif	2026-08-25 20:23:12.851788+00	\N
238	J08267099	AKPO	Judith	+2290197312358	3	CEG DU LAC	\N	actif	2026-08-25 20:23:13.382645+00	\N
240	J08267011	AVLESSI	Sylvia	+2290161401513	3	CEG DU LAC	\N	actif	2026-08-25 20:23:14.456945+00	\N
242	J08262629	BAHOUNON	Zéphaniah	+2290197072759	3	CEG STE RITA	\N	actif	2026-08-25 20:23:15.398769+00	\N
244	J08269502	CHOGOLOU	Merveille	+2290197998135	3	CEG DU LAC	\N	actif	2026-08-25 20:23:16.398331+00	\N
246	J08265577	DAKOSSI	Constance	+2290196411598	3	CEG DU LAC	\N	actif	2026-08-25 20:23:17.305422+00	\N
249	J08261989	DAVI	Elias	+2290166265614	3	CEG DU LAC	\N	actif	2026-08-25 20:23:19.057647+00	\N
251	J08266975	HINVI	Imtinane	+2290157594918	3	CEG DU LAC	\N	actif	2026-08-25 20:23:20.444147+00	\N
253	J08261576	KOUDJOU	Alves	+2290197987658	3	BETHESDA	\N	actif	2026-08-25 20:23:22.5059+00	\N
255	J08263921	AFO	Fabienne	+2290197987658	3	CEG DU LAC	\N	actif	2026-08-25 20:23:25.206681+00	\N
257	J08265274	AKPLAGBE	Surprise	+2290196720577	3	CEG DU LAC	\N	actif	2026-08-25 20:23:26.13395+00	\N
259	J08267492	DJOSSOU	Adèle	+2290197372198	3	CEG 2 GODOMEY	\N	actif	2026-08-25 20:23:26.997793+00	\N
261	J08265175	GANDONOU	Olivier	+2290194404286	3	CEG DANTOKPA	\N	actif	2026-08-25 20:23:27.857529+00	\N
263	J08267347	GNONLONFOUN	Amour	+2290166696627	3	CEG STE RITA	\N	actif	2026-08-25 20:23:28.696394+00	\N
265	J08267619	HOUSSOU	Grâce	+2290161323568	3	CEG DU LAC	\N	actif	2026-08-25 20:23:29.537398+00	\N
267	J08269487	IJIDINAN	Romain	+2290161933531	3	CEG DU LAC	\N	actif	2026-08-25 20:23:30.584441+00	\N
269	J08263201	KODJO	Merveille	+2290148879069	3	CEG DANTOKPA	\N	actif	2026-08-25 20:23:31.44012+00	\N
271	J08261832	KOUNNOU	Chancelle	+2290197489751	3	CEG DU LAC	\N	actif	2026-08-25 20:23:32.319837+00	\N
273	J08261907	N'TIA	Auristelle	+2290195457945	3	CEG DANTOKPA	\N	actif	2026-08-25 20:23:33.256898+00	\N
276	J08261766	SEWADE	Anne Marie	+2290197127769	3	CEG DU LAC	\N	actif	2026-08-25 20:23:34.709415+00	\N
278	J08269245	SYLLA	Fousséni	+2290195951499	3	CEG DU LAC	\N	actif	2026-08-25 20:23:35.514883+00	\N
280	J08269234	TCHOKOTI	Peace	+2290197630428	3	CEG STE RITA	\N	actif	2026-08-25 20:23:36.333557+00	\N
282	J08267300	ZINLI	Dario	+2290197169020	3	ST JEAN	\N	actif	2026-08-25 20:23:37.2431+00	\N
239	J08264258	AMOUSSOU	Elfrida	+2290144551058	3	CEG PLATEAU	\N	actif	2026-08-25 20:23:13.952646+00	\N
241	J08266621	BAGBONON	Thérèse	+2290197294636	3	CEG DU LAC	\N	actif	2026-08-25 20:23:15.00794+00	\N
243	J08262739	CHOGOLOU	Daniel	+2290197998135	3	CEG GBEGAMEY	\N	actif	2026-08-25 20:23:15.951138+00	\N
245	J08261829	CODJOVI	Warren	+2290196532358	3	CEG DU LAC	\N	actif	2026-08-25 20:23:16.862292+00	\N
247	J08264514	DANSI	Inès	+2290153291153	3	CEG DU LAC	\N	actif	2026-08-25 20:23:17.72742+00	\N
248	J08266520	DAVI	Emmanuel	+2290166265614	3	CEG DU LAC	\N	actif	2026-08-25 20:23:18.60171+00	\N
250	J08262738	FOFANA	Tidjani	+2290197084944	3	CEG DU LAC	\N	actif	2026-08-25 20:23:19.48638+00	\N
252	J08264241	KOLI	Jamal	+2290197839250	3	CEG DU LAC	\N	actif	2026-08-25 20:23:21.743552+00	\N
254	J08264859	WINSAVI	Nadège	+2290197987658	3	CEG DU LAC	\N	actif	2026-08-25 20:23:24.06998+00	\N
256	J08269613	AGONZAN	Victoire	+2290143596788	3	CEG DANTOKPA	\N	actif	2026-08-25 20:23:25.619346+00	\N
258	J08266187	ANAGONOU	Lydwine Judith	+2290198268798	3	CEG STE RITA	\N	actif	2026-08-25 20:23:26.597694+00	\N
260	J08262042	GANDONOU	Olivia	+2290194404286	3	CEG DANTOKPA	\N	actif	2026-08-25 20:23:27.441798+00	\N
262	J08262658	GANKOU	Nelda	+2290195425289	3	CEG DU LAC	\N	actif	2026-08-25 20:23:28.26659+00	\N
264	J08266200	HOUNTONDJI	Josué	+2290150390481	3	CEG DU LAC	\N	actif	2026-08-25 20:23:29.112226+00	\N
266	J08264225	HOUSSOU	Jean Pascal	+2290161323568	3	CEG DU LAC	\N	actif	2026-08-25 20:23:30.192136+00	\N
268	J08267503	KINSOU	Wilsdom	+2290169357557	3	CEG GBEGAMEY	\N	actif	2026-08-25 20:23:31.011701+00	\N
270	J08261928	KOUDJANNANGNI	Favour	+2290196720577	3	CEG DU LAC	\N	actif	2026-08-25 20:23:31.909157+00	\N
272	J08262068	NOUDAMESSI	Esther	+2290199303063	3	CEG DU LAC	\N	actif	2026-08-25 20:23:32.792163+00	\N
274	J08267045	PRINCE AGBODJAN	Marius	+2290197352202	3	CEG DU LAC	\N	actif	2026-08-25 20:23:33.7096+00	\N
275	J08267091	SEDJAME	Fifamè	+2290195030593	3	CEG STE RITA	\N	actif	2026-08-25 20:23:34.281538+00	\N
277	J08262326	SYLLA	Alassane	+2290195951499	3	CEG DU LAC	\N	actif	2026-08-25 20:23:35.115682+00	\N
279	J08269120	TCHIAKPE	Exaucée	+2290197909012	3	CEG STE RITA	\N	actif	2026-08-25 20:23:35.93473+00	\N
281	J08266134	ZANNOU	Géraldo	+2290161089001	3	CEG STE RITA	\N	actif	2026-08-25 20:23:36.820695+00	\N
283	J08265678	ADANZOUNNON	Marie Louise	+2290167734945	18	CEG STE RITA	\N	actif	2026-08-25 20:25:07.214745+00	\N
284	J08262750	ADJINAKOU	Dénise	+2290196516030	18	CEG DU LAC	\N	actif	2026-08-25 20:25:07.768867+00	\N
285	J08265741	AGOGNON	Ericaelle	+2290196463831	18	CEG DU LAC	\N	actif	2026-08-25 20:25:08.223234+00	\N
286	J08267659	AHLONSOU	Gloria	+2290197538418	18	CEG DU LAC	\N	actif	2026-08-25 20:25:08.679252+00	\N
287	J08267451	AHOKPE	Odile	+2290197253091	18	CEG DU LAC	\N	actif	2026-08-25 20:25:09.147118+00	\N
288	J08266640	AHOUANGBO	Francois	+2290168004959	18	CEG FIYEGNON	\N	actif	2026-08-25 20:25:09.570642+00	\N
289	J08264875	ALANGBOKINTO	Marc Vivien	+2290152241099	18	CEG DU LAC	\N	actif	2026-08-25 20:25:10.230234+00	\N
290	J08264353	ATSEFONYA	Komlavi Dieu donné	+2290169366200	18	CEG DU LAC	\N	actif	2026-08-25 20:25:10.68848+00	\N
291	J08269655	DANSOU	Madeleine	+2290195096495	18	CEG DU LAC	\N	actif	2026-08-25 20:25:11.292537+00	\N
292	J08266833	DJIGBE	Gédéon	+2290167281533	18	CEG DU LAC	\N	actif	2026-08-25 20:25:11.803676+00	\N
293	J08261299	FRANCISCO	Géovani Bignon	+2290197984238	18	CEG DU LAC	\N	actif	2026-08-25 20:25:12.270564+00	\N
294	J08262991	HOUENOU	Lorindo	+2290161020067	18	CEG DU LAC	\N	actif	2026-08-25 20:25:12.680398+00	\N
295	J08263957	HOUETO	Ruth	+2290163395788	18	CEG DU LAC	\N	actif	2026-08-25 20:25:13.114509+00	\N
296	J08268053	HOUNTON	Mathieu	+2290144435235	18	CEG DU LAC	\N	actif	2026-08-25 20:25:13.611422+00	\N
297	J08267063	HOUNVO	Géronime	+2290197876278	18	CEG DU LAC	\N	actif	2026-08-25 20:25:14.050334+00	\N
298	J08264987	KLADJI	Joinelle	+2290197800590	18	CEG STE RITA	\N	actif	2026-08-25 20:25:14.699333+00	\N
299	J08263930	KLOTOE	Dénis	+2290166351585	18	CEG DU LAC	\N	actif	2026-08-25 20:25:15.205455+00	\N
300	J08266895	OKE	Narcisse	+2290197442195	18	CEG DU LAC	\N	actif	2026-08-25 20:25:15.642398+00	\N
301	J08267289	OKOU ADE	Huguette	+2290152716925	18	CEG DU LAC	\N	actif	2026-08-25 20:25:16.069019+00	\N
302	J08266620	RADJI	Rokibath	+2290196789444	18	CEG DANTOKPA	\N	actif	2026-08-25 20:25:16.96529+00	\N
303	J08264739	SAGBO	Madoché	+2290196749687	18	CEG DANTOKPA	\N	actif	2026-08-25 20:25:18.566774+00	\N
304	J08266189	TODJINOU	Bénoit	+2290197267528	18	CEG STE RITA	\N	actif	2026-08-25 20:25:19.000503+00	\N
305	J08267841	AGOSSOU	Damienne	+2290147992417	18	CEG DU LAC	\N	actif	2026-08-25 20:25:20.224754+00	\N
306	J08264502	AHISSOU	Marcolino	+2290197826116	18	CEG DU LAC	\N	actif	2026-08-25 20:25:20.819693+00	\N
307	J08264556	AWAZE	Mathias	+2290197939840	18	CEG DU LAC	\N	actif	2026-08-25 20:25:21.278402+00	\N
308	J08262903	AWODJE	Eric	+2290167318160	18	LA RÉFÉRENCE	\N	actif	2026-08-25 20:25:21.703789+00	\N
309	J08266858	CHEMITAN	Widad	+2290197069624	18	CEG STE RITA	\N	actif	2026-08-25 20:25:22.670713+00	\N
310	J08266360	GNONLONFOUN	Emmanuella	+2290195665249	18	CEG DU LAC	\N	actif	2026-08-25 20:25:23.085322+00	\N
311	J08263141	GNONLONFOUN	José	+2290196229662	18	CEG DU LAC	\N	actif	2026-08-25 20:25:23.48885+00	\N
312	J08265474	GOUSSANOU	Fanelle	+2290197992570	18	CEG DU LAC	\N	actif	2026-08-25 20:25:23.925831+00	\N
313	J08267475	HOUNNOU	Chakirath	+2290148159571	18	CEG DU LAC	\N	actif	2026-08-25 20:25:24.538587+00	\N
314	J08261428	HOUNTONDJI	Josephine	+2290150390481	18	CEG DU LAC	\N	actif	2026-08-25 20:25:24.939314+00	\N
315	J08264286	KOULIHO	Giovanie	+2290197159757	18	CEG DU LAC	\N	actif	2026-08-25 20:25:25.346721+00	\N
316	J08266367	MASSANGA	Emmanuel	+2290143724658	18	CEG DU LAC	\N	actif	2026-08-25 20:25:25.747623+00	\N
317	J08266763	YESSOUFOU	Ihssane	+2290197670868	18	CEG DU LAC	\N	actif	2026-08-25 20:25:26.162121+00	\N
318	J08263702	ZOUMENOU	Mystère	+2290166767937	18	LA RÉFÉRENCE	\N	actif	2026-08-25 20:25:26.599413+00	\N
319	J08268271	ZOUNDJI	Lucien	+2290196735162	18	CEG DU LAC	\N	actif	2026-08-25 20:25:26.996866+00	\N
320	J08267224	AGBOGLO	Landréa	+2290149874238	4	CEG DU LAC	\N	actif	2026-08-25 22:14:33.504289+00	\N
321	J08262660	AGBOGLO	Landryne	+2290165672456	4	CEG DU LAC	\N	actif	2026-08-25 22:14:34.326423+00	\N
322	J08265442	ATEKPO	Modérand	+2290195879022	4	CEG DU LAC	\N	actif	2026-08-25 22:14:34.962607+00	\N
323	J08264998	CISSE	Salif	+2290152240511	4	CEG DANTOKPA	\N	actif	2026-08-25 22:14:35.569304+00	\N
324	J08261460	DADJO	Ramatou	+2290161240573	4	COURONNE DE DIEU	\N	actif	2026-08-25 22:14:36.351809+00	\N
325	J08266812	GANDONOU	Arol	+2290161610898	4	CEG STE RITA	\N	actif	2026-08-25 22:14:36.749973+00	\N
326	J08262414	KPODJI	Joseph	+2290167221243	4	CEG STE RITA	\N	actif	2026-08-25 22:14:37.371621+00	\N
327	J08269665	OLOUWO	Michel	+2290161228481	4	CEG STE RITA	\N	actif	2026-08-25 22:14:37.958767+00	\N
328	J08268729	SOKE	Yésid	+2290197389466	4	CEG DU LAC	\N	actif	2026-08-25 22:14:38.542672+00	\N
329	J08266681	TOSSOU	Marc Owen	+2290190630154	4	CEG DU LAC	\N	actif	2026-08-25 22:14:38.945502+00	\N
330	J08261722	ZOHOU	Mickel Ange	+2290194747461	4	CEG DU LAC	\N	actif	2026-08-25 22:14:39.354596+00	\N
331	J08263741	AMEGAN	Eliséi	+2290197776338	4	BERGER FIDELE	\N	actif	2026-08-25 22:14:40.092649+00	\N
332	J08265015	ATINKPINDA	Tatiana	+2290169690372	4	CEG DU LAC	\N	actif	2026-08-25 22:14:40.509959+00	\N
333	J08262238	SALAOU	Hamza	+2290162080013	4	CEG DU LAC	\N	actif	2026-08-25 22:14:40.909561+00	\N
334	J08263491	TOGNI	Iniestar	+2290197722297	4	CEG DU LAC	\N	actif	2026-08-25 22:14:41.316381+00	\N
335	J08263933	ABENI	Edith	+2290197214548	17	CEG DU LAC	\N	actif	2026-08-25 22:15:06.275484+00	\N
336	J08262004	ADAMMAHO	Paulas	+2290166339941	17	CEG DU LAC	\N	actif	2026-08-25 22:15:06.884622+00	\N
337	J08264620	ADANDE	Bénicia	+2290197130866	17	CEG DU LAC	\N	actif	2026-08-25 22:15:07.674864+00	\N
338	J08264145	ADANKON	Fernand	+2290197287319	17	CEG DU LAC	\N	actif	2026-08-25 22:15:08.452369+00	\N
339	J08267295	ADANNOU	Sheerine	+2290194665662	17	CEG STE RITA	\N	actif	2026-08-25 22:15:09.270972+00	\N
340	J08263981	ADANZOUNON	Paterne	+2290195619575	17	CEG STE RITA	\N	actif	2026-08-25 22:15:10.074535+00	\N
341	J08268204	AGBO	Tatiana	+2290166637510	17	CEG DU LAC	\N	actif	2026-08-25 22:15:10.473901+00	\N
342	J08269220	AGUEHOUNKA	Eternel	+2290166995092	17	CEG STE RITA	\N	actif	2026-08-25 22:15:10.900786+00	\N
343	J08262432	AHO	Débora	+2290140584422	17	CEG STE RITA	\N	actif	2026-08-25 22:15:11.310428+00	\N
344	J08269195	AHOGBO	Mariette	+2290166568060	17	CEG DU LAC	\N	actif	2026-08-25 22:15:11.841235+00	\N
345	J08265827	AHOUANHIDE	Godwin Adonai	+2290196138109	17	CEG STE RITA	\N	actif	2026-08-25 22:15:12.218918+00	\N
346	J08263176	AKINOCHO	Joseph	+2290166450317	17	CEG DU LAC	\N	actif	2026-08-25 22:15:12.643017+00	\N
347	J08267095	AKIOLA	Célestine	+2290197180553	17	CEG DU LAC	\N	actif	2026-08-25 22:15:13.100231+00	\N
348	J08269135	AMOUSSOU	Floriane	+2290197910617	17	CEG DU LAC	\N	actif	2026-08-25 22:15:13.503796+00	\N
349	J08264535	AMOUSSOU	Taslima	+2290161567682	17	CEG STE RITA	\N	actif	2026-08-25 22:15:13.917255+00	\N
350	J08265777	ATINDEHOU	Otniel	+2290197148496	17	CEG STE RITA	\N	actif	2026-08-25 22:15:14.442288+00	\N
351	J08265626	AZOKLI	Daniel	+2290197759862	17	CEG DU LAC	\N	actif	2026-08-25 22:15:15.05849+00	\N
352	J08263983	BEHETON	Yasmine	+2290167091774	17	CEG L'ENTENTE	\N	actif	2026-08-25 22:15:15.657735+00	\N
353	J08264657	BONIFACIO	Rissikath	+2290162114194	17	CEG STE RITA	\N	actif	2026-08-25 22:15:16.235884+00	\N
354	J08267971	BOTOKOU	Sylvia	+2290197218926	17	CEG STE RITA	\N	actif	2026-08-25 22:15:16.943256+00	\N
355	J08269209	CAKPO SOGOE	Fadel	+2290197931064	17	CEG DU LAC	\N	actif	2026-08-25 22:15:17.325973+00	\N
356	J08264383	DAGBA	Darren Espérance	+2290196966772	17	CEG STE RITA	\N	actif	2026-08-25 22:15:17.720252+00	\N
357	J08269816	DE CAMPOS	Marie Michel	+2290197195343	17	CEG STE RITA	\N	actif	2026-08-25 22:15:18.10785+00	\N
358	J08265789	DIOGO	Jacques	+2290166027220	17	CEG STE RITA	\N	actif	2026-08-25 22:15:18.58232+00	\N
359	J08262712	DOSSA	Onyx	+2290147607652	17	CEG DU LAC	\N	actif	2026-08-25 22:15:18.999566+00	\N
360	J08269832	GANDE	Carmel	+2290191071425	17	CEG DU LAC	\N	actif	2026-08-25 22:15:19.398282+00	\N
361	J08261528	GAYET	Miracle	+2290196883610	17	CEG DU LAC	\N	actif	2026-08-25 22:15:19.795282+00	\N
362	J08264236	HONFOVOU	Christelle	+2290161546467	17	CEG COCOTIERS	\N	actif	2026-08-25 22:15:20.323362+00	\N
363	J08268786	HOUESSOU	Fifamè	+2290166743512	17	CEG DU LAC	\N	actif	2026-08-25 22:15:20.740288+00	\N
364	J08263005	HOUETCHOU	Précieux	+2290166765769	17	CEG DU LAC	\N	actif	2026-08-25 22:15:21.166729+00	\N
365	J08264067	HOUNGBE	Ezéchias	+2290196411710	17	CEG STE RITA	\N	actif	2026-08-25 22:15:21.560194+00	\N
366	J08265751	HOUNKPATIN	Claudine	+2290196579438	17	CEG DU LAC	\N	actif	2026-08-25 22:15:22.167159+00	\N
367	J08262179	HOUNSOU	Abraham	+2290196000568	17	CEG DANTOKPA	\N	actif	2026-08-25 22:15:22.794346+00	\N
368	J08263737	HOUNSSINOU	Emmanuella	+2290161881005	17	CEG STE RITA	\N	actif	2026-08-25 22:15:23.199641+00	\N
369	J08268631	KAKINI	Déborah	+2290161943189	17	CEG DU LAC	\N	actif	2026-08-25 22:15:23.628899+00	\N
370	J08265101	KOSSOU	Yvonne	+2290196747073	17	CEG STE RITA	\N	actif	2026-08-25 22:15:24.033508+00	\N
371	J08266455	KOUMA	Léonce	+2290196285600	17	CEG DU LAC	\N	actif	2026-08-25 22:15:24.503603+00	\N
372	J08261484	KPADE	Christiane	+2290197403809	17	CEG STE RITA	\N	actif	2026-08-25 22:15:24.918149+00	\N
373	J08265275	MEGNIZIN	Sonia	+2290141575823	17	CEG STE RITA	\N	actif	2026-08-25 22:15:25.306196+00	\N
374	J08269845	OLAGUNJU	Mutimayinath	+2290152245274	17	CEG DU LAC	\N	actif	2026-08-25 22:15:25.721387+00	\N
375	J08268070	OMIALE	Faouziyath	+2290190301261	17	CEG DU LAC	\N	actif	2026-08-25 22:15:26.158239+00	\N
376	J08264187	OWOLABI	Sélim	+2290169687994	17	LA PAIX	\N	actif	2026-08-25 22:15:26.592593+00	\N
377	J08262715	ROUFAI	Amiratou	+2290151044263	17	CEG STE RITA	\N	actif	2026-08-25 22:15:27.387279+00	\N
378	J08268727	SAGBOHAN	Alex	+2290197691772	17	CEG DANTOKPA	\N	actif	2026-08-25 22:15:27.794315+00	\N
379	J08265055	SEWA	Epiphane	+2290197473838	17	CEG DU LAC	\N	actif	2026-08-25 22:15:28.183219+00	\N
380	J08267322	SEWADE	Crépin	+2290140641890	17	CEG DU LAC	\N	actif	2026-08-25 22:15:28.789136+00	\N
381	J08263179	SOUNOUVOU	Julienne	+2290195461198	17	CEG DU LAC	\N	actif	2026-08-25 22:15:29.58494+00	\N
382	J08264085	TOVIHO	Séraphine	+2290141240993	17	CEG STE RITA	\N	actif	2026-08-25 22:15:29.984707+00	\N
383	J08268965	WANKPO	Sylvanio	+2290191560549	17	CEG DU LAC	\N	actif	2026-08-25 22:15:30.577999+00	\N
384	J08264426	YESSOUFOU	Karimath	+2290196847244	17	CEG DU LAC	\N	actif	2026-08-25 22:15:30.954944+00	\N
385	J08268467	ZANNOU	Ghislain	+2290197833912	17	CEG DU LAC	\N	actif	2026-08-25 22:15:31.551663+00	\N
386	J08262427	ZOUNDJAN	Parfaite	+2290196273395	17	CEG DU LAC	\N	actif	2026-08-25 22:15:32.14211+00	\N
387	J08263539	ADAMOU	Fahad	+2290196675300	22	LA RÉFÉRENCE	\N	actif	2026-08-25 22:22:41.881185+00	\N
388	J08264407	ADANMAHO	Exaucé	+2290197767338	22	CEG DU LAC	\N	actif	2026-08-25 22:22:42.297344+00	\N
389	J08261792	ADEYEMON	Inès	+2290140124702	22	CEG DU LAC	\N	actif	2026-08-25 22:22:42.699436+00	\N
390	J08268286	ADJANOHOUN	Brice	+2290165192802	22	CEG SURU LÉRÉ	\N	actif	2026-08-25 22:22:43.318394+00	\N
391	J08269560	ADOHOUNGBO	Faribelle	+2290197080258	22	CEG DU LAC	\N	actif	2026-08-25 22:22:43.751236+00	\N
392	J08266792	ADOUKONOU	Private	+2290155724053	22	CEG DU LAC	\N	actif	2026-08-25 22:22:44.174553+00	\N
393	J08264246	AGASSOUSSI	Inès Kévine	+2290166027083	22	CEG DU LAC	\N	actif	2026-08-25 22:22:44.599289+00	\N
394	J08266217	AGBEGNINOU	Audrey	+2290165507546	22	CEG DU LAC	\N	actif	2026-08-25 22:22:44.994151+00	\N
395	J08265555	AGOGNON	Dolorès	+2290162795215	22	CEG DU LAC	\N	actif	2026-08-25 22:22:45.389891+00	\N
396	J08262113	AGOSSOU	Ange	+2290197215500	22	CEG DU LAC	\N	actif	2026-08-25 22:22:45.775241+00	\N
397	J08263684	AGOSSOU	Eunice	+2290197215500	22	CEG DU LAC	\N	actif	2026-08-25 22:22:46.193486+00	\N
398	J08262352	AHLINVI JULIANO	Juliano Kévin	+2290166810720	22	CEG DU LAC	\N	actif	2026-08-25 22:22:46.608851+00	\N
399	J08261595	AHLONSOU	Francois	+2290149230522	22	CEG DU LAC	\N	actif	2026-08-25 22:22:47.014544+00	\N
400	J08265650	AHOUANGANON	Estelle	+2290191472923	22	CEG TOHOUE	\N	actif	2026-08-25 22:22:47.424713+00	\N
401	J08265072	AKANDJONAN	Belmond	+2290190312616	22	CEG DANTOKPA	\N	actif	2026-08-25 22:22:47.80973+00	\N
402	J08266577	AKOUETE	Eugénio	+2290147657093	22	CEG DU LAC	\N	actif	2026-08-25 22:22:48.625943+00	\N
403	J08267662	AMOUSSOU	Fanette	+2290147001102	22	CEG DU LAC	\N	actif	2026-08-25 22:22:49.05639+00	\N
404	J08266028	AMOUSSOU	Nicolette	+2290144025280	22	CEG DU LAC	\N	actif	2026-08-25 22:22:49.482707+00	\N
405	J08264111	ASSOCLE	Eunice	+2290162215407	22	CEG DU LAC	\N	actif	2026-08-25 22:22:49.882583+00	\N
406	J08265754	AVOCEHOUIN	Josué	+2290197557052	22	CEG DU LAC	\N	actif	2026-08-25 22:22:50.276405+00	\N
407	J08263103	BANDJE	Israel	+2290197020336	22	CEG DU LAC	\N	actif	2026-08-25 22:22:50.668507+00	\N
408	J08266622	BOURAIMA	Elisabeth	+2290196226854	22	CEG STE RITA	\N	actif	2026-08-25 22:22:51.065285+00	\N
409	J08264946	CHANGOTADE	Landry	+2290148454819	22	CEG DU LAC	\N	actif	2026-08-25 22:22:51.67579+00	\N
410	J08262150	DAGA	Carmelle	+2290157527662	22	CEG STE RITA	\N	actif	2026-08-25 22:22:52.231827+00	\N
411	J08267122	DELE	Jean Baptiste	+2290196144429	22	CEG DANTOKPA	\N	actif	2026-08-25 22:22:52.624564+00	\N
412	J08267317	DJOTCHOU	Modeste	+2290152240834	22	CEG DU LAC	\N	actif	2026-08-25 22:22:53.050626+00	\N
413	J08266675	DJOWADAN	Laurent	+2290149396475	22	CEG DU LAC	\N	actif	2026-08-25 22:22:53.446482+00	\N
414	J08267220	DOSSOU	Béatrice	+2290161153420	22	CEG DU LAC	\N	actif	2026-08-25 22:22:53.841919+00	\N
415	J08266783	DOUROSSIMI	Rodiath	+2290144070871	22	CEG DU LAC	\N	actif	2026-08-25 22:22:54.245664+00	\N
416	J08263905	EZOUNKATON	Merveille	+2290148969037	22	CEG DU LAC	\N	actif	2026-08-25 22:22:54.641527+00	\N
417	J08268126	GANDE BERNADETTE	Bernadette	+2290196324194	22	CEG DU LAC	\N	actif	2026-08-25 22:22:55.066696+00	\N
418	J08266487	GBAMMADO MARIE GRÂCE	Marie Grâce	+2290197226046	22	CEG DU LAC	\N	actif	2026-08-25 22:22:55.483515+00	\N
419	J08266029	GNANSOUNOU IRÈNE	Irène	+2290196564684	22	CEG DANTOKPA	\N	actif	2026-08-25 22:22:56.12035+00	\N
420	J08269287	GUEGNI KÉVIN STEEVER	Kévin Steever	+2290197566084	22	CEG STE RITA	\N	actif	2026-08-25 22:22:56.554584+00	\N
421	J08264165	HINVI DAMILOLA	Damilola	+2290197063773	22	CEG DU LAC	\N	actif	2026-08-25 22:22:56.944847+00	\N
422	J08266089	HONFO AICHATH	Aichath	+2290197731084	22	CEG DU LAC	\N	actif	2026-08-25 22:22:57.338877+00	\N
423	J08265706	HOUADJETO	Emilio	+2290148152298	22	CEG DU LAC	\N	actif	2026-08-25 22:22:57.773133+00	\N
424	J08268313	HOUEGNANNOU	Floriane	+2290197069177	22	CEG DU LAC	\N	actif	2026-08-25 22:22:58.174511+00	\N
425	J08268377	HOUENOU	Jean Véronique	+2290166856732	22	CEG DU LAC	\N	actif	2026-08-25 22:22:58.606343+00	\N
426	J08263043	HOUIDODJITCHE	Fèmi	+2290197884684	22	CEG DU LAC	\N	actif	2026-08-25 22:22:59.087799+00	\N
427	J08262511	HOUNGUE	Fanie	+2290196811232	22	CEG DU LAC	\N	actif	2026-08-25 22:22:59.54351+00	\N
428	J08267952	HOUNVO	Irène	+2290197876278	22	CEG DU LAC	\N	actif	2026-08-25 22:22:59.942572+00	\N
429	J08268450	HOUNYE GANSI	Jules	+2290197298082	22	CEG DU LAC	\N	actif	2026-08-25 22:23:00.374501+00	\N
430	J08268212	KIKI	Anne Marie	+2290190985340	22	CEG DU LAC	\N	actif	2026-08-25 22:23:00.817065+00	\N
431	J08265875	KOHOUNKO	Samson	+2290197706504	22	CEG DU LAC	\N	actif	2026-08-25 22:23:01.222732+00	\N
432	J08265265	KOUAKANOU	Jeannette	+2290197313260	22	CEG DU LAC	\N	actif	2026-08-25 22:23:01.636137+00	\N
433	J08265028	KOULIHO	Majoie	+2290197321641	22	CEG DU LAC	\N	actif	2026-08-25 22:23:02.041996+00	\N
434	J08265130	KOUYONOU	Damienne	+2290150390481	22	CEG DU LAC	\N	actif	2026-08-25 22:23:02.44536+00	\N
435	J08268029	N'DA	Princesse	+2290156328589	22	CEG DU LAC	\N	actif	2026-08-25 22:23:03.038634+00	\N
436	J08262474	NOUDEHOU	Sènami	+2290161133223	22	CEG DU LAC	\N	actif	2026-08-25 22:23:03.435801+00	\N
437	J08262720	SANNI	Moutawakim	+2290197832245	22	CEG DU LAC	\N	actif	2026-08-25 22:23:03.832782+00	\N
438	J08269682	SEMAYI	Roméo	+2290162216522	22	CEG DU LAC	\N	actif	2026-08-25 22:23:04.236192+00	\N
439	J08264829	SODE	Wilfried	+2290157082656	22	CEG DU LAC	\N	actif	2026-08-25 22:23:04.972729+00	\N
440	J08266422	SOKENOU	Jean Baptiste	+2290197602502	22	CEG DU LAC	\N	actif	2026-08-25 22:23:05.395526+00	\N
441	J08264630	TCHINA	Daniel	+2290159004836	22	CEG DU LAC	\N	actif	2026-08-25 22:23:05.796339+00	\N
442	J08265495	TODJINOU	Glorieuse	+2290197267528	22	CEG STE RITA	\N	actif	2026-08-25 22:23:06.194453+00	\N
443	J08263375	TOSSOU	Conforte	+2290161243265	22	CEG DU LAC	\N	actif	2026-08-25 22:23:06.609899+00	\N
444	J08269629	TOTIN	Judicaelo	+2290197000961	22	LA RÉFÉRENCE	\N	actif	2026-08-25 22:23:07.037585+00	\N
445	J08268554	VIEYRA	Faridath	+2290197987365	22	CEG GBEGAMEY	\N	actif	2026-08-25 22:23:07.544609+00	\N
446	J08266220	ZOUNDJI	Lazare	+2290158735627	22	CEG DU LAC	\N	actif	2026-08-25 22:23:07.948545+00	\N
447	J08264316	ADELEYE	Fulbert	+2290155845758	24	CEG DU LAC	\N	actif	2026-08-25 22:30:18.537005+00	\N
448	J08267214	AGOSSOU	Ashley	+2290195964187	24	CEG DU LAC	\N	actif	2026-08-25 22:30:19.206795+00	\N
449	J08262509	AKLO	Ezéchiel	+2290197955076	24	CEG DU LAC	\N	actif	2026-08-25 22:30:19.65303+00	\N
450	J08266270	DOVI	Edwige	+2290197445773	24	CEG DU LAC	\N	actif	2026-08-25 22:30:20.055139+00	\N
451	J08268703	DOVONON	Samuel	+2290156453316	24	CEG DU LAC	\N	actif	2026-08-25 22:30:20.869457+00	\N
452	J08264476	FASSINOU	Odette	+2290197552156	24	CEG DU LAC	\N	actif	2026-08-25 22:30:21.358943+00	\N
453	J08266856	HOUNGA	Christian	+2290162641120	24	CEG DU LAC	\N	actif	2026-08-25 22:30:22.088243+00	\N
454	J08266085	KANA	Emmanuella	+2290195154337	24	CEG DU LAC	\N	actif	2026-08-25 22:30:22.501925+00	\N
455	J08262339	LEGUEDE	Emmanuel	+2290197488643	24	CEG DU LAC	\N	actif	2026-08-25 22:30:22.898937+00	\N
456	J08262538	NICOUE	Faith	+2290190467081	24	CEG DU LAC	\N	actif	2026-08-25 22:30:23.416348+00	\N
457	J08265627	NICOUE	Love	+2290190467081	24	CEG DU LAC	\N	actif	2026-08-25 22:30:23.816738+00	\N
458	J08262386	SALAOU	Ismael	+2290196085957	24	CEG DU LAC	\N	actif	2026-08-25 22:30:24.237185+00	\N
459	J08262634	ADEKPODJOU	Fatima	+2290195198341	8	CEG DU LAC	\N	actif	2026-08-25 22:30:45.23724+00	\N
460	J08265985	ADIMOU	Julie	+2290196074725	8	CEG DU LAC	\N	actif	2026-08-25 22:30:45.629244+00	\N
461	J08261913	ADJAGNISSOUDE	Pamella	+2290197189342	8	CEG YAGBE	\N	actif	2026-08-25 22:30:46.218547+00	\N
462	J08262094	ADJASSOHO	Conceptine	+2290199000351	8	CEG DU LAC	\N	actif	2026-08-25 22:30:46.801766+00	\N
463	J08268263	AGOSSOU	Immaculée	+2290169038875	8	CEG DU LAC	\N	actif	2026-08-25 22:30:47.208753+00	\N
464	J08266158	AHOGBO	Dieu donné	+2290166568060	8	CEG DU LAC	\N	actif	2026-08-25 22:30:47.628794+00	\N
465	J08262897	AHOUANGANON	Nadège	+2290158078453	8	CEG DU LAC	\N	actif	2026-08-25 22:30:48.013349+00	\N
466	J08262066	AMONDO	Kiriya	+2290197856320	8	CEG DU LAC	\N	actif	2026-08-25 22:30:48.496882+00	\N
468	J08263858	ASSANI	Moussa	+2290190620865	8	CEG DU LAC	\N	actif	2026-08-25 22:30:49.319854+00	\N
470	J08265218	BOUKARI	Mira	+2290196915692	8	CEG STE RITA	\N	actif	2026-08-25 22:30:50.110871+00	\N
472	J08267175	DJOCHOU	Louise	+2290152240834	8	CEG DU LAC	\N	actif	2026-08-25 22:30:51.125127+00	\N
474	J08269687	GNONLONFOUN	Rose Kèmi	+2290166696627	8	CEG DU LAC	\N	actif	2026-08-25 22:30:52.367575+00	\N
476	J08261562	HOUNGUIEVI	Odile	+2290194278568	8	CEG DU LAC	\N	actif	2026-08-25 22:30:53.204639+00	\N
478	J08265611	KINTCHIMON	Charbelle	+2290197984354	8	CEG DU LAC	\N	actif	2026-08-25 22:30:54.006119+00	\N
479	J08265430	KODJO	Miracle	+2290190613956	8	CEG DU LAC	\N	actif	2026-08-25 22:30:54.547781+00	\N
481	J08263898	KOUNNOU	Jocelyne	+2290166023351	8	CEG DU LAC	\N	actif	2026-08-25 22:30:55.366095+00	\N
483	J08266694	OLLIVIER DE MONTAGUERE	Luce	+2290161041350	8	CEG DU LAC	\N	actif	2026-08-25 22:30:56.178429+00	\N
485	J08263278	RADJI	Nadiath	+2290196789444	8	CEG DANTOKPA	\N	actif	2026-08-25 22:30:57.087489+00	\N
487	J08264683	TOGNIFODE	Alain	+2290147278514	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.091731+00	\N
489	J08264427	ZANNOU	Félix	+2290197337122	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.920784+00	\N
467	J08268338	AMOUZOUN	David	+2290141819742	8	CEG DU LAC	\N	actif	2026-08-25 22:30:48.884874+00	\N
469	J08266759	AZANKPO	Prisca	+2290197942377	8	CEG DU LAC	\N	actif	2026-08-25 22:30:49.715617+00	\N
471	J08262314	DAGA	Clémence	+2290157527662	8	CEG DU LAC	\N	actif	2026-08-25 22:30:50.549347+00	\N
473	J08265173	FAGNISSE	Majoie	+2290196345696	8	CEG DU LAC	\N	actif	2026-08-25 22:30:51.767662+00	\N
475	J08263238	HOLOEYI	Félicien	+2290153815647	8	CEG DU LAC	\N	actif	2026-08-25 22:30:52.795631+00	\N
477	J08266889	HOUNGUIEVI	Sètondji  David	+2290194278568	8	CEG DU LAC	\N	actif	2026-08-25 22:30:53.616358+00	\N
480	J08268591	KOUDEGNAN	Rodolpho	+2290161419976	8	CEG DU LAC	\N	actif	2026-08-25 22:30:54.948426+00	\N
482	J08264009	OGOULOLA	Léa	+2290191404508	8	CEG DU LAC	\N	actif	2026-08-25 22:30:55.778228+00	\N
484	J08268728	RADJEDO	Pierrette	+2290150719228	8	CEG DU LAC	\N	actif	2026-08-25 22:30:56.599547+00	\N
486	J08269335	SEDJAME	Néhémie	+2290195030593	8	CEG STE RITA	\N	actif	2026-08-25 22:30:57.484661+00	\N
488	J08267145	ZANNOU	Jacqueline	+2290197337122	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.505002+00	\N
490	J08261386	AHOWEKOUN	Noel	+2290192715933	11	CEG DU LAC	\N	actif	2026-08-25 22:37:59.330365+00	\N
491	J08262060	DOSSA	Immaculée	+2290197288140	11	CEG DU LAC	\N	actif	2026-08-25 22:37:59.736211+00	\N
492	J08265127	DOSSOU	Fourier	+2290197176633	11	CEG DU LAC	\N	actif	2026-08-25 22:38:00.346514+00	\N
493	J08264994	HASSANE	Fondé	+2290199757637	11	CEG DU LAC	\N	actif	2026-08-25 22:38:00.735028+00	\N
494	J08261345	LOHOUNME	Emmanuella	+2290166418569	11	CEG DU LAC	\N	actif	2026-08-25 22:38:01.124003+00	\N
495	J08265986	SABALIHOSSOU	Aristide	+2290143722100	11	CEG DU LAC	\N	actif	2026-08-25 22:38:01.539705+00	\N
496	J08268600	TONOU	Sètondji Ezechias	+2290143722100	11	CEG DU LAC	\N	actif	2026-08-25 22:38:02.189929+00	\N
497	J08269513	ZONON	Roberta	+2290151797551	11	CEG DU LAC	\N	actif	2026-08-25 22:38:02.617364+00	\N
498	J08264731	ABOUDOU	Rufus	+2290144373544	12	CEG STE RITA	\N	actif	2026-08-25 22:38:22.229393+00	\N
499	J08269228	AGBOSSODJAN	Esther	+2290144973242	12	CEG DU LAC	\N	actif	2026-08-25 22:38:22.992179+00	\N
500	J08265110	AGOSSOU	Nicodème	+2290167476339	12	CEG DU LAC	\N	actif	2026-08-25 22:38:23.378496+00	\N
501	J08261475	AHOWEKOUN	Alice	+2290161312823	12	CEG DU LAC	\N	actif	2026-08-25 22:38:23.767259+00	\N
502	J08263495	AKOUEGNINOU	Ernest	+2290197384806	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.150997+00	\N
503	J08262331	AVANDE	Mauriace	+2290152240745	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.544978+00	\N
504	J08265797	AZOUASSI	Rose	+2290194666556	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.930368+00	\N
505	J08265831	AMEGAN	Angela Doloresse	+2290197776338	12	CEG DU LAC	\N	actif	2026-08-25 22:38:25.551403+00	\N
506	J08269330	ARIORI	Parfaite	+2290166765135	12	CEG DU LAC	\N	actif	2026-08-25 22:38:26.344688+00	\N
507	J08265608	ATEKPO	Néoland	+2290152706991	12	CEG DU LAC	\N	actif	2026-08-25 22:38:26.854616+00	\N
508	J08268464	D'ALMEIDA	Merveille Ifè	+2290196577824	12	CEG DU LAC	\N	actif	2026-08-25 22:38:27.25613+00	\N
509	J08263602	DENAKPO	Charles	+2290196970092	12	CEG DU LAC	\N	actif	2026-08-25 22:38:27.660258+00	\N
510	J08262190	DE MEDEIROS	Eunice	+2290167276744	12	CEG DU LAC	\N	actif	2026-08-25 22:38:28.046056+00	\N
511	J08267939	FAGNON	Grâce	+2290197614777	12	CEG DU LAC	\N	actif	2026-08-25 22:38:28.475049+00	\N
512	J08261985	GNASSOUNOU	Marie Lauraine	+2290167692528	12	CEG DU LAC	\N	actif	2026-08-25 22:38:28.865325+00	\N
513	J08266987	HESSA	Clarisse	+2290166670004	12	CEG DU LAC	\N	actif	2026-08-25 22:38:29.265808+00	\N
514	J08268157	HOUNTO ADA	Francis	+2290195666328	12	CEG DU LAC	\N	actif	2026-08-25 22:38:29.643545+00	\N
515	J08266463	HOUNTONDJI	Espérancia	+2290197511214	12	CEG DU LAC	\N	actif	2026-08-25 22:38:30.024495+00	\N
516	J08266123	HOUSSA	Samuel	+2290197188094	12	CEG DU LAC	\N	actif	2026-08-25 22:38:30.408529+00	\N
517	J08264619	HOUNGUE	Hugues	+2290197334536	12	CEG STE RITA	\N	actif	2026-08-25 22:38:30.804467+00	\N
518	J08266137	MARCOS	Mariano	+2290197839801	12	CEG DU LAC	\N	actif	2026-08-25 22:38:31.185714+00	\N
519	J08269471	OKE	Raoul	+2290197442195	12	CEG DU LAC	\N	actif	2026-08-25 22:38:31.568051+00	\N
520	J08269249	OLAGUNJU	Mariam	+2290162806169	12	CEG DU LAC	\N	actif	2026-08-25 22:38:31.960019+00	\N
521	J08262030	OMIALE	Ziyadath	+2290190301261	12	CEG DU LAC	\N	actif	2026-08-25 22:38:32.405764+00	\N
522	J08268442	OTCHRAN	Amour	+2290151827753	12	CEG DU LAC	\N	actif	2026-08-25 22:38:32.805729+00	\N
523	J08262095	ROUFAI	Fahimath	+2290197264392	12	CEG DU LAC	\N	actif	2026-08-25 22:38:33.197533+00	\N
524	J08268606	SONON	Ozias Péniel	+2290197896235	12	CEG STE RITA	\N	actif	2026-08-25 22:38:33.589484+00	\N
525	J08264903	SOSSA	Wilson	+2290144115091	12	CEG DU LAC	\N	actif	2026-08-25 22:38:34.004969+00	\N
526	J08263060	ZANNOU	Foeube	+2290166526102	12	CEG DU LAC	\N	actif	2026-08-25 22:38:34.40601+00	\N
527	J08265155	ZANNOU	François	+2290197833912	12	LA RÉFÉRENCE	\N	actif	2026-08-25 22:38:34.799523+00	\N
528	J08263934	ZANNOU	Julien	+2290197833912	12	CEG DU LAC	\N	actif	2026-08-25 22:38:35.200743+00	\N
529	Y08268030	ADANHONDJI	Osias	+2290140783317	13	CEG YAGBE	\N	actif	2026-08-26 05:06:26.656279+00	\N
530	Y08267130	AGOSSA	Osée	+2290197127693	13	CEG YAGBE	\N	actif	2026-08-26 05:06:27.46423+00	\N
531	Y08268870	AGOSSOU	Dossa Rosvald	+2290162060942	13	CEG YAGBE	\N	actif	2026-08-26 05:06:28.267437+00	\N
532	Y08266698	AHLOU GOZO	Exaucé	+2290166322169	13	CEG YAGBE	\N	actif	2026-08-26 05:06:28.653428+00	\N
533	Y08261849	ALI	Roubayatou	+2290156698299	13	CEG YAGBE	\N	actif	2026-08-26 05:06:29.259939+00	\N
534	Y08264031	BANKOLE	Alida	+2290197428276	13	CEG YAGBE	\N	actif	2026-08-26 05:06:30.070493+00	\N
535	Y08267913	DANGBEDJI	Cynthia Grâce	+2290166501017	13	CEG YAGBE	\N	actif	2026-08-26 05:06:30.45668+00	\N
536	Y08261375	DOSSOU-KOKO	Gentille	+2290150164950	13	CEG YAGBE	\N	actif	2026-08-26 05:06:31.048309+00	\N
537	Y08269847	DOURODOLA	Sofiath Adéola	+2290151782736	13	CEG YAGBE	\N	actif	2026-08-26 05:06:32.039317+00	\N
538	Y08261805	GOUTHON	Guillaume Guérin	+2290196601236	13	CEG YAGBE	\N	actif	2026-08-26 05:06:32.445818+00	\N
539	Y08267893	HOUANGNI	Elohim Merveille	+2290196006677	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.014741+00	\N
540	Y08267733	HOUESSOU	Isabelle	+2290196580930	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.426934+00	\N
541	Y08267369	HOUNGNANNOU	Marius	+2290148453091	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.834602+00	\N
542	Y08265665	HOUSSOU	Eric Samuel	+2290197842362	13	CEG YAGBE	\N	actif	2026-08-26 05:06:34.207595+00	\N
543	Y08268529	KANGNIDE	Bénoit	+2290164643291	13	CEG YAGBE	\N	actif	2026-08-26 05:06:34.586662+00	\N
544	Y08268504	KASSA	Rock Kodjo	+2290151993966	13	CEG YAGBE	\N	actif	2026-08-26 05:06:35.156231+00	\N
545	Y08267634	KITOYI	Bilal	+2290152605104	13	CEG YAGBE	\N	actif	2026-08-26 05:06:35.538708+00	\N
546	Y08264304	LOKO	Emmanuella	+2290144371877	13	CEG YAGBE	\N	actif	2026-08-26 05:06:36.316639+00	\N
547	Y08262415	MAIGA	Fatoumata	+2290162396051	13	CEG YAGBE	\N	actif	2026-08-26 05:06:36.692502+00	\N
548	Y08263608	MAIGA	Halimata	+2290162396051	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.072067+00	\N
549	Y08262435	MAIGA	Zoulaiha	+2290162396061	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.587933+00	\N
551	Y08263224	NOUFIONSOU	Grâce	+2290148972920	13	CEG YAGBE	\N	actif	2026-08-26 05:06:38.372418+00	\N
553	Y08263248	TINVOEYI	Merveille De Dieu	+2290152091308	13	CEG YAGBE	\N	actif	2026-08-26 05:06:39.346589+00	\N
555	Y08261278	ZANNOU	Dorcas	+2290169357452	13	CEG YAGBE	\N	actif	2026-08-26 05:06:40.273677+00	\N
550	Y08261421	MASSE	Thomadêsse	+2290165440636	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.983233+00	\N
552	Y08264124	OUABI	Romdonne	+2290197771856	13	CEG YAGBE	\N	actif	2026-08-26 05:06:38.753534+00	\N
554	Y08264735	TITI	Farida	+2290196646367	13	CEG YAGBE	\N	actif	2026-08-26 05:06:39.902788+00	\N
556	Y08261292	ADECHOLA	Saad	+2290197022341	14	CEG YAGBE	\N	actif	2026-08-26 05:08:48.418879+00	\N
557	Y08266946	ADJAGNISSOUDE	Ruth	+2290197189342	14	CEG YAGBE	\N	actif	2026-08-26 05:08:48.817662+00	\N
558	Y08267185	AGBEDJA	Miracle	+2290191383610	14	CEG YAGBE	\N	actif	2026-08-26 05:08:49.3923+00	\N
559	Y08266216	ATEMENOU	Hilary	+2290169261498	14	CEG YAGBE	\N	actif	2026-08-26 05:08:49.843058+00	\N
560	Y08264433	BADAROU	Mohamed	+2290197694392	14	CEG YAGBE	\N	actif	2026-08-26 05:08:50.217537+00	\N
561	Y08265886	BANGO	Emmanuel	+2290152236371	14	CEG YAGBE	\N	actif	2026-08-26 05:08:50.593712+00	\N
562	Y08267046	BOGNON	Isaac	+2290162398663	14	CEG YAGBE	\N	actif	2026-08-26 05:08:51.015729+00	\N
563	Y08267529	DARAMANI	Amir	+2290141266053	14	CEG YAGBE	\N	actif	2026-08-26 05:08:51.426197+00	\N
564	Y08267630	DOSSOU	Marie Irène	+2290197720161	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.045119+00	\N
565	Y08263713	ESSOUM	Esther Ruth	+2290197885232	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.443953+00	\N
566	Y08261959	HOUESSOU	Emmanuel	+2290197251571	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.825821+00	\N
567	Y08266460	HOUNDENOU	Jeannette	+2290197334020	14	CEG YAGBE	\N	actif	2026-08-26 05:08:53.402274+00	\N
568	Y08265256	HOUNGBO	Mardoché	+2290197066005	14	CEG YAGBE	\N	actif	2026-08-26 05:08:53.78932+00	\N
569	Y08262321	ISSEKI	Marie Thérèse	+2290197755796	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.15568+00	\N
570	Y08266338	KAKA	Jilichricia	+2290166152655	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.611625+00	\N
571	Y08268089	KEKE	Florent	+2290197679887	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.980536+00	\N
572	Y08265874	KOTIN	Didier	+2290166020333	14	CEG YAGBE	\N	actif	2026-08-26 05:08:55.400035+00	\N
573	Y08268197	KPANGON	Célione	+2290166692043	14	CEG YAGBE	\N	actif	2026-08-26 05:08:55.773243+00	\N
574	Y08266990	MASSE	Victoire	+2290165440636	14	CEG YAGBE	\N	actif	2026-08-26 05:08:56.155059+00	\N
575	Y08262460	MASSE	Wilfried	+2290165440636	14	CEG YAGBE	\N	actif	2026-08-26 05:08:56.914813+00	\N
576	Y08263327	ODI	Bernice	+2290196496983	14	CEG YAGBE	\N	actif	2026-08-26 05:08:57.315074+00	\N
577	Y08265146	SALIOU	Fridaous	+2290166031250	14	CEG YAGBE	\N	actif	2026-08-26 05:08:57.693728+00	\N
578	Y08265526	SOHE	Abebi	+2290197198647	14	CEG YAGBE	\N	actif	2026-08-26 05:08:58.084632+00	\N
579	Y08266928	TAO	Hidirou	+2290198427915	14	CEG YAGBE	\N	actif	2026-08-26 05:08:58.466381+00	\N
580	Y08262710	TOGBE	Mohamed	+2290196359815	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.05091+00	\N
581	Y08265533	TOGBE	Obérique	+2290167665433	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.46022+00	\N
582	Y08268680	YAYA OYE	Soubedatou	+2290169003643	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.849627+00	\N
583	Y08264402	ADAMON	Assande	+2290196431908	15	CEG YAGBE	\N	actif	2026-08-26 05:09:20.465725+00	\N
584	Y08268668	ADAMON	Rossime	+2290196566106	15	CEG YAGBE	\N	actif	2026-08-26 05:09:20.846356+00	\N
585	Y08264813	ADANHONDJI	Daniella	+2290197935230	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.226044+00	\N
586	Y08265050	ADANHONDJI	Gloria	+2290197452727	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.618601+00	\N
587	Y08268530	AGOSSA	Edna Inès	+2290197599452	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.986855+00	\N
588	Y08261806	AGOSSA	Obed	+2290197127693	15	CEG YAGBE	\N	actif	2026-08-26 05:09:22.390946+00	\N
589	Y08268677	AHLONSOU	Synthiche	+2290196296213	15	CEG YAGBE	\N	actif	2026-08-26 05:09:22.771404+00	\N
590	Y08262204	AKAKPO	Isabelle	+2290196445487	15	CEG YAGBE	\N	actif	2026-08-26 05:09:23.153873+00	\N
591	Y08267993	AKOGOUN	Zékiath	+2290193902690	15	CEG YAGBE	\N	actif	2026-08-26 05:09:23.552739+00	\N
592	Y08263589	ALLODE	Jérémie	+2290197481751	15	CEG YAGBE	\N	actif	2026-08-26 05:09:23.930509+00	\N
593	Y08264022	ALLODE	Léonce	+2290197481751	15	CEG YAGBE	\N	actif	2026-08-26 05:09:24.325881+00	\N
594	Y08263842	BADAROU	Yékini	+2290197247234	15	CEG YAGBE	\N	actif	2026-08-26 05:09:24.727583+00	\N
595	Y08268402	BAKPE	Jacques	+2290190525828	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.107306+00	\N
596	Y08267020	BAMIGBADE	Otniel	+2290197641417	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.485235+00	\N
597	Y08267520	BANKOLE	David	+2290197428276	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.856608+00	\N
598	Y08263174	BANKOLE	Noel	+2290197428276	15	CEG YAGBE	\N	actif	2026-08-26 05:09:26.254907+00	\N
599	Y08269579	DANSOU	Laurence	+2290166831544	15	CEG YAGBE	\N	actif	2026-08-26 05:09:26.646412+00	\N
600	Y08267701	DOSSOU	Bénédicte	+2290196580930	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.037992+00	\N
601	Y08266899	DOSSOU	Immaculée	+2290196953652	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.418849+00	\N
602	Y08267161	GANDONOU	Loïs	+2290165406987	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.809298+00	\N
603	Y08264249	GNAMBODE	Bénédicte	+2290155438512	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.195939+00	\N
604	Y08267580	HODOMIHOU	Cécile	+2290166657478	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.582105+00	\N
605	Y08268521	HODOMIHOU	Jeanne	+2290166657478	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.954878+00	\N
606	Y08262979	HOLLARD	Emmanuel	+2290195407566	15	CEG YAGBE	\N	actif	2026-08-26 05:09:29.343262+00	\N
607	Y08266426	HOSSOU	Marcelle	+2290196810679	15	CEG YAGBE	\N	actif	2026-08-26 05:09:29.729414+00	\N
608	Y08262889	HOSSOU	Paterne	+2290196810679	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.10539+00	\N
609	Y08266545	HOUESSOU	Belforeste	+2290196371580	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.499214+00	\N
610	Y08269826	HOUETCHOEZON	Didier	+2290191040567	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.883123+00	\N
611	Y08265099	HOUNDENOU	Emilienne	+2290197334020	15	CEG YAGBE	\N	actif	2026-08-26 05:09:31.269025+00	\N
612	Y08269420	HOUNDETON	Silvia	+2290144763739	15	CEG YAGBE	\N	actif	2026-08-26 05:09:31.656278+00	\N
613	Y08263538	HOUNDETON	Louise	+2290144763739	15	CEG YAGBE	\N	actif	2026-08-26 05:09:32.054503+00	\N
614	Y08269245	HOUNKPATIN	Constance	+2290197573580	15	CEG YAGBE	\N	actif	2026-08-26 05:09:32.438881+00	\N
615	Y08266634	HOUNKPATIN	Ornella	+2290197762900	15	CEG YAGBE	\N	actif	2026-08-26 05:09:33.025573+00	\N
616	Y08264713	KOUKOUI	Mariette	+2290197294746	15	CEG YAGBE	\N	actif	2026-08-26 05:09:33.422391+00	\N
617	Y08268145	LAKOUSSAN	Josué	+2290196609769	15	CEG YAGBE	\N	actif	2026-08-26 05:09:33.805917+00	\N
618	Y08266275	LOGBO	Siméon	+2290167763931	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.208577+00	\N
619	Y08268871	LOKO	Carolle	+2290196005511	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.583446+00	\N
620	Y08266252	MAHOUGBE	Alki	+2290167560380	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.965797+00	\N
621	Y08262090	MISSIKPODE	Malaleel	+2290197345620	15	CEG YAGBE	\N	actif	2026-08-26 05:09:35.333118+00	\N
622	Y08262014	OGOUTCHI	Oré Oluwa Merveille	+2290166376314	15	CEG YAGBE	\N	actif	2026-08-26 05:09:35.75142+00	\N
623	Y08268733	OLOUKPEDE	Floriane	+2290163103710	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.146702+00	\N
624	Y08262868	SAGBOHAN	Divine	+2290166285000	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.552985+00	\N
625	Y08262554	SALAKO	Mariano	+2290161824028	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.936539+00	\N
627	Y08262955	SOSSOU	Ruth	+2290196534513	15	CEG YAGBE	\N	actif	2026-08-26 05:09:37.712014+00	\N
629	Y08267413	TCHANGOTADE	Doris	+2290191274074	15	CEG YAGBE	\N	actif	2026-08-26 05:09:38.495658+00	\N
631	Y08269477	YESSOUFOU	Sodirath	+2290197482674	15	CEG YAGBE	\N	actif	2026-08-26 05:09:39.261892+00	\N
633	Y08262231	ZANNOU	Kauis	+2290197480937	15	CEG YAGBE	\N	actif	2026-08-26 05:09:40.019524+00	\N
626	Y08264700	SOMASSE	Sonia	+2290197540636	15	CEG YAGBE	\N	actif	2026-08-26 05:09:37.327035+00	\N
628	Y08262947	SOUMANOU	Yousra	+2290197062518	15	CEG YAGBE	\N	actif	2026-08-26 05:09:38.10923+00	\N
630	Y08263533	TOLOFON	Eben Ezer	+2290190030696	15	CEG YAGBE	\N	actif	2026-08-26 05:09:38.889136+00	\N
632	Y08261636	ZANNOU	Kephil	+2290195432819	15	CEG YAGBE	\N	actif	2026-08-26 05:09:39.635741+00	\N
634	Y08265856	ABOKI	Daniel	+2290197073508	16	CEG YAGBE	\N	actif	2026-08-26 05:10:19.759651+00	\N
635	Y08266767	ADANHONDJI	Edith	+2290197169446	16	CEG YAGBE	\N	actif	2026-08-26 05:10:20.146612+00	\N
636	Y08261739	ADJAGNISSOUDE	Jérémie	+2290196667584	16	CEG YAGBE	\N	actif	2026-08-26 05:10:20.531336+00	\N
637	Y08264406	ADJAGNISSOUDE	Parfait	+2290167248075	16	CEG YAGBE	\N	actif	2026-08-26 05:10:20.919054+00	\N
638	Y08263391	AKALA	Achani	+2290167007819	16	CEG YAGBE	\N	actif	2026-08-26 05:10:21.307814+00	\N
639	Y08261253	AKON	Junior	+2290196475434	16	CEG YAGBE	\N	actif	2026-08-26 05:10:21.697789+00	\N
640	Y08265492	ASSOCLE	Doris	+2290166829586	16	CEG YAGBE	\N	actif	2026-08-26 05:10:22.083622+00	\N
641	Y08268688	ATCHADE	Grâce	+2290196154376	16	CEG YAGBE	\N	actif	2026-08-26 05:10:22.663731+00	\N
642	Y08267443	AWOUSSA	Dénise	+2290197818921	16	CEG YAGBE	\N	actif	2026-08-26 05:10:23.044425+00	\N
643	Y08264430	AZANGBE	Céline	+2290197738516	16	CEG YAGBE	\N	actif	2026-08-26 05:10:23.461833+00	\N
644	Y08263904	DANTODJI	Amos	+2290197681137	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.057591+00	\N
645	Y08263449	DANTON	Emmanuella	+2290140739385	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.450314+00	\N
646	Y08269761	DJIDENOU	Elysée	+2290197341857	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.824266+00	\N
647	Y08269235	DJODE	Wilson	+2290197568176	16	CEG YAGBE	\N	actif	2026-08-26 05:10:25.257024+00	\N
648	Y08261899	ESSOUM	Ozias	+2290197885232	16	CEG YAGBE	\N	actif	2026-08-26 05:10:25.634746+00	\N
649	Y08265374	GOGAN	Gloria	+2290197033746	16	CEG YAGBE	\N	actif	2026-08-26 05:10:26.221361+00	\N
650	Y08267681	GOGAN	Paul	+2290197033746	16	CEG YAGBE	\N	actif	2026-08-26 05:10:26.617392+00	\N
651	Y08264481	HESSANON	Marie Noel	+2290196003555	16	CEG YAGBE	\N	actif	2026-08-26 05:10:27.003884+00	\N
652	Y08262562	HOUNKPATIN	Melvine	+2290197573580	16	CEG YAGBE	\N	actif	2026-08-26 05:10:27.382202+00	\N
653	Y08265469	HOUNMENOU	Odile	+2290197647346	16	CEG YAGBE	\N	actif	2026-08-26 05:10:27.773135+00	\N
654	Y08263427	KABORE	Mohamed	+2290196530180	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.149791+00	\N
655	Y08266853	KOUTON	Franck	+2290197138284	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.532337+00	\N
656	Y08269124	KOUTON	Francky	+2290197138284	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.980225+00	\N
657	Y08264767	LANKPOEDJA	Pascaline	+2290190521313	16	CEG YAGBE	\N	actif	2026-08-26 05:10:29.377806+00	\N
658	Y08264191	MASSE	Thomas	+2290165440636	16	CEG YAGBE	\N	actif	2026-08-26 05:10:29.760361+00	\N
659	Y08266002	MINTOKIN	Bernadette	+2290196547165	16	CEG YAGBE	\N	actif	2026-08-26 05:10:30.15958+00	\N
660	Y08265561	NOUMON	Lauriane	+2290197120315	16	CEG YAGBE	\N	actif	2026-08-26 05:10:30.573136+00	\N
661	Y08265213	SAMOU	Ashley	+2290160592676	16	CEG YAGBE	\N	actif	2026-08-26 05:10:30.970702+00	\N
662	Y08263046	SETON	Innocent	+2290196569446	16	CEG YAGBE	\N	actif	2026-08-26 05:10:31.353165+00	\N
663	Y08266220	SOSSOU	Ornella	+2290153503224	16	CEG YAGBE	\N	actif	2026-08-26 05:10:31.756167+00	\N
664	Y08266563	TAIWO	Tayé	+2290196794716	16	CEG YAGBE	\N	actif	2026-08-26 05:10:32.128494+00	\N
665	Y08266195	YOLOU	Chaidatou	+2290197773338	16	CEG YAGBE	\N	actif	2026-08-26 05:10:32.509562+00	\N
666	Y08261815	ZANNOU	Bilal	+2290197029828	16	CEG YAGBE	\N	actif	2026-08-26 05:10:32.898645+00	\N
\.


--
-- Data for Name: eleves_suspendus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves_suspendus (id, eleve_id, site_id, raison, motif, montant_du, date_suspension, suspendu_par, annee_scolaire_id, mois_souscription) FROM stdin;
\.


--
-- Data for Name: frais_td; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frais_td (id, classe_id, montant) FROM stdin;
2	13	2000.00
6	15	3000.00
7	4	5000.00
9	5	5000.00
10	6	5000.00
11	7	6000.00
12	8	6000.00
14	10	8000.00
16	12	8000.00
17	17	5000.00
1	1	2500.00
20	20	2500.00
3	2	2500.00
19	19	2500.00
5	3	3500.00
18	18	3500.00
15	11	10000.00
22	22	5000.00
23	23	5000.00
24	24	6000.00
4	14	2000.00
8	16	4000.00
\.


--
-- Data for Name: galerie; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie (id, storage_path, date_insertion) FROM stdin;
\.


--
-- Data for Name: galerie_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie_admin (id, storage_path, nom_fichier, taille_octets, ajoute_par, date_ajout) FROM stdin;
\.


--
-- Data for Name: log_whatsapp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_whatsapp (id, matricule, mois_souscription, montant_restant, contact_parent, envoye_par, date_envoi) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, identifiant, portail, reussi, ip, date_tentative) FROM stdin;
1	jealexhouegbe	admin	t	\N	2026-08-08 09:04:55.328051+00
2	jealexhouegbe	admin	t	\N	2026-08-08 09:39:40.149597+00
3	jealexhouegbe	admin	t	\N	2026-08-08 10:11:21.70487+00
4	jealexhouegbe	admin	t	\N	2026-08-08 17:28:36.86968+00
5	jealexhouegbe	admin	t	\N	2026-08-08 19:50:29.083241+00
6	jealexhouegbe	admin	t	\N	2026-08-08 20:18:37.037356+00
7	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:19:48.89375+00
8	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:20:20.527295+00
9	urielhouegbe	admin	t	\N	2026-08-08 20:21:05.91664+00
10	jealexhouegbe	admin	t	\N	2026-08-09 07:24:15.712276+00
11	jealexhouegbe	admin	t	\N	2026-08-09 17:50:38.07625+00
12	jealexhouegbe	admin	t	\N	2026-08-09 18:04:09.738492+00
13	jealexhouegbe	admin	t	\N	2026-08-09 21:45:01.744606+00
14	jealexhouegbe	admin	t	\N	2026-08-09 22:30:52.951794+00
15	jealexhouegbe	admin	t	\N	2026-08-09 22:51:08.511658+00
16	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:17:04.613553+00
17	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:38:02.296944+00
18	jealexhouegbe	admin	t	\N	2026-08-10 06:54:14.925918+00
19	urielhouegbe	admin	t	\N	2026-08-10 06:54:53.49026+00
20	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-10 14:16:24.752172+00
21	jealexhouegbe	admin	t	\N	2026-08-11 05:15:32.956857+00
22	jealexhouegbe	admin	t	\N	2026-08-11 07:17:09.84883+00
23	jealexhouegbe	admin	t	\N	2026-08-11 14:42:01.560105+00
24	jealexhouegbe 	admin	f	\N	2026-08-11 14:50:28.385101+00
25	jealexhouegbe	admin	t	\N	2026-08-11 14:51:47.881878+00
26	urielhouegbe	admin	t	\N	2026-08-11 22:09:42.773948+00
27	urielhouegbe	admin	t	\N	2026-08-11 22:55:35.577395+00
28	jucalhouegbe	admin	f	\N	2026-08-11 23:47:44.631597+00
29	jealexlhouegbe	admin	f	\N	2026-08-11 23:47:59.101531+00
30	jealexhouegbe	admin	t	\N	2026-08-11 23:48:07.321782+00
31	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:07:07.80926+00
32	jealexhouegbe	admin	t	\N	2026-08-12 00:14:52.139976+00
33	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:14:52.297684+00
34	jealexhouegbe	admin	t	\N	2026-08-12 00:40:28.33475+00
35	jealexhouegbe	admin	t	\N	2026-08-13 06:44:02.687375+00
36	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-13 06:51:51.529595+00
37	urielhouegbe	admin	t	\N	2026-08-13 10:02:55.168658+00
38	urielhouegbe 	admin	f	\N	2026-08-13 10:12:23.387167+00
39	urielhouegbe	admin	t	\N	2026-08-13 10:12:31.147252+00
40	jealexhouegbe	admin	t	\N	2026-08-13 19:58:42.339916+00
41	jealexhouegbe	admin	t	\N	2026-08-13 20:31:27.647073+00
42	urielhouegbe	admin	t	\N	2026-08-14 00:18:35.46862+00
43	urielhouegbe	admin	t	\N	2026-08-15 18:08:50.226733+00
44	jucalhouegbe	admin	f	\N	2026-08-16 16:51:07.068095+00
45	jealexhouegbe	admin	t	\N	2026-08-16 16:51:21.321239+00
46	urielhouegbe	admin	t	\N	2026-08-16 23:14:59.890519+00
47	jealexhouegbe	admin	t	\N	2026-08-17 04:22:29.319416+00
48	urielhouegbe	admin	t	\N	2026-08-17 19:20:15.425783+00
49	jealexhouegbe	admin	f	\N	2026-08-17 19:50:55.965311+00
50	jealexhouegbe	admin	t	\N	2026-08-17 19:51:24.8748+00
51	jealexhouegbe 	admin	f	\N	2026-08-17 19:54:57.472031+00
52	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:11.314247+00
53	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:15.276516+00
54	jealexhouegbe	admin	t	\N	2026-08-17 19:55:32.145075+00
55	urielhouegbe	admin	t	\N	2026-08-18 14:39:31.730354+00
56	urielhouegbe	admin	t	\N	2026-08-18 15:01:39.644185+00
57	jealexhouegbe	admin	t	\N	2026-08-18 18:19:26.597107+00
58	urielhouegbe	admin	t	\N	2026-08-18 18:25:36.774151+00
59	urielhouegbe	admin	t	\N	2026-08-18 19:18:33.026739+00
60	urielhouegbe	admin	t	\N	2026-08-18 19:41:50.997441+00
61	urielhouegbe	admin	t	\N	2026-08-18 19:46:37.319351+00
62	urielhouegbe	admin	t	\N	2026-08-18 20:04:14.497463+00
63	urielhouegbe	admin	t	\N	2026-08-18 20:24:31.820607+00
64	jealexhouegbe	admin	t	\N	2026-08-18 20:57:59.714752+00
65	jealexhouegbe	admin	f	\N	2026-08-18 21:35:02.243166+00
66	jealexhouegbe	admin	t	\N	2026-08-18 21:35:26.978454+00
67	jealexhouegbe	admin	t	\N	2026-08-18 22:15:50.900336+00
68	jealexhouegbe	admin	t	\N	2026-08-18 22:25:22.228939+00
69	jealexhouegbe	admin	t	\N	2026-08-18 22:26:16.772262+00
70	jealexhouegbe	admin	f	\N	2026-08-20 20:51:38.231956+00
71	jealexhouegbe	admin	t	\N	2026-08-20 20:52:02.9463+00
72	jealexhouegbe	admin	t	\N	2026-08-20 22:40:52.726733+00
73	jealexhouegbe	admin	t	\N	2026-08-21 05:34:05.517187+00
74	jealexhouegbe	admin	t	\N	2026-08-24 08:05:32.234437+00
75	jealexhouegbe	admin	t	\N	2026-08-24 09:27:48.297251+00
76	sylvestregblagodo@gmail.com	td	f	\N	2026-08-24 21:19:59.614399+00
77	jealexhouegbe	admin	t	\N	2026-08-24 23:51:25.967698+00
78	louislucnou@gmail.com	td	f	\N	2026-08-25 11:10:13.546533+00
79	jealexhouegbe	admin	t	\N	2026-08-25 14:17:27.114846+00
80	piomedesse@gmail.com	td	f	\N	2026-08-25 17:34:32.465617+00
81	jealexhouegbe	admin	t	\N	2026-08-25 19:58:21.76755+00
82	jealexhouegbe	admin	t	\N	2026-08-25 20:04:35.214424+00
83	jealexhouegbe	admin	t	\N	2026-08-25 21:59:07.881512+00
84	jealexhouegbe	admin	t	\N	2026-08-25 22:28:27.334899+00
85	jealexhouegbe	admin	t	\N	2026-08-26 05:04:34.848327+00
86	jealexhouegbe	admin	t	\N	2026-08-26 05:25:00.305425+00
87	urielhouegbe	admin	t	\N	2026-08-26 05:26:07.905145+00
88	urielhouegbe	admin	t	\N	2026-08-26 05:33:11.71263+00
89	urielhouegbe	admin	t	\N	2026-08-26 06:39:47.176169+00
90	urielhouegbe	admin	t	\N	2026-08-26 06:45:04.452508+00
91	jealexhouegbe	admin	t	\N	2026-08-26 06:47:20.684668+00
92	jealexhouegbe	admin	t	\N	2026-08-26 07:29:32.628906+00
93	urielhouegbe	admin	t	\N	2026-08-26 07:34:42.59047+00
94	jealexhouegbe	admin	t	\N	2026-08-26 07:39:09.898096+00
95	jealexhouegbe	admin	t	\N	2026-08-26 19:22:10.541005+00
96	urielhouegbe	admin	t	\N	2026-08-26 19:22:17.499147+00
97	jealexhouegbe	admin	t	\N	2026-08-26 19:54:34.621802+00
98	djossoudavid19@gmail.com	td	f	\N	2026-08-27 06:27:52.0945+00
99	kegnidedavid70@gmail.com	td	f	\N	2026-08-27 22:49:29.236976+00
100	kegnidedavid70@gmail.com	td	f	\N	2026-08-27 22:49:38.098546+00
\.


--
-- Data for Name: matieres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matieres (id, nom, code, ordre, actif) FROM stdin;
1	Francais	FR	1	t
2	Mathematiques	MATHS	2	t
3	Anglais	ANG	3	t
5	SVT	SVT	5	t
6	Philosophie	PHILO	6	t
7	Histoire-Geographie	HG	7	t
8	Economie	ECO	8	t
9	Espagnol	ESP	9	t
10	Allemand	ALL	10	t
11	Com. Ecrite	COM_ECRITE	11	t
4	PCT	PCT	4	t
\.


--
-- Data for Name: mois_exoneres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mois_exoneres (id, eleve_id, mois_souscription, annee_scolaire_id, motif, exonere_par, date_exoneration) FROM stdin;
\.


--
-- Data for Name: moyennes_semestrielles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.moyennes_semestrielles (id, eleve_id, annee_scolaire_id, semestre, moyenne_generale, cloture_par, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, eleve_id, matiere_id, type_note, valeur, annee_scolaire_id, updated_at, semestre) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, site_id, contenu, lu, date_creation) FROM stdin;
\.


--
-- Data for Name: paiements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements (id, eleve_id, mois_souscription, montant_paye, date_paiement, mode_paiement, annee_scolaire_id, enregistre_par) FROM stdin;
\.


--
-- Data for Name: paiements_supprimes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements_supprimes (id, matricule, mois_souscription, montant_paye, date_paiement, mode_paiement, admin_id, date_suppression, motif) FROM stdin;
\.


--
-- Data for Name: penalites_reinscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.penalites_reinscription (id, eleve_id, montant, mode_paiement, date_paiement, enregistre_par, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: presences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.presences (id, eleve_id, date_presence, site_id, classe_id, present, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: recompenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recompenses (id, note_id, eleve_id, annee_scolaire_id, mois, type_gain, montant, depense_id, paye_par, date_paiement, created_at) FROM stdin;
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, nom_site, initiale) FROM stdin;
2	Yagbé	Y
1	Jéricho	J
\.


--
-- Data for Name: user_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sites (user_id, site_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, role, site_id, actif) FROM stdin;
55899634-2a3d-4d0c-a169-c883ddd3b72f	jealexhouegbe	jucaljealexhouegbe@gmail.com	coordonnateur	\N	t
7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	urielhouegbe	urielaxelhouegbe@gmail.com	comptable	\N	t
\.


--
-- Data for Name: creneaux; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.creneaux (id, semaine_id, classe_id, matiere_id, date_td, heure_debut, heure_fin, montant_prevu, statut_creneau) FROM stdin;
3	4	20	3	2026-10-10	08:00:00	10:00:00	3000.00	cloture
4	4	18	1	2026-10-10	10:30:00	12:30:00	3000.00	cloture
5	5	20	7	2026-10-14	10:00:00	12:00:00	2000.00	cloture
6	5	18	4	2026-10-14	10:00:00	12:00:00	3000.00	cloture
\.


--
-- Data for Name: matieres_td; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.matieres_td (id, nom_matiere) FROM stdin;
1	Francais
2	Mathematiques
3	Anglais
5	SVT
6	Philosophie
7	Histoire-Geographie
8	Economie
9	Espagnol
10	Allemand
11	Communication écrite
4	PCT
\.


--
-- Data for Name: postulations; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.postulations (id, creneau_id, professeur_id, statut_validation, date_postulation, motif_retrait) FROM stdin;
3	3	1	Valide	2026-08-12 00:37:45.857256+00	\N
5	6	1	Refuse	2026-08-13 06:52:27.566445+00	\N
4	5	1	Retiree	2026-08-13 06:52:19.155386+00	Maladie
\.


--
-- Data for Name: professeurs; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.professeurs (id, nom, prenom, telephone, email, mot_de_passe, zone_id, matiere_principale_id, actif, date_inscription) FROM stdin;
1	HOUEGBE	Uriel	0169974527	urielaxelhouegbe@gmail.com	$2b$10$kTFT24SIP1kiTHh.450jdepLCViUKeP/iN8GqsSu7snvTAROKciG.	1	2	t	2026-08-09 23:16:20.976307+00
\.


--
-- Data for Name: semaines; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.semaines (id, libelle, date_debut, date_fin, statut, date_creation, date_cloture) FROM stdin;
4	Semaine 1	2026-10-05	2026-10-11	cloturee	2026-08-12 00:27:06.382828+00	2026-08-12 00:45:18.88+00
5	Semaine 2	2026-10-12	2026-10-18	cloturee	2026-08-13 06:46:47.446567+00	2026-08-13 07:10:14.833+00
\.


--
-- Data for Name: zones; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.zones (id, nom_zone) FROM stdin;
1	Jéricho
2	Yagbé
3	Vèdoko
\.


--
-- Name: actualites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_id_seq', 3, true);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_images_id_seq', 3, true);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.annees_scolaires_id_seq', 1, true);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_depenses_id_seq', 10, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.classes_id_seq', 24, true);


--
-- Name: coefficients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.coefficients_id_seq', 186, true);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comptes_parents_id_seq', 1, false);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.decisions_passage_id_seq', 2, true);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.depenses_annexes_id_seq', 1, false);


--
-- Name: eleves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_id_seq', 666, true);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_suspendus_id_seq', 1, false);


--
-- Name: frais_td_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frais_td_id_seq', 24, true);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_admin_id_seq', 1, true);


--
-- Name: galerie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_id_seq', 1, false);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_whatsapp_id_seq', 1, false);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_attempts_id_seq', 100, true);


--
-- Name: matieres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matieres_id_seq', 11, true);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mois_exoneres_id_seq', 1, false);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.moyennes_semestrielles_id_seq', 2, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: paiements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_id_seq', 1, false);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_supprimes_id_seq', 1, false);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.penalites_reinscription_id_seq', 1, false);


--
-- Name: presences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.presences_id_seq', 1, false);


--
-- Name: recompenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recompenses_id_seq', 1, false);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 2, true);


--
-- Name: creneaux_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.creneaux_id_seq', 6, true);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.matieres_td_id_seq', 11, true);


--
-- Name: postulations_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.postulations_id_seq', 5, true);


--
-- Name: professeurs_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.professeurs_id_seq', 1, true);


--
-- Name: semaines_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.semaines_id_seq', 5, true);


--
-- Name: zones_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.zones_id_seq', 3, true);


--
-- Name: actualites_images actualites_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_pkey PRIMARY KEY (id);


--
-- Name: actualites actualites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_pkey PRIMARY KEY (id);


--
-- Name: annees_scolaires annees_scolaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires
    ADD CONSTRAINT annees_scolaires_pkey PRIMARY KEY (id);


--
-- Name: categories_depenses categories_depenses_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_nom_key UNIQUE (nom);


--
-- Name: categories_depenses categories_depenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_pkey PRIMARY KEY (id);


--
-- Name: classes classes_nom_classe_site_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_nom_classe_site_id_key UNIQUE (nom_classe, site_id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: coefficients coefficients_classe_id_matiere_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_matiere_id_key UNIQUE (classe_id, matiere_id);


--
-- Name: coefficients coefficients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_pkey PRIMARY KEY (id);


--
-- Name: comptes_parents comptes_parents_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_matricule_key UNIQUE (matricule);


--
-- Name: comptes_parents comptes_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_pkey PRIMARY KEY (id);


--
-- Name: decisions_passage decisions_passage_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_key UNIQUE (eleve_id);


--
-- Name: decisions_passage decisions_passage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_pkey PRIMARY KEY (id);


--
-- Name: depenses_annexes depenses_annexes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_pkey PRIMARY KEY (id);


--
-- Name: eleves eleves_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_matricule_key UNIQUE (matricule);


--
-- Name: eleves eleves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_pkey PRIMARY KEY (id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_key UNIQUE (eleve_id);


--
-- Name: eleves_suspendus eleves_suspendus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_pkey PRIMARY KEY (id);


--
-- Name: frais_td frais_td_classe_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_key UNIQUE (classe_id);


--
-- Name: frais_td frais_td_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_pkey PRIMARY KEY (id);


--
-- Name: galerie_admin galerie_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_pkey PRIMARY KEY (id);


--
-- Name: galerie galerie_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie
    ADD CONSTRAINT galerie_pkey PRIMARY KEY (id);


--
-- Name: log_whatsapp log_whatsapp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: matieres matieres_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_code_key UNIQUE (code);


--
-- Name: matieres matieres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_pkey PRIMARY KEY (id);


--
-- Name: mois_exoneres mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key UNIQUE (eleve_id, mois_souscription, annee_scolaire_id);


--
-- Name: mois_exoneres mois_exoneres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_pkey PRIMARY KEY (id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key UNIQUE (eleve_id, annee_scolaire_id, semestre);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_pkey PRIMARY KEY (id);


--
-- Name: notes notes_eleve_matiere_type_annee_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_matiere_type_annee_semestre_key UNIQUE (eleve_id, matiere_id, type_note, annee_scolaire_id, semestre);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: paiements paiements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_pkey PRIMARY KEY (id);


--
-- Name: paiements_supprimes paiements_supprimes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_pkey PRIMARY KEY (id);


--
-- Name: penalites_reinscription penalites_reinscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_pkey PRIMARY KEY (id);


--
-- Name: presences presences_eleve_id_date_presence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_date_presence_key UNIQUE (eleve_id, date_presence);


--
-- Name: presences presences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_pkey PRIMARY KEY (id);


--
-- Name: recompenses recompenses_note_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_key UNIQUE (note_id);


--
-- Name: recompenses recompenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_pkey PRIMARY KEY (id);


--
-- Name: sites sites_initiale_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_initiale_key UNIQUE (initiale);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: user_sites user_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_pkey PRIMARY KEY (user_id, site_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: creneaux creneaux_classe_id_date_td_heure_debut_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_date_td_heure_debut_key UNIQUE (classe_id, date_td, heure_debut);


--
-- Name: creneaux creneaux_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_pkey PRIMARY KEY (id);


--
-- Name: matieres_td matieres_td_nom_matiere_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_nom_matiere_key UNIQUE (nom_matiere);


--
-- Name: matieres_td matieres_td_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_pkey PRIMARY KEY (id);


--
-- Name: postulations postulations_creneau_id_professeur_id_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_professeur_id_key UNIQUE (creneau_id, professeur_id);


--
-- Name: postulations postulations_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_email_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_email_key UNIQUE (email);


--
-- Name: professeurs professeurs_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_telephone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_telephone_key UNIQUE (telephone);


--
-- Name: semaines semaines_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines
    ADD CONSTRAINT semaines_pkey PRIMARY KEY (id);


--
-- Name: zones zones_nom_zone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_nom_zone_key UNIQUE (nom_zone);


--
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id);


--
-- Name: idx_login_attempts_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_attempts_lookup ON public.login_attempts USING btree (identifiant, portail, date_tentative);


--
-- Name: frais_td trg_frais_td_lock_period; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_frais_td_lock_period BEFORE UPDATE OF montant ON public.frais_td FOR EACH ROW EXECUTE FUNCTION public.trg_frais_td_lock_period_fn();


--
-- Name: annees_scolaires trg_unique_annee_en_cours; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_unique_annee_en_cours BEFORE INSERT OR UPDATE ON public.annees_scolaires FOR EACH ROW EXECUTE FUNCTION public.trg_unique_annee_en_cours_fn();


--
-- Name: users trg_users_scope_coherence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_scope_coherence BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.trg_users_scope_coherence_fn();


--
-- Name: actualites actualites_cree_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_cree_par_fkey FOREIGN KEY (cree_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: actualites_images actualites_images_actualite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_actualite_id_fkey FOREIGN KEY (actualite_id) REFERENCES public.actualites(id) ON DELETE CASCADE;


--
-- Name: classes classes_classe_suivante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_classe_suivante_id_fkey FOREIGN KEY (classe_suivante_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: classes classes_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: decisions_passage decisions_passage_decide_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_decide_par_fkey FOREIGN KEY (decide_par) REFERENCES public.users(id);


--
-- Name: decisions_passage decisions_passage_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_nouvelle_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_nouvelle_classe_id_fkey FOREIGN KEY (nouvelle_classe_id) REFERENCES public.classes(id);


--
-- Name: depenses_annexes depenses_annexes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_categorie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_categorie_id_fkey FOREIGN KEY (categorie_id) REFERENCES public.categories_depenses(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_saisi_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_saisi_par_fkey FOREIGN KEY (saisi_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: eleves eleves_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_suspendu_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_suspendu_par_fkey FOREIGN KEY (suspendu_par) REFERENCES public.users(id);


--
-- Name: frais_td frais_td_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: galerie_admin galerie_admin_ajoute_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_ajoute_par_fkey FOREIGN KEY (ajoute_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: log_whatsapp log_whatsapp_envoye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_envoye_par_fkey FOREIGN KEY (envoye_par) REFERENCES public.users(id);


--
-- Name: mois_exoneres mois_exoneres_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_exonere_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_exonere_par_fkey FOREIGN KEY (exonere_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: moyennes_semestrielles moyennes_semestrielles_cloture_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_cloture_par_fkey FOREIGN KEY (cloture_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: notes notes_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: paiements_supprimes paiements_supprimes_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: penalites_reinscription penalites_reinscription_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id);


--
-- Name: presences presences_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: presences presences_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: presences presences_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: presences presences_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_depense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_depense_id_fkey FOREIGN KEY (depense_id) REFERENCES public.depenses_annexes(id) ON DELETE SET NULL;


--
-- Name: recompenses recompenses_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_paye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_paye_par_fkey FOREIGN KEY (paye_par) REFERENCES public.users(id);


--
-- Name: user_sites user_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: user_sites user_sites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users users_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: creneaux creneaux_classe_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_matiere_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_semaine_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_semaine_id_fkey FOREIGN KEY (semaine_id) REFERENCES td.semaines(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_creneau_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_fkey FOREIGN KEY (creneau_id) REFERENCES td.creneaux(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_professeur_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_professeur_id_fkey FOREIGN KEY (professeur_id) REFERENCES td.professeurs(id) ON DELETE CASCADE;


--
-- Name: professeurs professeurs_matiere_principale_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_matiere_principale_id_fkey FOREIGN KEY (matiere_principale_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: professeurs professeurs_zone_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES td.zones(id) ON DELETE RESTRICT;


--
-- Name: actualites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites_images ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images actualites_images_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_images_lecture_publique ON public.actualites_images FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.actualites a
  WHERE ((a.id = actualites_images.actualite_id) AND (a.statut = 'publie'::text)))));


--
-- Name: actualites actualites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_lecture_publique ON public.actualites FOR SELECT USING ((statut = 'publie'::text));


--
-- Name: annees_scolaires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.annees_scolaires ENABLE ROW LEVEL SECURITY;

--
-- Name: annees_scolaires annees_scolaires_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY annees_scolaires_lecture_staff ON public.annees_scolaires FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: categories_depenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.categories_depenses ENABLE ROW LEVEL SECURITY;

--
-- Name: categories_depenses categories_depenses_lecture_global; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY categories_depenses_lecture_global ON public.categories_depenses FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: classes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;

--
-- Name: classes classes_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_publique ON public.classes FOR SELECT TO anon USING (true);


--
-- Name: classes classes_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_staff ON public.classes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: coefficients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coefficients ENABLE ROW LEVEL SECURITY;

--
-- Name: coefficients coefficients_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY coefficients_lecture_staff ON public.coefficients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: comptes_parents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.comptes_parents ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decisions_passage ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage decisions_passage_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY decisions_passage_lecture ON public.decisions_passage FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: depenses_annexes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.depenses_annexes ENABLE ROW LEVEL SECURITY;

--
-- Name: depenses_annexes depenses_annexes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY depenses_annexes_lecture ON public.depenses_annexes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: eleves; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves eleves_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_acces ON public.eleves USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM (public.user_sites us
             JOIN public.classes c ON ((c.id = eleves.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM public.classes c
          WHERE ((c.id = eleves.classe_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: eleves_suspendus; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves_suspendus ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves_suspendus eleves_suspendus_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_suspendus_acces ON public.eleves_suspendus USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = eleves_suspendus.site_id))))))))));


--
-- Name: frais_td; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.frais_td ENABLE ROW LEVEL SECURITY;

--
-- Name: frais_td frais_td_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY frais_td_lecture_staff ON public.frais_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: galerie; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie_admin ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin galerie_admin_ajout; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_ajout ON public.galerie_admin FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_lecture ON public.galerie_admin FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_suppression; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_suppression ON public.galerie_admin FOR DELETE USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text])) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (galerie_admin.ajoute_par = auth.uid())))))));


--
-- Name: galerie galerie_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_lecture_publique ON public.galerie FOR SELECT USING (true);


--
-- Name: log_whatsapp; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.log_whatsapp ENABLE ROW LEVEL SECURITY;

--
-- Name: log_whatsapp log_whatsapp_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY log_whatsapp_acces ON public.log_whatsapp FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON (((e.matricule)::text = (log_whatsapp.matricule)::text)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: login_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.matieres ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres matieres_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY matieres_lecture_staff ON public.matieres FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: mois_exoneres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mois_exoneres ENABLE ROW LEVEL SECURITY;

--
-- Name: mois_exoneres mois_exoneres_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mois_exoneres_acces ON public.mois_exoneres USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = mois_exoneres.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: moyennes_semestrielles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.moyennes_semestrielles ENABLE ROW LEVEL SECURITY;

--
-- Name: moyennes_semestrielles moyennes_semestrielles_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY moyennes_semestrielles_acces ON public.moyennes_semestrielles USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = moyennes_semestrielles.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = moyennes_semestrielles.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: notes notes_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notes_acces ON public.notes USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = notes.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = notes.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_acces ON public.notifications FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = notifications.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = notifications.site_id)))))));


--
-- Name: paiements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements paiements_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_acces ON public.paiements USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = paiements.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: paiements_supprimes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements_supprimes ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements_supprimes paiements_supprimes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_supprimes_lecture ON public.paiements_supprimes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: penalites_reinscription; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.penalites_reinscription ENABLE ROW LEVEL SECURITY;

--
-- Name: penalites_reinscription penalites_reinscription_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY penalites_reinscription_acces ON public.penalites_reinscription USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = penalites_reinscription.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: presences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.presences ENABLE ROW LEVEL SECURITY;

--
-- Name: presences presences_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY presences_acces ON public.presences USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = presences.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = presences.site_id)))))));


--
-- Name: recompenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recompenses ENABLE ROW LEVEL SECURITY;

--
-- Name: recompenses recompenses_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY recompenses_acces ON public.recompenses USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = recompenses.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: sites sites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_publique ON public.sites FOR SELECT TO anon USING (true);


--
-- Name: sites sites_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_staff ON public.sites FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: user_sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_sites ENABLE ROW LEVEL SECURITY;

--
-- Name: user_sites user_sites_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_sites_lecture_soi_meme ON public.user_sites FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_soi_meme ON public.users FOR SELECT USING ((id = auth.uid()));


--
-- Name: users users_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_staff ON public.users FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: creneaux; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.creneaux ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres_td; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.matieres_td ENABLE ROW LEVEL SECURITY;

--
-- Name: postulations; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.postulations ENABLE ROW LEVEL SECURITY;

--
-- Name: professeurs; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.professeurs ENABLE ROW LEVEL SECURITY;

--
-- Name: semaines; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.semaines ENABLE ROW LEVEL SECURITY;

--
-- Name: creneaux td_creneaux_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_coordonnateur ON td.creneaux FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: creneaux td_creneaux_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_publique ON td.creneaux FOR SELECT TO anon USING (((statut_creneau = ANY (ARRAY['public'::text, 'cloture'::text])) AND (EXISTS ( SELECT 1
   FROM td.semaines s
  WHERE ((s.id = creneaux.semaine_id) AND (s.statut = 'publiee'::text))))));


--
-- Name: matieres_td td_matieres_td_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_coordonnateur ON td.matieres_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: matieres_td td_matieres_td_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_publique ON td.matieres_td FOR SELECT TO anon USING (true);


--
-- Name: postulations td_postulations_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_postulations_lecture_coordonnateur ON td.postulations FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: professeurs td_professeurs_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_professeurs_lecture_coordonnateur ON td.professeurs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_coordonnateur ON td.semaines FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_publique ON td.semaines FOR SELECT TO anon USING ((statut = 'publiee'::text));


--
-- Name: zones td_zones_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_zones_lecture_coordonnateur ON td.zones FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: zones; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.zones ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 1T5YapyQewArz5g7mRs8CiV4uNA9v8JWC45EtAFq6FY9L5XVzRRGIdE5pVYV4iU


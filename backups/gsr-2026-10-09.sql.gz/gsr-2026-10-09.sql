--
-- PostgreSQL database dump
--

\restrict H4jzywpEmueTgd9JZYe8oIysI6hupx8qvgqOK1R0BBvgLyq5meU1nRu7Up1JMOg

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS td_zones_lecture_coordonnateur ON td.zones;
DROP POLICY IF EXISTS td_semaines_lecture_publique ON td.semaines;
DROP POLICY IF EXISTS td_semaines_lecture_coordonnateur ON td.semaines;
DROP POLICY IF EXISTS td_professeurs_lecture_coordonnateur ON td.professeurs;
DROP POLICY IF EXISTS td_postulations_lecture_coordonnateur ON td.postulations;
DROP POLICY IF EXISTS td_matieres_td_lecture_publique ON td.matieres_td;
DROP POLICY IF EXISTS td_matieres_td_lecture_coordonnateur ON td.matieres_td;
DROP POLICY IF EXISTS td_creneaux_lecture_publique ON td.creneaux;
DROP POLICY IF EXISTS td_creneaux_lecture_coordonnateur ON td.creneaux;
DROP POLICY IF EXISTS users_lecture_staff ON public.users;
DROP POLICY IF EXISTS users_lecture_soi_meme ON public.users;
DROP POLICY IF EXISTS user_sites_lecture_soi_meme ON public.user_sites;
DROP POLICY IF EXISTS sites_lecture_staff ON public.sites;
DROP POLICY IF EXISTS sites_lecture_publique ON public.sites;
DROP POLICY IF EXISTS recompenses_acces ON public.recompenses;
DROP POLICY IF EXISTS presences_acces ON public.presences;
DROP POLICY IF EXISTS penalites_reinscription_acces ON public.penalites_reinscription;
DROP POLICY IF EXISTS paiements_supprimes_lecture ON public.paiements_supprimes;
DROP POLICY IF EXISTS paiements_acces ON public.paiements;
DROP POLICY IF EXISTS notifications_acces ON public.notifications;
DROP POLICY IF EXISTS notes_acces ON public.notes;
DROP POLICY IF EXISTS moyennes_semestrielles_acces ON public.moyennes_semestrielles;
DROP POLICY IF EXISTS mois_exoneres_acces ON public.mois_exoneres;
DROP POLICY IF EXISTS matieres_lecture_staff ON public.matieres;
DROP POLICY IF EXISTS log_whatsapp_acces ON public.log_whatsapp;
DROP POLICY IF EXISTS galerie_lecture_publique ON public.galerie;
DROP POLICY IF EXISTS galerie_admin_suppression ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_lecture ON public.galerie_admin;
DROP POLICY IF EXISTS galerie_admin_ajout ON public.galerie_admin;
DROP POLICY IF EXISTS frais_td_lecture_staff ON public.frais_td;
DROP POLICY IF EXISTS eleves_suspendus_acces ON public.eleves_suspendus;
DROP POLICY IF EXISTS eleves_exonerations_lecture ON public.eleves_exonerations;
DROP POLICY IF EXISTS eleves_exonerations_ecriture ON public.eleves_exonerations;
DROP POLICY IF EXISTS eleves_acces ON public.eleves;
DROP POLICY IF EXISTS depenses_annexes_lecture ON public.depenses_annexes;
DROP POLICY IF EXISTS decisions_passage_lecture ON public.decisions_passage;
DROP POLICY IF EXISTS coefficients_lecture_staff ON public.coefficients;
DROP POLICY IF EXISTS classes_lecture_staff ON public.classes;
DROP POLICY IF EXISTS classes_lecture_publique ON public.classes;
DROP POLICY IF EXISTS categories_depenses_lecture_global ON public.categories_depenses;
DROP POLICY IF EXISTS annees_scolaires_lecture_staff ON public.annees_scolaires;
DROP POLICY IF EXISTS actualites_lecture_publique ON public.actualites;
DROP POLICY IF EXISTS actualites_images_lecture_publique ON public.actualites_images;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_zone_id_fkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_matiere_principale_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_professeur_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_semaine_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_paye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_depense_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_admin_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_enregistre_par_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_cloture_par_fkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_exonere_par_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_envoye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_ajoute_par_fkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_suspendu_par_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_accorde_par_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_saisi_par_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_categorie_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_nouvelle_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_decide_par_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_classe_suivante_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_actualite_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_cree_par_fkey;
DROP TRIGGER IF EXISTS trg_check_max_postulations ON td.postulations;
DROP TRIGGER IF EXISTS trg_users_scope_coherence ON public.users;
DROP TRIGGER IF EXISTS trg_unique_annee_en_cours ON public.annees_scolaires;
DROP TRIGGER IF EXISTS trg_frais_td_lock_period ON public.frais_td;
DROP INDEX IF EXISTS td.idx_professeurs_valide;
DROP INDEX IF EXISTS public.idx_login_attempts_lookup;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_pkey;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_nom_zone_key;
ALTER TABLE IF EXISTS ONLY td.semaines DROP CONSTRAINT IF EXISTS semaines_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_telephone_key;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_email_key;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_pkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_professeur_id_key;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_pkey;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_nom_matiere_key;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_pkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_date_td_heure_debut_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_initiale_key;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_pkey;
ALTER TABLE IF EXISTS ONLY public.recompenses DROP CONSTRAINT IF EXISTS recompenses_note_id_key;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_pkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_date_presence_key;
ALTER TABLE IF EXISTS ONLY public.penalites_reinscription DROP CONSTRAINT IF EXISTS penalites_reinscription_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_matiere_type_annee_semestre_key;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_pkey;
ALTER TABLE IF EXISTS ONLY public.moyennes_semestrielles DROP CONSTRAINT IF EXISTS moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_pkey;
ALTER TABLE IF EXISTS ONLY public.mois_exoneres DROP CONSTRAINT IF EXISTS mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_pkey;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_code_key;
ALTER TABLE IF EXISTS ONLY public.login_attempts DROP CONSTRAINT IF EXISTS login_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie DROP CONSTRAINT IF EXISTS galerie_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_matricule_key;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves_exonerations DROP CONSTRAINT IF EXISTS eleves_exonerations_eleve_id_annee_scolaire_id_key;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_pkey;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_matricule_key;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_pkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_matiere_id_key;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_pkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_nom_classe_site_id_key;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_pkey;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_nom_key;
ALTER TABLE IF EXISTS ONLY public.annees_scolaires DROP CONSTRAINT IF EXISTS annees_scolaires_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_pkey;
ALTER TABLE IF EXISTS td.zones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.semaines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.professeurs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.postulations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.matieres_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.creneaux ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.recompenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.presences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.penalites_reinscription ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements_supprimes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.moyennes_semestrielles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mois_exoneres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matieres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.login_attempts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.log_whatsapp ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie_admin ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.frais_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves_suspendus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves_exonerations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.depenses_annexes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.decisions_passage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comptes_parents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.coefficients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories_depenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.annees_scolaires ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS td.zones_id_seq;
DROP TABLE IF EXISTS td.zones;
DROP SEQUENCE IF EXISTS td.semaines_id_seq;
DROP TABLE IF EXISTS td.semaines;
DROP SEQUENCE IF EXISTS td.professeurs_id_seq;
DROP TABLE IF EXISTS td.professeurs;
DROP SEQUENCE IF EXISTS td.postulations_id_seq;
DROP TABLE IF EXISTS td.postulations;
DROP SEQUENCE IF EXISTS td.matieres_td_id_seq;
DROP TABLE IF EXISTS td.matieres_td;
DROP SEQUENCE IF EXISTS td.creneaux_id_seq;
DROP TABLE IF EXISTS td.creneaux;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sites;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.recompenses_id_seq;
DROP TABLE IF EXISTS public.recompenses;
DROP SEQUENCE IF EXISTS public.presences_id_seq;
DROP TABLE IF EXISTS public.presences;
DROP SEQUENCE IF EXISTS public.penalites_reinscription_id_seq;
DROP TABLE IF EXISTS public.penalites_reinscription;
DROP SEQUENCE IF EXISTS public.paiements_supprimes_id_seq;
DROP TABLE IF EXISTS public.paiements_supprimes;
DROP SEQUENCE IF EXISTS public.paiements_id_seq;
DROP TABLE IF EXISTS public.paiements;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notes_id_seq;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.moyennes_semestrielles_id_seq;
DROP TABLE IF EXISTS public.moyennes_semestrielles;
DROP SEQUENCE IF EXISTS public.mois_exoneres_id_seq;
DROP TABLE IF EXISTS public.mois_exoneres;
DROP SEQUENCE IF EXISTS public.matieres_id_seq;
DROP TABLE IF EXISTS public.matieres;
DROP SEQUENCE IF EXISTS public.login_attempts_id_seq;
DROP TABLE IF EXISTS public.login_attempts;
DROP SEQUENCE IF EXISTS public.log_whatsapp_id_seq;
DROP TABLE IF EXISTS public.log_whatsapp;
DROP SEQUENCE IF EXISTS public.galerie_id_seq;
DROP SEQUENCE IF EXISTS public.galerie_admin_id_seq;
DROP TABLE IF EXISTS public.galerie_admin;
DROP TABLE IF EXISTS public.galerie;
DROP SEQUENCE IF EXISTS public.frais_td_id_seq;
DROP TABLE IF EXISTS public.frais_td;
DROP SEQUENCE IF EXISTS public.eleves_suspendus_id_seq;
DROP TABLE IF EXISTS public.eleves_suspendus;
DROP SEQUENCE IF EXISTS public.eleves_id_seq;
DROP SEQUENCE IF EXISTS public.eleves_exonerations_id_seq;
DROP TABLE IF EXISTS public.eleves_exonerations;
DROP TABLE IF EXISTS public.eleves;
DROP SEQUENCE IF EXISTS public.depenses_annexes_id_seq;
DROP TABLE IF EXISTS public.depenses_annexes;
DROP SEQUENCE IF EXISTS public.decisions_passage_id_seq;
DROP TABLE IF EXISTS public.decisions_passage;
DROP SEQUENCE IF EXISTS public.comptes_parents_id_seq;
DROP TABLE IF EXISTS public.comptes_parents;
DROP SEQUENCE IF EXISTS public.coefficients_id_seq;
DROP TABLE IF EXISTS public.coefficients;
DROP SEQUENCE IF EXISTS public.classes_id_seq;
DROP TABLE IF EXISTS public.classes;
DROP SEQUENCE IF EXISTS public.categories_depenses_id_seq;
DROP TABLE IF EXISTS public.categories_depenses;
DROP SEQUENCE IF EXISTS public.annees_scolaires_id_seq;
DROP TABLE IF EXISTS public.annees_scolaires;
DROP SEQUENCE IF EXISTS public.actualites_images_id_seq;
DROP TABLE IF EXISTS public.actualites_images;
DROP SEQUENCE IF EXISTS public.actualites_id_seq;
DROP TABLE IF EXISTS public.actualites;
DROP FUNCTION IF EXISTS td.check_max_postulations();
DROP FUNCTION IF EXISTS td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer);
DROP FUNCTION IF EXISTS td.affecter_directement_creneau(p_creneau_id integer, p_professeur_id integer);
DROP FUNCTION IF EXISTS public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date);
DROP FUNCTION IF EXISTS public.trg_users_scope_coherence_fn();
DROP FUNCTION IF EXISTS public.trg_unique_annee_en_cours_fn();
DROP FUNCTION IF EXISTS public.trg_frais_td_lock_period_fn();
DROP FUNCTION IF EXISTS public.rls_auto_enable();
DROP FUNCTION IF EXISTS public.resolve_staff_email(p_username text);
DROP FUNCTION IF EXISTS public.enregistrer_paiement_atomique(p_eleve_id integer, p_mois_souscription text, p_montant_paye numeric, p_date_paiement date, p_mode_paiement text, p_enregistre_par uuid);
DROP FUNCTION IF EXISTS public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]);
DROP SCHEMA IF EXISTS td;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: td; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA td;


--
-- Name: assigner_sites_superviseur(uuid, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  DELETE FROM public.user_sites WHERE user_id = p_user_id;
  INSERT INTO public.user_sites (user_id, site_id)
  SELECT p_user_id, unnest(p_site_ids);
END;
$$;


--
-- Name: enregistrer_paiement_atomique(integer, text, numeric, date, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enregistrer_paiement_atomique(p_eleve_id integer, p_mois_souscription text, p_montant_paye numeric, p_date_paiement date, p_mode_paiement text, p_enregistre_par uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_classe_id integer;
  v_statut text;
  v_college text;
  v_montant_frais numeric;
  v_annee_id integer;
  v_annee_libelle text;
  v_exo_motif text;
  v_total_deja_paye numeric;
  v_reste numeric;
  v_nouveau_paiement_id integer;
  v_total_apres numeric;
  v_reste_apres numeric;
BEGIN
  -- 1. Verrouiller la ligne de l'élève pour sérialiser tout paiement sur cet élève
  SELECT classe_id, statut, college INTO v_classe_id, v_statut, v_college
  FROM public.eleves
  WHERE id = p_eleve_id
  FOR UPDATE;

  IF NOT FOUND OR v_statut <> 'actif' THEN
    RETURN jsonb_build_object('success', false, 'error', 'Élève introuvable ou suspendu');
  END IF;

  -- 2. Récupérer l'année scolaire en cours
  SELECT id, libelle INTO v_annee_id, v_annee_libelle
  FROM public.annees_scolaires
  WHERE statut = 'en_cours'
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Aucune année scolaire en cours');
  END IF;

  -- 3. Vérifier les frais TD configurés
  SELECT montant INTO v_montant_frais
  FROM public.frais_td
  WHERE classe_id = v_classe_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Aucun montant de frais TD configuré pour cette classe');
  END IF;

  -- 4. Vérifier exonération
  SELECT motif INTO v_exo_motif
  FROM public.mois_exoneres
  WHERE eleve_id = p_eleve_id
    AND mois_souscription = p_mois_souscription
    AND annee_scolaire_id = v_annee_id;

  IF FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Ce mois est exonéré ou déjà pris en charge (' || v_exo_motif || '). Aucun paiement requis.');
  END IF;

  -- 5. Calculer le total déjà payé
  SELECT COALESCE(SUM(montant_paye), 0) INTO v_total_deja_paye
  FROM public.paiements
  WHERE eleve_id = p_eleve_id
    AND mois_souscription = p_mois_souscription
    AND annee_scolaire_id = v_annee_id;

  v_reste := GREATEST(0, v_montant_frais - v_total_deja_paye);

  IF p_montant_paye > v_reste THEN
    RETURN jsonb_build_object('success', false, 'error', 'Le montant dépasse le reste dû (' || v_reste || ' F)');
  END IF;

  -- 6. Insérer le paiement avec la variable correcte v_annee_id
  INSERT INTO public.paiements (
    eleve_id,
    mois_souscription,
    montant_paye,
    date_paiement,
    mode_paiement,
    annee_scolaire_id,
    enregistre_par
  ) VALUES (
    p_eleve_id,
    p_mois_souscription,
    p_montant_paye,
    p_date_paiement,
    p_mode_paiement,
    v_annee_id,
    p_enregistre_par
  ) RETURNING id INTO v_nouveau_paiement_id;

  v_total_apres := v_total_deja_paye + p_montant_paye;
  v_reste_apres := GREATEST(0, v_montant_frais - v_total_apres);

  RETURN jsonb_build_object(
    'success', true,
    'last_paiement_id', v_nouveau_paiement_id,
    'reste_apres_paiement', v_reste_apres,
    'montant_attendu', v_montant_frais,
    'college', v_college,
    'annee_libelle', v_annee_libelle,
    'annee_id', v_annee_id
  );
END;
$$;


--
-- Name: resolve_staff_email(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_staff_email(p_username text) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  RETURN (SELECT email FROM public.users WHERE username = p_username AND actif = true LIMIT 1);
END;
$$;


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rls_auto_enable() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: trg_frais_td_lock_period_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_frais_td_lock_period_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_debut date;
  v_fin   date;
begin
  select date_debut, date_fin into v_debut, v_fin
  from public.annees_scolaires where statut = 'en_cours';

  if v_debut is not null and current_date between v_debut and v_fin then
    raise exception 'Modification du montant interdite pendant l''année scolaire en cours — uniquement en période de vacances, après l''arbitrage de fin d''année';
  end if;

  return new;
end;
$$;


--
-- Name: trg_unique_annee_en_cours_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_unique_annee_en_cours_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.statut = 'en_cours' and exists (
    select 1 from public.annees_scolaires
    where statut = 'en_cours' and id <> new.id
  ) then
    raise exception 'Une année scolaire est déjà en_cours';
  end if;

  return new;
end;
$$;


--
-- Name: trg_users_scope_coherence_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_users_scope_coherence_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.role in ('chef_site', 'secretaire') and new.site_id is null then
    raise exception 'site_id obligatoire pour le rôle %', new.role;
  end if;

  if new.role in ('coordonnateur','comptable','superviseur') and new.site_id is not null then
    raise exception 'site_id doit être NULL pour le rôle %', new.role;
  end if;

  return new;
end;
$$;


--
-- Name: valider_fin_annee(text, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  -- 1. Créer la nouvelle année scolaire
  INSERT INTO public.annees_scolaires (libelle, date_debut, date_fin, statut)
  VALUES (p_nouvelle_libelle, p_nouvelle_date_debut, p_nouvelle_date_fin, 'en_cours');

  -- 2. Clôturer l'ancienne
  UPDATE public.annees_scolaires SET statut = 'terminee' WHERE statut = 'en_pause';

  -- 3. Appliquer les décisions "passe"
  UPDATE public.eleves e
  SET classe_id = d.nouvelle_classe_id
  FROM public.decisions_passage d
  WHERE d.eleve_id = e.id
    AND d.decision = 'passe'
    AND d.nouvelle_classe_id IS NOT NULL;

  -- 4. Supprimer définitivement les élèves sortant / encore suspendus
  DELETE FROM public.eleves e
  WHERE e.id IN (SELECT eleve_id FROM public.decisions_passage WHERE decision = 'sortant')
     OR e.statut = 'suspendu';

  -- 5. Purger les logs applicatifs des élèves désormais absents de `eleves`
  DELETE FROM public.log_whatsapp
  WHERE matricule NOT IN (SELECT matricule FROM public.eleves);

  DELETE FROM public.paiements_supprimes
  WHERE matricule NOT IN (SELECT matricule FROM public.eleves);

  -- 6. Purger la table tampon des décisions
  TRUNCATE public.decisions_passage;

  -- 7. Récompenses de fin d'année
  UPDATE public.recompenses_fin_annee
  SET date_distribution = now()
  WHERE annee_scolaire_id IN (
    SELECT id FROM public.annees_scolaires WHERE statut = 'terminee'
  )
  AND date_distribution IS NULL;

EXCEPTION WHEN OTHERS THEN
  RAISE;
END;
$$;


--
-- Name: affecter_directement_creneau(integer, integer); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.affecter_directement_creneau(p_creneau_id integer, p_professeur_id integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'td', 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM td.creneaux WHERE id = p_creneau_id AND statut_creneau = 'public'
  ) THEN
    RAISE EXCEPTION 'Ce créneau n''est plus ouvert aux candidatures ou à l''affectation.';
  END IF;

  -- Garde anti-chevauchement
  IF EXISTS (
    SELECT 1
    FROM td.postulations p_autre
    JOIN td.creneaux c_autre ON c_autre.id = p_autre.creneau_id
    JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
    WHERE p_autre.professeur_id = p_professeur_id
      AND p_autre.statut_validation = 'Valide'
      AND c_autre.id != p_creneau_id
      AND c_autre.date_td = c_ref.date_td
      AND c_autre.heure_debut < c_ref.heure_fin
      AND c_autre.heure_fin > c_ref.heure_debut
  ) THEN
    RAISE EXCEPTION 'Ce professeur est déjà validé sur un créneau qui chevauche celui-ci.';
  END IF;

  -- 1. Insérer ou mettre à jour la postulation du professeur choisi à "Valide"
  INSERT INTO td.postulations (creneau_id, professeur_id, statut_validation)
  VALUES (p_creneau_id, p_professeur_id, 'Valide')
  ON CONFLICT (creneau_id, professeur_id)
  DO UPDATE SET statut_validation = 'Valide';

  -- 2. Refuser les autres candidatures en attente sur ce créneau
  UPDATE td.postulations
  SET statut_validation = 'Refuse'
  WHERE creneau_id = p_creneau_id
    AND professeur_id != p_professeur_id
    AND statut_validation = 'En attente';

  -- 3. Règle A : Refuser les autres candidatures en attente de ce même professeur sur les créneaux chevauchants
  UPDATE td.postulations
  SET statut_validation = 'Refuse'
  WHERE professeur_id = p_professeur_id
    AND statut_validation = 'En attente'
    AND creneau_id IN (
      SELECT c_autre.id
      FROM td.creneaux c_autre
      JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
      WHERE c_autre.id != p_creneau_id
        AND c_autre.date_td = c_ref.date_td
        AND c_autre.heure_debut < c_ref.heure_fin
        AND c_autre.heure_fin > c_ref.heure_debut
    );

  -- 4. Clôturer le créneau
  UPDATE td.creneaux SET statut_creneau = 'cloture' WHERE id = p_creneau_id;

EXCEPTION WHEN OTHERS THEN
  RAISE;
END;
$$;


--
-- Name: arbitrer_creneau(integer, integer); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'td', 'public', 'pg_temp'
    AS $$
BEGIN
  IF (SELECT role FROM public.users WHERE id = auth.uid()) != 'coordonnateur' THEN
    RAISE EXCEPTION 'Non autorisé : réservé au coordonnateur';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM td.postulations p_autre
    JOIN td.creneaux c_autre ON c_autre.id = p_autre.creneau_id
    JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
    WHERE p_autre.professeur_id = p_professeur_id
      AND p_autre.statut_validation = 'Valide'
      AND c_autre.id != p_creneau_id
      AND c_autre.date_td = c_ref.date_td
      AND c_autre.heure_debut < c_ref.heure_fin
      AND c_autre.heure_fin > c_ref.heure_debut
  ) THEN
    RAISE EXCEPTION 'Ce professeur est déjà validé sur un créneau qui chevauche celui-ci.';
  END IF;

  UPDATE td.postulations SET statut_validation = 'Valide'
  WHERE creneau_id = p_creneau_id AND professeur_id = p_professeur_id;

  UPDATE td.postulations SET statut_validation = 'Refuse'
  WHERE creneau_id = p_creneau_id AND professeur_id != p_professeur_id
    AND statut_validation = 'En attente';

  -- Règle A : vrai chevauchement
  UPDATE td.postulations
  SET statut_validation = 'Refuse'
  WHERE professeur_id = p_professeur_id
    AND statut_validation = 'En attente'
    AND creneau_id IN (
      SELECT c_autre.id
      FROM td.creneaux c_autre
      JOIN td.creneaux c_ref ON c_ref.id = p_creneau_id
      WHERE c_autre.id != p_creneau_id
        AND c_autre.date_td = c_ref.date_td
        AND c_autre.heure_debut < c_ref.heure_fin
        AND c_autre.heure_fin > c_ref.heure_debut
    );

  UPDATE td.creneaux SET statut_creneau = 'cloture' WHERE id = p_creneau_id;

EXCEPTION WHEN OTHERS THEN
  RAISE;
END;
$$;


--
-- Name: check_max_postulations(); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.check_max_postulations() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_count integer;
begin
  if NEW.statut_validation = 'En attente' then
    select count(*) into v_count
    from td.postulations
    where creneau_id = NEW.creneau_id
      and statut_validation = 'En attente'
      and id != coalesce(NEW.id, 0);

    if v_count >= 3 then
      raise exception 'Ce créneau a déjà atteint le nombre maximal de candidatures (3).'
        using errcode = '23514';
    end if;
  end if;
  return NEW;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actualites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites (
    id integer NOT NULL,
    titre character varying(200) NOT NULL,
    categorie text NOT NULL,
    extrait text NOT NULL,
    contenu text NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    a_la_une_jusqu_au date,
    date_publication timestamp with time zone DEFAULT now() NOT NULL,
    cree_par uuid,
    CONSTRAINT actualites_categorie_check CHECK ((categorie = ANY (ARRAY['Vie scolaire'::text, 'Événement'::text, 'Réussite'::text, 'Cours'::text, 'Examens/Contrôle'::text]))),
    CONSTRAINT actualites_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publie'::text])))
);


--
-- Name: actualites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_id_seq OWNED BY public.actualites.id;


--
-- Name: actualites_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites_images (
    id integer NOT NULL,
    actualite_id integer NOT NULL,
    storage_path text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL
);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_images_id_seq OWNED BY public.actualites_images.id;


--
-- Name: annees_scolaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.annees_scolaires (
    id integer NOT NULL,
    libelle character varying(10) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'en_cours'::text NOT NULL,
    CONSTRAINT annees_scolaires_statut_check CHECK ((statut = ANY (ARRAY['en_cours'::text, 'en_pause'::text, 'terminee'::text])))
);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.annees_scolaires_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.annees_scolaires_id_seq OWNED BY public.annees_scolaires.id;


--
-- Name: categories_depenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories_depenses (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    systeme boolean DEFAULT false NOT NULL
);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_depenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_depenses_id_seq OWNED BY public.categories_depenses.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id integer NOT NULL,
    nom_classe character varying(50) NOT NULL,
    site_id integer NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    classe_suivante_id integer
);


--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: coefficients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coefficients (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    coefficient numeric(4,2) NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT coefficients_coefficient_check CHECK ((coefficient > (0)::numeric))
);


--
-- Name: coefficients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coefficients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coefficients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coefficients_id_seq OWNED BY public.coefficients.id;


--
-- Name: comptes_parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comptes_parents (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mot_de_passe text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    derniere_connexion timestamp with time zone
);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comptes_parents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comptes_parents_id_seq OWNED BY public.comptes_parents.id;


--
-- Name: decisions_passage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decisions_passage (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    decision text NOT NULL,
    nouvelle_classe_id integer,
    annee_scolaire_id integer NOT NULL,
    date_decision timestamp with time zone DEFAULT now() NOT NULL,
    decide_par uuid NOT NULL,
    CONSTRAINT decisions_passage_decision_check CHECK ((decision = ANY (ARRAY['passe'::text, 'redouble'::text, 'sortant'::text])))
);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.decisions_passage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.decisions_passage_id_seq OWNED BY public.decisions_passage.id;


--
-- Name: depenses_annexes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.depenses_annexes (
    id integer NOT NULL,
    categorie_id integer NOT NULL,
    libelle character varying(255) NOT NULL,
    montant numeric(10,2) NOT NULL,
    date_depense date NOT NULL,
    saisi_par uuid NOT NULL,
    date_saisie timestamp with time zone DEFAULT now() NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.depenses_annexes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.depenses_annexes_id_seq OWNED BY public.depenses_annexes.id;


--
-- Name: eleves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    nom character varying(100) NOT NULL,
    prenoms character varying(150) NOT NULL,
    contact_parent character varying(15),
    classe_id integer NOT NULL,
    college character varying(150) NOT NULL,
    option_m character varying(10),
    statut text DEFAULT 'actif'::text NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL,
    contact_parent_2 character varying(15),
    CONSTRAINT eleves_au_moins_un_contact CHECK (((contact_parent IS NOT NULL) OR (contact_parent_2 IS NOT NULL))),
    CONSTRAINT eleves_statut_check CHECK ((statut = ANY (ARRAY['actif'::text, 'suspendu'::text])))
);


--
-- Name: eleves_exonerations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves_exonerations (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    type_exoneration text NOT NULL,
    nombre_mois integer NOT NULL,
    mois_couverts text[] NOT NULL,
    motif text NOT NULL,
    accorde_par uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT eleves_exonerations_nombre_mois_check CHECK (((nombre_mois >= 1) AND (nombre_mois <= 8))),
    CONSTRAINT eleves_exonerations_type_exoneration_check CHECK ((type_exoneration = ANY (ARRAY['permanente'::text, 'bourse'::text])))
);


--
-- Name: eleves_exonerations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_exonerations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_exonerations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_exonerations_id_seq OWNED BY public.eleves_exonerations.id;


--
-- Name: eleves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_id_seq OWNED BY public.eleves.id;


--
-- Name: eleves_suspendus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves_suspendus (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    site_id integer NOT NULL,
    raison text NOT NULL,
    motif text NOT NULL,
    montant_du integer DEFAULT 0 NOT NULL,
    date_suspension timestamp with time zone DEFAULT now() NOT NULL,
    suspendu_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois_souscription character varying(20),
    CONSTRAINT eleves_suspendus_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[]))),
    CONSTRAINT eleves_suspendus_raison_check CHECK ((raison = ANY (ARRAY['maladie'::text, 'renvoi'::text, 'defaut_paiement'::text, 'autre'::text])))
);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_suspendus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_suspendus_id_seq OWNED BY public.eleves_suspendus.id;


--
-- Name: frais_td; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frais_td (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    montant numeric(10,2) NOT NULL
);


--
-- Name: frais_td_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frais_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frais_td_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frais_td_id_seq OWNED BY public.frais_td.id;


--
-- Name: galerie; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie (
    id integer NOT NULL,
    storage_path text NOT NULL,
    date_insertion timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie_admin (
    id integer NOT NULL,
    storage_path text NOT NULL,
    nom_fichier text NOT NULL,
    taille_octets integer,
    ajoute_par uuid NOT NULL,
    date_ajout timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_admin_id_seq OWNED BY public.galerie_admin.id;


--
-- Name: galerie_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_id_seq OWNED BY public.galerie.id;


--
-- Name: log_whatsapp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_whatsapp (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_restant integer NOT NULL,
    contact_parent character varying(25) NOT NULL,
    envoye_par uuid NOT NULL,
    date_envoi timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_whatsapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_whatsapp_id_seq OWNED BY public.log_whatsapp.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id integer NOT NULL,
    identifiant text NOT NULL,
    portail text NOT NULL,
    reussi boolean NOT NULL,
    ip inet,
    date_tentative timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT login_attempts_portail_check CHECK ((portail = ANY (ARRAY['admin'::text, 'parent'::text, 'td'::text])))
);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_attempts_id_seq OWNED BY public.login_attempts.id;


--
-- Name: matieres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matieres (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL
);


--
-- Name: matieres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matieres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matieres_id_seq OWNED BY public.matieres.id;


--
-- Name: mois_exoneres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mois_exoneres (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    motif text DEFAULT 'Absence totale durant le mois suspendu — dispense du montant dû à la réinscription'::text NOT NULL,
    exonere_par uuid NOT NULL,
    date_exoneration timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mois_exoneres_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mois_exoneres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mois_exoneres_id_seq OWNED BY public.mois_exoneres.id;


--
-- Name: moyennes_semestrielles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.moyennes_semestrielles (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    semestre smallint NOT NULL,
    moyenne_generale numeric(4,2),
    cloture_par uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT moyennes_semestrielles_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2])))
);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.moyennes_semestrielles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.moyennes_semestrielles_id_seq OWNED BY public.moyennes_semestrielles.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    matiere_id integer NOT NULL,
    type_note text NOT NULL,
    valeur numeric(4,2) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    semestre smallint DEFAULT 1 NOT NULL,
    CONSTRAINT notes_semestre_check CHECK ((semestre = ANY (ARRAY[1, 2]))),
    CONSTRAINT notes_type_note_check CHECK ((type_note = ANY (ARRAY['I1'::text, 'I2'::text, 'I3'::text, 'D1'::text, 'D2'::text, 'Ctrl'::text]))),
    CONSTRAINT notes_valeur_check CHECK (((valeur >= (0)::numeric) AND (valeur <= (20)::numeric)))
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    site_id integer NOT NULL,
    contenu text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    roles_cibles text[]
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: paiements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    enregistre_par uuid,
    CONSTRAINT paiements_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[]))),
    CONSTRAINT paiements_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: paiements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_id_seq OWNED BY public.paiements.id;


--
-- Name: paiements_supprimes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements_supprimes (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    admin_id uuid NOT NULL,
    date_suppression timestamp with time zone DEFAULT now() NOT NULL,
    motif text NOT NULL
);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_supprimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_supprimes_id_seq OWNED BY public.paiements_supprimes.id;


--
-- Name: penalites_reinscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.penalites_reinscription (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    montant integer DEFAULT 500 NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    date_paiement date NOT NULL,
    enregistre_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    CONSTRAINT penalites_reinscription_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[])))
);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.penalites_reinscription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.penalites_reinscription_id_seq OWNED BY public.penalites_reinscription.id;


--
-- Name: presences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.presences (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    date_presence date NOT NULL,
    site_id integer NOT NULL,
    classe_id integer NOT NULL,
    present boolean DEFAULT true NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: presences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.presences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: presences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.presences_id_seq OWNED BY public.presences.id;


--
-- Name: recompenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recompenses (
    id integer NOT NULL,
    note_id integer NOT NULL,
    eleve_id integer NOT NULL,
    annee_scolaire_id integer NOT NULL,
    mois character varying(20) NOT NULL,
    type_gain text NOT NULL,
    montant integer NOT NULL,
    depense_id integer,
    paye_par uuid NOT NULL,
    date_paiement date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recompenses_montant_check CHECK ((montant = ANY (ARRAY[200, 500]))),
    CONSTRAINT recompenses_type_gain_check CHECK ((type_gain = ANY (ARRAY['interro'::text, 'devoir'::text])))
);


--
-- Name: recompenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recompenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recompenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recompenses_id_seq OWNED BY public.recompenses.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    nom_site character varying(100) NOT NULL,
    initiale character(1) NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: user_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sites (
    user_id uuid NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    site_id integer,
    actif boolean DEFAULT true NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text])))
);


--
-- Name: creneaux; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.creneaux (
    id integer NOT NULL,
    semaine_id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    date_td date NOT NULL,
    heure_debut time without time zone NOT NULL,
    heure_fin time without time zone NOT NULL,
    montant_prevu numeric(10,2) DEFAULT 0 NOT NULL,
    statut_creneau text DEFAULT 'brouillon'::text NOT NULL,
    CONSTRAINT creneaux_statut_creneau_check CHECK ((statut_creneau = ANY (ARRAY['brouillon'::text, 'public'::text, 'cloture'::text])))
);


--
-- Name: creneaux_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.creneaux_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: creneaux_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.creneaux_id_seq OWNED BY td.creneaux.id;


--
-- Name: matieres_td; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.matieres_td (
    id integer NOT NULL,
    nom_matiere character varying(100) NOT NULL
);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.matieres_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_td_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.matieres_td_id_seq OWNED BY td.matieres_td.id;


--
-- Name: postulations; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.postulations (
    id integer NOT NULL,
    creneau_id integer NOT NULL,
    professeur_id integer NOT NULL,
    statut_validation text DEFAULT 'En attente'::text NOT NULL,
    date_postulation timestamp with time zone DEFAULT now() NOT NULL,
    motif_retrait text,
    CONSTRAINT postulations_statut_validation_check CHECK ((statut_validation = ANY (ARRAY['En attente'::text, 'Valide'::text, 'Refuse'::text, 'Retiree'::text])))
);


--
-- Name: postulations_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.postulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: postulations_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.postulations_id_seq OWNED BY td.postulations.id;


--
-- Name: professeurs; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.professeurs (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100) NOT NULL,
    telephone character varying(25) NOT NULL,
    email character varying(150) NOT NULL,
    mot_de_passe text NOT NULL,
    zone_id integer NOT NULL,
    matiere_principale_id integer NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL,
    valide boolean DEFAULT true NOT NULL
);


--
-- Name: professeurs_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.professeurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professeurs_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.professeurs_id_seq OWNED BY td.professeurs.id;


--
-- Name: semaines; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.semaines (
    id integer NOT NULL,
    libelle character varying(100) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    date_cloture timestamp with time zone,
    CONSTRAINT semaines_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publiee'::text, 'cloturee'::text])))
);


--
-- Name: semaines_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.semaines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semaines_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.semaines_id_seq OWNED BY td.semaines.id;


--
-- Name: zones; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.zones (
    id integer NOT NULL,
    nom_zone character varying(100) NOT NULL
);


--
-- Name: zones_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.zones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zones_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.zones_id_seq OWNED BY td.zones.id;


--
-- Name: actualites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites ALTER COLUMN id SET DEFAULT nextval('public.actualites_id_seq'::regclass);


--
-- Name: actualites_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images ALTER COLUMN id SET DEFAULT nextval('public.actualites_images_id_seq'::regclass);


--
-- Name: annees_scolaires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires ALTER COLUMN id SET DEFAULT nextval('public.annees_scolaires_id_seq'::regclass);


--
-- Name: categories_depenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses ALTER COLUMN id SET DEFAULT nextval('public.categories_depenses_id_seq'::regclass);


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: coefficients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients ALTER COLUMN id SET DEFAULT nextval('public.coefficients_id_seq'::regclass);


--
-- Name: comptes_parents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents ALTER COLUMN id SET DEFAULT nextval('public.comptes_parents_id_seq'::regclass);


--
-- Name: decisions_passage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage ALTER COLUMN id SET DEFAULT nextval('public.decisions_passage_id_seq'::regclass);


--
-- Name: depenses_annexes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes ALTER COLUMN id SET DEFAULT nextval('public.depenses_annexes_id_seq'::regclass);


--
-- Name: eleves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves ALTER COLUMN id SET DEFAULT nextval('public.eleves_id_seq'::regclass);


--
-- Name: eleves_exonerations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations ALTER COLUMN id SET DEFAULT nextval('public.eleves_exonerations_id_seq'::regclass);


--
-- Name: eleves_suspendus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus ALTER COLUMN id SET DEFAULT nextval('public.eleves_suspendus_id_seq'::regclass);


--
-- Name: frais_td id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td ALTER COLUMN id SET DEFAULT nextval('public.frais_td_id_seq'::regclass);


--
-- Name: galerie id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie ALTER COLUMN id SET DEFAULT nextval('public.galerie_id_seq'::regclass);


--
-- Name: galerie_admin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin ALTER COLUMN id SET DEFAULT nextval('public.galerie_admin_id_seq'::regclass);


--
-- Name: log_whatsapp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp ALTER COLUMN id SET DEFAULT nextval('public.log_whatsapp_id_seq'::regclass);


--
-- Name: login_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN id SET DEFAULT nextval('public.login_attempts_id_seq'::regclass);


--
-- Name: matieres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres ALTER COLUMN id SET DEFAULT nextval('public.matieres_id_seq'::regclass);


--
-- Name: mois_exoneres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres ALTER COLUMN id SET DEFAULT nextval('public.mois_exoneres_id_seq'::regclass);


--
-- Name: moyennes_semestrielles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles ALTER COLUMN id SET DEFAULT nextval('public.moyennes_semestrielles_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: paiements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements ALTER COLUMN id SET DEFAULT nextval('public.paiements_id_seq'::regclass);


--
-- Name: paiements_supprimes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes ALTER COLUMN id SET DEFAULT nextval('public.paiements_supprimes_id_seq'::regclass);


--
-- Name: penalites_reinscription id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription ALTER COLUMN id SET DEFAULT nextval('public.penalites_reinscription_id_seq'::regclass);


--
-- Name: presences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences ALTER COLUMN id SET DEFAULT nextval('public.presences_id_seq'::regclass);


--
-- Name: recompenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses ALTER COLUMN id SET DEFAULT nextval('public.recompenses_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: creneaux id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux ALTER COLUMN id SET DEFAULT nextval('td.creneaux_id_seq'::regclass);


--
-- Name: matieres_td id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td ALTER COLUMN id SET DEFAULT nextval('td.matieres_td_id_seq'::regclass);


--
-- Name: postulations id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations ALTER COLUMN id SET DEFAULT nextval('td.postulations_id_seq'::regclass);


--
-- Name: professeurs id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs ALTER COLUMN id SET DEFAULT nextval('td.professeurs_id_seq'::regclass);


--
-- Name: semaines id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines ALTER COLUMN id SET DEFAULT nextval('td.semaines_id_seq'::regclass);


--
-- Name: zones id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones ALTER COLUMN id SET DEFAULT nextval('td.zones_id_seq'::regclass);


--
-- Data for Name: actualites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites (id, titre, categorie, extrait, contenu, statut, a_la_une_jusqu_au, date_publication, cree_par) FROM stdin;
1	Démarrage des Cours Intensifs Préparatoires — Édition 2026	Cours	Le GSR lance sa nouvelle édition des Cours Intensifs Préparatoires sur ses 3 sites. Un programme pensé pour combler les lacunes et aborder la suite de l'année en confiance.	Le Groupe Secret de la Réussite ouvre officiellement sa nouvelle édition des Cours Intensifs Préparatoires, sur ses trois sites de Jéricho, Yagbé et Vèdoko. Ce programme, pensé pour la période de vacances, s'adresse à tous les élèves de la 6ème à la Terminale qui souhaitent consolider leurs acquis avant la reprise.\r\n\r\nL'objectif est simple : aborder en douceur les nouvelles notions du programme à venir. Chaque séance s'appuie sur des documents de cours structurés et des évaluations ciblées, pour que chaque élève progresse à son rythme sans se sentir dépassé.\r\n\r\nNos enseignants sont sélectionnés pour leur rigueur et leur pédagogie. Les tarifs, accessibles et adaptés à chaque niveau, sont disponibles en détail sur notre page Tarifs.\r\n\r\nLes places étant limitées sur chaque site, nous invitons les parents à inscrire rapidement leurs enfants en se rendant directement sur l'un de nos trois centres, ou en nous contactant par téléphone pour toute question sur le programme et les horaires.	publie	2026-08-22	2026-08-08 06:48:05.408897+00	\N
2	Démarrage des séances de révision BEPC 2026	Examens/Contrôle	À l'approche des examens, le GSR met en place un dispositif de révision intensif et méthodique dédié aux candidats.	À quelques mois d'une échéance décisive, le Groupe Secret de la Réussite lance ses séances de révision dédiées aux candidats au BEPC 2026. Ce dispositif vise à consolider les acquis sur l'ensemble du programme dans toutes les matières, avec un accent particulier sur les matières fondamentales : Mathématiques, PCT et SVT.\r\n\r\nLe format retenu combine rappels de cours structurés et exercices ciblés chacun suivi d'une correction méthodique en groupe. Cette approche permet à chaque candidat de mesurer précisément ses progrès et d'identifier les points qui demandent encore du travail avant le jour J.\r\n\r\nNos enseignants, habitués aux exigences de l'examen, accompagnent les élèves avec des conseils pratiques de gestion du temps et de méthodologie de rédaction, deux facteurs qui font souvent la différence le jour de l'épreuve.\r\n\r\nLes séances se déroulent sur nos sites de Jéricho et Yagbé, selon un calendrier communiqué aux familles inscrites. Pour rejoindre le dispositif ou obtenir plus d'informations, contactez-nous ou rendez-vous directement sur l'un de nos centres.	publie	\N	2026-08-01 06:48:05.408897+00	\N
3	Séance de Coaching et de Motivation des candidats aux examens 2026	Vie scolaire	Au-delà des révisions académiques, le GSR accompagne aussi ses candidats sur le plan psychologique avec une séance de coaching et de motivation.	La réussite aux examens ne se joue pas uniquement sur les connaissances académiques : la confiance en soi, la gestion du stress et la discipline personnelle jouent un rôle tout aussi déterminant. C'est dans cet esprit que le Groupe Secret de la Réussite a organisé une séance de coaching et de motivation dédiée à ses candidats aux examens 2026.\r\n\r\nAnimée par notre équipe pédagogique, cette rencontre a permis d'aborder des sujets essentiels à l'approche des épreuves : techniques de gestion du stress, organisation efficace du temps de révision, et surtout, comment garder confiance face à la pression des examens.\r\n\r\nLes élèves ont pu échanger librement sur leurs appréhensions et repartir avec des outils concrets pour aborder sereinement les semaines à venir. Cette dimension d'accompagnement humain fait partie intégrante de notre philosophie : préparer nos élèves non seulement académiquement, mais aussi mentalement, à affronter les moments décisifs de leur parcours scolaire.	publie	\N	2026-07-25 06:48:05.408897+00	\N
\.


--
-- Data for Name: actualites_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites_images (id, actualite_id, storage_path, ordre) FROM stdin;
1	1	vitrine/accueil/img_cip.jpg	0
2	2	vitrine/accueil/img_prepa.jpg	0
\.


--
-- Data for Name: annees_scolaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.annees_scolaires (id, libelle, date_debut, date_fin, statut) FROM stdin;
1	2026-2027	2026-10-01	2027-05-31	en_cours
\.


--
-- Data for Name: categories_depenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories_depenses (id, nom, systeme) FROM stdin;
1	Location Site	t
2	Paiement Prof	t
3	Fournitures	t
4	Transport	t
5	Communication	t
6	Maintenance	t
7	Frais bancaires	t
8	Autre	t
9	Récompense	f
11	Entretien	f
12	Salaire coordonnateur	f
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, nom_classe, site_id, ordre, classe_suivante_id) FROM stdin;
12	Terminale D	1	7	\N
13	6ème	2	1	14
15	4ème	2	3	16
4	3ème A	1	4	\N
17	3ème B	1	4	\N
1	6ème A	1	1	2
20	6ème B	1	1	19
2	5ème A	1	2	3
19	5ème B	1	2	18
11	Terminale C	1	7	\N
7	Première B	1	6	10
10	Terminale B	1	7	\N
22	3ème C	1	4	\N
8	Première D	1	6	12
6	Seconde C	1	5	24
24	Première C	1	6	11
23	Seconde D	1	5	8
14	5ème	2	2	15
16	3ème	2	4	\N
26	3ème D	1	4	\N
25	4ème C	1	3	26
18	4ème B	1	3	22
3	4ème A	1	3	17
27	5ème C	1	2	25
28	6ème C	1	1	27
5	Seconde B	1	5	7
\.


--
-- Data for Name: coefficients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coefficients (id, classe_id, matiere_id, coefficient, updated_at) FROM stdin;
1	1	1	1.00	2026-08-09 22:33:29.272+00
2	1	2	1.00	2026-08-09 22:33:38.434+00
3	1	3	1.00	2026-08-09 22:33:42.435+00
4	1	4	1.00	2026-08-09 22:33:50.941+00
5	1	5	1.00	2026-08-09 22:33:53.754+00
7	1	7	1.00	2026-08-09 22:34:02.071+00
11	20	1	1.00	2026-08-09 22:35:23.232+00
12	20	2	1.00	2026-08-09 22:35:26.587+00
13	20	3	1.00	2026-08-09 22:35:29.64+00
14	20	4	1.00	2026-08-09 22:35:32.733+00
15	20	5	1.00	2026-08-09 22:35:36.384+00
17	20	7	1.00	2026-08-09 22:36:21.475+00
21	2	1	1.00	2026-08-09 22:38:19.883+00
22	2	2	1.00	2026-08-09 22:38:23.389+00
23	2	3	1.00	2026-08-09 22:38:28.759+00
24	2	4	1.00	2026-08-09 22:38:33.558+00
25	2	5	1.00	2026-08-09 22:38:37.453+00
124	22	1	2.00	2026-08-20 21:47:51.364+00
29	2	7	1.00	2026-08-09 22:39:47.027+00
32	19	1	1.00	2026-08-09 22:41:11.023+00
33	19	2	1.00	2026-08-09 22:41:15.097+00
34	19	3	1.00	2026-08-09 22:41:19.274+00
35	19	4	1.00	2026-08-09 22:41:25.689+00
36	19	5	1.00	2026-08-09 22:41:29.795+00
38	19	7	1.00	2026-08-09 22:42:13.316+00
42	13	1	1.00	2026-08-09 22:43:48.04+00
43	13	2	1.00	2026-08-09 22:43:55.083+00
44	13	3	1.00	2026-08-09 22:44:00.208+00
45	13	4	1.00	2026-08-09 22:44:05.903+00
46	13	5	1.00	2026-08-09 22:44:11.06+00
47	13	6	1.00	2026-08-09 22:44:31.404+00
48	13	7	1.00	2026-08-09 22:44:42.046+00
49	13	8	1.00	2026-08-09 22:44:52.513+00
50	13	9	1.00	2026-08-09 22:45:02.407+00
51	13	10	1.00	2026-08-09 22:45:13.351+00
52	14	1	1.00	2026-08-09 22:46:19.228+00
53	14	2	1.00	2026-08-09 22:46:23.192+00
54	14	3	1.00	2026-08-09 22:46:28.257+00
55	14	4	1.00	2026-08-09 22:46:32.856+00
56	14	5	1.00	2026-08-09 22:46:37.237+00
57	14	6	1.00	2026-08-09 22:47:00.854+00
58	14	7	1.00	2026-08-09 22:47:10.978+00
59	14	8	1.00	2026-08-09 22:47:24.397+00
60	14	9	1.00	2026-08-09 22:47:35.053+00
61	14	10	1.00	2026-08-09 22:47:46.279+00
63	3	1	2.00	2026-08-09 22:57:20.66+00
64	3	2	3.00	2026-08-09 22:57:22.919+00
65	3	3	2.00	2026-08-09 22:57:25.385+00
66	3	4	2.00	2026-08-09 22:57:27.442+00
67	3	5	2.00	2026-08-09 22:57:29.779+00
69	3	7	2.00	2026-08-09 22:57:33.838+00
72	3	10	2.00	2026-08-09 22:57:40.597+00
74	1	11	1.00	2026-08-20 20:53:48.029+00
75	20	11	1.00	2026-08-20 20:58:22.005+00
76	2	11	1.00	2026-08-20 21:02:33.637+00
77	19	11	1.00	2026-08-20 21:03:58.459+00
78	3	9	2.00	2026-08-20 21:05:58.431+00
79	3	11	2.00	2026-08-20 21:06:13.081+00
80	18	1	2.00	2026-08-20 21:07:05.907+00
81	18	2	3.00	2026-08-20 21:07:12.194+00
82	18	3	2.00	2026-08-20 21:07:19.585+00
83	18	4	2.00	2026-08-20 21:07:30.287+00
84	18	5	2.00	2026-08-20 21:07:38.124+00
85	18	7	2.00	2026-08-20 21:07:47.063+00
86	18	9	2.00	2026-08-20 21:07:57.975+00
87	18	10	2.00	2026-08-20 21:08:05.342+00
88	18	11	2.00	2026-08-20 21:08:10.38+00
89	4	1	2.00	2026-08-20 21:09:54.018+00
91	4	3	2.00	2026-08-20 21:10:05.73+00
90	4	2	3.00	2026-08-20 21:10:10.801+00
93	4	4	2.00	2026-08-20 21:10:19.65+00
94	4	5	2.00	2026-08-20 21:10:37.474+00
95	4	7	2.00	2026-08-20 21:10:51.068+00
96	4	9	2.00	2026-08-20 21:10:59.718+00
97	4	10	2.00	2026-08-20 21:11:04.992+00
98	4	11	2.00	2026-08-20 21:11:10.35+00
99	17	1	2.00	2026-08-20 21:11:35.157+00
100	17	2	3.00	2026-08-20 21:11:41.091+00
101	17	3	2.00	2026-08-20 21:11:47.24+00
102	17	4	2.00	2026-08-20 21:11:54.935+00
103	17	5	2.00	2026-08-20 21:12:02.594+00
104	17	7	2.00	2026-08-20 21:12:42.877+00
105	17	11	2.00	2026-08-20 21:12:52.309+00
106	17	10	2.00	2026-08-20 21:12:57.798+00
107	17	9	2.00	2026-08-20 21:13:03.305+00
108	5	1	2.00	2026-08-20 21:16:35.619+00
109	5	6	2.00	2026-08-20 21:18:10.993+00
110	5	7	2.00	2026-08-20 21:18:47.551+00
111	5	9	2.00	2026-08-20 21:19:00.825+00
112	5	10	2.00	2026-08-20 21:19:03.931+00
113	5	8	2.00	2026-08-20 21:19:21.803+00
114	5	2	1.00	2026-08-20 21:19:44.393+00
115	5	5	1.00	2026-08-20 21:20:08.798+00
117	6	1	1.00	2026-08-20 21:23:29.97+00
118	6	3	2.00	2026-08-20 21:23:35.617+00
119	6	6	2.00	2026-08-20 21:24:11.632+00
120	6	7	1.00	2026-08-20 21:24:16.308+00
121	6	2	3.00	2026-08-20 21:25:08.492+00
122	6	4	3.00	2026-08-20 21:26:06.809+00
123	6	5	3.00	2026-08-20 21:26:11.502+00
125	22	2	3.00	2026-08-20 21:47:55.724+00
126	22	3	2.00	2026-08-20 21:48:06.475+00
127	22	4	2.00	2026-08-20 21:48:12.505+00
128	22	5	2.00	2026-08-20 21:48:19.214+00
129	22	7	2.00	2026-08-20 21:48:31.284+00
130	22	9	2.00	2026-08-20 21:48:38.832+00
131	22	10	2.00	2026-08-20 21:48:44.799+00
132	22	11	2.00	2026-08-20 21:48:52.642+00
116	5	3	2.00	2026-08-20 21:51:19.858+00
134	23	1	1.00	2026-08-20 22:46:51.427+00
135	23	3	2.00	2026-08-20 22:46:58.666+00
136	23	6	2.00	2026-08-20 22:47:16.311+00
137	23	7	1.00	2026-08-20 22:47:38.451+00
138	23	4	3.00	2026-08-20 22:48:20.759+00
139	23	5	3.00	2026-08-20 22:48:25.28+00
140	23	2	3.00	2026-08-20 22:48:33.194+00
141	8	2	4.00	2026-08-20 22:55:08.233+00
142	8	4	4.00	2026-08-20 22:55:16.977+00
143	8	5	5.00	2026-08-20 22:55:20.283+00
144	8	1	2.00	2026-08-20 22:55:33.318+00
145	8	3	2.00	2026-08-20 22:55:37.662+00
146	8	6	2.00	2026-08-20 22:55:41.973+00
147	8	7	2.00	2026-08-20 22:55:49.107+00
148	24	7	2.00	2026-08-20 22:59:21.262+00
149	24	6	2.00	2026-08-20 22:59:24.671+00
150	24	5	2.00	2026-08-20 22:59:28.71+00
151	24	4	5.00	2026-08-20 22:59:34.997+00
152	24	3	2.00	2026-08-20 22:59:39.451+00
153	24	2	5.00	2026-08-20 22:59:46.135+00
154	24	1	2.00	2026-08-20 22:59:49.919+00
155	7	10	1.00	2026-08-20 23:03:01.782+00
156	7	9	1.00	2026-08-20 23:03:26.481+00
157	7	8	4.00	2026-08-20 23:03:30.625+00
158	7	7	4.00	2026-08-20 23:03:34.118+00
159	7	6	3.00	2026-08-20 23:03:37.839+00
163	7	1	4.00	2026-08-20 23:03:56.335+00
160	7	5	2.00	2026-08-20 23:03:41.992+00
161	7	3	3.00	2026-08-20 23:03:48.955+00
162	7	2	2.00	2026-08-20 23:03:52.106+00
164	12	7	2.00	2026-08-20 23:05:03.142+00
165	12	6	2.00	2026-08-20 23:05:06.21+00
166	12	5	5.00	2026-08-20 23:05:11.855+00
167	12	4	4.00	2026-08-20 23:05:18.934+00
168	12	3	2.00	2026-08-20 23:05:22.5+00
169	12	2	4.00	2026-08-20 23:05:29.37+00
170	12	1	2.00	2026-08-20 23:05:32.335+00
171	11	7	2.00	2026-08-20 23:07:58.54+00
172	11	6	2.00	2026-08-20 23:08:02.077+00
173	11	5	2.00	2026-08-20 23:08:09.04+00
174	11	4	5.00	2026-08-20 23:08:17.229+00
175	11	3	2.00	2026-08-20 23:08:23.15+00
176	11	2	6.00	2026-08-20 23:08:27.895+00
177	11	1	2.00	2026-08-20 23:09:00.712+00
178	10	10	1.00	2026-08-20 23:11:25.359+00
179	10	9	1.00	2026-08-20 23:11:28.377+00
180	10	8	4.00	2026-08-20 23:11:33.319+00
181	10	7	4.00	2026-08-20 23:11:37.508+00
182	10	6	3.00	2026-08-20 23:11:40.834+00
183	10	5	2.00	2026-08-20 23:11:44.256+00
184	10	3	3.00	2026-08-20 23:11:52.313+00
185	10	2	2.00	2026-08-20 23:12:05.25+00
186	10	1	4.00	2026-08-20 23:12:11.515+00
\.


--
-- Data for Name: comptes_parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comptes_parents (id, matricule, mot_de_passe, date_creation, derniere_connexion) FROM stdin;
\.


--
-- Data for Name: decisions_passage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.decisions_passage (id, eleve_id, decision, nouvelle_classe_id, annee_scolaire_id, date_decision, decide_par) FROM stdin;
\.


--
-- Data for Name: depenses_annexes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.depenses_annexes (id, categorie_id, libelle, montant, date_depense, saisi_par, date_saisie, annee_scolaire_id) FROM stdin;
1	3	Papier Ram (1 Carton)	11000.00	2026-09-18	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:27:28.478041+00	1
5	8	Lampe torche (2)	6000.00	2026-09-25	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:47:04.831226+00	1
6	5	Affiche Publicitaire Grand format (2)	7200.00	2026-09-12	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:49:07.695571+00	1
7	1	Frais de site Jéricho mois d'Octobre 2026	130000.00	2026-09-30	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 11:34:43.970864+00	1
3	11	Balayage du 25 Septembre 2026	9000.00	2026-09-25	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:44:00.680196+00	1
2	11	Balayage du 18 Septembre 2026	7000.00	2026-09-18	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:31:48.482039+00	1
8	11	Balayage du 02 et du 04 Octobre 2026	13600.00	2026-10-04	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 11:39:54.479131+00	1
9	3	Papier Ram (2 paquets) + craie (1 boîte)	6200.00	2026-10-02	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 12:22:42.01093+00	1
4	5	Forfait appel Celtiis	10000.00	2026-09-14	7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	2026-09-28 07:45:00.359199+00	1
10	5	Forfait appel Celtis	5000.00	2026-10-06	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-07 07:45:26.690655+00	1
11	11	Balayage du 07 Octobre 2026	2000.00	2026-10-07	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 05:55:13.834101+00	1
12	8	Lampe torche (3)	9000.00	2026-10-07	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 12:06:30.325447+00	1
13	3	Imprimante kyocera blanc noir 	53500.00	2026-10-08	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 13:15:39.693425+00	1
14	12	Avance sur salaire (Porte chambre Gbetagbo)	56000.00	2026-10-08	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 13:18:27.683109+00	1
\.


--
-- Data for Name: eleves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves (id, matricule, nom, prenoms, contact_parent, classe_id, college, option_m, statut, date_inscription, contact_parent_2) FROM stdin;
62	J08262797	HOUESSINON	Océane	+2290195192360	1	CEG DU LAC	\N	actif	2026-08-25 20:08:51.955924+00	\N
5	J08268267	AHOTON	Aristide	+2290199245666	1	CEG DU LAC	\N	actif	2026-08-25 20:08:13.202517+00	\N
7	J08267548	ALI KPONOU	Barnabé	+2290149231863	1	CEG DU LAC	\N	actif	2026-08-25 20:08:14.629668+00	\N
8	J08263106	AMOUSSOU	Angéline Tété	+2290147001102	1	CEG DU LAC	\N	actif	2026-08-25 20:08:15.145837+00	\N
10	J08264473	BONOU	Andréa	+2290167569601	1	CEG DU LAC	\N	actif	2026-08-25 20:08:16.409862+00	\N
11	J08267444	BOUSSARI	Aemane	+2290197832325	1	CEG DU LAC	\N	actif	2026-08-25 20:08:16.849956+00	\N
12	J08268911	DANNOUDO	Belvine	+2290197149708	1	CEG DU LAC	\N	actif	2026-08-25 20:08:17.309641+00	\N
15	J08261500	DEGBO	Abel	+2290169008428	1	CEG DU LAC	\N	actif	2026-08-25 20:08:23.804393+00	\N
16	J08264569	DJOHA	Fridaouce	+2290144989378	1	CEG DU LAC	\N	actif	2026-08-25 20:08:24.29167+00	\N
20	J08262550	HAROUNA	Hamza	+2290161360409	1	CEG DU LAC	\N	actif	2026-08-25 20:08:27.76559+00	\N
21	J08264212	HASSANE	Abdoul Razack	+2290196124155	1	CEG DU LAC	\N	actif	2026-08-25 20:08:28.782043+00	\N
26	J08264348	HOUNGBO	Kafui Belle	+2290161958178	1	CEG DU LAC	\N	actif	2026-08-25 20:08:33.099597+00	\N
29	J08269137	KOUKPAKI	Habiguel	+2290147104032	1	CEG DU LAC	\N	actif	2026-08-25 20:08:34.966879+00	\N
30	J08267246	KPLAKOTCHA	Bignon Pascaline	+2290197161718	1	CEG DU LAC	\N	actif	2026-08-25 20:08:35.393318+00	\N
31	J08269413	OLOUGBADE	Fèmi Ruthe	+2290166234656	1	CEG DU LAC	\N	actif	2026-08-25 20:08:35.850566+00	\N
34	J08267043	TOSSAVI	Eurielle	+2290196145763	1	CEG DU LAC	\N	actif	2026-08-25 20:08:37.573351+00	\N
37	J08265784	ZANNOU	Charles	+2290197833912	1	CEG DU LAC	\N	actif	2026-08-25 20:08:38.913405+00	\N
41	J08268546	AFFO	Régina	+2290197618574	1	CEG DU LAC	\N	actif	2026-08-25 20:08:40.957883+00	\N
42	J08268517	AGOSSOU	Diane Christiane	+2290197860677	1	CEG DU LAC	\N	actif	2026-08-25 20:08:41.492241+00	\N
43	J08263823	AHEHEHINNOU	Princesse	+2290143979537	1	CEG DU LAC	\N	actif	2026-08-25 20:08:42.640039+00	\N
48	J08267893	ALLOSSE	Merveil	+2290166027811	1	CEG DU LAC	\N	actif	2026-08-25 20:08:45.350018+00	\N
49	J08264584	AWAZE	Rosalie	+2290197939840	1	CEG DU LAC	\N	actif	2026-08-25 20:08:45.778327+00	\N
51	J08269366	BALA	Nabil	+2290140357078	1	CEG DU LAC	\N	actif	2026-08-25 20:08:46.59036+00	\N
52	J08262516	BOUKARI	Majoie	+2290196915692	1	CEG DU LAC	\N	actif	2026-08-25 20:08:47.016333+00	\N
53	J08262940	CHOGOLOU	Naomie	+2290195319539	1	CEG DU LAC	\N	actif	2026-08-25 20:08:47.65703+00	\N
55	J08265035	DAGA	Ella	+2290157527662	1	CEG DU LAC	\N	actif	2026-08-25 20:08:48.755396+00	\N
56	J08267543	DELE	Astride	+2290196144429	1	CEG DU LAC	\N	actif	2026-08-25 20:08:49.188918+00	\N
57	J08268114	DENAKPO	Samuel	+2290196009792	1	CEG DU LAC	\N	actif	2026-08-25 20:08:49.731717+00	\N
58	J08268391	DOUDJI	Thierry	+2290166237408	1	CEG DU LAC	\N	actif	2026-08-25 20:08:50.188168+00	\N
64	J08269872	HOUNDO	Urbain	+2290163357881	1	CEG DU LAC	\N	actif	2026-08-25 20:08:53.094261+00	\N
66	J08262719	HOUNGA	Romuald	+2290157606352	1	CEG DU LAC	\N	actif	2026-08-25 20:08:54.143593+00	\N
68	J08264253	HOUNNOU	Rachelle Fèmi	+2290140577316	1	CEG DU LAC	\N	actif	2026-08-25 20:08:55.004408+00	\N
69	J08269764	HONFOGA	Juliette	+2290197338328	1	CEG DU LAC	\N	actif	2026-08-25 20:08:55.537954+00	\N
19	J08264361	GODONOU	Gloria Merveille	+2290197328732	1	CEG DU LAC	\N	actif	2026-08-25 20:08:26.430749+00	+2290164785458
3	J08268022	ADANMAHO	Ruth	+2290141428811	28	CEG DU LAC	\N	actif	2026-08-25 20:08:12.287334+00	\N
23	J08268178	HOUADJETO	Rose	+2290148152298	28	CEG DU LAC	\N	actif	2026-08-25 20:08:31.134829+00	\N
24	J08265291	HOUADJETO	Jéhovany	+2290197766388	28	CEG DU LAC	\N	actif	2026-08-25 20:08:32.219574+00	\N
25	J08264295	HOUESSOU	Prince	+2290196044502	28	CEG DU LAC	\N	actif	2026-08-25 20:08:32.667205+00	\N
39	J08263259	ADEYEMON	Alphé	+2290197327899	28	CEG DU LAC	\N	actif	2026-08-25 20:08:39.817428+00	\N
35	J08265282	TRAORE	Azizé	+2290140629303	28	CEG DU LAC	\N	actif	2026-08-25 20:08:38.005556+00	\N
38	J08267089	ZINHO	Edwige	+2290196965912	28	CEG DU LAC	\N	actif	2026-08-25 20:08:39.362039+00	\N
44	J08263759	AKINOCHO	Espérancia	+2290196820635	28	CEG DU LAC	\N	actif	2026-08-25 20:08:43.37113+00	\N
50	J08268975	AZOUASSI	Arielle	+2290194666556	28	CEG DU LAC	\N	actif	2026-08-25 20:08:46.181513+00	\N
54	J08266460	COUMASSOU	Fifamè	+2290197080003	28	CEG DU LAC	\N	actif	2026-08-25 20:08:48.334516+00	\N
60	J08268706	GNONLONFOUN	Majoie	+2290197117984	28	CEG DU LAC	\N	actif	2026-08-25 20:08:50.997934+00	\N
61	J08269126	HESSOU	Inès	+2290192279414	28	CEG DU LAC	\N	actif	2026-08-25 20:08:51.552828+00	\N
65	J08266301	HOUNGBEDJI	Christian	+2290159951859	28	CEG DU LAC	\N	actif	2026-08-25 20:08:53.52506+00	\N
67	J08264399	HOUNGBO	Emannuel	+2290166552204	28	CEG DU LAC	\N	actif	2026-08-25 20:08:54.584899+00	\N
70	J08263486	IMOROU	Arafat	+2290197690110	28	CEG DU LAC	\N	actif	2026-08-25 20:08:56.184621+00	\N
33	J08264309	THON	Elians	+2290142323537	1	CEG DU LAC	\N	actif	2026-08-25 20:08:36.961589+00	\N
40	J08266080	ADJOVI	Gilles-Christ	+2290197987658	28	CEG DU LAC	\N	actif	2026-08-25 20:08:40.498962+00	\N
4	J08262268	AGOSSOU	Gael	+2290192174008	28	CEG DU LAC	\N	actif	2026-08-25 20:08:12.750321+00	\N
6	J08261730	AHOUANDJINOU	Mitricia	+2290166458411	28	CEG DU LAC	\N	actif	2026-08-25 20:08:13.849166+00	\N
45	J08264362	ALANGBOKINTO	Christ-fort	+2290152241099	28	CEG DU LAC	\N	actif	2026-08-25 20:08:43.822812+00	\N
47	J08265636	ALOSSE	Mahutin	+2290144225320	28	CEG DU LAC	\N	actif	2026-08-25 20:08:44.716053+00	\N
9	J08263536	BODJOSSOU	Chimène	+2290160623544	28	CEG DU LAC	\N	actif	2026-08-25 20:08:15.816509+00	\N
13	J08266999	DANNOUDO	Joanita	+2290151510388	28	CEG DU LAC	\N	actif	2026-08-25 20:08:18.070132+00	\N
14	J08262951	DANSOU	René	+2290197301151	28	CEG DU LAC	\N	actif	2026-08-25 20:08:21.971968+00	\N
17	J08262766	EDIBO	Haidou	+2290148069124	28	CEG DU LAC	\N	actif	2026-08-25 20:08:24.716298+00	\N
59	J08266111	GNONLONFOUN	Elisabeth	+2290166696627	28	CEG DU LAC	\N	actif	2026-08-25 20:08:50.585842+00	\N
22	J08262551	HONVOU	Josué Norbert	+2290166095595	28	CEG DU LAC	\N	actif	2026-08-25 20:08:30.227764+00	\N
63	J08262289	HOUESSOU	Brice	+2290143868500	28	CEG DU LAC	\N	actif	2026-08-25 20:08:52.590268+00	\N
27	J08268757	HOUNGBO	Urielle	+2290161958178	28	CEG DU LAC	\N	actif	2026-08-25 20:08:33.817155+00	\N
28	J08262703	HOUNSOU	Béni	+2290197166900	28	CEG DU LAC	\N	actif	2026-08-25 20:08:34.488511+00	\N
36	J08263772	YEHOUENOU	Elisabeth	+2290196357947	28	CEG DU LAC	\N	actif	2026-08-25 20:08:38.477267+00	\N
32	J08269042	SIMENOU	M. Jérôme	+2290166098259	20	CEG DU LAC	\N	actif	2026-08-25 20:08:36.525755+00	\N
71	J08268667	KEITA	Aminata	+2290197314371	1	CEG DU LAC	\N	actif	2026-08-25 20:08:57.16069+00	\N
77	J08265783	KPODJI	Néhémie	+2290167221243	1	CEG DU LAC	\N	actif	2026-08-25 20:09:04.385038+00	\N
84	J08264180	TCHEWENOU	Arsène	+2290166035605	1	CEG DU LAC	\N	actif	2026-08-25 20:09:10.199278+00	\N
73	J08261761	KOUMA	Patricia	+2290196285600	28	CEG DU LAC	\N	actif	2026-08-25 20:08:58.480465+00	\N
80	J08264530	QUENUM	Wahib	+2290167156231	28	CEG DU LAC	\N	actif	2026-08-25 20:09:06.597571+00	\N
82	J08265267	SOUNOUVOU	Christophe	+2290153841388	28	CEG DU LAC	\N	actif	2026-08-25 20:09:08.191075+00	\N
75	J08262583	NASSARA	Firmin Tobias	+2290197746868	28	CEG DU LAC	\N	actif	2026-08-25 20:09:02.918057+00	\N
72	J08267215	KODJO	Abdiel	+2290197984238	1	CEG DU LAC	\N	actif	2026-08-25 20:08:57.791864+00	\N
78	J08268262	OKE	Henriette	+2290197442195	1	CEG DU LAC	\N	actif	2026-08-25 20:09:05.120007+00	\N
81	J08268561	RADJI	Raoudath	+2290196789444	1	CEG DU LAC	\N	actif	2026-08-25 20:09:07.022291+00	\N
87	J08264552	HOUNGBO	Delphin	+2290196688515	20	CEG DU LAC	\N	actif	2026-08-25 20:15:08.675427+00	\N
95	J08269363	ADOUNVO	Jennifer	+2290197594007	20	CEG DU LAC	\N	actif	2026-08-25 20:15:13.188926+00	\N
96	J08263763	AGBODJINOU	Mariale	+2290167663696	20	CEG DU LAC	\N	actif	2026-08-25 20:15:13.647296+00	\N
97	J08268080	AGOSSOU	Emmanuella Théodora	+2290197055133	20	CEG DU LAC	\N	actif	2026-08-25 20:15:14.205934+00	\N
98	J08267514	AGUEGUE	Osée	+2290195781077	20	CEG DU LAC	\N	actif	2026-08-25 20:15:14.878921+00	\N
99	J08262485	AHOUMENOU	Jephte	+2290154559145	20	CEG DU LAC	\N	actif	2026-08-25 20:15:15.538523+00	\N
103	J08267273	AMADOU	Yasmine	+2290154066389	20	CEG DU LAC	\N	actif	2026-08-25 20:15:18.87951+00	\N
105	J08263579	AZOGA	Ibrahim Prince	+2290197589978	20	CEG DU LAC	\N	actif	2026-08-25 20:15:20.660217+00	\N
111	J08265923	DEDEWANOU	Antoine Karl	+2290166035959	20	CEG DU LAC	\N	actif	2026-08-25 20:15:30.321026+00	\N
113	J08264655	FANOU	Daniel	+2290197476899	20	CEG DU LAC	\N	actif	2026-08-25 20:15:35.193329+00	\N
115	J08268220	GANTIN	Sandrine	+2290166752832	20	CEG DU LAC	\N	actif	2026-08-25 20:15:37.004969+00	\N
116	J08265269	GANTIN	Jean Marie Vianney	+2290166752832	20	CEG DU LAC	\N	actif	2026-08-25 20:15:38.133241+00	\N
125	J08261749	IBRAHIM	Moustékim	+2290197125758	20	CEG DU LAC	\N	actif	2026-08-25 20:15:46.741241+00	\N
126	J08261886	KINTOKONOU	Miracle	+2290167580440	20	CEG DU LAC	\N	actif	2026-08-25 20:15:47.647946+00	\N
127	J08264575	KONGNON	Délia	+2290197735776	20	CEG DU LAC	\N	actif	2026-08-25 20:15:48.490539+00	\N
128	J08265578	KOUNNI	Ferdinand	+2290161714247	20	CEG DU LAC	\N	actif	2026-08-25 20:15:49.298866+00	\N
135	J08269085	NOUHOU	Abdoul Malick	+2290153544001	20	CEG DU LAC	\N	actif	2026-08-25 20:15:52.848805+00	\N
137	J08265347	OSSE	Rodiath	+2290196214481	20	CEG DU LAC	\N	actif	2026-08-25 20:15:54.922733+00	\N
141	J08265266	TCHOUTCHOU	Julien	+2290197640248	20	CEG DU LAC	\N	actif	2026-08-25 20:15:57.638412+00	\N
142	J08268635	VODOUNON	Abigael	+2290161473452	20	CEG DU LAC	\N	actif	2026-08-25 20:15:58.139998+00	\N
74	J08262790	MEGNIZIN	Melvine	+2290151005574	28	CEG DU LAC	\N	actif	2026-08-25 20:09:02.392539+00	\N
76	J08264701	NASSARA	Augustin	+2290197746868	28	CEG DU LAC	\N	actif	2026-08-25 20:09:03.943786+00	\N
85	J08269178	AMEVONOUKE	Maeva	+2290197615288	1	CEG DU LAC	\N	actif	2026-08-25 20:15:07.072103+00	\N
83	J08263178	SOVIGUIDI	Nadège	+2290166292136	28	CEG DU LAC	\N	actif	2026-08-25 20:09:08.96418+00	\N
104	J08261768	AYIVODJI	Bernice	+2290197956392	1	CEG DU LAC	\N	actif	2026-08-25 20:15:19.351894+00	\N
88	J08264951	NOUGBODJI	Chantale	+2290167025464	28	CEG DU LAC	\N	actif	2026-08-25 20:15:09.297982+00	\N
90	J08268492	ABDOULAYE	Anas	+2290162900495	28	CEG DU LAC	\N	actif	2026-08-25 20:15:10.277646+00	\N
91	J08262251	ADAM	Hamirath	+2290140582104	28	CEG DU LAC	\N	actif	2026-08-25 20:15:10.754545+00	\N
94	J08266648	ADONON	Agathe	+2290147881027	28	CEG DU LAC	\N	actif	2026-08-25 20:15:12.762012+00	\N
102	J08264234	AKOWE	Roméo	+2290162049568	28	CEG DU LAC	\N	actif	2026-08-25 20:15:17.583852+00	\N
106	J08269030	BEAHENOU	Luchrist	+2290197728001	28	CEG DU LAC	\N	actif	2026-08-25 20:15:21.360524+00	\N
107	J08265020	BONI	Gloire	+2290196012335	28	CEG DU LAC	\N	actif	2026-08-25 20:15:23.150309+00	\N
108	J08261340	CHOGOLOU	Géovani	+2290166767956	28	CEG DU LAC	\N	actif	2026-08-25 20:15:24.901272+00	\N
109	J08268419	DAVI	Elysée	+2290162810417	28	CEG DU LAC	\N	actif	2026-08-25 20:15:27.614585+00	\N
110	J08262136	DANSOU	Constantin	+2290160321132	28	CEG DU LAC	\N	actif	2026-08-25 20:15:29.896947+00	\N
112	J08269531	DIAWARA	Aicha	+2290151013401	28	CEG DU LAC	\N	actif	2026-08-25 20:15:31.239653+00	\N
114	J08261370	GANDJI	Donald	+2290197271442	28	CEG DU LAC	\N	actif	2026-08-25 20:15:36.577634+00	\N
117	J08263929	GBETCHOEVI	Ornela	+2290162892348	28	CEG DU LAC	\N	actif	2026-08-25 20:15:39.912646+00	\N
119	J08263073	GNITABOU	Pierrette	+2290168614988	28	CEG DU LAC	\N	actif	2026-08-25 20:15:41.281183+00	\N
121	J08265639	HOUENOU	Chrismel	+2290195261961	28	CEG DU LAC	\N	actif	2026-08-25 20:15:43.839733+00	\N
120	J08262823	HONFO	Irène	+2290197278334	20	CEG DU LAC	\N	actif	2026-08-25 20:15:42.182296+00	\N
122	J08268864	HOUNGUE	Huguette	+2290140594592	28	CEG DU LAC	\N	actif	2026-08-25 20:15:44.976962+00	\N
123	J08262013	HOUNGUIEVI	Firmin	+2290140594592	28	CEG DU LAC	\N	actif	2026-08-25 20:15:45.713205+00	\N
130	J08264113	LINDE	Houeffa	+2290196847244	28	CEG DU LAC	\N	actif	2026-08-25 20:15:50.43672+00	\N
100	J08269537	AHOUSSINOU	Ariane	+2290197419771	20	CEG OKOUN SEME	\N	actif	2026-08-25 20:15:16.172653+00	\N
132	J08264738	MONNOU	Mariam	+2290197523980	28	CEG DU LAC	\N	actif	2026-08-25 20:15:51.315888+00	\N
79	J08266095	OTCHRAN	Micheline	+2290197695346	1	CEG DU LAC	\N	actif	2026-08-25 20:09:05.686255+00	\N
134	J08265457	MOUTAIROU	Sékinath	+2290197258357	28	CEG DU LAC	\N	actif	2026-08-25 20:15:52.410892+00	\N
136	J08268253	ODOUTAN	Florent	+2290196490961	28	CEG DU LAC	\N	actif	2026-08-25 20:15:53.892276+00	\N
138	J08263689	OUSSA	Soubela	+2290197673649	28	CEG DU LAC	\N	actif	2026-08-25 20:15:55.421293+00	\N
139	J08262611	SODEDJI	Florence	+2290147795712	28	CEG DU LAC	\N	actif	2026-08-25 20:15:56.055523+00	\N
140	J08268798	SOKE	Elisée	+2290197278334	28	CEG DU LAC	\N	actif	2026-08-25 20:15:56.771367+00	\N
144	J08264158	ZANNOU	Hervé	+2290197327392	28	CEG DU LAC	\N	actif	2026-08-25 20:15:59.908548+00	\N
133	J08265910	MOUSSA	Souraimou	+2290196097248	1	CEG DU LAC	\N	actif	2026-08-25 20:15:51.779213+00	\N
131	J08261580	MEGNIHA	Darius	+2290197323982	1	CEG DU LAC	\N	actif	2026-08-25 20:15:50.8644+00	\N
101	J08267211	AHOUSSINOU	Trésora	+2290197419771	20	CEG OKOUN SEME	\N	actif	2026-08-25 20:15:16.629155+00	\N
92	J08268011	ADAN	Ginette	+2290162787297	28	CEG DU LAC	\N	actif	2026-08-25 20:15:11.682561+00	\N
93	J08264206	ADINGNI	Espoir	+2290140356215	28	CEG DU LAC	\N	actif	2026-08-25 20:15:12.342674+00	\N
86	J08264120	COSSE	Florentine	+2290144160724	28	CEG DU LAC	\N	actif	2026-08-25 20:15:07.837595+00	\N
118	J08268290	GNANSOUNOU	Angelo	+2290147468030	28	CEG DU LAC	\N	actif	2026-08-25 20:15:40.531851+00	\N
129	J08262492	LATEDJOU	Arafat	+2290166522471	28	CEG DU LAC	\N	actif	2026-08-25 20:15:50.007937+00	\N
143	J08262675	VOITAN	Mirabelle	+2290191122266	28	CEG DU LAC	\N	actif	2026-08-25 20:15:59.165779+00	\N
145	J08269788	ZOUNDJIEKPON	Clément	+2290157571197	28	CEG DU LAC	\N	actif	2026-08-25 20:16:00.345965+00	\N
146	J08267193	ADANDE	Fifamè	+2290147278817	27	CEG DU LAC	\N	actif	2026-08-25 20:17:53.410659+00	\N
147	J08268357	AGBO	Bénédicte	+2290166637510	2	CEG DU LAC	\N	actif	2026-08-25 20:17:54.054576+00	\N
151	J08265785	AGOSSOU	Victorine	+2290167476339	2	CEG DU LAC	\N	actif	2026-08-25 20:17:55.946261+00	\N
153	J08266287	AKPO	Mirabelle	+2290197312358	2	CEG DU LAC	\N	actif	2026-08-25 20:17:57.307348+00	\N
157	J08266313	COUMASSOU	Prince	+2290197080003	2	CEG DU LAC	\N	actif	2026-08-25 20:17:59.305607+00	\N
165	J08261302	GNANMLIN	Miracle	+2290190467078	2	CEG DU LAC	\N	actif	2026-08-25 20:18:08.05419+00	\N
167	J08262389	HINVI	Ziad	+2290197037460	2	CEG DU LAC	\N	actif	2026-08-25 20:18:09.138801+00	\N
173	J08269254	KOULIHO	Esther	+2290197255177	2	CEG DU LAC	\N	actif	2026-08-25 20:18:12.453726+00	\N
177	J08265692	MOUSSA	Housna	+2290197349831	2	CEG STE RITA	\N	actif	2026-08-25 20:18:14.80965+00	\N
179	J08268326	OLADELE	Mukaram	+2290196527675	2	CEG DU LAC	\N	actif	2026-08-25 20:18:16.453348+00	\N
187	J08267645	YEDIYETON	Bénoit	+2290161997615	2	CEG DU LAC	\N	actif	2026-08-25 20:18:27.07848+00	\N
189	J08266477	ZOUMENOU	Kenneth	+2290166767937	2	LA RÉFÉRENCE	\N	actif	2026-08-25 20:18:28.651564+00	\N
149	J08263105	AGOGNON	Junior	+2290162795215	27	CEG DU LAC	\N	actif	2026-08-25 20:17:54.987945+00	\N
155	J08263879	ATCHONDE	Fednand	+2290196610899	27	CEG SURU LÉRÉ	\N	actif	2026-08-25 20:17:58.426979+00	\N
159	J08266153	DE CAMPOS	Lionel	+2290197195343	27	CEG STE RITA	\N	actif	2026-08-25 20:18:00.330067+00	\N
161	J08263996	DJOTCHOU	Arnaud	+2290152240834	27	CEG DU LAC	\N	actif	2026-08-25 20:18:03.104742+00	\N
163	J08265816	FOHOU	Eunice	+2290167066737	27	CEG DU LAC	\N	actif	2026-08-25 20:18:06.996572+00	\N
169	J08265404	HOUNSOU	Grâce	+2290197166900	27	CEG STE RITA	\N	actif	2026-08-25 20:18:09.95982+00	\N
171	J08269582	KABADE	Doreil	+2290145287197	27	CEG DU LAC	\N	actif	2026-08-25 20:18:11.092859+00	\N
175	J08262887	LAWANI	Nourou Dine	+2290160472979	27	PAVELO MISÉRICORDE	\N	actif	2026-08-25 20:18:13.355407+00	\N
181	J08263282	PADONOU	Chancelle	+2290151901775	27	CEG DU LAC	\N	actif	2026-08-25 20:18:17.3188+00	\N
183	J08264312	SEDJRO	Abiba Fifamè	+2290158395794	27	CEG STE RITA	\N	actif	2026-08-25 20:18:20.561534+00	\N
185	J08263674	TIDJANI	Imraan	+2290197146509	27	LA RÉFÉRENCE	\N	actif	2026-08-25 20:18:22.894576+00	\N
148	J08261306	AGLI	Marie Grâce	+2290196727958	2	CEG DU LAC	\N	actif	2026-08-25 20:17:54.508992+00	\N
150	J08262276	AGOSSOU	Lorice	+2290197860677	2	CEG DU LAC	\N	actif	2026-08-25 20:17:55.462522+00	\N
152	J08269605	AHISSOU	Exaucé	+2290197826116	2	CEG DU LAC	\N	actif	2026-08-25 20:17:56.653392+00	\N
156	J08262999	AYONOU	Samuel	+2290166901887	2	CEG DU LAC	\N	actif	2026-08-25 20:17:58.840807+00	\N
158	J08269052	DANSI-GAH	Sèdjro Assuerus	+2290197261814	2	CEG DANTOKPA	\N	actif	2026-08-25 20:17:59.923184+00	\N
162	J08268276	DOSSA	Ifè Edwige M.	+2290196610899	2	CEG DU LAC	\N	actif	2026-08-25 20:18:04.591692+00	\N
164	J08266507	GBAMMADO	Marie Guillaumine	+2290197226046	2	CEG DU LAC	\N	actif	2026-08-25 20:18:07.439743+00	\N
166	J08266025	GOUNFLE	Fréjuste	+2290169685526	2	CEG DU LAC	\N	actif	2026-08-25 20:18:08.705773+00	\N
168	J08265768	HOUETCHOU	Boris	+2290166765769	2	CEG DU LAC	\N	actif	2026-08-25 20:18:09.536271+00	\N
174	J08267855	KPIKPONSOUHOU	Chérif	+2290157369995	2	CEG DANTOKPA	\N	actif	2026-08-25 20:18:12.914535+00	\N
176	J08267340	MIGNONTODE	Flora	+2290197217601	2	CEG DU LAC	\N	actif	2026-08-25 20:18:13.815287+00	\N
178	J08261650	NANDANAN	Harvey	+2290166759633	2	CEG DU LAC	\N	actif	2026-08-25 20:18:15.636598+00	\N
180	J08269233	OLOUGBADE	Anne Yémissi	+2290166234656	2	CEG STE RITA	\N	actif	2026-08-25 20:18:16.872952+00	\N
184	J08265037	SOUNOUVO	Exaucé Nadège	+2290190182835	2	CEG DU LAC	\N	actif	2026-08-25 20:18:22.432022+00	\N
186	J08267188	TOSSA	Kasmi	+2290145408425	2	CEG DU LAC	\N	actif	2026-08-25 20:18:25.753843+00	\N
188	J08262689	YESSOUFOU	Ambidath	+2290196757912	2	CEG DU LAC	\N	actif	2026-08-25 20:18:28.21583+00	\N
190	J08269360	ADJIWANOU	Gérade	+2290195506360	19	CEG DU LAC	\N	actif	2026-08-25 20:21:06.754093+00	\N
191	J08264547	AGBO ZINSOU	Anick	+2290166011707	19	CEG DU LAC	\N	actif	2026-08-25 20:21:08.054005+00	\N
192	J08265248	AGLO-HOUNGA	Fèmi	+2290196927722	19	CEG DU LAC	\N	actif	2026-08-25 20:21:08.530436+00	\N
193	J08263232	AGOGNON	Légende	+2290166775177	19	CEG DU LAC	\N	actif	2026-08-25 20:21:09.043323+00	\N
194	J08263499	AGOSSOU	Victoria	+2290167476339	19	CEG DU LAC	\N	actif	2026-08-25 20:21:09.554304+00	\N
196	J08263082	AHOUHENOU	Trésor	+2290148501864	19	CEG DU LAC	\N	actif	2026-08-25 20:21:10.794834+00	\N
197	J08267899	AKPOVI	Freshnelle	+2290167801676	19	CEG STE RITA	\N	actif	2026-08-25 20:21:11.217474+00	\N
198	J08264964	ARIORI	Sagesse	+2290197893687	19	CEG DU LAC	\N	actif	2026-08-25 20:21:11.762538+00	\N
200	J08263509	BOTON FATCHE	Etienne	+2290165566653	19	CEG DU LAC	\N	actif	2026-08-25 20:21:13.991351+00	\N
201	J08263520	DAGA	Rosalma	+2290157527662	19	CEG STE RITA	\N	actif	2026-08-25 20:21:15.344264+00	\N
202	J08266547	DA SILVA	Peace Joy	+2290197379738	19	CEG STE RITA	\N	actif	2026-08-25 20:21:16.923281+00	\N
203	J08266148	DEGBOGBAHOUN	Aldonie	+2290196315585	19	CEG DU LAC	\N	actif	2026-08-25 20:21:17.358207+00	\N
204	J08265241	DJIGBE	Bernadin	+2290147278964	19	CEG DU LAC	\N	actif	2026-08-25 20:21:18.399457+00	\N
206	J08269627	DOSSOU	Urielle Alfreda	+2290166889076	19	CEG DU LAC	\N	actif	2026-08-25 20:21:19.96175+00	\N
207	J08264321	GANHOUNOUTO	Marie Thérèse	+2290196125479	19	CEG DU LAC	\N	actif	2026-08-25 20:21:20.392061+00	\N
208	J08261310	GLELE	David Junior	+2290167077126	19	CEG DU LAC	\N	actif	2026-08-25 20:21:20.883773+00	\N
209	J08266177	GOUGBE	Yvette	+2290167258787	19	CEG DU LAC	\N	actif	2026-08-25 20:21:21.38959+00	\N
210	J08268159	GUELIFO	Romuald	+2290197866174	19	CEG STE RITA	\N	actif	2026-08-25 20:21:21.8343+00	\N
212	J08266932	HOUNSOU	Adéline	+2290197029777	19	CEG STE RITA	\N	actif	2026-08-25 20:21:22.72532+00	\N
214	J08263025	IBRAHIM	Mohamed	+2290153547976	19	CEG DU LAC	\N	actif	2026-08-25 20:21:23.746714+00	\N
215	J08265764	KODJO	Abimael	+2290197984238	19	SAINT MICHEL	\N	actif	2026-08-25 20:21:24.190851+00	\N
216	J08268081	KOUTON	Dorcas Mahugnon	+2290155414875	19	CEG DU LAC	\N	actif	2026-08-25 20:21:24.669724+00	\N
217	J08268611	LAHADE	Christelle	+2290196803007	19	CEG DU LAC	\N	actif	2026-08-25 20:21:25.075425+00	\N
218	J08265895	MEGOTIN	Inecia Gloria	+2290197610834	19	CEG STE RITA	\N	actif	2026-08-25 20:21:25.725845+00	\N
219	J08266524	MUIDEEN	Adidjathou	+2290147346708	19	CEG STE RITA	\N	actif	2026-08-25 20:21:26.118675+00	\N
221	J08263831	NOUVOESSI	Fortuné T.	+2290197084300	19	CEG DU LAC	\N	actif	2026-08-25 20:21:26.941801+00	\N
222	J08263037	OLAWOMI	Anne marie	+2290151517544	19	CEG DU LAC	\N	actif	2026-08-25 20:21:27.591132+00	\N
224	J08262449	SAGBO	Exaucé	+2290197779418	19	CEG ZOGBO	\N	actif	2026-08-25 20:21:28.438895+00	\N
225	J08263366	SAVIAKO	Achille	+2290194576237	19	CEG DU LAC	\N	actif	2026-08-25 20:21:28.871734+00	\N
226	J08265047	SOTON	Williams	+2290169193199	19	CEG DU LAC	\N	actif	2026-08-25 20:21:29.285542+00	\N
227	J08262359	SOUNOUVO	Ezéchiel	+2290166119513	19	CEG DANTOKPA	\N	actif	2026-08-25 20:21:29.705505+00	\N
231	J08267962	YESSOUFOU	Himayath	+2290157577890	19	CEG DU LAC	\N	actif	2026-08-25 20:21:32.536467+00	\N
232	J08269533	YEVO EDO	Bénédicte	+2290191311563	19	CEG DU LAC	\N	actif	2026-08-25 20:21:32.964158+00	\N
233	J08264376	ZOUNDJI	Inès	+2290143799412	19	CEG DU LAC	\N	actif	2026-08-25 20:21:33.790518+00	\N
195	J08268059	AGUE	Dolorès	+2290169473256	27	CEG DU LAC	\N	actif	2026-08-25 20:21:10.326029+00	\N
237	J08262029	AHOUAGA	Fabrice	+2290197187377	25	CEG STE RITA	\N	actif	2026-08-25 20:23:12.851788+00	\N
235	J08269590	ADJOVI	Dylane	+2290197987658	25	CEG DU LAC	\N	actif	2026-08-25 20:23:11.768278+00	\N
236	J08261424	AGONYE	Monique	+2290144025590	25	CEG DU LAC	\N	actif	2026-08-25 20:23:12.428888+00	\N
199	J08264845	ATEDJI	Fernand	+2290166524763	27	CEG DU LAC	\N	actif	2026-08-25 20:21:13.439039+00	\N
205	J08266725	DJOWADAN	Christine	+2290169802591	27	CEG DU LAC	\N	actif	2026-08-25 20:21:19.342817+00	\N
211	J08263744	HOUENOU	Abdias	+2290166288729	27	LA RÉFÉRENCE	\N	actif	2026-08-25 20:21:22.237327+00	\N
213	J08264360	HOYETON	Daniel	+2290191394417	27	CEG DU LAC	\N	actif	2026-08-25 20:21:23.347821+00	\N
220	J08267191	MOUKAILA	Adidjath	+2290153023124	27	LA SONNETTE	\N	actif	2026-08-25 20:21:26.54022+00	\N
223	J08262732	OUSSENI	Ramdia	+2290155557481	27	CEG DU LAC	\N	actif	2026-08-25 20:21:28.024848+00	\N
228	J08265715	TOKPANOU	Osé	+2290161161748	27	CEG STE RITA	\N	actif	2026-08-25 20:21:30.152565+00	\N
229	J08264817	TOUNAOU	Mohamed	+2290190317491	27	CEG DU LAC	\N	actif	2026-08-25 20:21:30.643041+00	\N
230	J08264526	VIGAN	Horsman	+2290160474607	27	CEG STE RITA	\N	actif	2026-08-25 20:21:31.125334+00	\N
154	J08264017	ALLOSSE	Charafath	+2290167258787	27	CEG DU LAC	\N	actif	2026-08-25 20:17:57.753864+00	\N
160	J08264331	DHESSIN	Ingrid	+2290166379901	27	LA PAIX	\N	actif	2026-08-25 20:18:02.478379+00	\N
172	J08265429	KAKPO	Précieuse	+2290197189428	27	CEG DU LAC	\N	actif	2026-08-25 20:18:11.523899+00	\N
182	J08267573	SALAMI	Mourtador	+2290166991407	27	CEG STE RITA	\N	actif	2026-08-25 20:18:18.821198+00	\N
238	J08267099	AKPO	Judith	+2290197312358	3	CEG DU LAC	\N	actif	2026-08-25 20:23:13.382645+00	\N
242	J08262629	BAHOUNON	Zéphaniah	+2290197072759	3	CEG STE RITA	\N	actif	2026-08-25 20:23:15.398769+00	\N
244	J08269502	CHOGOLOU	Merveille	+2290197998135	3	CEG DU LAC	\N	actif	2026-08-25 20:23:16.398331+00	\N
251	J08266975	HINVI	Imtinane	+2290157594918	3	CEG DU LAC	\N	actif	2026-08-25 20:23:20.444147+00	\N
257	J08265274	AKPLAGBE	Surprise	+2290196720577	3	CEG DU LAC	\N	actif	2026-08-25 20:23:26.13395+00	\N
263	J08267347	GNONLONFOUN	Amour	+2290166696627	3	CEG STE RITA	\N	actif	2026-08-25 20:23:28.696394+00	\N
269	J08263201	KODJO	Merveille	+2290148879069	3	CEG DANTOKPA	\N	actif	2026-08-25 20:23:31.44012+00	\N
276	J08261766	SEWADE	Anne Marie	+2290197127769	3	CEG DU LAC	\N	actif	2026-08-25 20:23:34.709415+00	\N
249	J08261989	DAVI	Elias	+2290166265614	18	CEG DU LAC	\N	actif	2026-08-25 20:23:19.057647+00	\N
265	J08267619	HOUSSOU	Grâce	+2290161323568	18	CEG DU LAC	\N	actif	2026-08-25 20:23:29.537398+00	\N
278	J08269245	SYLLA	Fousséni	+2290195951499	18	CEG DU LAC	\N	actif	2026-08-25 20:23:35.514883+00	\N
282	J08267300	ZINLI	Dario	+2290197169020	18	ST JEAN	\N	actif	2026-08-25 20:23:37.2431+00	\N
240	J08267011	AVLESSI	Sylvia	+2290161401513	25	CEG DU LAC	\N	actif	2026-08-25 20:23:14.456945+00	\N
246	J08265577	DAKOSSI	Constance	+2290196411598	25	CEG DU LAC	\N	actif	2026-08-25 20:23:17.305422+00	\N
259	J08267492	DJOSSOU	Adèle	+2290197372198	25	CEG 2 GODOMEY	\N	actif	2026-08-25 20:23:26.997793+00	\N
261	J08265175	GANDONOU	Olivier	+2290194404286	25	CEG DANTOKPA	\N	actif	2026-08-25 20:23:27.857529+00	\N
267	J08269487	IJIDINAN	Romain	+2290161933531	25	CEG DU LAC	\N	actif	2026-08-25 20:23:30.584441+00	\N
271	J08261832	KOUNNOU	Chancelle	+2290197489751	25	CEG DU LAC	\N	actif	2026-08-25 20:23:32.319837+00	\N
273	J08261907	N'TIA	Auristelle	+2290195457945	25	CEG DANTOKPA	\N	actif	2026-08-25 20:23:33.256898+00	\N
280	J08269234	TCHOKOTI	Peace	+2290197630428	25	CEG STE RITA	\N	actif	2026-08-25 20:23:36.333557+00	\N
255	J08263921	AFO	Fabienne	+2290197987658	25	CEG DU LAC	\N	actif	2026-08-25 20:23:25.206681+00	\N
253	J08261576	KOUDJOU	Alves	+2290197987658	25	BETHESDA	\N	actif	2026-08-25 20:23:22.5059+00	\N
241	J08266621	BAGBONON	Thérèse	+2290197294636	3	CEG DU LAC	\N	actif	2026-08-25 20:23:15.00794+00	\N
243	J08262739	CHOGOLOU	Daniel	+2290197998135	3	CEG GBEGAMEY	\N	actif	2026-08-25 20:23:15.951138+00	\N
245	J08261829	CODJOVI	Warren	+2290196532358	3	CEG DU LAC	\N	actif	2026-08-25 20:23:16.862292+00	\N
247	J08264514	DANSI	Inès	+2290153291153	3	CEG DU LAC	\N	actif	2026-08-25 20:23:17.72742+00	\N
252	J08264241	KOLI	Jamal	+2290197839250	3	CEG DU LAC	\N	actif	2026-08-25 20:23:21.743552+00	\N
264	J08266200	HOUNTONDJI	Josué	+2290150390481	3	CEG DU LAC	\N	actif	2026-08-25 20:23:29.112226+00	\N
270	J08261928	KOUDJANNANGNI	Favour	+2290196720577	3	CEG DU LAC	\N	actif	2026-08-25 20:23:31.909157+00	\N
272	J08262068	NOUDAMESSI	Esther	+2290199303063	3	CEG DU LAC	\N	actif	2026-08-25 20:23:32.792163+00	\N
275	J08267091	SEDJAME	Fifamè	+2290195030593	3	CEG STE RITA	\N	actif	2026-08-25 20:23:34.281538+00	\N
283	J08265678	ADANZOUNNON	Marie Louise	+2290167734945	18	CEG STE RITA	\N	actif	2026-08-25 20:25:07.214745+00	\N
284	J08262750	ADJINAKOU	Dénise	+2290196516030	18	CEG DU LAC	\N	actif	2026-08-25 20:25:07.768867+00	\N
285	J08265741	AGOGNON	Ericaelle	+2290196463831	18	CEG DU LAC	\N	actif	2026-08-25 20:25:08.223234+00	\N
286	J08267659	AHLONSOU	Gloria	+2290197538418	18	CEG DU LAC	\N	actif	2026-08-25 20:25:08.679252+00	\N
288	J08266640	AHOUANGBO	Francois	+2290168004959	18	CEG FIYEGNON	\N	actif	2026-08-25 20:25:09.570642+00	\N
290	J08264353	ATSEFONYA	Komlavi Dieu donné	+2290169366200	18	CEG DU LAC	\N	actif	2026-08-25 20:25:10.68848+00	\N
293	J08261299	FRANCISCO	Géovani Bignon	+2290197984238	18	CEG DU LAC	\N	actif	2026-08-25 20:25:12.270564+00	\N
294	J08262991	HOUENOU	Lorindo	+2290161020067	18	CEG DU LAC	\N	actif	2026-08-25 20:25:12.680398+00	\N
295	J08263957	HOUETO	Ruth	+2290163395788	18	CEG DU LAC	\N	actif	2026-08-25 20:25:13.114509+00	\N
298	J08264987	KLADJI	Joinelle	+2290197800590	18	CEG STE RITA	\N	actif	2026-08-25 20:25:14.699333+00	\N
300	J08266895	OKE	Narcisse	+2290197442195	18	CEG DU LAC	\N	actif	2026-08-25 20:25:15.642398+00	\N
301	J08267289	OKOU ADE	Huguette	+2290152716925	18	CEG DU LAC	\N	actif	2026-08-25 20:25:16.069019+00	\N
302	J08266620	RADJI	Rokibath	+2290196789444	18	CEG DANTOKPA	\N	actif	2026-08-25 20:25:16.96529+00	\N
303	J08264739	SAGBO	Madoché	+2290196749687	18	CEG DANTOKPA	\N	actif	2026-08-25 20:25:18.566774+00	\N
305	J08267841	AGOSSOU	Damienne	+2290147992417	18	CEG DU LAC	\N	actif	2026-08-25 20:25:20.224754+00	\N
306	J08264502	AHISSOU	Marcolino	+2290197826116	18	CEG DU LAC	\N	actif	2026-08-25 20:25:20.819693+00	\N
307	J08264556	AWAZE	Mathias	+2290197939840	18	CEG DU LAC	\N	actif	2026-08-25 20:25:21.278402+00	\N
308	J08262903	AWODJE	Eric	+2290167318160	18	LA RÉFÉRENCE	\N	actif	2026-08-25 20:25:21.703789+00	\N
309	J08266858	CHEMITAN	Widad	+2290197069624	18	CEG STE RITA	\N	actif	2026-08-25 20:25:22.670713+00	\N
310	J08266360	GNONLONFOUN	Emmanuella	+2290195665249	18	CEG DU LAC	\N	actif	2026-08-25 20:25:23.085322+00	\N
311	J08263141	GNONLONFOUN	José	+2290196229662	18	CEG DU LAC	\N	actif	2026-08-25 20:25:23.48885+00	\N
312	J08265474	GOUSSANOU	Fanelle	+2290197992570	18	CEG DU LAC	\N	actif	2026-08-25 20:25:23.925831+00	\N
313	J08267475	HOUNNOU	Chakirath	+2290148159571	18	CEG DU LAC	\N	actif	2026-08-25 20:25:24.538587+00	\N
314	J08261428	HOUNTONDJI	Josephine	+2290150390481	18	CEG DU LAC	\N	actif	2026-08-25 20:25:24.939314+00	\N
315	J08264286	KOULIHO	Giovanie	+2290197159757	18	CEG DU LAC	\N	actif	2026-08-25 20:25:25.346721+00	\N
317	J08266763	YESSOUFOU	Ihssane	+2290197670868	18	CEG DU LAC	\N	actif	2026-08-25 20:25:26.162121+00	\N
318	J08263702	ZOUMENOU	Mystère	+2290166767937	18	LA RÉFÉRENCE	\N	actif	2026-08-25 20:25:26.599413+00	\N
322	J08265442	ATEKPO	Modérand	+2290195879022	4	CEG DU LAC	\N	actif	2026-08-25 22:14:34.962607+00	\N
323	J08264998	CISSE	Salif	+2290152240511	4	CEG DANTOKPA	\N	actif	2026-08-25 22:14:35.569304+00	\N
324	J08261460	DADJO	Ramatou	+2290161240573	4	COURONNE DE DIEU	\N	actif	2026-08-25 22:14:36.351809+00	\N
326	J08262414	KPODJI	Joseph	+2290167221243	4	CEG STE RITA	\N	actif	2026-08-25 22:14:37.371621+00	\N
328	J08268729	SOKE	Yésid	+2290197389466	4	CEG DU LAC	\N	actif	2026-08-25 22:14:38.542672+00	\N
256	J08269613	AGONZAN	Victoire	+2290143596788	18	CEG DANTOKPA	\N	actif	2026-08-25 20:23:25.619346+00	\N
258	J08266187	ANAGONOU	Lydwine Judith	+2290198268798	25	CEG STE RITA	\N	actif	2026-08-25 20:23:26.597694+00	\N
260	J08262042	GANDONOU	Olivia	+2290194404286	25	CEG DANTOKPA	\N	actif	2026-08-25 20:23:27.441798+00	\N
248	J08266520	DAVI	Emmanuel	+2290166265614	18	CEG DU LAC	\N	actif	2026-08-25 20:23:18.60171+00	\N
250	J08262738	FOFANA	Tidjani	+2290197084944	18	CEG DU LAC	\N	actif	2026-08-25 20:23:19.48638+00	\N
262	J08262658	GANKOU	Nelda	+2290195425289	25	CEG DU LAC	\N	actif	2026-08-25 20:23:28.26659+00	\N
268	J08267503	KINSOU	Wilsdom	+2290169357557	25	CEG GBEGAMEY	\N	actif	2026-08-25 20:23:31.011701+00	\N
299	J08263930	KLOTOE	Dénis	+2290166351585	25	CEG DU LAC	\N	actif	2026-08-25 20:25:15.205455+00	\N
325	J08266812	GANDONOU	Arol	+2290161610898	26	CEG STE RITA	\N	actif	2026-08-25 22:14:36.749973+00	\N
277	J08262326	SYLLA	Alassane	+2290195951499	18	CEG DU LAC	\N	actif	2026-08-25 20:23:35.115682+00	\N
279	J08269120	TCHIAKPE	Exaucée	+2290197909012	18	CEG STE RITA	\N	actif	2026-08-25 20:23:35.93473+00	\N
287	J08267451	AHOKPE	Odile	+2290197253091	25	CEG DU LAC	\N	actif	2026-08-25 20:25:09.147118+00	\N
281	J08266134	ZANNOU	Géraldo	+2290161089001	18	CEG STE RITA	\N	actif	2026-08-25 20:23:36.820695+00	\N
239	J08264258	AMOUSSOU	Elfrida	+2290144551058	25	CEG PLATEAU	\N	actif	2026-08-25 20:23:13.952646+00	\N
289	J08264875	ALANGBOKINTO	Marc Vivien	+2290152241099	25	CEG DU LAC	\N	actif	2026-08-25 20:25:10.230234+00	\N
291	J08269655	DANSOU	Madeleine	+2290195096495	25	CEG DU LAC	\N	actif	2026-08-25 20:25:11.292537+00	\N
292	J08266833	DJIGBE	Gédéon	+2290167281533	25	CEG DU LAC	\N	actif	2026-08-25 20:25:11.803676+00	\N
296	J08268053	HOUNTON	Mathieu	+2290144435235	25	CEG DU LAC	\N	actif	2026-08-25 20:25:13.611422+00	\N
297	J08267063	HOUNVO	Géronime	+2290197876278	25	CEG DU LAC	\N	actif	2026-08-25 20:25:14.050334+00	\N
304	J08266189	TODJINOU	Bénoit	+2290197267528	25	CEG STE RITA	\N	actif	2026-08-25 20:25:19.000503+00	\N
316	J08266367	MASSANGA	Emmanuel	+2290143724658	25	CEG DU LAC	\N	actif	2026-08-25 20:25:25.747623+00	\N
266	J08264225	HOUSSOU	Jean Pascal	+2290161323568	25	CEG DU LAC	\N	actif	2026-08-25 20:23:30.192136+00	\N
254	J08264859	WINSAVI	Nadège	+2290197987658	25	CEG DU LAC	\N	actif	2026-08-25 20:23:24.06998+00	\N
327	J08269665	OLOUWO	Michel	+2290161228481	26	CEG STE RITA	\N	actif	2026-08-25 22:14:37.958767+00	\N
329	J08266681	TOSSOU	Marc Owen	+2290190630154	4	CEG DU LAC	\N	actif	2026-08-25 22:14:38.945502+00	\N
330	J08261722	ZOHOU	Mickel Ange	+2290194747461	4	CEG DU LAC	\N	actif	2026-08-25 22:14:39.354596+00	\N
332	J08265015	ATINKPINDA	Tatiana	+2290169690372	4	CEG DU LAC	\N	actif	2026-08-25 22:14:40.509959+00	\N
333	J08262238	SALAOU	Hamza	+2290162080013	4	CEG DU LAC	\N	actif	2026-08-25 22:14:40.909561+00	\N
334	J08263491	TOGNI	Iniestar	+2290197722297	4	CEG DU LAC	\N	actif	2026-08-25 22:14:41.316381+00	\N
335	J08263933	ABENI	Edith	+2290197214548	17	CEG DU LAC	\N	actif	2026-08-25 22:15:06.275484+00	\N
337	J08264620	ADANDE	Bénicia	+2290197130866	17	CEG DU LAC	\N	actif	2026-08-25 22:15:07.674864+00	\N
339	J08267295	ADANNOU	Sheerine	+2290194665662	17	CEG STE RITA	\N	actif	2026-08-25 22:15:09.270972+00	\N
341	J08268204	AGBO	Tatiana	+2290166637510	17	CEG DU LAC	\N	actif	2026-08-25 22:15:10.473901+00	\N
342	J08269220	AGUEHOUNKA	Eternel	+2290166995092	17	CEG STE RITA	\N	actif	2026-08-25 22:15:10.900786+00	\N
344	J08269195	AHOGBO	Mariette	+2290166568060	17	CEG DU LAC	\N	actif	2026-08-25 22:15:11.841235+00	\N
345	J08265827	AHOUANHIDE	Godwin Adonai	+2290196138109	17	CEG STE RITA	\N	actif	2026-08-25 22:15:12.218918+00	\N
346	J08263176	AKINOCHO	Joseph	+2290166450317	17	CEG DU LAC	\N	actif	2026-08-25 22:15:12.643017+00	\N
347	J08267095	AKIOLA	Célestine	+2290197180553	17	CEG DU LAC	\N	actif	2026-08-25 22:15:13.100231+00	\N
348	J08269135	AMOUSSOU	Floriane	+2290197910617	17	CEG DU LAC	\N	actif	2026-08-25 22:15:13.503796+00	\N
355	J08269209	CAKPO SOGOE	Fadel	+2290197931064	17	CEG DU LAC	\N	actif	2026-08-25 22:15:17.325973+00	\N
358	J08265789	DIOGO	Jacques	+2290166027220	17	CEG STE RITA	\N	actif	2026-08-25 22:15:18.58232+00	\N
361	J08261528	GAYET	Miracle	+2290196883610	17	CEG DU LAC	\N	actif	2026-08-25 22:15:19.795282+00	\N
364	J08263005	HOUETCHOU	Précieux	+2290166765769	17	CEG DU LAC	\N	actif	2026-08-25 22:15:21.166729+00	\N
365	J08264067	HOUNGBE	Ezéchias	+2290196411710	17	CEG STE RITA	\N	actif	2026-08-25 22:15:21.560194+00	\N
366	J08265751	HOUNKPATIN	Claudine	+2290196579438	17	CEG DU LAC	\N	actif	2026-08-25 22:15:22.167159+00	\N
369	J08268631	KAKINI	Déborah	+2290161943189	17	CEG DU LAC	\N	actif	2026-08-25 22:15:23.628899+00	\N
371	J08266455	KOUMA	Léonce	+2290196285600	17	CEG DU LAC	\N	actif	2026-08-25 22:15:24.503603+00	\N
375	J08268070	OMIALE	Faouziyath	+2290190301261	17	CEG DU LAC	\N	actif	2026-08-25 22:15:26.158239+00	\N
379	J08265055	SEWA	Epiphane	+2290197473838	17	CEG DU LAC	\N	actif	2026-08-25 22:15:28.183219+00	\N
380	J08267322	SEWADE	Crépin	+2290140641890	17	CEG DU LAC	\N	actif	2026-08-25 22:15:28.789136+00	\N
381	J08263179	SOUNOUVOU	Julienne	+2290195461198	17	CEG DU LAC	\N	actif	2026-08-25 22:15:29.58494+00	\N
383	J08268965	WANKPO	Sylvanio	+2290191560549	17	CEG DU LAC	\N	actif	2026-08-25 22:15:30.577999+00	\N
385	J08268467	ZANNOU	Ghislain	+2290197833912	17	CEG DU LAC	\N	actif	2026-08-25 22:15:31.551663+00	\N
386	J08262427	ZOUNDJAN	Parfaite	+2290196273395	17	CEG DU LAC	\N	actif	2026-08-25 22:15:32.14211+00	\N
389	J08261792	ADEYEMON	Inès	+2290140124702	22	CEG DU LAC	\N	actif	2026-08-25 22:22:42.699436+00	\N
391	J08269560	ADOHOUNGBO	Faribelle	+2290197080258	22	CEG DU LAC	\N	actif	2026-08-25 22:22:43.751236+00	\N
395	J08265555	AGOGNON	Dolorès	+2290162795215	22	CEG DU LAC	\N	actif	2026-08-25 22:22:45.389891+00	\N
396	J08262113	AGOSSOU	Ange	+2290197215500	22	CEG DU LAC	\N	actif	2026-08-25 22:22:45.775241+00	\N
397	J08263684	AGOSSOU	Eunice	+2290197215500	22	CEG DU LAC	\N	actif	2026-08-25 22:22:46.193486+00	\N
336	J08262004	ADAMMAHO	Paulas	+2290166339941	26	CEG DU LAC	\N	actif	2026-08-25 22:15:06.884622+00	\N
338	J08264145	ADANKON	Fernand	+2290197287319	26	CEG DU LAC	\N	actif	2026-08-25 22:15:08.452369+00	\N
340	J08263981	ADANZOUNON	Paterne	+2290195619575	26	CEG STE RITA	\N	actif	2026-08-25 22:15:10.074535+00	\N
343	J08262432	AHO	Débora	+2290140584422	26	CEG STE RITA	\N	actif	2026-08-25 22:15:11.310428+00	\N
349	J08264535	AMOUSSOU	Taslima	+2290161567682	26	CEG STE RITA	\N	actif	2026-08-25 22:15:13.917255+00	\N
350	J08265777	ATINDEHOU	Otniel	+2290197148496	26	CEG STE RITA	\N	actif	2026-08-25 22:15:14.442288+00	\N
351	J08265626	AZOKLI	Daniel	+2290197759862	26	CEG DU LAC	\N	actif	2026-08-25 22:15:15.05849+00	\N
352	J08263983	BEHETON	Yasmine	+2290167091774	26	CEG L'ENTENTE	\N	actif	2026-08-25 22:15:15.657735+00	\N
353	J08264657	BONIFACIO	Rissikath	+2290162114194	26	CEG STE RITA	\N	actif	2026-08-25 22:15:16.235884+00	\N
354	J08267971	BOTOKOU	Sylvia	+2290197218926	26	CEG STE RITA	\N	actif	2026-08-25 22:15:16.943256+00	\N
356	J08264383	DAGBA	Darren Espérance	+2290196966772	26	CEG STE RITA	\N	actif	2026-08-25 22:15:17.720252+00	\N
357	J08269816	DE CAMPOS	Marie Michel	+2290197195343	26	CEG STE RITA	\N	actif	2026-08-25 22:15:18.10785+00	\N
359	J08262712	DOSSA	Onyx	+2290147607652	26	CEG DU LAC	\N	actif	2026-08-25 22:15:18.999566+00	\N
360	J08269832	GANDE	Carmel	+2290191071425	26	CEG DU LAC	\N	actif	2026-08-25 22:15:19.398282+00	\N
362	J08264236	HONFOVOU	Christelle	+2290161546467	26	CEG COCOTIERS	\N	actif	2026-08-25 22:15:20.323362+00	\N
363	J08268786	HOUESSOU	Fifamè	+2290166743512	26	CEG DU LAC	\N	actif	2026-08-25 22:15:20.740288+00	\N
367	J08262179	HOUNSOU	Abraham	+2290196000568	26	CEG DANTOKPA	\N	actif	2026-08-25 22:15:22.794346+00	\N
368	J08263737	HOUNSSINOU	Emmanuella	+2290161881005	26	CEG STE RITA	\N	actif	2026-08-25 22:15:23.199641+00	\N
370	J08265101	KOSSOU	Yvonne	+2290196747073	26	CEG STE RITA	\N	actif	2026-08-25 22:15:24.033508+00	\N
372	J08261484	KPADE	Christiane	+2290197403809	26	CEG STE RITA	\N	actif	2026-08-25 22:15:24.918149+00	\N
373	J08265275	MEGNIZIN	Sonia	+2290141575823	26	CEG STE RITA	\N	actif	2026-08-25 22:15:25.306196+00	\N
374	J08269845	OLAGUNJU	Mutimayinath	+2290152245274	26	CEG DU LAC	\N	actif	2026-08-25 22:15:25.721387+00	\N
376	J08264187	OWOLABI	Sélim	+2290169687994	26	LA PAIX	\N	actif	2026-08-25 22:15:26.592593+00	\N
377	J08262715	ROUFAI	Amiratou	+2290151044263	26	CEG STE RITA	\N	actif	2026-08-25 22:15:27.387279+00	\N
378	J08268727	SAGBOHAN	Alex	+2290197691772	26	CEG DANTOKPA	\N	actif	2026-08-25 22:15:27.794315+00	\N
382	J08264085	TOVIHO	Séraphine	+2290141240993	26	CEG STE RITA	\N	actif	2026-08-25 22:15:29.984707+00	\N
384	J08264426	YESSOUFOU	Karimath	+2290196847244	26	CEG DU LAC	\N	actif	2026-08-25 22:15:30.954944+00	\N
388	J08264407	ADANMAHO	Exaucé	+2290197767338	26	CEG DU LAC	\N	actif	2026-08-25 22:22:42.297344+00	\N
392	J08266792	ADOUKONOU	Private	+2290155724053	26	CEG DU LAC	\N	actif	2026-08-25 22:22:44.174553+00	\N
387	J08263539	ADAMOU	Fahad	+2290196675300	17	LA RÉFÉRENCE	\N	actif	2026-08-25 22:22:41.881185+00	\N
393	J08264246	AGASSOUSSI	Inès Kévine	+2290166027083	17	CEG DU LAC	\N	actif	2026-08-25 22:22:44.599289+00	\N
394	J08266217	AGBEGNINOU	Audrey	+2290165507546	17	CEG DU LAC	\N	actif	2026-08-25 22:22:44.994151+00	\N
399	J08261595	AHLONSOU	Francois	+2290149230522	22	CEG DU LAC	\N	actif	2026-08-25 22:22:47.014544+00	\N
401	J08265072	AKANDJONAN	Belmond	+2290190312616	22	CEG DANTOKPA	\N	actif	2026-08-25 22:22:47.80973+00	\N
402	J08266577	AKOUETE	Eugénio	+2290147657093	22	CEG DU LAC	\N	actif	2026-08-25 22:22:48.625943+00	\N
403	J08267662	AMOUSSOU	Fanette	+2290147001102	22	CEG DU LAC	\N	actif	2026-08-25 22:22:49.05639+00	\N
404	J08266028	AMOUSSOU	Nicolette	+2290144025280	22	CEG DU LAC	\N	actif	2026-08-25 22:22:49.482707+00	\N
406	J08265754	AVOCEHOUIN	Josué	+2290197557052	22	CEG DU LAC	\N	actif	2026-08-25 22:22:50.276405+00	\N
407	J08263103	BANDJE	Israel	+2290197020336	22	CEG DU LAC	\N	actif	2026-08-25 22:22:50.668507+00	\N
408	J08266622	BOURAIMA	Elisabeth	+2290196226854	22	CEG STE RITA	\N	actif	2026-08-25 22:22:51.065285+00	\N
409	J08264946	CHANGOTADE	Landry	+2290148454819	22	CEG DU LAC	\N	actif	2026-08-25 22:22:51.67579+00	\N
410	J08262150	DAGA	Carmelle	+2290157527662	22	CEG STE RITA	\N	actif	2026-08-25 22:22:52.231827+00	\N
414	J08267220	DOSSOU	Béatrice	+2290161153420	22	CEG DU LAC	\N	actif	2026-08-25 22:22:53.841919+00	\N
415	J08266783	DOUROSSIMI	Rodiath	+2290144070871	22	CEG DU LAC	\N	actif	2026-08-25 22:22:54.245664+00	\N
418	J08266487	GBAMMADO MARIE GRÂCE	Marie Grâce	+2290197226046	22	CEG DU LAC	\N	actif	2026-08-25 22:22:55.483515+00	\N
419	J08266029	GNANSOUNOU IRÈNE	Irène	+2290196564684	22	CEG DANTOKPA	\N	actif	2026-08-25 22:22:56.12035+00	\N
421	J08264165	HINVI DAMILOLA	Damilola	+2290197063773	22	CEG DU LAC	\N	actif	2026-08-25 22:22:56.944847+00	\N
422	J08266089	HONFO AICHATH	Aichath	+2290197731084	22	CEG DU LAC	\N	actif	2026-08-25 22:22:57.338877+00	\N
423	J08265706	HOUADJETO	Emilio	+2290148152298	22	CEG DU LAC	\N	actif	2026-08-25 22:22:57.773133+00	\N
424	J08268313	HOUEGNANNOU	Floriane	+2290197069177	22	CEG DU LAC	\N	actif	2026-08-25 22:22:58.174511+00	\N
425	J08268377	HOUENOU	Jean Véronique	+2290166856732	22	CEG DU LAC	\N	actif	2026-08-25 22:22:58.606343+00	\N
427	J08262511	HOUNGUE	Fanie	+2290196811232	22	CEG DU LAC	\N	actif	2026-08-25 22:22:59.54351+00	\N
428	J08267952	HOUNVO	Irène	+2290197876278	22	CEG DU LAC	\N	actif	2026-08-25 22:22:59.942572+00	\N
429	J08268450	HOUNYE GANSI	Jules	+2290197298082	22	CEG DU LAC	\N	actif	2026-08-25 22:23:00.374501+00	\N
430	J08268212	KIKI	Anne Marie	+2290190985340	22	CEG DU LAC	\N	actif	2026-08-25 22:23:00.817065+00	\N
432	J08265265	KOUAKANOU	Jeannette	+2290197313260	22	CEG DU LAC	\N	actif	2026-08-25 22:23:01.636137+00	\N
433	J08265028	KOULIHO	Majoie	+2290197321641	22	CEG DU LAC	\N	actif	2026-08-25 22:23:02.041996+00	\N
434	J08265130	KOUYONOU	Damienne	+2290150390481	22	CEG DU LAC	\N	actif	2026-08-25 22:23:02.44536+00	\N
443	J08263375	TOSSOU	Conforte	+2290161243265	22	CEG DU LAC	\N	actif	2026-08-25 22:23:06.609899+00	\N
447	J08264316	ADELEYE	Fulbert	+2290155845758	24	CEG DU LAC	\N	actif	2026-08-25 22:30:18.537005+00	\N
448	J08267214	AGOSSOU	Ashley	+2290195964187	24	CEG DU LAC	\N	actif	2026-08-25 22:30:19.206795+00	\N
449	J08262509	AKLO	Ezéchiel	+2290197955076	24	CEG DU LAC	\N	actif	2026-08-25 22:30:19.65303+00	\N
450	J08266270	DOVI	Edwige	+2290197445773	24	CEG DU LAC	\N	actif	2026-08-25 22:30:20.055139+00	\N
452	J08264476	FASSINOU	Odette	+2290197552156	24	CEG DU LAC	\N	actif	2026-08-25 22:30:21.358943+00	\N
453	J08266856	HOUNGA	Christian	+2290162641120	24	CEG DU LAC	\N	actif	2026-08-25 22:30:22.088243+00	\N
454	J08266085	KANA	Emmanuella	+2290195154337	24	CEG DU LAC	\N	actif	2026-08-25 22:30:22.501925+00	\N
456	J08262538	NICOUE	Faith	+2290190467081	24	CEG DU LAC	\N	actif	2026-08-25 22:30:23.416348+00	\N
457	J08265627	NICOUE	Love	+2290190467081	24	CEG DU LAC	\N	actif	2026-08-25 22:30:23.816738+00	\N
458	J08262386	SALAOU	Ismael	+2290196085957	24	CEG DU LAC	\N	actif	2026-08-25 22:30:24.237185+00	\N
459	J08262634	ADEKPODJOU	Fatima	+2290195198341	8	CEG DU LAC	\N	actif	2026-08-25 22:30:45.23724+00	\N
462	J08262094	ADJASSOHO	Conceptine	+2290199000351	8	CEG DU LAC	\N	actif	2026-08-25 22:30:46.801766+00	\N
463	J08268263	AGOSSOU	Immaculée	+2290169038875	8	CEG DU LAC	\N	actif	2026-08-25 22:30:47.208753+00	\N
464	J08266158	AHOGBO	Dieu donné	+2290166568060	8	CEG DU LAC	\N	actif	2026-08-25 22:30:47.628794+00	\N
451	J08268703	DOVONON	Samuel	+2290156453316	8	CEG DU LAC	\N	actif	2026-08-25 22:30:20.869457+00	\N
416	J08263905	EZOUNKATON	Merveille	+2290148969037	17	CEG DU LAC	\N	actif	2026-08-25 22:22:54.641527+00	\N
398	J08262352	AHLINVI JULIANO	Juliano Kévin	+2290166810720	26	CEG DU LAC	\N	actif	2026-08-25 22:22:46.608851+00	\N
400	J08265650	AHOUANGANON	Estelle	+2290191472923	26	CEG TOHOUE	\N	actif	2026-08-25 22:22:47.424713+00	\N
405	J08264111	ASSOCLE	Eunice	+2290162215407	26	CEG DU LAC	\N	actif	2026-08-25 22:22:49.882583+00	\N
412	J08267317	DJOTCHOU	Modeste	+2290152240834	26	CEG DU LAC	\N	actif	2026-08-25 22:22:53.050626+00	\N
413	J08266675	DJOWADAN	Laurent	+2290149396475	26	CEG DU LAC	\N	actif	2026-08-25 22:22:53.446482+00	\N
417	J08268126	GANDE BERNADETTE	Bernadette	+2290196324194	26	CEG DU LAC	\N	actif	2026-08-25 22:22:55.066696+00	\N
420	J08269287	GUEGNI KÉVIN STEEVER	Kévin Steever	+2290197566084	26	CEG STE RITA	\N	actif	2026-08-25 22:22:56.554584+00	\N
426	J08263043	HOUIDODJITCHE	Fèmi	+2290197884684	26	CEG DU LAC	\N	actif	2026-08-25 22:22:59.087799+00	\N
431	J08265875	KOHOUNKO	Samson	+2290197706504	26	CEG DU LAC	\N	actif	2026-08-25 22:23:01.222732+00	\N
435	J08268029	N'DA	Princesse	+2290156328589	26	CEG DU LAC	\N	actif	2026-08-25 22:23:03.038634+00	\N
436	J08262474	NOUDEHOU	Sènami	+2290161133223	26	CEG DU LAC	\N	actif	2026-08-25 22:23:03.435801+00	\N
437	J08262720	SANNI	Moutawakim	+2290197832245	26	CEG DU LAC	\N	actif	2026-08-25 22:23:03.832782+00	\N
438	J08269682	SEMAYI	Roméo	+2290162216522	26	CEG DU LAC	\N	actif	2026-08-25 22:23:04.236192+00	\N
439	J08264829	SODE	Wilfried	+2290157082656	26	CEG DU LAC	\N	actif	2026-08-25 22:23:04.972729+00	\N
440	J08266422	SOKENOU	Jean Baptiste	+2290197602502	26	CEG DU LAC	\N	actif	2026-08-25 22:23:05.395526+00	\N
441	J08264630	TCHINA	Daniel	+2290159004836	26	CEG DU LAC	\N	actif	2026-08-25 22:23:05.796339+00	\N
442	J08265495	TODJINOU	Glorieuse	+2290197267528	26	CEG STE RITA	\N	actif	2026-08-25 22:23:06.194453+00	\N
444	J08269629	TOTIN	Judicaelo	+2290197000961	26	LA RÉFÉRENCE	\N	actif	2026-08-25 22:23:07.037585+00	\N
445	J08268554	VIEYRA	Faridath	+2290197987365	26	CEG GBEGAMEY	\N	actif	2026-08-25 22:23:07.544609+00	\N
446	J08266220	ZOUNDJI	Lazare	+2290158735627	26	CEG DU LAC	\N	actif	2026-08-25 22:23:07.948545+00	\N
411	J08267122	DELE	Jean Baptiste	+2290196144429	17	CEG DANTOKPA	\N	actif	2026-08-25 22:22:52.624564+00	\N
466	J08262066	AMONDO	Kiriya	+2290197856320	8	CEG DU LAC	\N	actif	2026-08-25 22:30:48.496882+00	\N
468	J08263858	ASSANI	Moussa	+2290190620865	8	CEG DU LAC	\N	actif	2026-08-25 22:30:49.319854+00	\N
472	J08267175	DJOCHOU	Louise	+2290152240834	8	CEG DU LAC	\N	actif	2026-08-25 22:30:51.125127+00	\N
474	J08269687	GNONLONFOUN	Rose Kèmi	+2290166696627	8	CEG DU LAC	\N	actif	2026-08-25 22:30:52.367575+00	\N
476	J08261562	HOUNGUIEVI	Odile	+2290194278568	8	CEG DU LAC	\N	actif	2026-08-25 22:30:53.204639+00	\N
478	J08265611	KINTCHIMON	Charbelle	+2290197984354	8	CEG DU LAC	\N	actif	2026-08-25 22:30:54.006119+00	\N
479	J08265430	KODJO	Miracle	+2290190613956	8	CEG DU LAC	\N	actif	2026-08-25 22:30:54.547781+00	\N
481	J08263898	KOUNNOU	Jocelyne	+2290166023351	8	CEG DU LAC	\N	actif	2026-08-25 22:30:55.366095+00	\N
483	J08266694	OLLIVIER DE MONTAGUERE	Luce	+2290161041350	8	CEG DU LAC	\N	actif	2026-08-25 22:30:56.178429+00	\N
485	J08263278	RADJI	Nadiath	+2290196789444	8	CEG DANTOKPA	\N	actif	2026-08-25 22:30:57.087489+00	\N
487	J08264683	TOGNIFODE	Alain	+2290147278514	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.091731+00	\N
489	J08264427	ZANNOU	Félix	+2290197337122	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.920784+00	\N
470	J08265218	BOUKARI	Mira	+2290196915692	23	CEG STE RITA	\N	actif	2026-08-25 22:30:50.110871+00	\N
467	J08268338	AMOUZOUN	David	+2290141819742	8	CEG DU LAC	\N	actif	2026-08-25 22:30:48.884874+00	\N
469	J08266759	AZANKPO	Prisca	+2290197942377	8	CEG DU LAC	\N	actif	2026-08-25 22:30:49.715617+00	\N
471	J08262314	DAGA	Clémence	+2290157527662	8	CEG DU LAC	\N	actif	2026-08-25 22:30:50.549347+00	\N
473	J08265173	FAGNISSE	Majoie	+2290196345696	8	CEG DU LAC	\N	actif	2026-08-25 22:30:51.767662+00	\N
475	J08263238	HOLOEYI	Félicien	+2290153815647	8	CEG DU LAC	\N	actif	2026-08-25 22:30:52.795631+00	\N
477	J08266889	HOUNGUIEVI	Sètondji  David	+2290194278568	8	CEG DU LAC	\N	actif	2026-08-25 22:30:53.616358+00	\N
480	J08268591	KOUDEGNAN	Rodolpho	+2290161419976	8	CEG DU LAC	\N	actif	2026-08-25 22:30:54.948426+00	\N
482	J08264009	OGOULOLA	Léa	+2290191404508	8	CEG DU LAC	\N	actif	2026-08-25 22:30:55.778228+00	\N
484	J08268728	RADJEDO	Pierrette	+2290150719228	8	CEG DU LAC	\N	actif	2026-08-25 22:30:56.599547+00	\N
486	J08269335	SEDJAME	Néhémie	+2290195030593	8	CEG STE RITA	\N	actif	2026-08-25 22:30:57.484661+00	\N
488	J08267145	ZANNOU	Jacqueline	+2290197337122	8	CEG DU LAC	\N	actif	2026-08-25 22:30:58.505002+00	\N
490	J08261386	AHOWEKOUN	Noel	+2290192715933	11	CEG DU LAC	\N	actif	2026-08-25 22:37:59.330365+00	\N
491	J08262060	DOSSA	Immaculée	+2290197288140	11	CEG DU LAC	\N	actif	2026-08-25 22:37:59.736211+00	\N
492	J08265127	DOSSOU	Fourier	+2290197176633	11	CEG DU LAC	\N	actif	2026-08-25 22:38:00.346514+00	\N
493	J08264994	HASSANE	Fondé	+2290199757637	11	CEG DU LAC	\N	actif	2026-08-25 22:38:00.735028+00	\N
494	J08261345	LOHOUNME	Emmanuella	+2290166418569	11	CEG DU LAC	\N	actif	2026-08-25 22:38:01.124003+00	\N
495	J08265986	SABALIHOSSOU	Aristide	+2290143722100	11	CEG DU LAC	\N	actif	2026-08-25 22:38:01.539705+00	\N
496	J08268600	TONOU	Sètondji Ezechias	+2290143722100	11	CEG DU LAC	\N	actif	2026-08-25 22:38:02.189929+00	\N
497	J08269513	ZONON	Roberta	+2290151797551	11	CEG DU LAC	\N	actif	2026-08-25 22:38:02.617364+00	\N
498	J08264731	ABOUDOU	Rufus	+2290144373544	12	CEG STE RITA	\N	actif	2026-08-25 22:38:22.229393+00	\N
499	J08269228	AGBOSSODJAN	Esther	+2290144973242	12	CEG DU LAC	\N	actif	2026-08-25 22:38:22.992179+00	\N
500	J08265110	AGOSSOU	Nicodème	+2290167476339	12	CEG DU LAC	\N	actif	2026-08-25 22:38:23.378496+00	\N
501	J08261475	AHOWEKOUN	Alice	+2290161312823	12	CEG DU LAC	\N	actif	2026-08-25 22:38:23.767259+00	\N
502	J08263495	AKOUEGNINOU	Ernest	+2290197384806	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.150997+00	\N
503	J08262331	AVANDE	Mauriace	+2290152240745	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.544978+00	\N
504	J08265797	AZOUASSI	Rose	+2290194666556	12	CEG DU LAC	\N	actif	2026-08-25 22:38:24.930368+00	\N
505	J08265831	AMEGAN	Angela Doloresse	+2290197776338	12	CEG DU LAC	\N	actif	2026-08-25 22:38:25.551403+00	\N
506	J08269330	ARIORI	Parfaite	+2290166765135	12	CEG DU LAC	\N	actif	2026-08-25 22:38:26.344688+00	\N
507	J08265608	ATEKPO	Néoland	+2290152706991	12	CEG DU LAC	\N	actif	2026-08-25 22:38:26.854616+00	\N
508	J08268464	D'ALMEIDA	Merveille Ifè	+2290196577824	12	CEG DU LAC	\N	actif	2026-08-25 22:38:27.25613+00	\N
509	J08263602	DENAKPO	Charles	+2290196970092	12	CEG DU LAC	\N	actif	2026-08-25 22:38:27.660258+00	\N
510	J08262190	DE MEDEIROS	Eunice	+2290167276744	12	CEG DU LAC	\N	actif	2026-08-25 22:38:28.046056+00	\N
511	J08267939	FAGNON	Grâce	+2290197614777	12	CEG DU LAC	\N	actif	2026-08-25 22:38:28.475049+00	\N
512	J08261985	GNASSOUNOU	Marie Lauraine	+2290167692528	12	CEG DU LAC	\N	actif	2026-08-25 22:38:28.865325+00	\N
513	J08266987	HESSA	Clarisse	+2290166670004	12	CEG DU LAC	\N	actif	2026-08-25 22:38:29.265808+00	\N
514	J08268157	HOUNTO ADA	Francis	+2290195666328	12	CEG DU LAC	\N	actif	2026-08-25 22:38:29.643545+00	\N
515	J08266463	HOUNTONDJI	Espérancia	+2290197511214	12	CEG DU LAC	\N	actif	2026-08-25 22:38:30.024495+00	\N
516	J08266123	HOUSSA	Samuel	+2290197188094	12	CEG DU LAC	\N	actif	2026-08-25 22:38:30.408529+00	\N
517	J08264619	HOUNGUE	Hugues	+2290197334536	12	CEG STE RITA	\N	actif	2026-08-25 22:38:30.804467+00	\N
518	J08266137	MARCOS	Mariano	+2290197839801	12	CEG DU LAC	\N	actif	2026-08-25 22:38:31.185714+00	\N
519	J08269471	OKE	Raoul	+2290197442195	12	CEG DU LAC	\N	actif	2026-08-25 22:38:31.568051+00	\N
520	J08269249	OLAGUNJU	Mariam	+2290162806169	12	CEG DU LAC	\N	actif	2026-08-25 22:38:31.960019+00	\N
521	J08262030	OMIALE	Ziyadath	+2290190301261	12	CEG DU LAC	\N	actif	2026-08-25 22:38:32.405764+00	\N
522	J08268442	OTCHRAN	Amour	+2290151827753	12	CEG DU LAC	\N	actif	2026-08-25 22:38:32.805729+00	\N
523	J08262095	ROUFAI	Fahimath	+2290197264392	12	CEG DU LAC	\N	actif	2026-08-25 22:38:33.197533+00	\N
524	J08268606	SONON	Ozias Péniel	+2290197896235	12	CEG STE RITA	\N	actif	2026-08-25 22:38:33.589484+00	\N
525	J08264903	SOSSA	Wilson	+2290144115091	12	CEG DU LAC	\N	actif	2026-08-25 22:38:34.004969+00	\N
526	J08263060	ZANNOU	Foeube	+2290166526102	12	CEG DU LAC	\N	actif	2026-08-25 22:38:34.40601+00	\N
527	J08265155	ZANNOU	François	+2290197833912	12	LA RÉFÉRENCE	\N	actif	2026-08-25 22:38:34.799523+00	\N
528	J08263934	ZANNOU	Julien	+2290197833912	12	CEG DU LAC	\N	actif	2026-08-25 22:38:35.200743+00	\N
529	Y08268030	ADANHONDJI	Osias	+2290140783317	13	CEG YAGBE	\N	actif	2026-08-26 05:06:26.656279+00	\N
530	Y08267130	AGOSSA	Osée	+2290197127693	13	CEG YAGBE	\N	actif	2026-08-26 05:06:27.46423+00	\N
531	Y08268870	AGOSSOU	Dossa Rosvald	+2290162060942	13	CEG YAGBE	\N	actif	2026-08-26 05:06:28.267437+00	\N
532	Y08266698	AHLOU GOZO	Exaucé	+2290166322169	13	CEG YAGBE	\N	actif	2026-08-26 05:06:28.653428+00	\N
533	Y08261849	ALI	Roubayatou	+2290156698299	13	CEG YAGBE	\N	actif	2026-08-26 05:06:29.259939+00	\N
534	Y08264031	BANKOLE	Alida	+2290197428276	13	CEG YAGBE	\N	actif	2026-08-26 05:06:30.070493+00	\N
535	Y08267913	DANGBEDJI	Cynthia Grâce	+2290166501017	13	CEG YAGBE	\N	actif	2026-08-26 05:06:30.45668+00	\N
536	Y08261375	DOSSOU-KOKO	Gentille	+2290150164950	13	CEG YAGBE	\N	actif	2026-08-26 05:06:31.048309+00	\N
537	Y08269847	DOURODOLA	Sofiath Adéola	+2290151782736	13	CEG YAGBE	\N	actif	2026-08-26 05:06:32.039317+00	\N
538	Y08261805	GOUTHON	Guillaume Guérin	+2290196601236	13	CEG YAGBE	\N	actif	2026-08-26 05:06:32.445818+00	\N
539	Y08267893	HOUANGNI	Elohim Merveille	+2290196006677	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.014741+00	\N
540	Y08267733	HOUESSOU	Isabelle	+2290196580930	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.426934+00	\N
541	Y08267369	HOUNGNANNOU	Marius	+2290148453091	13	CEG YAGBE	\N	actif	2026-08-26 05:06:33.834602+00	\N
542	Y08265665	HOUSSOU	Eric Samuel	+2290197842362	13	CEG YAGBE	\N	actif	2026-08-26 05:06:34.207595+00	\N
543	Y08268529	KANGNIDE	Bénoit	+2290164643291	13	CEG YAGBE	\N	actif	2026-08-26 05:06:34.586662+00	\N
544	Y08268504	KASSA	Rock Kodjo	+2290151993966	13	CEG YAGBE	\N	actif	2026-08-26 05:06:35.156231+00	\N
545	Y08267634	KITOYI	Bilal	+2290152605104	13	CEG YAGBE	\N	actif	2026-08-26 05:06:35.538708+00	\N
546	Y08264304	LOKO	Emmanuella	+2290144371877	13	CEG YAGBE	\N	actif	2026-08-26 05:06:36.316639+00	\N
547	Y08262415	MAIGA	Fatoumata	+2290162396051	13	CEG YAGBE	\N	actif	2026-08-26 05:06:36.692502+00	\N
548	Y08263608	MAIGA	Halimata	+2290162396051	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.072067+00	\N
549	Y08262435	MAIGA	Zoulaiha	+2290162396061	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.587933+00	\N
551	Y08263224	NOUFIONSOU	Grâce	+2290148972920	13	CEG YAGBE	\N	actif	2026-08-26 05:06:38.372418+00	\N
553	Y08263248	TINVOEYI	Merveille De Dieu	+2290152091308	13	CEG YAGBE	\N	actif	2026-08-26 05:06:39.346589+00	\N
555	Y08261278	ZANNOU	Dorcas	+2290169357452	13	CEG YAGBE	\N	actif	2026-08-26 05:06:40.273677+00	\N
550	Y08261421	MASSE	Thomadêsse	+2290165440636	13	CEG YAGBE	\N	actif	2026-08-26 05:06:37.983233+00	\N
552	Y08264124	OUABI	Romdonne	+2290197771856	13	CEG YAGBE	\N	actif	2026-08-26 05:06:38.753534+00	\N
554	Y08264735	TITI	Farida	+2290196646367	13	CEG YAGBE	\N	actif	2026-08-26 05:06:39.902788+00	\N
556	Y08261292	ADECHOLA	Saad	+2290197022341	14	CEG YAGBE	\N	actif	2026-08-26 05:08:48.418879+00	\N
557	Y08266946	ADJAGNISSOUDE	Ruth	+2290197189342	14	CEG YAGBE	\N	actif	2026-08-26 05:08:48.817662+00	\N
558	Y08267185	AGBEDJA	Miracle	+2290191383610	14	CEG YAGBE	\N	actif	2026-08-26 05:08:49.3923+00	\N
559	Y08266216	ATEMENOU	Hilary	+2290169261498	14	CEG YAGBE	\N	actif	2026-08-26 05:08:49.843058+00	\N
560	Y08264433	BADAROU	Mohamed	+2290197694392	14	CEG YAGBE	\N	actif	2026-08-26 05:08:50.217537+00	\N
561	Y08265886	BANGO	Emmanuel	+2290152236371	14	CEG YAGBE	\N	actif	2026-08-26 05:08:50.593712+00	\N
562	Y08267046	BOGNON	Isaac	+2290162398663	14	CEG YAGBE	\N	actif	2026-08-26 05:08:51.015729+00	\N
563	Y08267529	DARAMANI	Amir	+2290141266053	14	CEG YAGBE	\N	actif	2026-08-26 05:08:51.426197+00	\N
564	Y08267630	DOSSOU	Marie Irène	+2290197720161	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.045119+00	\N
565	Y08263713	ESSOUM	Esther Ruth	+2290197885232	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.443953+00	\N
566	Y08261959	HOUESSOU	Emmanuel	+2290197251571	14	CEG YAGBE	\N	actif	2026-08-26 05:08:52.825821+00	\N
567	Y08266460	HOUNDENOU	Jeannette	+2290197334020	14	CEG YAGBE	\N	actif	2026-08-26 05:08:53.402274+00	\N
568	Y08265256	HOUNGBO	Mardoché	+2290197066005	14	CEG YAGBE	\N	actif	2026-08-26 05:08:53.78932+00	\N
569	Y08262321	ISSEKI	Marie Thérèse	+2290197755796	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.15568+00	\N
570	Y08266338	KAKA	Jilichricia	+2290166152655	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.611625+00	\N
571	Y08268089	KEKE	Florent	+2290197679887	14	CEG YAGBE	\N	actif	2026-08-26 05:08:54.980536+00	\N
572	Y08265874	KOTIN	Didier	+2290166020333	14	CEG YAGBE	\N	actif	2026-08-26 05:08:55.400035+00	\N
573	Y08268197	KPANGON	Célione	+2290166692043	14	CEG YAGBE	\N	actif	2026-08-26 05:08:55.773243+00	\N
575	Y08262460	MASSE	Wilfried	+2290165440636	14	CEG YAGBE	\N	actif	2026-08-26 05:08:56.914813+00	\N
576	Y08263327	ODI	Bernice	+2290196496983	14	CEG YAGBE	\N	actif	2026-08-26 05:08:57.315074+00	\N
577	Y08265146	SALIOU	Fridaous	+2290166031250	14	CEG YAGBE	\N	actif	2026-08-26 05:08:57.693728+00	\N
578	Y08265526	SOHE	Abebi	+2290197198647	14	CEG YAGBE	\N	actif	2026-08-26 05:08:58.084632+00	\N
579	Y08266928	TAO	Hidirou	+2290198427915	14	CEG YAGBE	\N	actif	2026-08-26 05:08:58.466381+00	\N
580	Y08262710	TOGBE	Mohamed	+2290196359815	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.05091+00	\N
581	Y08265533	TOGBE	Obérique	+2290167665433	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.46022+00	\N
582	Y08268680	YAYA OYE	Soubedatou	+2290169003643	14	CEG YAGBE	\N	actif	2026-08-26 05:08:59.849627+00	\N
583	Y08264402	ADAMON	Assande	+2290196431908	15	CEG YAGBE	\N	actif	2026-08-26 05:09:20.465725+00	\N
584	Y08268668	ADAMON	Rossime	+2290196566106	15	CEG YAGBE	\N	actif	2026-08-26 05:09:20.846356+00	\N
585	Y08264813	ADANHONDJI	Daniella	+2290197935230	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.226044+00	\N
586	Y08265050	ADANHONDJI	Gloria	+2290197452727	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.618601+00	\N
587	Y08268530	AGOSSA	Edna Inès	+2290197599452	15	CEG YAGBE	\N	actif	2026-08-26 05:09:21.986855+00	\N
588	Y08261806	AGOSSA	Obed	+2290197127693	15	CEG YAGBE	\N	actif	2026-08-26 05:09:22.390946+00	\N
589	Y08268677	AHLONSOU	Synthiche	+2290196296213	15	CEG YAGBE	\N	actif	2026-08-26 05:09:22.771404+00	\N
590	Y08262204	AKAKPO	Isabelle	+2290196445487	15	CEG YAGBE	\N	actif	2026-08-26 05:09:23.153873+00	\N
591	Y08267993	AKOGOUN	Zékiath	+2290193902690	15	CEG YAGBE	\N	actif	2026-08-26 05:09:23.552739+00	\N
592	Y08263589	ALLODE	Jérémie	+2290197481751	15	CEG YAGBE	\N	actif	2026-08-26 05:09:23.930509+00	\N
593	Y08264022	ALLODE	Léonce	+2290197481751	15	CEG YAGBE	\N	actif	2026-08-26 05:09:24.325881+00	\N
594	Y08263842	BADAROU	Yékini	+2290197247234	15	CEG YAGBE	\N	actif	2026-08-26 05:09:24.727583+00	\N
595	Y08268402	BAKPE	Jacques	+2290190525828	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.107306+00	\N
596	Y08267020	BAMIGBADE	Otniel	+2290197641417	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.485235+00	\N
597	Y08267520	BANKOLE	David	+2290197428276	15	CEG YAGBE	\N	actif	2026-08-26 05:09:25.856608+00	\N
599	Y08269579	DANSOU	Laurence	+2290166831544	15	CEG YAGBE	\N	actif	2026-08-26 05:09:26.646412+00	\N
600	Y08267701	DOSSOU	Bénédicte	+2290196580930	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.037992+00	\N
601	Y08266899	DOSSOU	Immaculée	+2290196953652	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.418849+00	\N
602	Y08267161	GANDONOU	Loïs	+2290165406987	15	CEG YAGBE	\N	actif	2026-08-26 05:09:27.809298+00	\N
603	Y08264249	GNAMBODE	Bénédicte	+2290155438512	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.195939+00	\N
604	Y08267580	HODOMIHOU	Cécile	+2290166657478	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.582105+00	\N
605	Y08268521	HODOMIHOU	Jeanne	+2290166657478	15	CEG YAGBE	\N	actif	2026-08-26 05:09:28.954878+00	\N
606	Y08262979	HOLLARD	Emmanuel	+2290195407566	15	CEG YAGBE	\N	actif	2026-08-26 05:09:29.343262+00	\N
607	Y08266426	HOSSOU	Marcelle	+2290196810679	15	CEG YAGBE	\N	actif	2026-08-26 05:09:29.729414+00	\N
608	Y08262889	HOSSOU	Paterne	+2290196810679	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.10539+00	\N
609	Y08266545	HOUESSOU	Belforeste	+2290196371580	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.499214+00	\N
610	Y08269826	HOUETCHOEZON	Didier	+2290191040567	15	CEG YAGBE	\N	actif	2026-08-26 05:09:30.883123+00	\N
611	Y08265099	HOUNDENOU	Emilienne	+2290197334020	15	CEG YAGBE	\N	actif	2026-08-26 05:09:31.269025+00	\N
612	Y08269420	HOUNDETON	Silvia	+2290144763739	15	CEG YAGBE	\N	actif	2026-08-26 05:09:31.656278+00	\N
613	Y08263538	HOUNDETON	Louise	+2290144763739	15	CEG YAGBE	\N	actif	2026-08-26 05:09:32.054503+00	\N
614	Y08269245	HOUNKPATIN	Constance	+2290197573580	15	CEG YAGBE	\N	actif	2026-08-26 05:09:32.438881+00	\N
615	Y08266634	HOUNKPATIN	Ornella	+2290197762900	15	CEG YAGBE	\N	actif	2026-08-26 05:09:33.025573+00	\N
616	Y08264713	KOUKOUI	Mariette	+2290197294746	15	CEG YAGBE	\N	actif	2026-08-26 05:09:33.422391+00	\N
617	Y08268145	LAKOUSSAN	Josué	+2290196609769	15	CEG YAGBE	\N	actif	2026-08-26 05:09:33.805917+00	\N
618	Y08266275	LOGBO	Siméon	+2290167763931	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.208577+00	\N
619	Y08268871	LOKO	Carolle	+2290196005511	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.583446+00	\N
621	Y08262090	MISSIKPODE	Malaleel	+2290197345620	15	CEG YAGBE	\N	actif	2026-08-26 05:09:35.333118+00	\N
622	Y08262014	OGOUTCHI	Oré Oluwa Merveille	+2290166376314	15	CEG YAGBE	\N	actif	2026-08-26 05:09:35.75142+00	\N
623	Y08268733	OLOUKPEDE	Floriane	+2290163103710	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.146702+00	\N
624	Y08262868	SAGBOHAN	Divine	+2290166285000	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.552985+00	\N
574	Y08266990	MASSE	Victoire	+2290165440636	13	CEG YAGBE	\N	actif	2026-08-26 05:08:56.155059+00	\N
598	Y08263174	BANKOLE	Noel	+2290197428276	14	CEG YAGBE	\N	actif	2026-08-26 05:09:26.254907+00	\N
625	Y08262554	SALAKO	Mariano	+2290161824028	15	CEG YAGBE	\N	actif	2026-08-26 05:09:36.936539+00	\N
627	Y08262955	SOSSOU	Ruth	+2290196534513	15	CEG YAGBE	\N	actif	2026-08-26 05:09:37.712014+00	\N
629	Y08267413	TCHANGOTADE	Doris	+2290191274074	15	CEG YAGBE	\N	actif	2026-08-26 05:09:38.495658+00	\N
631	Y08269477	YESSOUFOU	Sodirath	+2290197482674	15	CEG YAGBE	\N	actif	2026-08-26 05:09:39.261892+00	\N
633	Y08262231	ZANNOU	Kauis	+2290197480937	15	CEG YAGBE	\N	actif	2026-08-26 05:09:40.019524+00	\N
626	Y08264700	SOMASSE	Sonia	+2290197540636	15	CEG YAGBE	\N	actif	2026-08-26 05:09:37.327035+00	\N
628	Y08262947	SOUMANOU	Yousra	+2290197062518	15	CEG YAGBE	\N	actif	2026-08-26 05:09:38.10923+00	\N
630	Y08263533	TOLOFON	Eben Ezer	+2290190030696	15	CEG YAGBE	\N	actif	2026-08-26 05:09:38.889136+00	\N
632	Y08261636	ZANNOU	Kephil	+2290195432819	15	CEG YAGBE	\N	actif	2026-08-26 05:09:39.635741+00	\N
634	Y08265856	ABOKI	Daniel	+2290197073508	16	CEG YAGBE	\N	actif	2026-08-26 05:10:19.759651+00	\N
635	Y08266767	ADANHONDJI	Edith	+2290197169446	16	CEG YAGBE	\N	actif	2026-08-26 05:10:20.146612+00	\N
636	Y08261739	ADJAGNISSOUDE	Jérémie	+2290196667584	16	CEG YAGBE	\N	actif	2026-08-26 05:10:20.531336+00	\N
637	Y08264406	ADJAGNISSOUDE	Parfait	+2290167248075	16	CEG YAGBE	\N	actif	2026-08-26 05:10:20.919054+00	\N
638	Y08263391	AKALA	Achani	+2290167007819	16	CEG YAGBE	\N	actif	2026-08-26 05:10:21.307814+00	\N
639	Y08261253	AKON	Junior	+2290196475434	16	CEG YAGBE	\N	actif	2026-08-26 05:10:21.697789+00	\N
640	Y08265492	ASSOCLE	Doris	+2290166829586	16	CEG YAGBE	\N	actif	2026-08-26 05:10:22.083622+00	\N
641	Y08268688	ATCHADE	Grâce	+2290196154376	16	CEG YAGBE	\N	actif	2026-08-26 05:10:22.663731+00	\N
642	Y08267443	AWOUSSA	Dénise	+2290197818921	16	CEG YAGBE	\N	actif	2026-08-26 05:10:23.044425+00	\N
643	Y08264430	AZANGBE	Céline	+2290197738516	16	CEG YAGBE	\N	actif	2026-08-26 05:10:23.461833+00	\N
644	Y08263904	DANTODJI	Amos	+2290197681137	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.057591+00	\N
645	Y08263449	DANTON	Emmanuella	+2290140739385	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.450314+00	\N
646	Y08269761	DJIDENOU	Elysée	+2290197341857	16	CEG YAGBE	\N	actif	2026-08-26 05:10:24.824266+00	\N
647	Y08269235	DJODE	Wilson	+2290197568176	16	CEG YAGBE	\N	actif	2026-08-26 05:10:25.257024+00	\N
648	Y08261899	ESSOUM	Ozias	+2290197885232	16	CEG YAGBE	\N	actif	2026-08-26 05:10:25.634746+00	\N
649	Y08265374	GOGAN	Gloria	+2290197033746	16	CEG YAGBE	\N	actif	2026-08-26 05:10:26.221361+00	\N
650	Y08267681	GOGAN	Paul	+2290197033746	16	CEG YAGBE	\N	actif	2026-08-26 05:10:26.617392+00	\N
651	Y08264481	HESSANON	Marie Noel	+2290196003555	16	CEG YAGBE	\N	actif	2026-08-26 05:10:27.003884+00	\N
652	Y08262562	HOUNKPATIN	Melvine	+2290197573580	16	CEG YAGBE	\N	actif	2026-08-26 05:10:27.382202+00	\N
653	Y08265469	HOUNMENOU	Odile	+2290197647346	16	CEG YAGBE	\N	actif	2026-08-26 05:10:27.773135+00	\N
654	Y08263427	KABORE	Mohamed	+2290196530180	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.149791+00	\N
655	Y08266853	KOUTON	Franck	+2290197138284	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.532337+00	\N
656	Y08269124	KOUTON	Francky	+2290197138284	16	CEG YAGBE	\N	actif	2026-08-26 05:10:28.980225+00	\N
657	Y08264767	LANKPOEDJA	Pascaline	+2290190521313	16	CEG YAGBE	\N	actif	2026-08-26 05:10:29.377806+00	\N
658	Y08264191	MASSE	Thomas	+2290165440636	16	CEG YAGBE	\N	actif	2026-08-26 05:10:29.760361+00	\N
659	Y08266002	MINTOKIN	Bernadette	+2290196547165	16	CEG YAGBE	\N	actif	2026-08-26 05:10:30.15958+00	\N
660	Y08265561	NOUMON	Lauriane	+2290197120315	16	CEG YAGBE	\N	actif	2026-08-26 05:10:30.573136+00	\N
661	Y08265213	SAMOU	Ashley	+2290160592676	16	CEG YAGBE	\N	actif	2026-08-26 05:10:30.970702+00	\N
662	Y08263046	SETON	Innocent	+2290196569446	16	CEG YAGBE	\N	actif	2026-08-26 05:10:31.353165+00	\N
663	Y08266220	SOSSOU	Ornella	+2290153503224	16	CEG YAGBE	\N	actif	2026-08-26 05:10:31.756167+00	\N
664	Y08266563	TAIWO	Tayé	+2290196794716	16	CEG YAGBE	\N	actif	2026-08-26 05:10:32.128494+00	\N
665	Y08266195	YOLOU	Chaidatou	+2290197773338	16	CEG YAGBE	\N	actif	2026-08-26 05:10:32.509562+00	\N
666	Y08261815	ZANNOU	Bilal	+2290197029828	16	CEG YAGBE	\N	actif	2026-08-26 05:10:32.898645+00	\N
672	J08267766	ATINDEHOU	Chaanou Baozine	+2290197148496	20	CEG DU LAC	\N	actif	2026-08-31 13:48:33.293695+00	\N
682	J08268280	VITCHOEDO	Clémence	+2290197073687	20	CEG DU LAC	\N	actif	2026-08-31 13:58:41.399693+00	\N
684	J08263297	BOGNON	Isaac	+2290193350986	2	CEG DU LAC	\N	actif	2026-08-31 14:08:01.842413+00	\N
687	J08268256	OLAITAN	Chefiou	+2290196094508	19	FRANCO ARABE	\N	actif	2026-08-31 14:18:03.940363+00	\N
688	J08265135	HOUNTONDJI	Gaspard	+2290196041927	19	CEG DU LAC	\N	actif	2026-08-31 14:19:45.732143+00	\N
689	J08265649	CODJIA	Joinès	+2290197148281	19	CEG DU LAC	\N	actif	2026-08-31 14:20:56.80596+00	\N
690	J08267093	AYIMETON	Pierrette	+2290197063986	19	CEG DU LAC	\N	actif	2026-08-31 14:22:01.81661+00	\N
697	J08265051	SALE	Nicole	+2290197074831	25	COLLEGE STE CÉCILE	\N	actif	2026-08-31 14:39:37.436975+00	\N
696	J08267530	AYIDOKINHOU	Kévine Junior	+2290166379901	25	CEG DU LAC	\N	actif	2026-08-31 14:38:13.893374+00	\N
89	J08261282	OYASIDI	Amed	+2290144509057	28	CEG DU LAC	\N	actif	2026-08-25 20:15:09.824213+00	\N
698	J08262093	ATTAKPA	O'neil	+2290196278211	25	CEG DU LAC	\N	actif	2026-08-31 14:48:24.520157+00	\N
667	J08267999	AHIHA	Antoine	+2290152411317	28	CEG DU LAC	\N	actif	2026-08-31 13:33:21.951134+00	\N
668	J08265432	AHIHA	Joanès	+2290152411317	28	CEG DU LAC	\N	actif	2026-08-31 13:34:08.581075+00	\N
46	J08266596	ALI	Nabilath	+2290197234996	1	CEG DU LAC	\N	actif	2026-08-25 20:08:44.262153+00	\N
670	J08263647	AKAKPO	Marie Jeanne	+2290162360149	28	CEG DU LAC	\N	actif	2026-08-31 13:46:48.436476+00	\N
671	J08269684	ADEOSSI	Sergino	+2290156369257	28	CEG DU LAC	\N	actif	2026-08-31 13:47:35.482283+00	\N
674	J08265023	GNANSOUNOU	William	+2290147468030	28	CEG DU LAC	\N	actif	2026-08-31 13:50:13.17849+00	\N
676	J08263162	HOUNGA	Eric	+2290159876708	28	CEG DU LAC	\N	actif	2026-08-31 13:52:15.303478+00	\N
677	J08269644	HOUNKONDE	Christ	+2290196343525	28	CEG DU LAC	\N	actif	2026-08-31 13:52:59.334329+00	\N
678	J08261480	OGOUDJOBI	Mounirath	+2290144362871	28	CEG DU LAC	\N	actif	2026-08-31 13:54:02.891058+00	\N
693	J08262861	BATOSSI	Alexia	+2290157156505	25	CEG DU LAC	\N	actif	2026-08-31 14:34:58.252777+00	\N
681	J08262231	TOKPO	Dieu donné	+2290191494040	28	CEG DU LAC	\N	actif	2026-08-31 13:57:43.309758+00	\N
669	J08262391	AHOUANGONOU	Pauline	+2290148883807	20	CEG DU LAC	\N	actif	2026-08-31 13:45:47.956552+00	\N
673	J08266047	BOTON FATCHE	Augustin	+2290148988068	1	CEG DU LAC	\N	actif	2026-08-31 13:49:22.050227+00	\N
675	J08264804	HONFO	Adjimon Jean	+2290197278334	1	CEG DU LAC	\N	actif	2026-08-31 13:51:07.4033+00	\N
679	J08269868	QUENUM	Miracle	+2290197928516	1	CEG DU LAC	\N	actif	2026-08-31 13:54:45.95575+00	\N
695	J08267178	IMOROU	Nabil	+2290197690110	25	CEG DU LAC	\N	actif	2026-08-31 14:37:08.591762+00	\N
680	J08263582	TODE	Alexandre	+2290190480306	28	CEG DU LAC	\N	actif	2026-08-31 13:56:35.194644+00	\N
683	J08265238	ZINSOU	Sènami	+2290143139424	28	CEG DU LAC	\N	actif	2026-08-31 13:59:23.202302+00	\N
691	J08266944	KANGNI	Fernande	+2290196144429	27	CEG DU LAC	\N	actif	2026-08-31 14:25:46.952515+00	\N
685	J08266114	FOHOU	Tite	+2290167066737	27	CEG DU LAC	\N	actif	2026-08-31 14:08:53.406011+00	\N
686	J08267310	VICTOR VITOHOUINDJI	Appolinaire	+2290197404660	27	CEG DU LAC	\N	actif	2026-08-31 14:09:56.105883+00	\N
699	J08264161	DANKE	Junior	+2290197282214	18	CEG DU LAC	\N	actif	2026-08-31 14:49:14.178537+00	\N
701	J08269518	HOUNGBEMEY	Emmanuella	+2290197987888	18	CEG DU LAC	\N	actif	2026-08-31 14:51:34.909784+00	\N
708	J08265739	ADJASSOHO	Bernard	+2290194268533	17	CEG DU LAC	\N	actif	2026-08-31 15:27:49.347844+00	\N
710	J08267282	AHIDE	Dimitri Enguerran	+2290151901775	17	CEG DU LAC	\N	actif	2026-08-31 15:29:51.245757+00	\N
711	J08264907	AHISSOU	Myriam	+2290197943352	17	CEG DU LAC	\N	actif	2026-08-31 15:30:51.958894+00	\N
712	J08262838	DJIGBE	Pascal	+2290197501905	17	CEG DU LAC	\N	actif	2026-08-31 15:31:55.687855+00	\N
713	J08262067	GBADAMASSI	Nadjib	+2290196353521	17	CEG DU LAC	\N	actif	2026-08-31 15:33:25.202802+00	\N
714	J08268190	HOUNSAVOU	Merveille	+2290196435343	17	CEG DU LAC	\N	actif	2026-08-31 15:34:21.064974+00	\N
717	J08267578	OLAITAN	Kêphil	+2290196828789	17	CEG DU LAC	\N	actif	2026-08-31 15:37:15.192742+00	\N
719	J08267165	ZANNOU	Grâce	+2290197278211	17	CEG DU LAC	\N	actif	2026-08-31 15:38:52.487063+00	\N
729	J08268324	ONELECHI	Chiamaka	+2290196982815	22	CEG DU LAC	\N	actif	2026-08-31 16:17:36.947357+00	\N
731	J08267022	SAGBO	Rebecca	+2290151828951	22	CEG STE RITA	\N	actif	2026-08-31 16:19:24.880975+00	\N
732	J08265891	AFFO	Roukayath	+2290197498175	8	CEG DU LAC	\N	actif	2026-08-31 16:28:30.48894+00	\N
733	J08269857	AFOUFOU	Raymond	+2290197181891	8	COLLÈGE LA RÉFÉRENCE	\N	actif	2026-08-31 16:29:57.843769+00	\N
734	J08267751	AKPOTINKPE	Jacqueline	+2290142551336	8	CEG DU LAC	\N	actif	2026-08-31 16:30:48.156048+00	\N
735	J08263781	ASSONGBA	Ruth	+2290197649591	8	CEG STE RITA	\N	actif	2026-08-31 16:33:00.024608+00	\N
736	J08263809	ATEDJI	Madine	+2290194981612	8	CEG DU LAC	\N	actif	2026-08-31 16:33:55.467176+00	\N
737	J08263156	BALA	Aboubacar	+2290140357078	8	CEG DU LAC	\N	actif	2026-08-31 16:38:12.069562+00	\N
738	J08261574	KOTTIN	Modeste	+2290197686368	8	CEG DU LAC	\N	actif	2026-08-31 16:39:04.859097+00	\N
740	J08269599	MEVOGNON	Exelle	+2290197888605	8	CEG DU LAC	\N	actif	2026-08-31 16:41:23.904501+00	\N
741	J08267702	MIFOKPO	Jacqueline	+2290167318160	8	COLLÈGE LA RÉFÉRENCE	\N	actif	2026-08-31 16:42:30.646699+00	\N
742	J08268663	MIGNANWANDE	Gloria	+2290197036135	8	CEG DU LAC	\N	actif	2026-08-31 16:43:39.129423+00	\N
743	J08265326	ZOSSOU YOVO	Daniel	+2290196162912	8	COLLÈGE LA RÉFÉRENCE	\N	actif	2026-08-31 16:46:42.675699+00	\N
744	J08262221	GOUGBE	Athanase	+2290167258787	11	CEG DU LAC	\N	actif	2026-08-31 16:49:03.430575+00	\N
745	J08269014	HOUENOU	Miséricorde	+2290197185507	11	CEG DU LAC	\N	actif	2026-08-31 16:49:47.253107+00	\N
746	J08263975	ADOHOUNGBO	Lynce	+2290197080258	12	CEG DU LAC	\N	actif	2026-08-31 16:56:28.481538+00	\N
747	J08264485	AFIN	Aristide	+2290167333787	12	CEG DU LAC	\N	actif	2026-08-31 16:57:16.306404+00	\N
748	J08263532	AVLESSI	Pascal	+2290191909899	12	CEG DU LAC	\N	actif	2026-08-31 16:57:58.011549+00	\N
749	J08263273	BOTON	Dominique	+2290161966905	12	COLLÈGE LA RÉFÉRENCE	\N	actif	2026-08-31 16:58:47.388397+00	\N
750	J08268630	GUELIFO	Isidore	+2290197866174	12	CEG DU LAC	\N	actif	2026-08-31 17:00:05.272406+00	\N
751	J08265109	HOUESSOU	Junior	+2290147655984	12	CEG DU LAC	\N	actif	2026-08-31 17:01:02.358283+00	\N
752	J08266969	KOMABOU	Gédéon	+2290164071726	12	CEG DU LAC	\N	actif	2026-08-31 17:03:57.923771+00	\N
753	J08262890	LOKONON	Danick	+2290197762788	12	CEG DU LAC	\N	actif	2026-08-31 17:04:38.129159+00	\N
754	J08269076	MOUNIROU	Kadidjath	+2290193598632	12	CEG DU LAC	\N	actif	2026-08-31 17:05:29.858767+00	\N
755	J09267335	ADIKPETO	Espoir	+2290197659517	28	CEG DU LAC	\N	actif	2026-09-02 19:08:26.887542+00	\N
758	J09261849	AZONHOUBO	William	+2290166997753	28	CEG DU LAC	\N	actif	2026-09-02 19:08:28.375658+00	\N
759	J09265073	BATCHO	Carlos	+2290197942994	28	CEG DU LAC	\N	actif	2026-09-02 19:08:28.791341+00	\N
760	J09264793	DOSSA	Emmanuella La Rose	+2290197242647	28	CEG DU LAC	\N	actif	2026-09-02 19:08:29.179345+00	\N
761	J09269129	DOVONON	Donald	+2290167758786	28	CEG DU LAC	\N	actif	2026-09-02 19:08:29.956516+00	\N
763	J09261702	ETIKO	Kékéli Esther	+2290199465253	28	CEG DU LAC	\N	actif	2026-09-02 19:08:30.896418+00	\N
764	J09268392	FASSINOU	Chabel	+2290140643033	28	CEG DU LAC	\N	actif	2026-09-02 19:08:31.331034+00	\N
765	J09263590	GANHOUEDO	Jacques	+2290195885783	28	CEG DU LAC	\N	actif	2026-09-02 19:08:31.736526+00	\N
766	J09267843	HOUNDJENOUKON	Modeste	+2290197824150	28	CEG DU LAC	\N	actif	2026-09-02 19:08:32.316275+00	\N
728	J08268681	OLAITAN	Rafiath	+2290192174585	3	FRANCO ARABE	\N	actif	2026-08-31 16:16:55.202282+00	\N
739	J08264199	MAIGA	Fadie	+2290198076741	24	CEG DU LAC	\N	actif	2026-08-31 16:40:22.399744+00	\N
756	J09264012	ADJIBAWO	Sabine	+2290197839039	1	CEG DU LAC	\N	actif	2026-09-02 19:08:27.361416+00	\N
757	J09268132	AGUEMON	Junior	+2290159915355	1	CEG DU LAC	\N	actif	2026-09-02 19:08:27.815391+00	\N
700	J08269070	HONNAHO	Jahsther	+2290196103022	25	CEG DU LAC	\N	actif	2026-08-31 14:50:52.546594+00	\N
702	J08268466	ODJO	Archimède	+2290197640434	25	CEG DU LAC	\N	actif	2026-08-31 14:52:42.799212+00	\N
709	J08267531	ADOGNON	Madochée	+2290196814068	26	CEG DU LAC	\N	actif	2026-08-31 15:28:54.691525+00	\N
703	J08265396	DENAKPO	Lydie	+2290196970092	26	CEG DU LAC	\N	actif	2026-08-31 14:55:27.760994+00	\N
704	J08266304	HINSON	Daniel	+2290192917047	26	CEG DU LAC	\N	actif	2026-08-31 14:56:23.781802+00	\N
715	J08265804	HOUNYE	Inès	+2290196569085	26	CEG DU LAC	\N	actif	2026-08-31 15:35:22.655723+00	\N
716	J08267985	MIGNANHOUANDE	Mathias	+2290197144058	26	CEG DU LAC	\N	actif	2026-08-31 15:36:13.19167+00	\N
718	J08263723	SESSINOU	Sydney	+2290195782472	26	CEG DU LAC	\N	actif	2026-08-31 15:38:11.814937+00	\N
720	J08263504	AHEHEHINNOU	Carmelle	+2290152236032	26	COLLEGE STE FACE	\N	actif	2026-08-31 16:09:06.786589+00	\N
721	J08261881	ALODEDJI	Merveille	+2290197226286	26	CEG DU LAC	\N	actif	2026-08-31 16:10:26.354712+00	\N
722	J08267663	AMITIN	Sylviane	+2290196622466	26	CEG DU LAC	\N	actif	2026-08-31 16:11:23.189249+00	\N
723	J08264481	AZAINON	Catherin	+2290166820096	26	CEG DU LAC	\N	actif	2026-08-31 16:13:17.9021+00	\N
705	J08267448	AZONSI	Esther	+2290167487836	26	CEG DU LAC	\N	actif	2026-08-31 14:59:23.709212+00	\N
724	J08267627	DAH AGOLI	Leslie	+2290141986010	26	CEG STE RITA	\N	actif	2026-08-31 16:14:05.617616+00	\N
726	J08265077	DOSSOU	Tatiana	+2290197346306	26	CEG DU LAC	\N	actif	2026-08-31 16:15:24.349774+00	\N
725	J08262935	DOSSOU	Elysée	+2290196624304	26	CEG DU LAC	\N	actif	2026-08-31 16:14:45.391184+00	\N
706	J08267221	GNONLONFOUN	Regina	+2290197174323	26	LA RÉFÉRENCE	\N	actif	2026-08-31 15:00:49.577023+00	\N
727	J08263104	HOUNGA	Chancelle	+2290157606352	26	CEG DU LAC	\N	actif	2026-08-31 16:16:13.610014+00	\N
730	J08263194	OUSSOUGBO	Dieu donné	+2290140438774	26	CEG DU LAC	\N	actif	2026-08-31 16:18:22.097871+00	\N
707	J08265494	HOUEDJIEKPON	Esther	+2290195434783	17	CEG DU LAC	\N	actif	2026-08-31 15:01:54.826475+00	\N
772	J09265808	TOTCHOU	Akonassou Appolinaire	+2290197126481	28	CEG DU LAC	\N	actif	2026-09-02 19:08:35.141423+00	\N
776	J09264109	AVOTOGNIN	Cécile	+2290191019529	28	CEG DU LAC	\N	actif	2026-09-02 19:08:36.947428+00	\N
780	J09265349	NOUVOESSI	Armandine Chérita	+2290197061113	28	CEG DU LAC	\N	actif	2026-09-02 19:08:38.562144+00	\N
788	J09266836	BOSSA	Abigaelle Fifamè	+2290195304423	28	CEG DU LAC	\N	actif	2026-09-02 19:08:42.751643+00	\N
792	J09265284	DOMINGO	Friclesse	+2290144383135	28	CEG DU LAC	\N	actif	2026-09-02 19:08:44.668547+00	\N
796	J09268744	HOUEGLO	Qéren	+2290164272278	28	CEG DU LAC	\N	actif	2026-09-02 19:08:46.60354+00	\N
800	J09262385	LOKOSSOU	David	+2290195549916	28	CEG DU LAC	\N	actif	2026-09-02 19:08:48.462465+00	\N
804	J09263577	VILOHOUNDJI	Noelie	+2290167527543	28	CEG DU LAC	\N	actif	2026-09-02 19:08:50.324056+00	\N
809	J09268260	AKONDE	Esaie	+2290193892858	28	CEG DU LAC	\N	actif	2026-09-02 19:08:52.615659+00	\N
813	J09267531	ASSOGBA	Andréa	+2290196001070	28	CEG DU LAC	\N	actif	2026-09-02 19:08:54.516833+00	\N
817	J09268736	DOSSOU	Rolande	+2290166251599	28	CEG DU LAC	\N	actif	2026-09-02 19:08:56.468855+00	\N
821	J09266345	MITONGNON	Aurelie	+2290197821561	28	CEG DU LAC	\N	actif	2026-09-02 19:08:58.165638+00	\N
829	J09262248	HOUNGUE	Vivien	+2290164369350	28	CEG DU LAC	\N	actif	2026-09-02 19:09:01.741055+00	\N
833	J09264806	MITCHODIGNI	Immaculée	+2290151029128	28	CEG DU LAC	\N	actif	2026-09-02 19:09:03.440973+00	\N
767	J09261706	HOUNYE	Dossou Firmin	+2290162362342	1	CEG DU LAC	\N	actif	2026-09-02 19:08:32.715052+00	\N
784	J09265900	ADAKE	Gisèle	+2290195588948	1	CEG DU LAC	\N	actif	2026-09-02 19:08:40.626923+00	\N
825	J09266929	ADANGNIKOUN	Stébane	+2290197126039	20	CEG DU LAC	\N	actif	2026-09-02 19:08:59.857794+00	\N
768	J09262646	NICOUE	Emmanuella	+2290191379000	28	CEG DU LAC	\N	actif	2026-09-02 19:08:33.167595+00	\N
773	J09267122	VIMEGNON	Liliane	+2290168925469	28	CEG DU LAC	\N	actif	2026-09-02 19:08:35.616831+00	\N
781	J09265860	OKE	Robencia	+2290158171556	28	CEG DU LAC	\N	actif	2026-09-02 19:08:39.014175+00	\N
785	J09263937	ADANMAHO	Ruth Fifamè	+2290141428811	28	CEG DU LAC	\N	actif	2026-09-02 19:08:41.062904+00	\N
789	J09263789	DJAGBA	Majoie	+2290144148432	28	CEG DU LAC	\N	actif	2026-09-02 19:08:43.183518+00	\N
797	J09268255	KOUNOUME	Léonielle	+2290197502544	28	CEG DU LAC	\N	actif	2026-09-02 19:08:47.083237+00	\N
801	J09267638	NADALEDJI	Divine	+2290197030346	28	CEG DU LAC	\N	actif	2026-09-02 19:08:48.888447+00	\N
810	J09265065	AMADOU	Nadia	+2290165545304	28	CEG DU LAC	\N	actif	2026-09-02 19:08:53.030449+00	\N
814	J09261373	BABAT	Moustadjab	+2290197315034	28	CEG DU LAC	\N	actif	2026-09-02 19:08:55.182503+00	\N
818	J09261801	GNANSOUNOU	Toussaint	+2290169696311	28	CEG DU LAC	\N	actif	2026-09-02 19:08:56.924681+00	\N
822	J09263014	TCHEZOUNME	Mickael	+2290147375790	28	CEG DU LAC	\N	actif	2026-09-02 19:08:58.578846+00	\N
826	J09268643	DJIVO	David	+2290197740103	28	CEG DU LAC	\N	actif	2026-09-02 19:09:00.268625+00	\N
834	J09267367	OUSSA	Jahou Samuel	+2290197060217	28	CEG DU LAC	\N	actif	2026-09-02 19:09:04.000245+00	\N
805	J09264694	VITIN	Anath Elisée	+2290151509219	20	CEG DU LAC	\N	actif	2026-09-02 19:08:50.7413+00	\N
777	J09264246	GANDJEMEDE	Dorcas	+2290198744183	1	CEG DU LAC	\N	actif	2026-09-02 19:08:37.352103+00	\N
793	J09269735	FOLY-KOUTODJO	Cathérine	+2290197797473	1	CEG DU LAC	\N	actif	2026-09-02 19:08:45.137625+00	\N
830	J09261318	HOUNSA	Gédéon	+2290196961885	20	CEG DU LAC	\N	actif	2026-09-02 19:09:02.159745+00	\N
769	J09261449	SOVIGUIDI	Dègnon Emmanuel	+2290166292136	28	CEG DU LAC	\N	actif	2026-09-02 19:08:33.64143+00	\N
770	J09263478	TCHEHOUNDJE	Y. Rolande	+2290197289871	28	CEG DU LAC	\N	actif	2026-09-02 19:08:34.282065+00	\N
774	J09261308	VIMEGNON	Ruth	+2290168925469	28	CEG DU LAC	\N	actif	2026-09-02 19:08:36.025231+00	\N
778	J09269126	LAWANI	Moukaram	+2290192794830	28	CEG DU LAC	\N	actif	2026-09-02 19:08:37.75718+00	\N
782	J09268647	SAGBADJOU	Abdoul Rachid	+2290197656448	28	CEG DU LAC	\N	actif	2026-09-02 19:08:39.51339+00	\N
786	J09264500	AMOUVI	Ange	+2290148257625	28	CEG DU LAC	\N	actif	2026-09-02 19:08:41.909171+00	\N
790	J09264891	DJOSSOU	Oronce Neymar	+2290196005453	28	CEG DU LAC	\N	actif	2026-09-02 19:08:43.614512+00	\N
794	J09267532	GOUTOLOU	Pacome Samson	+2290191800905	28	CEG DU LAC	\N	actif	2026-09-02 19:08:45.56578+00	\N
798	J09264872	LANHOUNHEDO	Emmanuel	+2290152693008	28	CEG DU LAC	\N	actif	2026-09-02 19:08:47.536457+00	\N
811	J09263334	AMOUSSA	Moussina	+2290151805395	28	CEG DU LAC	\N	actif	2026-09-02 19:08:53.462015+00	\N
819	J09263038	KETE BERTINE	Bertine	+2290143415256	28	CEG DU LAC	\N	actif	2026-09-02 19:08:57.355167+00	\N
831	J09266748	HOUNYEME	Thomas	+2290169050750	28	CEG DU LAC	\N	actif	2026-09-02 19:09:02.567665+00	\N
836	J09263721	SALAKO	Hermann Jonas	+2290196385581	28	CEG DU LAC	\N	actif	2026-09-02 19:09:05.227143+00	\N
815	J09268212	DEDJI	Maximilienne	+2290162129301	20	CEG DU LAC	\N	actif	2026-09-02 19:08:55.63603+00	\N
802	J09262545	OKE	Miracle Martine	+2290140392837	20	CEG DU LAC	\N	actif	2026-09-02 19:08:49.302403+00	\N
806	J09267084	ZOSSOU	Charles	+2290156444783	20	CEG DU LAC	\N	actif	2026-09-02 19:08:51.168053+00	\N
823	J09266731	TOTIN	Judicael	+2290153236106	20	CEG DU LAC	\N	actif	2026-09-02 19:08:58.987155+00	\N
827	J09263247	HOSSOU	Sidonie Fifamè	+2290197287662	20	CEG DU LAC	\N	actif	2026-09-02 19:09:00.685219+00	\N
835	J09267989	OUSSOU	Tadagbé José	+2290197876891	20	CEG DU LAC	\N	actif	2026-09-02 19:09:04.637459+00	\N
771	J09269223	TOITCHA	Euphraim Jonas	+2290196581166	28	CEG DU LAC	\N	actif	2026-09-02 19:08:34.690769+00	\N
775	J09264493	AKINOTCHO	Aladé	+2290197521051	28	CEG DU LAC	\N	actif	2026-09-02 19:08:36.440965+00	\N
779	J09269688	LAWANI	Wassi	+2290192794830	28	CEG DU LAC	\N	actif	2026-09-02 19:08:38.149407+00	\N
787	J09261956	BADA	Prisca	+2290197939552	28	CEG DU LAC	\N	actif	2026-09-02 19:08:42.347668+00	\N
791	J09263669	DJOTINEKPO	Gaston	+2290196613350	28	CEG DU LAC	\N	actif	2026-09-02 19:08:44.263009+00	\N
795	J09269357	HASSANE	Leila	+2290197940052	28	CEG DU LAC	\N	actif	2026-09-02 19:08:45.981539+00	\N
799	J09266613	LOKONON	Dénis	+2290161628886	28	CEG DU LAC	\N	actif	2026-09-02 19:08:48.042787+00	\N
803	J09267144	SANTOS	Espoir	+2290197856413	28	CEG DU LAC	\N	actif	2026-09-02 19:08:49.909362+00	\N
812	J09262009	AMOUSSA	Manfazath	+2290151805395	28	CEG DU LAC	\N	actif	2026-09-02 19:08:53.889135+00	\N
816	J09262979	DOSSOU	Firmin	+2290197580095	28	CEG DU LAC	\N	actif	2026-09-02 19:08:56.076656+00	\N
824	J09263552	ADANGNIKOU	Ulrich Vianney	+2290148044994	28	CEG DU LAC	\N	actif	2026-09-02 19:08:59.443299+00	\N
832	J09264910	KPATINVO	Sofiath	+2290197902376	28	CEG DU LAC	\N	actif	2026-09-02 19:09:03.02428+00	\N
837	J09263882	TITO	Daniel	+2290196874193	20	CEG DU LAC	\N	actif	2026-09-12 19:19:16.043039+00	\N
838	Y09263372	SOUNOUVOU	Michel	+2290151255990	13	CEG YAGBE	\N	actif	2026-09-12 19:27:08.35551+00	\N
840	J09261410	QUENUM	David	+2290197397395	20	CEG DU LAC	\N	actif	2026-09-12 19:38:09.527734+00	\N
841	J09267209	AGOUNDO	Princesse	+2290162591227	20	CEG DU LAC	\N	actif	2026-09-12 19:41:58.566468+00	\N
842	Y09267327	DENAKPO	Prince André	+2290197118590	13	CEG YAGBE	\N	actif	2026-09-12 19:54:42.812334+00	\N
820	J09264613	LOKOSSOU	Exaucée	+2290196007792	20	CEG DU LAC	\N	actif	2026-09-02 19:08:57.739639+00	\N
880	J09263199	ALLAGBE	Josué Boris	+2290197601477	5	CEG STE RITA	\N	actif	2026-09-17 22:19:05.676706+00	\N
843	Y09264628	AGOSSOU	Mariela	+2290165440636	13	CEG YAGBE	\N	actif	2026-09-12 20:05:27.793934+00	\N
844	J09261290	DAGBA	Othniella	+2290195810335	20	CEG DU LAC	\N	actif	2026-09-12 20:13:58.19492+00	\N
845	J09262759	ASSOGBA	Gaël	+2290197456393	8	CEG STE RITA	\N	actif	2026-09-12 20:32:23.352374+00	\N
846	J09264839	QUENUM	Précieux	+2290197397395	3	CEG STE RITA	\N	actif	2026-09-12 20:39:17.483913+00	\N
847	J09267055	AGOUNDO	Exaucé	+2290162591227	17	CEG DU LAC	\N	actif	2026-09-12 21:05:33.232988+00	\N
848	J09263304	CHOGOLOU	Junior	+2290195319539	23	CEG DANTOKPA	\N	actif	2026-09-12 21:15:05.284985+00	\N
849	J09264707	LANLENOU	Justin	+2290197172092	3	CEG DU LAC	\N	actif	2026-09-12 21:21:43.226122+00	\N
850	Y09263780	MEDEKO	Samétane	+2290197867177	14	CEG YAGBE	\N	actif	2026-09-12 21:24:38.149321+00	\N
851	J09261864	DAGBA	Hermance	+2290195810335	23	CEG STE RITA	\N	actif	2026-09-12 21:26:17.312251+00	\N
852	J09265772	DJOSSOU	Assanath	+2290151123040	8	CEG DU LAC	\N	actif	2026-09-14 10:44:42.72106+00	\N
853	J09267715	NIANDOU	Mohamed	+2290191392646	8	CEG DU LAC	\N	actif	2026-09-14 10:51:41.683738+00	\N
855	J09264479	AZONSI	Miracle	+2290197191212	23	CEG DANTOKPA	\N	actif	2026-09-14 11:07:08.375256+00	\N
857	Y09261630	OUMAROU	Ramatou	+2290166852743	13	CEG YAGBE	\N	actif	2026-09-14 11:31:42.720669+00	\N
858	Y09261367	ASSOCLE	Esther	+2290196356528	13	CEG YAGBE	\N	actif	2026-09-14 11:32:40.95348+00	\N
860	Y09264641	FASSINOU	Esther	+2290152178043	15	CEG YAGBE	\N	actif	2026-09-14 11:35:36.664978+00	\N
861	Y09263033	HOUNGA	Océane	+2290196325178	15	CEG YAGBE	\N	actif	2026-09-14 11:36:09.765438+00	\N
862	Y09264799	LOKO	Cyr	+2290152147964	15	CEG YAGBE	\N	actif	2026-09-14 11:36:45.332492+00	\N
863	Y09267706	ADAMOU	Rassida	+2290152478143	16	CEG YAGBE	\N	actif	2026-09-14 11:38:05.796238+00	\N
864	Y09269856	AMOUSSOU	Junior	+2290147853120	16	CEG YAGBE	\N	actif	2026-09-14 11:38:43.400765+00	\N
865	Y09262133	DJIMASSA	Caméria	+2290192123582	16	CEG YAGBE	\N	actif	2026-09-14 11:39:24.50902+00	\N
866	Y09265856	DOSSOU	Bernadin	+2290152177036	16	CEG YAGBE	\N	actif	2026-09-14 11:41:02.522304+00	\N
867	Y09262887	GADO	Ismaël	+2290147521967	16	CEG YAGBE	\N	actif	2026-09-14 11:41:40.768439+00	\N
868	Y09268075	HOUNNOU	Sandrine	+2290166371528	16	CEG YAGBE	\N	actif	2026-09-14 11:42:19.983829+00	\N
869	Y09261514	MINTOWANOU	Christiane	+2290166538219	16	CEG YAGBE	\N	actif	2026-09-14 11:43:11.278615+00	\N
871	J09264448	FALOLA	Rodrigue	\N	23	CEG DU LAC	\N	actif	2026-09-14 11:48:23.3918+00	+2290197146599
872	J09262610	FALOLA	Roselin	+2290197146599	2	CEG DU LAC	\N	actif	2026-09-14 11:49:12.747193+00	\N
873	J09267412	TOKPANOU	Bérenger	+2290195866169	1	CEG STE RITA	\N	actif	2026-09-14 12:03:27.604821+00	\N
874	J09268021	YESSOUFOU	Fathihiyath	+2290196095575	18	CEG DANTOKPA	\N	actif	2026-09-14 12:08:15.642552+00	\N
875	J09261819	AVOCE	Estella	+2290196386603	8	CEG DU LAC	\N	actif	2026-09-16 21:49:02.826014+00	\N
876	J09264484	GANHOUNOUTO	Miracle	+2290195533360	20	CEG STE RITA	\N	actif	2026-09-16 22:04:09.429384+00	\N
877	J09268939	GANHOUNOUTO	Emma	+2290195533360	5	CEG STE RITA	\N	actif	2026-09-16 22:05:01.072277+00	\N
878	J09265398	BALA	Faouziyath	+2290140357078	6	CEG DU LAC	\N	actif	2026-09-16 22:12:35.466017+00	\N
879	J09265604	ANATO	Gracia	+2290197267378	17	CEG STE RITA	\N	actif	2026-09-17 14:47:11.013051+00	\N
881	J09267623	YESSOUFOU	Farhane	+2290196095575	8	CEG DANTOKPA	\N	actif	2026-09-19 00:33:50.091546+00	\N
883	J09268409	LOKONON	Anaëlle	+2290197762788	17	CEG DU LAC	\N	actif	2026-09-19 01:01:25.112038+00	\N
884	J09264856	ABLADON	Sylvano	+2290197657850	17	CEG DU LAC	\N	actif	2026-09-19 01:07:15.285341+00	\N
885	J09265762	ABLADON	Abelline	+2290197657850	2	CEG DU LAC	\N	actif	2026-09-19 01:14:39.214789+00	\N
886	J09265908	SEWA	Marie Lyne	+2290197473838	1	CEG DU LAC	\N	actif	2026-09-20 07:49:36.492955+00	\N
762	J09267751	ESSOU	Valentine	+2290197276399	1	CEG DU LAC	\N	actif	2026-09-02 19:08:30.39158+00	\N
887	J09268034	AVLOKO	Farahane Mohamed	+2290166920827	1	CEG GBEGAMEY	\N	actif	2026-09-20 09:03:11.669221+00	\N
888	J09262081	BOCCO	Angélique	\N	1	CEG DU LAC	\N	actif	2026-09-20 10:27:53.030517+00	+2290197796471
870	J09261873	FALOLA	Gloria	+2290197146599	5	CEG DU LAC	\N	actif	2026-09-14 11:47:26.125112+00	\N
859	Y09263520	AWOUNOU	Emmanuella	+2290197415823	15	CEG YAGBE	\N	actif	2026-09-14 11:34:57.362975+00	\N
882	J09265700	GBEDO	Alex Sého	+2290197120811	20	CEG STE RITA	\N	actif	2026-09-19 00:43:50.033618+00	\N
783	J09267885	ABDOUL	Mariama	+2290194444523	1	CEG DU LAC	\N	actif	2026-09-02 19:08:40.191732+00	\N
807	J09265826	ABDOUL	Fatima	+2290161341396	20	CEG DU LAC	\N	actif	2026-09-02 19:08:51.655395+00	\N
828	J09262629	HOUNGA	Abigaelle	+2290197734530	20	CEG DU LAC	\N	actif	2026-09-02 19:09:01.095153+00	\N
839	J09263404	AGBOESSI	Marie Lumière	+2290196913075	20	COLLEGE STE CÉCILE	\N	actif	2026-09-12 19:33:06.185915+00	\N
854	J09267937	NIANDOU	Marouane	+2290191392646	26	CEG DU LAC	\N	actif	2026-09-14 10:56:42.487161+00	\N
889	J09266361	ZOTOGBE	Presley	+2290197681951	20	CEG DU LAC	\N	actif	2026-09-20 11:18:45.278531+00	\N
890	J09268322	HOUNTONDJI	Faoziath Aminath	+2290167703637	20	CEG DU LAC	\N	actif	2026-09-20 11:29:24.571259+00	\N
891	J09269107	HOUNTONDJI	Affissou	+2290167703637	20	CEG DU LAC	\N	actif	2026-09-20 11:30:58.441488+00	\N
892	J09265561	ADDY	Prince	\N	20	CEG DU LAC	\N	actif	2026-09-20 11:32:54.087636+00	+2290152240723
893	J09268851	WIGNANON	Phanuel	+2290141808865	20	CEG DU LAC	\N	actif	2026-09-20 11:34:36.246688+00	\N
894	J09266244	YABI	Chérifath	+2290147519987	2	CEG STE RITA	\N	actif	2026-09-20 11:55:32.735017+00	+2290197193836
895	J09264171	GANDONOU	Jaï-Christ	+2290197745255	2	CEG DU LAC	\N	actif	2026-09-20 11:58:12.943978+00	+2290147353783
896	J09264702	ACCROMBESSI	Robert	+2290197603711	2	CS LA RÉFÉRENCE	\N	actif	2026-09-20 12:00:06.884261+00	\N
897	J09265173	ADELOU	Michel Alix	+2290197403766	19	CEG DU LAC	\N	actif	2026-09-20 12:01:50.728376+00	+2290193718383
898	J09263770	OGOUBIYI	Nanyimanth	+2290197080216	19	CEG DU LAC	\N	actif	2026-09-20 12:11:28.461317+00	\N
900	J09262749	FADELE	Prince	+2290166731515	3	CEG DU LAC	\N	actif	2026-09-20 12:15:58.024381+00	+2290144970296
901	J09263905	DEGBOGBAHOUN	Samuel	\N	3	CEG DU LAC	\N	actif	2026-09-20 12:19:47.232992+00	+2290147079808
902	J09263051	HOUNSOU	Sélim Hamdrim	+2290197596533	3	CEG STE RITA	\N	actif	2026-09-20 12:22:35.561284+00	+2290143242625
903	J09264447	AVLOKO	Fadilath	+2290166920827	3	CEG GBEGAMEY	\N	actif	2026-09-20 12:24:14.584627+00	\N
904	J09266209	KPETOTON	Dorcas	+2290196310287	3	CEG DU LAC	\N	actif	2026-09-20 12:26:00.472763+00	\N
905	J09262320	AGUIDA	Raphaëlla	+2290197540087	3	CEG DANTOKPA	\N	actif	2026-09-20 12:29:58.726682+00	\N
906	J09261874	CODOHOUNSIN	Roberte	+2290196881398	3	CEG DANTOKPA	\N	actif	2026-09-20 12:32:03.444313+00	\N
907	J09269168	DEDJAN	Ronel	+2290197271667	3	CEG DANTOKPA	\N	actif	2026-09-20 12:33:35.748944+00	\N
908	J09265217	ADEGBINDIN	Sodic	+2290197190362	3	CEG DU LAC	\N	actif	2026-09-20 12:35:51.833631+00	\N
910	J09263774	TOLEFO	Marie Félicité	+2290196201911	18	CEG DU LAC	\N	actif	2026-09-20 12:53:58.607935+00	\N
913	J09262617	AHOWEKOUN	Gloria Lydie	+2290196621644	23	CEG DU LAC	\N	actif	2026-09-20 13:00:05.598163+00	+2290147982057
914	J09261251	AKAKPOVI	Daria	+2290195341070	23	CEG DU LAC	\N	actif	2026-09-20 13:11:08.690634+00	+2290196119393
915	J09262765	GANDONOU	Jirince	+2290197745255	23	CEG DU LAC	\N	actif	2026-09-20 13:12:28.599+00	+2290147353783
916	J09262521	KPEHOUNTON	Augustin	+2290167555423	23	CEG LE NOKOUE	\N	actif	2026-09-20 13:14:06.905264+00	\N
917	J09264268	ZOTOGBE	Philomey	+2290197681951	8	CEG DU LAC	\N	actif	2026-09-20 13:15:38.036665+00	\N
918	J09268232	KPEHOUNTON	Auguste	+2290167555423	8	CEG LE NOKOUE	\N	actif	2026-09-20 13:16:51.468242+00	\N
919	J09267586	HOUNGNISSI	Victoire	\N	8	CEG DU LAC	\N	actif	2026-09-20 13:18:44.239329+00	+2290197283985
920	J09269442	HOLO	Doris	+2290197733551	8	CEG DU LAC	\N	actif	2026-09-20 13:20:34.193844+00	\N
921	J09267044	BOUKARI	Bakiath	+2290196915692	7	CEG DU LAC	\N	actif	2026-09-20 13:22:12.935919+00	\N
923	J09267416	DEDEWANOU	Chancelle	+2290166035959	23	CEG DANTOKPA	\N	actif	2026-09-20 13:34:22.670149+00	\N
924	J09268180	SEKPONNA	Noëlie	+2290197011503	6	CEG DU LAC	\N	actif	2026-09-20 13:35:21.542828+00	\N
925	J09266868	DANSI-GAN	Godwin	+2290197261814	6	CEG DANTOKPA	\N	actif	2026-09-20 13:37:28.4925+00	\N
926	J09263314	HOUNSOUKPE	Adrien	+2290194940807	6	CEG DU LAC	\N	actif	2026-09-20 13:39:11.255048+00	\N
927	J09263981	HINVI	Rayane	+2290197037460	23	CEG DU LAC	\N	actif	2026-09-20 13:40:08.745562+00	\N
928	J09267263	DEGUENONVO	Estelle	+2290197011503	3	CEG DU LAC	\N	actif	2026-09-20 13:41:22.063265+00	\N
929	J09262762	GBESSI-SEWA	Prisca	+2290197558787	3	CEG DU LAC	\N	actif	2026-09-20 13:42:15.88935+00	\N
930	J09266774	ADEROMOU	Victorine	+2290197071411	3	CEG DU LAC	\N	actif	2026-09-20 13:43:24.647044+00	\N
931	J09262619	ALLAGBE	Espoir	+2290197601477	3	CEG STE RITA	\N	actif	2026-09-20 13:46:50.42332+00	\N
932	J09263043	METOZOUNVE	Fati	+2290166583294	19	CEG DU LAC	\N	actif	2026-09-20 13:48:36.851794+00	\N
455	J08262339	LEGUEDE	Emmanuel	+2290197488643	8	CEG DU LAC	\N	actif	2026-08-25 22:30:22.898937+00	\N
933	Y09263625	ADJANOHOUN	Brice	+2290165192802	16	CEG SURU LÉRÉ	\N	actif	2026-09-20 14:39:59.42149+00	\N
934	Y09265129	NOUWE	Styve	+2290197199375	16	CEG YAGBE	\N	actif	2026-09-20 15:46:19.708624+00	\N
935	Y09269264	MAHUGBE	Emmanuelle	+2290167560380	13	CEG YAGBE	\N	actif	2026-09-20 18:27:57.477441+00	\N
936	Y09263279	MISSIKPODE	Celestine	+2290197345620	13	CEG YAGBE	\N	actif	2026-09-20 18:30:35.331496+00	\N
937	Y09263321	NOUWE	Brice	+2290197199375	15	CEG YAGBE	\N	actif	2026-09-20 18:36:47.432952+00	\N
938	Y09262008	ZANNOU	Dakshi	+2290152111412	15	CEG YAGBE	\N	actif	2026-09-20 18:40:07.059908+00	\N
939	Y09264387	ATINDEYETIN	David	+2290197470749	16	CEG YAGBE	\N	actif	2026-09-20 18:45:11.621148+00	\N
940	Y09263383	MIDINGOYI	Fidélia	+2290197749119	15	CEG YAGBE	\N	actif	2026-09-20 18:47:16.868291+00	\N
941	Y09268165	BONOU	Charlotte	\N	16	CEG YAGBE	\N	actif	2026-09-20 18:52:09.647193+00	+2290161245720
942	Y09267396	HOUNKPATIN	Even-Ezer	+2290197812323	16	CEG YAGBE	\N	actif	2026-09-20 18:53:37.38977+00	\N
943	Y09266329	MEZONLIN	Anne	+2290197752366	16	CEG YAGBE	\N	actif	2026-09-20 18:55:41.065412+00	\N
944	Y09267882	BISSIRIOU	Michkath	+2290196103789	16	CEG YAGBE	\N	actif	2026-09-20 19:01:18.593121+00	\N
945	Y09268019	CHALLA	Marie Rose	\N	15	CEG YAGBE	\N	actif	2026-09-20 19:05:01.14489+00	+2290196368040
946	Y09263356	AMOUSSOU	Maximiene	+2290166224816	15	CEG YAGBE	\N	actif	2026-09-20 19:06:51.280471+00	\N
947	Y09269126	DANSOU	Géovani	+2290197118312	14	CEG YAGBE	\N	actif	2026-09-20 19:08:17.279629+00	\N
948	Y09261632	KPOBLI	Melchior	+2290140527323	14	CEG YAGBE	\N	actif	2026-09-20 19:11:31.748315+00	\N
949	Y09269206	AGONVI	Prince	+2290197811988	15	CEG YAGBE	\N	actif	2026-09-20 19:12:50.251827+00	\N
951	J09268002	OLORIY	Chania	+2290141312012	8	CEG STE RITA	\N	actif	2026-09-20 19:51:21.593373+00	\N
952	J09264825	METEHOUE	Emmaüs	+2290167072405	17	CEG DU LAC	\N	actif	2026-09-20 19:52:55.587007+00	\N
953	J09269042	TOGNIFODE	Florence	+2290167080147	17	CEG DU LAC	\N	actif	2026-09-20 19:57:35.280492+00	\N
911	J09261990	DAGA	Camelia	\N	22	CEG STE RITA	\N	actif	2026-09-20 12:56:21.240862+00	+2290157527662
954	J09261584	ESSOU	Joseph	+2290197276399	17	CEG DANTOKPA	\N	actif	2026-09-20 20:01:46.96751+00	+2290161014286
620	Y08266252	MAHOUGBE	Alki	+2290167560380	15	CEG YAGBE	\N	actif	2026-08-26 05:09:34.965797+00	\N
899	J09267347	KOUNOUHO	Florentin	+2290151698954	27	CEG DU LAC	\N	actif	2026-09-20 12:12:58.345854+00	\N
909	J09262151	HAROUNA	Moubarak	+2290161360409	25	CEG DU LAC	\N	actif	2026-09-20 12:52:19.421304+00	+2290140347381
950	J09261868	OLORIY	Elsia	+2290141312012	25	CEG STE RITA	\N	actif	2026-09-20 19:47:55.364781+00	\N
808	J09264941	AHISSOU	Jean Eudes	+2290197061112	20	CEG DU LAC	\N	actif	2026-09-02 19:08:52.202838+00	\N
956	J09268472	BAOLA	Faosath	+2290163346290	10	CEG DU LAC	\N	actif	2026-09-20 20:07:41.817731+00	+2290197467939
957	Y09262129	DEGBO	Vianney	+2290191374618	13	CEG YAGBE	\N	actif	2026-09-21 10:46:36.408507+00	\N
958	Y09265713	GANDONOU	Janvier	+2290197214957	16	CEG YAGBE	\N	actif	2026-09-21 10:50:20.873989+00	\N
959	J09263137	HOUESSOU	Christy Belvie Ligth	+2290194997203	1	CEG DU LAC	\N	actif	2026-09-22 07:50:13.218212+00	\N
961	J09266436	AGBOTON	Oluwa Fèmi	+2290197379922	7	CEG DU LAC	\N	actif	2026-09-24 00:52:41.064933+00	\N
962	J09262370	GANNEYEDO	Merveille	+2290166852390	18	CEG DU LAC	\N	actif	2026-09-24 07:38:50.500755+00	\N
963	Y09267605	MELLO	Romuald	+2290162362692	13	CEG YAGBE	\N	actif	2026-09-24 16:18:14.452805+00	\N
964	J09266223	ADANNOU	Lucienne	+2290141565967	19	CEG DU LAC	\N	actif	2026-09-24 22:19:26.023908+00	\N
966	J09264452	DAASSI	Freud	+2290197262346	19	CEG DU LAC	\N	actif	2026-09-26 03:24:28.439725+00	\N
967	J09265092	HAMIDOU	Haruna	+2290197262346	19	CEG DU LAC	\N	actif	2026-09-26 03:25:29.98266+00	\N
968	J09262693	DAASSI	Armandine	+2290197262346	3	CEG DU LAC	\N	actif	2026-09-26 03:27:26.648978+00	\N
969	J09268778	DJOGBE	Anicette	+2290167514889	1	CEG DU LAC	\N	actif	2026-09-26 08:34:57.293366+00	\N
970	J09266458	TCHEHOUNDJE	Rolande	+2290140460674	20	CEG DU LAC	\N	actif	2026-09-26 09:08:26.971484+00	\N
971	J09266751	TCHIAKPE	Stella	+2290167613034	5	CEG STE RITA	\N	actif	2026-09-26 09:14:22.126411+00	\N
922	J09269454	CHOKKI	Basilia	+2290197942674	5	CEG DU LAC	\N	actif	2026-09-20 13:33:31.300953+00	\N
972	J09264202	TOGBEME	Jonathan	+2290192261790	6	CEG DU LAC	\N	actif	2026-09-26 09:18:06.55338+00	\N
973	J09266457	KOUDJANNAGNI	Lydie	+2290196720577	6	CEG DU LAC	\N	actif	2026-09-26 09:19:27.522887+00	\N
974	J09265408	HOUNGBE	Ouzziel	+2290196299052	23	CEG DU LAC	\N	actif	2026-09-26 09:23:08.510768+00	\N
975	J09267221	SEKPONNA	Merveille	+2290197011503	3	CEG DU LAC	\N	actif	2026-09-26 09:47:41.779537+00	\N
976	J09264607	TODJINOU	Océane	+2290197267528	19	CEG DANTOKPA	\N	actif	2026-09-26 15:02:30.364051+00	\N
977	J09265137	WHANNOU	Jeannine	+2290166168106	8	CEG DU LAC	\N	actif	2026-09-27 05:39:24.470869+00	\N
978	Y09265069	DOSSA	Précieux	+2290197056272	16	CEG YAGBE	\N	actif	2026-09-27 05:59:17.276136+00	\N
979	Y09263504	OGOUHOLA	Expédit	+2290197888932	15	CEG YAGBE	\N	actif	2026-09-27 06:01:09.718019+00	\N
980	J09267083	AMOUZOUN	Occens	+2290169781377	19	CEG ZOGBO	\N	actif	2026-09-27 07:12:35.176459+00	\N
981	Y09262152	BOGNON	Emmanuel	+2290140128403	16	CEG YAGBE	\N	actif	2026-09-27 12:41:07.39478+00	+2290161103570
982	Y09264911	ABOUBAKAR	Mohamed	+2290197774065	15	CEG YAGBE	\N	actif	2026-09-27 18:32:16.399938+00	\N
983	Y09261642	GOGAN	Pierre	+2290197033746	14	CEG YAGBE	\N	actif	2026-09-27 18:35:28.96427+00	\N
984	Y09269253	SANNI	Nouhbath	+2290197086906	16	CEG YAGBE	\N	actif	2026-09-27 18:37:45.310909+00	\N
985	Y09263913	OGOUDJOBI	Aurelie	+2290197290380	15	CEG YAGBE	\N	actif	2026-09-27 19:01:14.580982+00	\N
986	Y09268092	DOSSOU	Josephine	+2290155091940	16	CEG YAGBE	\N	actif	2026-09-27 19:06:52.452052+00	\N
987	Y09263324	ADJAGNISSOUDE	Daniella	+2290197749436	14	CEG YAGBE	\N	actif	2026-09-27 19:09:50.40969+00	\N
988	Y09267690	ADJANOHOUN	Cyr Baudoin	+2290197034835	13	CEG YAGBE	\N	actif	2026-09-27 19:15:29.028975+00	\N
989	Y09263073	DJIBRIL MORIBA	Aliou	+2290197026002	15	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:17:10.523784+00	\N
990	Y09261426	DJIBRIL MORIBA	Grâce	+2290197026002	16	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:18:50.742938+00	\N
991	Y09264529	ADAMOU	Neyla	+2290197026002	13	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:21:52.60205+00	\N
993	Y09266282	LOKOSSOU	Ivenne	+2290197153537	15	CEG YAGBE	\N	actif	2026-09-27 19:25:58.022503+00	\N
994	Y09263722	FONTECLOUNON	Généreux	+2290167119605	13	CEG YAGBE	\N	actif	2026-09-27 19:29:18.588484+00	\N
995	Y09263297	FONTECLOUNON	Heureux	+2290167119605	13	CEG YAGBE	\N	actif	2026-09-27 19:30:49.192221+00	\N
996	Y09263643	ACAKPO	Lumière	+2290128511180	16	CEG YAGBE	\N	actif	2026-09-27 19:32:46.190466+00	\N
997	Y09267654	ADJAGNISSODE	Yvens	+2290197516128	16	CEG YAGBE	\N	actif	2026-09-27 19:34:04.937795+00	\N
998	Y09263367	DOSSOU KOKO	Georges	+2290168952225	16	CEG YAGBE	\N	actif	2026-09-27 19:36:33.84486+00	\N
999	Y09265552	BOKO	Askel	+2290162226218	14	CEG YAGBE	\N	actif	2026-09-27 19:37:33.910231+00	\N
1000	Y09262769	ALASSANE	Rayane	+2290167484906	16	CEG YAGBE	\N	actif	2026-09-27 19:43:41.655393+00	\N
1001	Y09265886	SOULE ADOWA	Aïda	+2290197864013	13	CEG YAGBE	\N	actif	2026-09-27 19:49:32.92598+00	\N
1002	Y09264101	SOULE ADOWA	Akil	+2290197864013	15	CEG YAGBE	\N	actif	2026-09-27 19:51:29.435173+00	\N
1003	Y09267411	MAMA	Imourane	+2290166558966	16	CEG YAGBE	\N	actif	2026-09-27 19:54:06.778818+00	\N
1004	J09261327	CAPO-CHICHI	Elysée Eléna Nathalie	+2290195667655	22	CEG DU LAC	\N	actif	2026-09-27 19:56:11.949775+00	+2290195231828
1005	J09269266	HOUNKPEVI	Natacha	+2290167613034	22	CEG STE RITA	\N	actif	2026-09-27 19:58:42.628709+00	\N
1006	J09268823	KPETOTON	Amour	+2290166262724	22	CEG DU LAC	\N	actif	2026-09-27 20:17:54.452802+00	+2290147280801
1007	J09264796	BIO-GABA	Isaac	+2290166365518	4	CEG DU LAC	\N	actif	2026-09-27 20:19:58.962012+00	\N
1008	J09268895	ALAO	Faoziath	+2290197639005	22	CEG DANTOKPA	\N	actif	2026-09-27 20:23:43.806203+00	\N
1009	J09265272	DEDO	Divine	+2290197441431	19	CEG DU LAC	\N	actif	2026-09-27 20:27:02.691218+00	\N
1010	J09268331	DOSSEH	Vicentia	+2290141907995	19	CEG DU LAC	\N	actif	2026-09-27 20:31:30.480887+00	+2290163960279
1011	J09268139	SODOHOUNSI	Raymond	+2290196881398	19	CEG DU LAC	\N	actif	2026-09-27 20:35:18.737788+00	\N
1012	J09269532	ALI	Zeynab	+2290196232591	8	CS LA PAIX	\N	actif	2026-09-27 20:38:07.881525+00	+2290144497544
1013	J09268975	MASSESSI	Mathilde	+2290195247806	8	CEG STE RITA	\N	actif	2026-09-27 20:39:56.808814+00	+2290169744470
1014	J09261974	TOSSE	Joyce	+2290197602223	3	CEG DU LAC	\N	actif	2026-09-27 20:52:52.348446+00	+2290143955156
1015	J09266481	GLO	Esméralda	+2290197538080	3	CEG DANTOKPA	\N	actif	2026-09-27 20:53:50.454952+00	\N
1016	J09262191	ALANHOUHEDO	Pélagie	+2290152693008	3	CEG DANTOKPA	\N	actif	2026-09-27 20:56:20.194376+00	\N
1017	J09264829	HOUESSOU	Majoie	+2290141804563	3	CEG DU LAC	\N	actif	2026-09-27 20:58:59.538165+00	\N
1018	J09269689	ADJASSOHO	Ossénath	+2290195397467	3	CEG DU LAC	\N	actif	2026-09-27 21:00:46.385601+00	+2290196577131
1019	J09267985	GNONLONSOU	Eunice	+2290197906041	3	CEG DU LAC	\N	actif	2026-09-27 21:02:10.727492+00	\N
960	J09263830	AYITE	Lucie Sarra	+2290196313654	22	CEG STE RITA	\N	actif	2026-09-24 00:37:04.675846+00	\N
965	J09269237	TOZO	Aser	+2290197013309	17	CEG DU LAC	\N	actif	2026-09-25 12:10:38.896771+00	\N
274	J08267045	PRINCE AGBODJAN	Marius	+2290197352202	27	CEG DU LAC	\N	actif	2026-08-25 20:23:33.7096+00	\N
1020	J09266004	WIKON	Mariam	+2290167729007	3	CEG DANTOKPA	\N	actif	2026-09-27 21:03:29.828699+00	+2290144601210
1021	J09266145	GBEHI	Samuel	+2290197029240	3	CEG DU LAC	\N	actif	2026-09-27 21:04:42.76989+00	+2290167359474
1022	J09264980	HOUSSA	Elisabeth	+2290166866574	3	CEG DU LAC	\N	actif	2026-09-27 21:06:40.663727+00	+2290163201738
1023	J09264808	KPETOTON	Celestine	+2290166262724	3	CEG DU LAC	\N	actif	2026-09-27 21:08:19.810437+00	+2290147280801
1024	J09268745	BOTON FATCHE	Bignon Merveille	+2290199594615	3	CEG DU LAC	\N	actif	2026-09-27 21:09:37.803444+00	+2290197743882
1025	J09262141	HOUESSOU	Salomé	+2290141804563	20	CEG DU LAC	\N	actif	2026-09-27 21:16:16.239533+00	\N
1027	J09265590	GOUHOUENOU	Osiniel	+2290197029674	20	CEG DU LAC	\N	actif	2026-09-27 21:42:42.241991+00	\N
1029	J09266908	DAMBIOKOU	Augustin	+2290166575867	3	CEG DU LAC	\N	actif	2026-09-27 21:45:33.107168+00	\N
1030	J09265584	MEDJOGBE	Fifamè	+2290195434989	3	CEG DU LAC	\N	actif	2026-09-27 21:46:50.436653+00	\N
1031	J09261983	AKELE	Christian	+2290197370155	3	CEG DANTOKPA	\N	actif	2026-09-27 21:48:30.536205+00	+2290144824461
1032	J09261744	HOUETO	Yasmine	+2290166816794	3	CEG DU LAC	\N	actif	2026-09-27 21:50:11.924469+00	\N
1033	J09263198	MADADANNI	Leslie	+2290197043360	3	CEG STE RITA	M5	actif	2026-09-27 21:51:16.102972+00	\N
1034	J09269399	MONLIGUI	Dorcas	+2290144818881	3	CEG DU LAC	M6	actif	2026-09-27 21:57:54.096684+00	\N
1035	J09267041	AZANKPO	Elisée	+2290197942377	3	CEG DU LAC	M4	actif	2026-09-27 21:59:04.628251+00	\N
1037	J09262488	KPOVIESSI	Victorine	+2290197930411	3	CEG DU LAC	M5	actif	2026-09-27 22:01:56.518758+00	\N
1038	J09266260	MEDJOGBE	Exaucée	+2290195434986	3	CEG DU LAC	\N	actif	2026-09-27 22:03:12.590959+00	\N
1039	J09269869	GNANGNON	Mariella	+2290197547207	3	CEG GBEGAMEY	M9	actif	2026-09-27 22:05:48.485038+00	\N
1040	J09268731	KPETOTON	Saturnin	+2290197334739	3	CEG DU LAC	M10	actif	2026-09-27 22:07:25.636661+00	\N
1042	J09266924	LOUMINGOU	Grâce	+2290161746084	3	CEG DU LAC	M3	actif	2026-09-27 22:10:25.738755+00	\N
1043	J09262714	AKELE	Jean-Baptiste	+2290197370155	19	CEG DANTOKPA	\N	actif	2026-09-27 22:11:50.372462+00	\N
1046	J09262506	ACCROMBESSI	Donald	+2290163737144	8	CEG DU LAC	\N	actif	2026-09-27 22:16:17.954547+00	\N
1047	J09268568	ASSILAMEHOU	Charley	+2290197575294	8	CEG DU LAC	\N	actif	2026-09-27 22:17:37.097718+00	\N
1048	J09264407	GBENONCHI	Pablo	+2290197963160	8	CEG DU LAC	\N	actif	2026-09-27 22:18:50.057203+00	\N
1050	J09262673	AGBENOMBA	Divine	+2290195440830	22	CEG DU LAC	\N	actif	2026-09-27 22:32:25.542384+00	\N
1051	J09269111	AVOCEVOU	Christelle	+2290162597511	22	CEG DANTOKPA	\N	actif	2026-09-27 22:34:05.808435+00	\N
1052	J09262744	AKANNI	Assanath	+2290166077537	22	CEG DU LAC	\N	actif	2026-09-27 22:37:27.511544+00	\N
1053	J09261470	DANGBENON	Ignance	+2290196799502	22	CEG DU LAC	\N	actif	2026-09-27 22:38:24.531636+00	\N
1054	J09268707	AHLONSOU	Ametiste	+2290197631315	22	CEG DU LAC	\N	actif	2026-09-27 22:39:24.47414+00	\N
1055	J09265287	GANSA	Shalom	+2290152236985	22	CEG DU LAC	\N	actif	2026-09-27 22:40:40.525517+00	\N
1056	J09264136	TOGNIFODE	Vlad	+2290197008629	22	CEG DU LAC	\N	actif	2026-09-27 22:41:39.408467+00	\N
1057	J09269640	SEDE	Abigaëlle	+2290195677493	22	CEG DANTOKPA	\N	actif	2026-09-27 22:43:23.265959+00	\N
1058	J09264352	SEDE	Josias	+2290195677493	22	CEG DANTOKPA	\N	actif	2026-09-27 22:44:13.691004+00	\N
1059	J09266065	DJOSSOU	Gwladys	+2290197742685	22	CEG DU LAC	\N	actif	2026-09-27 22:45:24.453904+00	\N
1060	J09266793	SOLEVO	Ikhlos	+2290197574124	5	CEG DU LAC	\N	actif	2026-09-27 22:51:52.596631+00	\N
1061	J09269783	TCHINAN	Sévérine	+2290165566201	19	CEG DU LAC	\N	actif	2026-09-29 22:57:21.844445+00	\N
1063	J10269394	AKPLOGAN	Aristide	+2290162129301	8	CEG DU LAC	\N	actif	2026-10-01 12:08:38.957554+00	\N
1064	J10263417	HOUNGBO	Aurel	+2290161550156	18	CEG DU LAC	\N	actif	2026-10-01 12:15:03.876203+00	\N
1065	J10264247	IDRISSOU	Yasmine	+2290190391603	22	CEG STE RITA	\N	actif	2026-10-02 09:02:43.444127+00	\N
1066	Y10267503	NOUNAGNON	Marie Christelle	+2290166997929	15	CEG YAGBE	\N	actif	2026-10-02 12:48:09.879146+00	\N
1062	J09266463	SETOME	Basilia	+2290165566201	20	CEG DU LAC	\N	actif	2026-09-29 22:58:13.778737+00	\N
692	J08263545	AHOUANGANON	Mariella	+2290166763161	18	CEG DU LAC	\N	actif	2026-08-31 14:33:52.252508+00	\N
1028	J09263217	AHOUSSINOU	Doriane	+2290197419771	3	CEG OKOUN SEME	\N	actif	2026-09-27 21:44:08.121517+00	\N
124	J08265471	HOUNMENOU	Urielle	+2290165753530	28	CEG DU LAC	\N	actif	2026-08-25 20:15:46.164498+00	\N
1068	J10263181	KPADONOU	Miracle	+2290197962188	22	CEG DU LAC	\N	actif	2026-10-04 05:57:15.829476+00	\N
1071	J10268288	KOUEVI	Mélissa	+2290161626638	22	CEG DU LAC	\N	actif	2026-10-04 06:05:48.270807+00	\N
1073	J10266226	METOZOUNVE	Eunice	+2290146908526	22	CEG DANTOKPA	\N	actif	2026-10-04 06:12:06.803687+00	\N
1070	J10267811	TOSSOU	Bernadine	+2290199988253	22	CEG DANTOKPA	\N	actif	2026-10-04 06:03:17.426507+00	+2290149502013
1069	J10268826	ADI	Océane	+2290197580293	22	CEG DU LAC	\N	actif	2026-10-04 06:00:10.073302+00	\N
1072	J10265879	ANAGOKE	José	+2290197554314	22	CEG DU LAC	\N	actif	2026-10-04 06:08:59.162948+00	+2290140362931
1074	J10263302	WOLLO	Emilienne	+2290197564409	12	CEG DU LAC	\N	actif	2026-10-04 06:18:53.560587+00	\N
1075	J10263264	OGOULOLA	Divine	+2290197885464	22	CEG DU LAC	\N	actif	2026-10-04 06:22:21.663762+00	+2290194435444
1076	J10266781	HOUNKANRIN	Estelle	\N	22	CEG DU LAC	\N	actif	2026-10-04 06:24:51.306566+00	+2290197804182
1077	J10266544	GBENONMEDJI	Dorcas	+2290195767557	12	CEG STE RITA	\N	actif	2026-10-04 06:26:48.590091+00	+2290169297820
1078	Y10265475	TAIROU	Mohamed Fridaous	+2290167781926	13	CEG YAGBE	\N	actif	2026-10-04 10:20:14.907328+00	\N
1079	Y10263424	BOLO	Naomie	+2290167341484	13	CEG SURU LÉRÉ	\N	actif	2026-10-04 10:21:49.282624+00	\N
1080	Y10266570	TOTCHOEDO	Boris	+2290149141962	13	CEG YAGBE	\N	actif	2026-10-04 10:24:02.079955+00	\N
1081	Y10268452	FADEYI	Donaldine	+2290196807537	13	CEG YAGBE	\N	actif	2026-10-04 10:38:51.153853+00	\N
1082	Y10268123	BONOU	Chabel	\N	13	CEG YAGBE	\N	actif	2026-10-04 10:40:10.113366+00	+2290147270077
1041	J09262968	SAGBO	Esther	+2290151828951	3	CEG STE RITA	M4	actif	2026-09-27 22:09:00.081479+00	\N
694	J08268479	HOUETO	Madochée Pio	+2290166973747	25	CEG DU LAC	\N	actif	2026-08-31 14:36:10.199384+00	\N
1036	J09263820	YETIN	Aliou	+2290196741698	25	CEG DU LAC	M9	actif	2026-09-27 22:00:31.498596+00	\N
1045	J09265505	HOUNMENOU	Orel	+2290161215023	27	CEG DANTOKPA	\N	actif	2026-09-27 22:14:37.69211+00	\N
1044	J09262184	HOUETO	Belvis	+2290167359551	27	CEG DU LAC	\N	actif	2026-09-27 22:13:23.076849+00	\N
1049	J09261792	TOKINHO	Ebénézer	+2290196145763	27	CEG DU LAC	\N	actif	2026-09-27 22:20:57.440752+00	\N
1083	Y10264683	HOUANGNI	Fériol	\N	14	CEG YAGBE	\N	actif	2026-10-04 10:41:46.79794+00	+2290147270077
1084	Y10266361	HOUNSA	Othniel	+2290196806998	14	CEG YAGBE	\N	actif	2026-10-04 10:43:06.919648+00	\N
1085	Y10264760	SAIZONOU	Lumen	+2290165412242	14	COLLÈGE LUCIE VERONE	\N	actif	2026-10-04 10:44:43.184568+00	\N
1086	Y10262115	ABOUBAKAR	Fatimatou	+2290194616120	14	CEG YAGBE	\N	actif	2026-10-04 10:46:11.969984+00	+2290197023536
1087	Y10266598	DJIMA	Raoudath	\N	14	CEG YAGBE	\N	actif	2026-10-04 10:47:09.581004+00	+2290167536958
1088	Y10262569	CISSE	Prunelle	+2290196468398	15	CEG YAGBE	\N	actif	2026-10-04 10:48:02.43763+00	\N
1089	Y10262364	BONOU	Anne Marie	+2290161245720	15	CEG YAGBE	\N	actif	2026-10-04 10:48:59.134205+00	\N
1090	Y10265441	AKADIRY	Foudlath	+2290167159970	15	CEG YAGBE	\N	actif	2026-10-04 10:50:00.446561+00	\N
1091	Y10267039	ADEBIYI	Antoinette	+2290196093516	15	CEG YAGBE	\N	actif	2026-10-04 10:50:52.463195+00	\N
1092	Y10268615	CAKPO-CHICHI	Mickaela	+2290196086169	15	CEG YAGBE	\N	actif	2026-10-04 10:51:59.701066+00	\N
1093	Y10266141	MOUSTAPHA	Soumaiya	+2290197995990	15	CEG YAGBE	\N	actif	2026-10-04 10:53:08.64887+00	\N
1094	Y10262246	HINTEGNI	Georjinio	+2290166045121	15	CEG YAGBE	\N	actif	2026-10-04 10:54:22.801225+00	\N
1095	Y10265483	OKPEICHA	Wadoud	+2290197442037	15	CEG YAGBE	\N	actif	2026-10-04 10:55:09.170153+00	\N
1096	Y10267473	HOUEGNANNOU	Jean Baptiste	+2290196267473	13	CEG YAGBE	\N	actif	2026-10-04 11:03:07.474984+00	\N
1097	Y10261711	ODOUNHARO	Antoine	+2290197513291	16	CEG YAGBE	\N	actif	2026-10-04 11:04:06.728328+00	\N
1098	Y10263279	DAH-DOSSOUNON	Vanessa	+2290199433224	16	CEG YAGBE	\N	actif	2026-10-04 11:39:59.05803+00	\N
1099	Y10263761	AKADIRY	Mahmoudath	+2290167159970	16	CEG YAGBE	\N	actif	2026-10-04 11:40:55.216682+00	\N
1100	Y10266810	ABOUBAKAR	Youssouf	+2290194616120	16	CEG YAGBE	\N	actif	2026-10-04 11:41:54.945938+00	+2290197023536
1101	Y10264902	OLOUKPEDE	Charbel	+2290191648674	16	CEG YAGBE	\N	actif	2026-10-04 11:42:37.33559+00	\N
1102	Y10262263	TIKO	Océane	+2290197553671	16	CEG YAGBE	\N	actif	2026-10-04 11:43:25.889816+00	\N
1103	J10263647	NASSARAH	Evrard	+2290164672825	20	CEG DU LAC	\N	actif	2026-10-04 12:36:01.534147+00	\N
1104	J10268764	NASSARAH	Bénit	+2290197639709	20	CEG DU LAC	\N	actif	2026-10-04 12:36:41.501423+00	\N
1105	J10263846	AFADJRO	Mario	+2290197556909	8	CEG DU LAC	\N	actif	2026-10-04 14:31:44.280834+00	\N
1106	J10268245	SALAVI	Josué	+2290197270887	8	CEG DU LAC	\N	actif	2026-10-04 14:34:39.217936+00	\N
1107	J10268851	ASSOGBA	Ariel	+2290197031698	8	CEG DU LAC	\N	actif	2026-10-04 14:49:16.319381+00	\N
1108	J10267753	MEKPO	Rotild	+2290197556075	24	CEG DANTOKPA	\N	actif	2026-10-04 14:52:20.784386+00	\N
1109	J10267800	ADJIWANOU	Emmanuella	+2290195506360	7	CEG DU LAC	\N	actif	2026-10-04 14:54:12.535029+00	\N
1110	J10262105	ADJOVI	Macive	+2290197092940	23	CEG DU LAC	\N	actif	2026-10-04 14:56:35.193382+00	+2290148758037
1111	J10269498	ADJASSSOHO	Osséni	+2290195397467	23	CEG DU LAC	\N	actif	2026-10-04 14:57:58.718924+00	\N
1112	J10268435	SOGLO	Jordan	+2290197538080	22	CEG DANTOKPA	\N	actif	2026-10-04 14:59:11.842846+00	+2290197849559
1113	J10263137	GODONOU	Belvida	+2290164785458	18	CEG DU LAC	\N	actif	2026-10-04 15:00:35.864763+00	\N
1114	J10265847	GODONOU	Géovania	+2290164785458	18	CEG DANTOKPA	\N	actif	2026-10-04 15:01:44.54752+00	\N
1115	J10268399	MOUTAIROU	Romziath	+2290196550970	18	CEG DU LAC	\N	actif	2026-10-04 15:04:02.964999+00	\N
1116	J10263085	AGBOOLA	Saobane	+2290141859959	18	CEG DU LAC	\N	actif	2026-10-04 15:04:57.634161+00	\N
1117	J10261246	AGONYE	Jesutin Marlène	+2290196720577	18	CEG DU LAC	\N	actif	2026-10-04 15:06:04.884714+00	\N
1118	J10266199	KPADONOU	Jacques	\N	18	CEG DU LAC	\N	actif	2026-10-04 15:07:22.346287+00	+2290147282237
1120	J10268116	DEGBO	Yannick	+2290197250573	18	CEG DU LAC	\N	actif	2026-10-04 15:10:14.057704+00	+2290194747363
1121	J10265210	NEVICE	Prunelle	\N	19	CEG DU LAC	\N	actif	2026-10-04 15:11:19.375209+00	+2290197717516
1122	J10266462	TOYIGBE	Valentine	+2290194309419	19	LA RÉFÉRENCE	\N	actif	2026-10-04 15:13:00.24133+00	\N
1123	J10261977	N'SOYENOU	Abigaëlle	+2290197092940	19	CEG DU LAC	\N	actif	2026-10-04 15:15:15.479364+00	+2290148758037
1124	J10267652	SALAVI	Prince	+2290197270887	19	CEG DANTOKPA	\N	actif	2026-10-04 15:18:39.088774+00	\N
1125	J10261869	TOYIGBE	Frédéric	+2290196811574	2	LA RÉFÉRENCE	\N	actif	2026-10-04 15:20:11.708495+00	\N
1126	J10268944	BOTON FATCHE	Honoré	+2290199594615	2	CEG DU LAC	\N	actif	2026-10-04 15:21:16.425693+00	\N
1127	J10261340	ASSOGBA	Christelle	\N	2	CEG STE RITA	\N	actif	2026-10-04 15:22:19.149512+00	+2290196432768
1128	J10263555	AGBOZE	Messi	+2290197692968	20	CEG DU LAC	\N	actif	2026-10-04 15:24:13.39993+00	+2290147949090
1129	J10261887	N'SOYENOU	Jean de Dieu	+2290197092940	20	CEG DU LAC	\N	actif	2026-10-04 15:25:35.880332+00	+2290148758037
1130	J10266955	SALAVI	Gloire de Dieu	+2290197270887	20	CEG DU LAC	\N	actif	2026-10-04 15:26:56.239159+00	\N
1131	J10264408	DEDJILA	Marigine	+2290161806373	20	CEG DANTOKPA	\N	actif	2026-10-04 15:30:12.363645+00	\N
1132	J10261772	ALAO	Olouwa Kèmi	+2290197639005	20	CEG DANTOKPA	\N	actif	2026-10-04 15:33:43.096533+00	\N
1133	J10261900	DJOTCHOU	Samuel Akouègnon	+2290197286137	1	CEG DU LAC	\N	actif	2026-10-04 15:37:25.248818+00	\N
1134	J10268019	HOUETO	Yanis	+2290166973747	8	CEG DU LAC	\N	actif	2026-10-04 19:50:08.814101+00	\N
1026	J09266010	MOIDE	Fènou Jériel Antonio	+2290195667655	20	CEG DU LAC	\N	actif	2026-09-27 21:18:37.381728+00	+2290195231828
1135	J10265203	DEGBO	Aubin	+2290169008428	18	CEG DU LAC	\N	actif	2026-10-05 00:18:10.674401+00	+2290191405028
1119	J10263248	KOUASSI	Shalom	+2290197779479	3	CEG DU LAC	\N	actif	2026-10-04 15:08:56.517844+00	+2290199516860
1136	J10261938	AHOUANVOEGBLA	Aurore	\N	8	CEG DU LAC	\N	actif	2026-10-05 00:42:37.037912+00	+2290147877997
992	Y09269649	DOHOUIN	Buscotin	+2290197026002	16	CEG SURU LÉRÉ	\N	actif	2026-09-27 19:23:47.516422+00	\N
1138	J10269348	HOUNSINOU	Emmanuella	+2290161881005	17	CEG STE RITA	\N	actif	2026-10-08 06:10:49.929962+00	\N
319	J08268271	ZOUNDJI	Lucien	+2290196735162	18	CEG DU LAC	\N	actif	2026-08-25 20:25:26.996866+00	\N
18	J08263543	GANGNON	Abidémi Mourana	+2290197311903	28	CEG DU LAC	\N	actif	2026-08-25 20:08:25.172258+00	\N
1140	J10262787	ADANZOUNNON	Irène	+2290167734945	20	CEG DU LAC	\N	actif	2026-10-08 22:40:23.376613+00	\N
170	J08267821	HOYETON	Diane	+2290191394417	27	CEG DU LAC	\N	actif	2026-08-25 20:18:10.358704+00	\N
1141	J10263179	ADJOVI	Sylvania	+2290151810649	2	CEG DU LAC	\N	actif	2026-10-09 00:35:32.828542+00	\N
1142	J10264536	ADONON	Grâce	+2290196312730	2	CEG DU LAC	\N	actif	2026-10-09 00:53:16.854469+00	\N
1143	J10269601	AGBOMAKOU	Lucresse	+2290191340563	2	CEG DU LAC	\N	actif	2026-10-09 00:54:14.032977+00	\N
1144	J10266288	ANAGO	Géraldine	+2290190181688	2	CEG DU LAC	\N	actif	2026-10-09 00:56:35.632552+00	\N
1139	J10269777	WIGNANON	Jessica	+2290141808865	17	CEG DU LAC	\N	actif	2026-10-08 06:14:43.399963+00	\N
1145	J10269800	ATINDEKOUN	Jean Baptiste	\N	2	CEG DU LAC	\N	actif	2026-10-09 00:57:33.45602+00	+2290197698474
1146	J10266527	ATORO	Failylath	+2290195809121	2	CEG DU LAC	\N	actif	2026-10-09 00:58:30.187341+00	\N
1147	J10262902	AVLESSI	Louise	+2290140444190	2	CEG DU LAC	\N	actif	2026-10-09 01:00:15.733985+00	\N
1148	J10269802	AVODAGBE	Emmanuella	\N	2	CEG DU LAC	\N	actif	2026-10-09 01:01:10.86221+00	+2290140725143
1149	J10268950	DOSSA	Isabella	+2290164001164	2	CEG DU LAC	\N	actif	2026-10-09 02:31:38.639136+00	\N
1150	J10269245	KODJO	Jeannette	+2290162383799	2	CEG DU LAC	\N	actif	2026-10-09 02:33:04.201875+00	\N
1151	J10267429	KPATINVO	Jean Marc	+2290196344395	2	CEG DU LAC	\N	actif	2026-10-09 02:34:50.348689+00	\N
1152	J10268250	KPOSSOU	Tatiana	+2290146502312	2	CEG DU LAC	\N	actif	2026-10-09 02:35:44.866176+00	\N
1153	J10267059	OKATTA	Esta	+2290161551004	2	CEG DU LAC	\N	actif	2026-10-09 02:36:32.158437+00	\N
1154	J10268790	OKE	Jacques	\N	2	CEG DU LAC	\N	actif	2026-10-09 02:37:22.920198+00	+2290141958935
1155	J10266118	OURO GERI	Amina	+2290195966269	2	CEG DU LAC	\N	actif	2026-10-09 02:38:18.968512+00	\N
1156	J10263593	OUSSOU YOVO	Roseline	+2290145885462	2	CEG DU LAC	\N	actif	2026-10-09 02:39:11.645262+00	\N
1157	J10263455	TANDE	Jean Brice	+2290197886484	2	CEG DU LAC	\N	actif	2026-10-09 02:40:02.09896+00	\N
1158	J10268623	TCHIBOZO	Sharon	+2290190444733	19	CEG DU LAC	\N	actif	2026-10-09 02:40:59.055525+00	\N
1159	J10267275	TCHIBOZO	Sèssimè	\N	2	CEG DU LAC	\N	actif	2026-10-09 02:42:17.313711+00	+2290163750858
1160	J10263101	VIAKINNOU	Alexandre	\N	2	CEG DU LAC	\N	actif	2026-10-09 02:43:07.770395+00	+2290197561254
1161	J10267659	VITOU	Aitchatou	\N	2	CEG DU LAC	\N	actif	2026-10-09 02:44:28.989815+00	+2290196240416
1162	J10263337	YESSOUFOU	Nafissath	\N	2	CEG DU LAC	\N	actif	2026-10-09 02:45:43.506595+00	+2290153276727
1137	J10265005	SENOU	Virgile	+2290191639607	17	CEG DU LAC	\N	actif	2026-10-08 05:58:44.508347+00	\N
912	J09268877	WIGNANON	Jéssica	+2290141808865	26	CEG DU LAC	\N	actif	2026-09-20 12:58:12.218711+00	+2290197168495
\.


--
-- Data for Name: eleves_exonerations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves_exonerations (id, eleve_id, annee_scolaire_id, type_exoneration, nombre_mois, mois_couverts, motif, accorde_par, created_at) FROM stdin;
1	467	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:40.951304+00
2	55	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:53.825667+00
3	209	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.054336+00
4	243	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:45.857556+00
5	334	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.697448+00
6	457	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.536282+00
7	487	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:47.806154+00
8	497	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:23.898365+00
9	501	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.603225+00
10	58	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:30:19.679793+00
11	164	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:04.872328+00
12	270	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:46.743438+00
14	456	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:01.344125+00
15	480	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:44.019351+00
16	490	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:26.327911+00
17	502	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:58.667355+00
18	9	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:35:51.510339+00
19	193	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:36:32.882999+00
20	235	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:37:00.397478+00
21	449	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:24.606245+00
22	469	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:51.06393+00
23	491	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:19.228814+00
24	509	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:59.342987+00
25	980	1	permanente	8	{Octobre,Novembre,Decembre,Janvier,Fevrier,Mars,Avril,Mai}	enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.372664+00
26	549	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.110041+00
27	530	1	bourse	2	{Fevrier,Mars}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:46:03.496344+00
28	546	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:47:04.372197+00
29	560	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.599569+00
30	564	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:37.67204+00
31	570	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:06.900455+00
32	625	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.523186+00
33	862	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:51:08.523286+00
34	620	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:21.313798+00
35	650	1	bourse	3	{Octobre,Novembre,Decembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.293738+00
36	657	1	bourse	2	{Octobre,Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:53:18.630318+00
37	659	1	bourse	1	{Octobre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:53:56.00745+00
38	328	1	bourse	1	{Novembre}	Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:55:12.254336+00
\.


--
-- Data for Name: eleves_suspendus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves_suspendus (id, eleve_id, site_id, raison, motif, montant_du, date_suspension, suspendu_par, annee_scolaire_id, mois_souscription) FROM stdin;
\.


--
-- Data for Name: frais_td; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frais_td (id, classe_id, montant) FROM stdin;
2	13	2000.00
6	15	3000.00
7	4	5000.00
9	5	5000.00
10	6	5000.00
11	7	6000.00
12	8	6000.00
14	10	8000.00
16	12	8000.00
17	17	5000.00
1	1	2500.00
20	20	2500.00
3	2	2500.00
19	19	2500.00
5	3	3500.00
18	18	3500.00
15	11	10000.00
22	22	5000.00
23	23	5000.00
24	24	6000.00
4	14	2000.00
8	16	4000.00
25	25	3500.00
26	26	5000.00
27	27	2500.00
28	28	2500.00
\.


--
-- Data for Name: galerie; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie (id, storage_path, date_insertion) FROM stdin;
\.


--
-- Data for Name: galerie_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie_admin (id, storage_path, nom_fichier, taille_octets, ajoute_par, date_ajout) FROM stdin;
\.


--
-- Data for Name: log_whatsapp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_whatsapp (id, matricule, mois_souscription, montant_restant, contact_parent, envoye_par, date_envoi) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, identifiant, portail, reussi, ip, date_tentative) FROM stdin;
1	jealexhouegbe	admin	t	\N	2026-08-08 09:04:55.328051+00
2	jealexhouegbe	admin	t	\N	2026-08-08 09:39:40.149597+00
3	jealexhouegbe	admin	t	\N	2026-08-08 10:11:21.70487+00
4	jealexhouegbe	admin	t	\N	2026-08-08 17:28:36.86968+00
5	jealexhouegbe	admin	t	\N	2026-08-08 19:50:29.083241+00
6	jealexhouegbe	admin	t	\N	2026-08-08 20:18:37.037356+00
7	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:19:48.89375+00
8	urielaxelhouegbe@gmail.com	admin	f	\N	2026-08-08 20:20:20.527295+00
9	urielhouegbe	admin	t	\N	2026-08-08 20:21:05.91664+00
10	jealexhouegbe	admin	t	\N	2026-08-09 07:24:15.712276+00
11	jealexhouegbe	admin	t	\N	2026-08-09 17:50:38.07625+00
12	jealexhouegbe	admin	t	\N	2026-08-09 18:04:09.738492+00
13	jealexhouegbe	admin	t	\N	2026-08-09 21:45:01.744606+00
14	jealexhouegbe	admin	t	\N	2026-08-09 22:30:52.951794+00
15	jealexhouegbe	admin	t	\N	2026-08-09 22:51:08.511658+00
16	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:17:04.613553+00
17	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-09 23:38:02.296944+00
18	jealexhouegbe	admin	t	\N	2026-08-10 06:54:14.925918+00
19	urielhouegbe	admin	t	\N	2026-08-10 06:54:53.49026+00
20	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-10 14:16:24.752172+00
21	jealexhouegbe	admin	t	\N	2026-08-11 05:15:32.956857+00
22	jealexhouegbe	admin	t	\N	2026-08-11 07:17:09.84883+00
23	jealexhouegbe	admin	t	\N	2026-08-11 14:42:01.560105+00
24	jealexhouegbe 	admin	f	\N	2026-08-11 14:50:28.385101+00
25	jealexhouegbe	admin	t	\N	2026-08-11 14:51:47.881878+00
26	urielhouegbe	admin	t	\N	2026-08-11 22:09:42.773948+00
27	urielhouegbe	admin	t	\N	2026-08-11 22:55:35.577395+00
28	jucalhouegbe	admin	f	\N	2026-08-11 23:47:44.631597+00
29	jealexlhouegbe	admin	f	\N	2026-08-11 23:47:59.101531+00
30	jealexhouegbe	admin	t	\N	2026-08-11 23:48:07.321782+00
31	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:07:07.80926+00
32	jealexhouegbe	admin	t	\N	2026-08-12 00:14:52.139976+00
33	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-12 00:14:52.297684+00
34	jealexhouegbe	admin	t	\N	2026-08-12 00:40:28.33475+00
35	jealexhouegbe	admin	t	\N	2026-08-13 06:44:02.687375+00
36	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-13 06:51:51.529595+00
37	urielhouegbe	admin	t	\N	2026-08-13 10:02:55.168658+00
38	urielhouegbe 	admin	f	\N	2026-08-13 10:12:23.387167+00
39	urielhouegbe	admin	t	\N	2026-08-13 10:12:31.147252+00
40	jealexhouegbe	admin	t	\N	2026-08-13 19:58:42.339916+00
41	jealexhouegbe	admin	t	\N	2026-08-13 20:31:27.647073+00
42	urielhouegbe	admin	t	\N	2026-08-14 00:18:35.46862+00
43	urielhouegbe	admin	t	\N	2026-08-15 18:08:50.226733+00
44	jucalhouegbe	admin	f	\N	2026-08-16 16:51:07.068095+00
45	jealexhouegbe	admin	t	\N	2026-08-16 16:51:21.321239+00
46	urielhouegbe	admin	t	\N	2026-08-16 23:14:59.890519+00
47	jealexhouegbe	admin	t	\N	2026-08-17 04:22:29.319416+00
48	urielhouegbe	admin	t	\N	2026-08-17 19:20:15.425783+00
49	jealexhouegbe	admin	f	\N	2026-08-17 19:50:55.965311+00
50	jealexhouegbe	admin	t	\N	2026-08-17 19:51:24.8748+00
51	jealexhouegbe 	admin	f	\N	2026-08-17 19:54:57.472031+00
52	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:11.314247+00
53	jealexhouegbe 	admin	f	\N	2026-08-17 19:55:15.276516+00
54	jealexhouegbe	admin	t	\N	2026-08-17 19:55:32.145075+00
55	urielhouegbe	admin	t	\N	2026-08-18 14:39:31.730354+00
56	urielhouegbe	admin	t	\N	2026-08-18 15:01:39.644185+00
57	jealexhouegbe	admin	t	\N	2026-08-18 18:19:26.597107+00
58	urielhouegbe	admin	t	\N	2026-08-18 18:25:36.774151+00
59	urielhouegbe	admin	t	\N	2026-08-18 19:18:33.026739+00
60	urielhouegbe	admin	t	\N	2026-08-18 19:41:50.997441+00
61	urielhouegbe	admin	t	\N	2026-08-18 19:46:37.319351+00
62	urielhouegbe	admin	t	\N	2026-08-18 20:04:14.497463+00
63	urielhouegbe	admin	t	\N	2026-08-18 20:24:31.820607+00
64	jealexhouegbe	admin	t	\N	2026-08-18 20:57:59.714752+00
65	jealexhouegbe	admin	f	\N	2026-08-18 21:35:02.243166+00
66	jealexhouegbe	admin	t	\N	2026-08-18 21:35:26.978454+00
67	jealexhouegbe	admin	t	\N	2026-08-18 22:15:50.900336+00
68	jealexhouegbe	admin	t	\N	2026-08-18 22:25:22.228939+00
69	jealexhouegbe	admin	t	\N	2026-08-18 22:26:16.772262+00
70	jealexhouegbe	admin	f	\N	2026-08-20 20:51:38.231956+00
71	jealexhouegbe	admin	t	\N	2026-08-20 20:52:02.9463+00
72	jealexhouegbe	admin	t	\N	2026-08-20 22:40:52.726733+00
73	jealexhouegbe	admin	t	\N	2026-08-21 05:34:05.517187+00
74	jealexhouegbe	admin	t	\N	2026-08-24 08:05:32.234437+00
75	jealexhouegbe	admin	t	\N	2026-08-24 09:27:48.297251+00
76	sylvestregblagodo@gmail.com	td	f	\N	2026-08-24 21:19:59.614399+00
77	jealexhouegbe	admin	t	\N	2026-08-24 23:51:25.967698+00
78	louislucnou@gmail.com	td	f	\N	2026-08-25 11:10:13.546533+00
79	jealexhouegbe	admin	t	\N	2026-08-25 14:17:27.114846+00
80	piomedesse@gmail.com	td	f	\N	2026-08-25 17:34:32.465617+00
81	jealexhouegbe	admin	t	\N	2026-08-25 19:58:21.76755+00
82	jealexhouegbe	admin	t	\N	2026-08-25 20:04:35.214424+00
83	jealexhouegbe	admin	t	\N	2026-08-25 21:59:07.881512+00
84	jealexhouegbe	admin	t	\N	2026-08-25 22:28:27.334899+00
85	jealexhouegbe	admin	t	\N	2026-08-26 05:04:34.848327+00
86	jealexhouegbe	admin	t	\N	2026-08-26 05:25:00.305425+00
87	urielhouegbe	admin	t	\N	2026-08-26 05:26:07.905145+00
88	urielhouegbe	admin	t	\N	2026-08-26 05:33:11.71263+00
89	urielhouegbe	admin	t	\N	2026-08-26 06:39:47.176169+00
90	urielhouegbe	admin	t	\N	2026-08-26 06:45:04.452508+00
91	jealexhouegbe	admin	t	\N	2026-08-26 06:47:20.684668+00
92	jealexhouegbe	admin	t	\N	2026-08-26 07:29:32.628906+00
93	urielhouegbe	admin	t	\N	2026-08-26 07:34:42.59047+00
94	jealexhouegbe	admin	t	\N	2026-08-26 07:39:09.898096+00
95	jealexhouegbe	admin	t	\N	2026-08-26 19:22:10.541005+00
96	urielhouegbe	admin	t	\N	2026-08-26 19:22:17.499147+00
97	jealexhouegbe	admin	t	\N	2026-08-26 19:54:34.621802+00
98	djossoudavid19@gmail.com	td	f	\N	2026-08-27 06:27:52.0945+00
99	kegnidedavid70@gmail.com	td	f	\N	2026-08-27 22:49:29.236976+00
100	kegnidedavid70@gmail.com	td	f	\N	2026-08-27 22:49:38.098546+00
101	romaricadjovi12@gmail.com	td	f	\N	2026-08-29 09:58:17.030525+00
102	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:49:15.325666+00
103	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:49:28.24588+00
104	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:49:54.500969+00
105	degnonfrederics@gmail.com	td	f	\N	2026-08-29 12:50:34.492743+00
106	jeremieabidegbekponou@gmail.com	td	f	\N	2026-08-29 17:13:15.658474+00
107	amankpemodeste761@gmail.com	td	f	\N	2026-08-30 10:39:33.94497+00
108	amankpemodeste761@gmail.com	td	f	\N	2026-08-30 10:42:06.962371+00
109	jealexhouegbe	admin	t	\N	2026-08-30 14:51:26.502628+00
110	jealexhouegbe	admin	t	\N	2026-08-30 19:27:17.776124+00
111	urielaxelhouegbe@gmail.com	td	t	\N	2026-08-30 19:35:14.075465+00
112	jealexhouegbe	admin	t	\N	2026-08-31 13:18:30.424268+00
113	jealexhouegbe	admin	t	\N	2026-08-31 16:07:13.248466+00
114	jealexhouegbe	admin	t	\N	2026-09-01 06:06:12.389123+00
115	jealexhouegbe	admin	t	\N	2026-09-02 18:47:56.174114+00
116	jealexhouegbe	admin	t	\N	2026-09-02 19:29:34.855369+00
117	jealexhouegbe 	admin	f	\N	2026-09-04 16:31:13.600098+00
118	jealexhouegbe	admin	t	\N	2026-09-04 16:31:22.231021+00
119	aurelgodfrid2@gmail.com	td	f	\N	2026-09-06 06:42:49.650185+00
120	jealexhouegbe	admin	t	\N	2026-09-06 14:34:13.904069+00
121	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-06 14:56:40.768797+00
122	djossoudavid19@gmail.com	admin	f	\N	2026-09-06 18:21:29.002743+00
123	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-06 22:11:20.431377+00
124	jealexhouegbe	admin	t	\N	2026-09-06 22:14:59.418656+00
125	jealexhouegbe	admin	t	\N	2026-09-06 22:25:24.857657+00
126	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 07:19:05.70145+00
127	jealexhouegbe	admin	t	\N	2026-09-07 08:20:11.259871+00
128	jealexhouegbe 	admin	f	\N	2026-09-07 08:48:30.552839+00
129	jealexhouegb	admin	f	\N	2026-09-07 08:49:32.716556+00
130	jealexhouegbe	admin	t	\N	2026-09-07 08:49:51.984579+00
131	jealexhouegbe	admin	t	\N	2026-09-07 09:24:54.821277+00
132	jealexhouegbe	admin	t	\N	2026-09-07 14:46:34.476593+00
133	arnaudzadji066@gmail.com	td	f	\N	2026-09-07 15:10:49.322012+00
134	arnaudzadji066@gmail.com	td	f	\N	2026-09-07 15:11:18.080867+00
135	jealexhouegbe	admin	t	\N	2026-09-07 15:19:58.379888+00
136	charliehounkanrin@gmail.com	td	f	\N	2026-09-07 15:32:15.363749+00
137	charliehounkanrin@gmail.com	td	f	\N	2026-09-07 15:32:57.573718+00
138	arnaudzadji066@gmail.com	td	t	\N	2026-09-07 15:33:41.236706+00
139	jealexhouegbe 	admin	f	\N	2026-09-07 15:36:16.05189+00
140	jealexhouegbe	admin	t	\N	2026-09-07 15:36:22.55051+00
141	piomedesse@gmail.com	td	f	\N	2026-09-07 15:38:39.896874+00
142	piomedesse@gmail.com	td	f	\N	2026-09-07 15:39:11.520009+00
143	piomedesse@gmail.com	td	f	\N	2026-09-07 15:39:23.83405+00
144	charliehounkanrin@gmail.com	td	t	\N	2026-09-07 15:39:51.365342+00
145	piomedesse@gmail.com	td	f	\N	2026-09-07 15:41:32.965879+00
146	piomedesse@gmail.com	td	f	\N	2026-09-07 15:41:46.742573+00
147	louislucnou@gmail.com	td	f	\N	2026-09-07 15:47:59.108894+00
148	louislucnou@gmail.com	td	t	\N	2026-09-07 15:48:39.009296+00
149	florenthinnou@gmail.com	td	t	\N	2026-09-07 16:09:29.057582+00
150	leopoldchangodele@gmail.com	td	f	\N	2026-09-07 16:10:00.772591+00
151	leopoldchangodele@gmail.com	td	f	\N	2026-09-07 16:10:06.887534+00
152	leopoldchangodele@gmail.com	td	f	\N	2026-09-07 16:10:31.059911+00
153	leopoldchangodele@gmail.com	td	t	\N	2026-09-07 16:12:24.653371+00
154	fauxence1994@gmail.com	td	t	\N	2026-09-07 16:27:29.592543+00
155	zoutounnouf@gmail.com	td	t	\N	2026-09-07 16:28:22.898891+00
156	mawougnongael91@gmail.com	td	f	\N	2026-09-07 16:34:21.561919+00
157	mawougnongael91@gmail.com	td	t	\N	2026-09-07 16:35:55.051974+00
158	sagbowilliam@gmail.com	td	f	\N	2026-09-07 16:40:05.869304+00
159	sagbowilliam@gmail.com	admin	f	\N	2026-09-07 16:40:19.433993+00
160	angekarson1@gmail.com	td	f	\N	2026-09-07 16:41:17.5689+00
161	angekarson1@gmail.com	td	f	\N	2026-09-07 16:41:27.620185+00
162	mawougnongael91@gmail.com	td	t	\N	2026-09-07 16:41:42.129007+00
163	angekarson1@gmail.com	td	f	\N	2026-09-07 16:41:45.438386+00
164	angekarson1@gmail.com	td	f	\N	2026-09-07 16:42:06.956887+00
165	sagbowilliam@gmail.com	admin	f	\N	2026-09-07 16:49:22.192363+00
166	sagbowilliam@gmail.com	admin	f	\N	2026-09-07 16:49:25.107283+00
167	charliehounkanrin@gmail.com	td	t	\N	2026-09-07 16:54:34.107492+00
168	ricoferno@gmail.com	td	t	\N	2026-09-07 16:56:57.741793+00
169	ghics2000@yahoo.fr	td	f	\N	2026-09-07 16:59:38.362339+00
170	ghics2000@yahoo.fr	td	t	\N	2026-09-07 17:04:46.043919+00
171	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:15:38.951332+00
172	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:16:16.795912+00
173	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:18:31.914911+00
174	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:18:35.682994+00
175	doctrinearnaud@gmail.com	td	f	\N	2026-09-07 17:18:45.150071+00
176	ferdinandagossou03@gmail.com	td	f	\N	2026-09-07 19:32:36.746486+00
177	jealexhouegbe	admin	t	\N	2026-09-07 19:44:16.99934+00
178	ferdinandagossou03@gmail.com	td	t	\N	2026-09-07 19:55:28.983056+00
179	carlosbokononhoui@gmail.com	td	t	\N	2026-09-07 20:02:40.49141+00
180	augustinnoutahi@gmail.com	td	f	\N	2026-09-07 20:10:47.493278+00
181	enagnonaugustinnoutahi@gmail.com	td	f	\N	2026-09-07 20:17:12.319047+00
182	enagnonaugustinnoutahi@gmail.com	td	f	\N	2026-09-07 20:17:48.352146+00
183	enagnonaugustinnoutahi@gmail.com	td	t	\N	2026-09-07 20:21:31.44175+00
184	faroukaremou5@gmail.com	td	f	\N	2026-09-07 21:00:14.734822+00
185	amankpemodeste761@gmail.com	td	f	\N	2026-09-07 21:08:00.066227+00
186	amankpemodeste761@gmail.com	td	t	\N	2026-09-07 21:09:57.790002+00
187	faroukaremou5@gmail.com	td	t	\N	2026-09-07 21:11:18.848169+00
188	jealexhouegbe	admin	t	\N	2026-09-07 21:32:40.499189+00
189	jealexhouegbe	admin	t	\N	2026-09-07 22:24:39.123957+00
190	jealexhouegbe	admin	t	\N	2026-09-07 22:26:26.261929+00
191	akakpoenock00@gmail.com	td	t	\N	2026-09-08 07:45:59.700265+00
192	charliehounkanrin@gmail.com	td	t	\N	2026-09-08 15:04:31.393706+00
193	jealexhouegbe	admin	t	\N	2026-09-08 16:57:23.884135+00
194	aurelgodfrid2@gmail.com	td	t	\N	2026-09-08 17:00:00.644839+00
195	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:16:44.818061+00
196	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:16:52.669302+00
197	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:17:05.670902+00
198	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:17:08.723116+00
199	lassissisaibouadehoumi@gmail.com	td	f	\N	2026-09-08 17:17:50.524738+00
200	aurelgodfrid2@gmail.com	td	t	\N	2026-09-08 17:20:55.367207+00
201	sahopaulh@gmail.com	td	f	\N	2026-09-08 17:39:03.871025+00
202	sahopaulh@gmail.com	td	f	\N	2026-09-08 17:39:37.920437+00
203	sahopaulh@gmail.com	td	f	\N	2026-09-08 17:39:56.194002+00
204	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-08 17:43:04.339291+00
205	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-08 17:46:41.32014+00
206	romaricadjovi12@gmail.com	td	f	\N	2026-09-08 17:49:15.692794+00
207	romaricadjovi12@gmail.com	td	f	\N	2026-09-08 17:50:34.501488+00
208	romaricadjovi12@gmail.com	td	t	\N	2026-09-08 17:50:52.981519+00
209	magbondejerome@gmail.com	td	t	\N	2026-09-08 17:59:41.430013+00
210	simkiki30@gmail.com	td	f	\N	2026-09-08 18:13:39.62656+00
211	simkiki30@gmail.com	td	f	\N	2026-09-08 18:15:20.13368+00
212	simkiki30@gmail.com	td	f	\N	2026-09-08 18:16:16.870798+00
213	simkiki30@gmail.com	td	f	\N	2026-09-08 18:16:27.361542+00
214	simkiki30@gmail.com	td	f	\N	2026-09-08 18:17:06.197495+00
215	simkiki30@gmail.com	admin	f	\N	2026-09-08 18:17:23.833101+00
216	hounkponouhorus@gmail.com	td	t	\N	2026-09-08 18:17:35.516017+00
217	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:29:23.843159+00
218	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:29:47.07518+00
219	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:29:54.72863+00
220	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:30:12.477541+00
221	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:31:43.053269+00
222	armelnou@gmail.com	td	f	\N	2026-09-08 18:36:56.302358+00
223	armelnou@gmail.com	td	f	\N	2026-09-08 18:39:26.315209+00
224	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:54:35.838524+00
225	soglohounfortun93@gmail.com	td	f	\N	2026-09-08 18:54:40.346182+00
226	avocevouemmanuel5@gmail.com	td	f	\N	2026-09-08 19:29:15.226242+00
227	avocevouemmanuel5@gmail.com	td	f	\N	2026-09-08 19:29:19.409738+00
228	avocevouemmanuel5@gmail.com	td	f	\N	2026-09-08 19:29:23.093843+00
229	jealexhouegbe	admin	t	\N	2026-09-08 19:45:56.129496+00
230	leondomessi04@gmail.com	td	f	\N	2026-09-08 21:08:40.258439+00
231	dansoumika8@gmail.com	td	f	\N	2026-09-08 21:38:48.23217+00
232	dansoumika8@gmail.com	td	f	\N	2026-09-08 21:38:57.148777+00
233	dansoumika8@gmail.com	admin	f	\N	2026-09-08 21:39:31.557871+00
234	dansoumika8@gmail.com	td	f	\N	2026-09-08 21:39:46.724113+00
235	jealexhouegbe	admin	t	\N	2026-09-08 21:47:52.463031+00
236	armelnou@gmail.com	td	t	\N	2026-09-08 22:14:06.00525+00
237	merveilleahounhosse54@gmail.com	td	f	\N	2026-09-08 22:25:52.672299+00
238	merveilleahounhosse54@gmail.com	td	f	\N	2026-09-08 22:25:56.175885+00
239	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-08 22:26:48.945064+00
240	jealexhouegbe	admin	t	\N	2026-09-08 22:30:09.289323+00
241	jealexhouegbe	admin	t	\N	2026-09-08 22:52:19.34283+00
242	urielhouegbe	admin	t	\N	2026-09-08 23:11:07.788843+00
243	urielhouegbe	admin	t	\N	2026-09-08 23:19:03.20489+00
244	djossougermain0@gmail.com	td	f	\N	2026-09-09 06:06:59.794509+00
245	djossougermain0@gmail.com	td	f	\N	2026-09-09 06:08:13.159685+00
246	djossougermain0@gmail.com	admin	f	\N	2026-09-09 06:08:28.498005+00
247	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:51:23.743759+00
248	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:51:47.921389+00
249	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:51:52.103425+00
250	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:52:00.293561+00
251	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 06:52:12.493077+00
252	kouamitode@gmail.com	td	f	\N	2026-09-09 10:34:55.250854+00
253	kouamitode@gmail.com	td	f	\N	2026-09-09 10:35:04.24174+00
254	kouamitode@gmail.com	td	f	\N	2026-09-09 10:35:22.752607+00
255	kouamitode@gmail.com	td	f	\N	2026-09-09 10:35:37.942858+00
256	kouamitode@gmail.com	td	f	\N	2026-09-09 10:36:02.048456+00
257	charliehounkanrin@gmail.com	td	t	\N	2026-09-09 10:53:24.239277+00
258	devtesteur	admin	f	\N	2026-09-09 11:31:51.354306+00
259	devtesteur	admin	f	\N	2026-09-09 11:34:50.312325+00
260	devtesteur	admin	f	\N	2026-09-09 11:34:54.929069+00
261	devtesteur	admin	f	\N	2026-09-09 11:35:08.553843+00
262	devtesteur	admin	f	\N	2026-09-09 11:35:12.499136+00
263	devtesteur	admin	f	\N	2026-09-09 11:50:44.816197+00
264	admin	admin	f	\N	2026-09-09 11:51:00.386029+00
265	kouamitode@gmail.com	td	f	\N	2026-09-09 11:58:50.981479+00
266	maurienakouamitode@gmail.com	td	f	\N	2026-09-09 11:59:06.397397+00
267	kouamitode@gmail.com	td	f	\N	2026-09-09 12:00:51.097231+00
268	kouamitode@gmail.com	td	f	\N	2026-09-09 12:06:33.329401+00
269	jealexhouegbe	admin	t	\N	2026-09-09 12:14:28.441223+00
270	kouamitode@gmail.com	td	t	\N	2026-09-09 12:56:58.651341+00
271	urielhouegbe	admin	f	\N	2026-09-09 13:47:46.124369+00
272	urielhouegbe	admin	t	\N	2026-09-09 13:47:52.546863+00
273	jealexhouegbe	admin	t	\N	2026-09-09 14:19:25.970401+00
274	marianototin@gmail.com	td	f	\N	2026-09-09 15:02:11.282244+00
275	jealexhouegbe	admin	t	\N	2026-09-09 21:38:53.460259+00
276	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:15:51.041988+00
277	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:16:06.396019+00
278	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:17:16.093318+00
279	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:17:23.019062+00
280	yessoufouassiath@gmail.com	td	f	\N	2026-09-09 22:17:26.490953+00
281	jealexhouegbe	admin	t	\N	2026-09-09 23:06:43.284138+00
282	jealexhouegbe	admin	t	\N	2026-09-10 04:42:41.325301+00
283	doskice@gmail.com	td	t	\N	2026-09-10 07:06:28.733203+00
284	jealexhouegbe	admin	t	\N	2026-09-11 09:24:14.722432+00
285	marianototin@gmail.com	td	t	\N	2026-09-11 10:37:46.184679+00
286	jealexhouegbe	admin	t	\N	2026-09-11 13:36:36.378006+00
287	urielhouegbe	admin	t	\N	2026-09-11 20:46:22.031152+00
288	jealexhouegbe	admin	t	\N	2026-09-11 21:12:40.316401+00
289	ferdinandagossou03@gmail.com	td	t	\N	2026-09-11 21:53:10.882861+00
290	jealexhouegbe	admin	t	\N	2026-09-11 21:55:52.370143+00
291	dkobahubert@gmail.com	td	t	\N	2026-09-11 22:59:56.564455+00
292	jealexhouegbe	admin	t	\N	2026-09-12 05:12:25.396241+00
293	jealexhouegbe	admin	t	\N	2026-09-12 07:45:33.760722+00
294	akakpoenock00@gmail.com	td	t	\N	2026-09-12 12:21:42.254294+00
295	charliehounkanrin@gmail.com	td	t	\N	2026-09-12 14:24:54.988704+00
296	jealexhouegbe	admin	t	\N	2026-09-12 16:15:34.441634+00
297	jealexhouegbe	admin	t	\N	2026-09-12 19:05:34.549037+00
298	jealexhouegbe	admin	t	\N	2026-09-12 20:04:08.867703+00
299	akakpoenock00@gmail.com	td	t	\N	2026-09-12 20:56:56.561324+00
300	jealexhouegbe	admin	t	\N	2026-09-12 21:04:23.479221+00
301	jealexhouegbe	admin	t	\N	2026-09-13 11:32:09.03945+00
302	jealexhouegbe	admin	t	\N	2026-09-13 13:03:41.064231+00
303	jealexhouegbe	admin	t	\N	2026-09-13 13:52:54.192683+00
304	jealexhouegbe	admin	t	\N	2026-09-13 14:26:06.236833+00
305	urielhouegbe	admin	t	\N	2026-09-13 15:56:07.699482+00
306	jealexhouegbe 	admin	f	\N	2026-09-13 16:26:05.307147+00
307	jealexhouegbe	admin	t	\N	2026-09-13 16:26:12.988548+00
308	jealexhouegbe 	admin	f	\N	2026-09-13 16:31:28.726433+00
309	jealexhouegbe	admin	t	\N	2026-09-13 16:31:36.489244+00
310	yetbaginn 	admin	f	\N	2026-09-13 16:35:06.743305+00
311	yetohoubago@gmail.com 	admin	f	\N	2026-09-13 16:35:30.116141+00
312	yetbaginn	admin	t	\N	2026-09-13 16:36:06.738423+00
313	jealexhouegbe	admin	t	\N	2026-09-13 16:36:56.725496+00
314	quenumparfait	admin	t	\N	2026-09-13 16:39:10.703296+00
315	yetbaginn	admin	t	\N	2026-09-13 16:39:53.692152+00
316	urielhouegbe	admin	t	\N	2026-09-13 16:41:44.983548+00
317	jealexhouegbe	admin	t	\N	2026-09-13 17:19:15.534746+00
318	urielhouegbe	admin	t	\N	2026-09-13 17:47:17.148192+00
319	jealexhouegbe	admin	t	\N	2026-09-13 17:47:19.098982+00
320	quenumparfait	admin	t	\N	2026-09-13 18:12:32.918547+00
321	quenumparfait	admin	t	\N	2026-09-13 18:16:38.374148+00
322	jealexhhouegbe	admin	f	\N	2026-09-13 20:02:32.822467+00
323	jealexhouegbe	admin	t	\N	2026-09-13 20:02:42.177757+00
324	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 20:30:35.311249+00
325	akakpoenock00@gmail.com	td	t	\N	2026-09-13 20:31:59.348786+00
326	mawougnongael91@gmail.com	td	t	\N	2026-09-13 20:33:06.080854+00
327	dkobahubert@gmail.com	td	t	\N	2026-09-13 20:33:42.268853+00
328	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 20:33:46.977433+00
329	aremouramziath@gmail.com	td	t	\N	2026-09-13 20:33:53.58636+00
330	degnonfrederics@gmail.com	td	t	\N	2026-09-13 20:35:11.689687+00
331	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 20:36:49.682391+00
332	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 20:41:12.730103+00
333	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 20:41:50.100314+00
334	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 20:42:24.201952+00
335	jucalhouegbe 	admin	f	\N	2026-09-13 20:45:27.687242+00
336	jucalhouegbe	admin	f	\N	2026-09-13 20:45:32.605097+00
337	jealexhouegbe	admin	t	\N	2026-09-13 20:45:50.82161+00
338	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 20:48:37.891842+00
339	aremouramziath@gmail.com	td	t	\N	2026-09-13 20:48:48.084567+00
340	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 21:07:01.327269+00
341	charliehounkanrin@gmail.com	td	t	\N	2026-09-13 21:17:20.380237+00
342	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 21:18:15.281163+00
343	carlosbokononhoui@gmail.com	td	t	\N	2026-09-13 21:18:44.821227+00
344	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-13 21:41:56.968681+00
345	jealexhouegbe	admin	t	\N	2026-09-13 22:13:40.523994+00
346	jealexhouegbe	admin	t	\N	2026-09-14 02:27:36.209712+00
347	jealexhouegbe	admin	t	\N	2026-09-14 02:44:26.157679+00
348	jealexhouegbe	admin	t	\N	2026-09-14 02:49:47.585415+00
349	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 03:36:26.922808+00
350	jealexhouegbe	admin	t	\N	2026-09-14 06:22:12.335793+00
351	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 06:39:22.198635+00
352	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 06:44:36.316497+00
353	jealexhouegbe	admin	t	\N	2026-09-14 07:12:49.929187+00
354	aremouramziath@gmail.com	td	t	\N	2026-09-14 07:52:19.105004+00
355	faroukaremou5@gmail.com	td	t	\N	2026-09-14 07:54:04.214891+00
356	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 07:55:36.012683+00
357	akakpoenock00@gmail.com	td	t	\N	2026-09-14 07:56:35.097174+00
358	degnonfrederics@gmail.com	td	t	\N	2026-09-14 08:08:44.527587+00
359	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-14 08:19:18.429385+00
360	jealexhouegbe	admin	t	\N	2026-09-14 08:19:21.415706+00
361	carlosbokononhoui@gmail.com	td	t	\N	2026-09-14 08:23:11.992365+00
362	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-14 08:45:21.075536+00
363	florenthinnou@gmail.com	td	t	\N	2026-09-14 09:13:52.516397+00
364	mawougnongael91@gmail.com	td	t	\N	2026-09-14 10:13:28.644776+00
365	jealexhouegbe	admin	t	\N	2026-09-14 10:33:43.965177+00
366	jealexhouegbe	admin	t	\N	2026-09-14 10:38:18.2797+00
367	jealexhouegbe	admin	t	\N	2026-09-14 11:08:14.266565+00
368	jeremieabidegbekponou@gmail.com	td	f	\N	2026-09-14 12:01:35.712231+00
369	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-14 12:01:47.619401+00
370	quenumparfait	admin	f	\N	2026-09-14 12:01:50.036028+00
371	quenumparfait	admin	f	\N	2026-09-14 12:02:01.822162+00
372	quenumparfait	admin	f	\N	2026-09-14 12:02:13.043869+00
373	quenumparfait	admin	f	\N	2026-09-14 12:02:34.742982+00
374	faroukaremou5@gmail.com	td	t	\N	2026-09-14 12:21:03.294228+00
375	mawougnongael91@gmail.com	td	t	\N	2026-09-14 12:47:27.90147+00
376	aldolalumiere80@gmail.com	td	t	\N	2026-09-14 13:55:15.614228+00
377	jealexhouegbe	admin	t	\N	2026-09-14 15:02:06.658439+00
378	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 15:34:58.056752+00
379	dkobahubert@gmail.com	td	t	\N	2026-09-14 15:53:19.769044+00
380	dkobahubert@gmail.com	td	t	\N	2026-09-14 15:53:56.356312+00
381	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 16:48:16.378835+00
382	degnonfrederics@gmail.com	td	t	\N	2026-09-14 16:57:53.587037+00
383	degnonfrederics@gmail.com	td	t	\N	2026-09-14 16:58:59.135653+00
384	leopoldchangodele@gmail.com	td	t	\N	2026-09-14 17:00:41.548585+00
385	quenumparfait	admin	f	\N	2026-09-14 17:03:20.880275+00
386	quenumparfait	admin	f	\N	2026-09-14 17:04:05.021938+00
387	leopoldchangodele@gmail.com	td	t	\N	2026-09-14 17:05:14.402555+00
388	piomedesse@gmail.com	td	t	\N	2026-09-14 17:09:33.380343+00
389	faroukaremou5@gmail.com	td	t	\N	2026-09-14 17:13:25.125716+00
390	jealexhouegbe	admin	t	\N	2026-09-14 17:24:52.534823+00
391	degnonfrederics@gmail.com	td	f	\N	2026-09-14 18:15:21.955912+00
392	degnonfrederics@gmail.com	td	t	\N	2026-09-14 18:15:45.97897+00
393	charliehounkanrin@gmail.com	td	t	\N	2026-09-14 19:16:54.251058+00
394	aldolalumiere80@gmail.com	td	t	\N	2026-09-14 19:59:18.513296+00
395	degnonfrederics@gmail.com	td	f	\N	2026-09-14 20:07:43.54482+00
396	degnonfrederics@gmail.com	td	t	\N	2026-09-14 20:08:12.950217+00
397	jealexhouegbe	admin	t	\N	2026-09-14 20:08:59.916574+00
398	akakpoenock00@gmail.com	td	t	\N	2026-09-14 20:25:45.539221+00
399	gedeonfinagnont@gmail.com	td	f	\N	2026-09-14 20:29:24.212008+00
400	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-14 20:29:56.162711+00
401	angekarson1@gmail.com	td	t	\N	2026-09-14 20:30:10.274982+00
402	leopoldchangodele@gmail.com	td	t	\N	2026-09-14 20:39:46.605144+00
403	jealexhouegbe	admin	t	\N	2026-09-14 20:44:59.542519+00
404	aldolalumiere80@gmail.com	td	t	\N	2026-09-14 20:54:46.695949+00
405	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:06.212954+00
406	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:16.180479+00
407	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:43.84361+00
408	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:56:55.789539+00
409	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 20:57:12.517721+00
410	zoutounnouf@gmail.com	td	t	\N	2026-09-14 21:24:39.426456+00
411	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:17.763746+00
412	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:32.558787+00
413	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:45.03107+00
414	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:31:54.291687+00
415	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:32:00.574816+00
416	louislucnou@gmail.com	td	t	\N	2026-09-14 21:34:28.667884+00
417	hounkponouhorus@gmail.com	td	t	\N	2026-09-14 21:51:07.715578+00
418	hounkponouhorus@gmail.com	td	t	\N	2026-09-14 21:51:38.507981+00
419	amankpemodeste761@gmail.com	td	f	\N	2026-09-14 21:55:08.912686+00
420	claudekinninnon@gmail.com	td	t	\N	2026-09-14 22:20:04.702679+00
421	akakpoenock00@gmail.com	td	t	\N	2026-09-14 22:31:12.136727+00
422	akakpoenock00@gmail.com	td	t	\N	2026-09-14 22:31:14.213917+00
423	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-14 23:22:50.764148+00
424	jealexhouegbe	admin	t	\N	2026-09-14 23:23:43.072662+00
425	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:38:25.203824+00
426	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:38:48.274015+00
427	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:38:53.006946+00
428	amankpemodeste761@gmail.com	td	f	\N	2026-09-15 00:39:10.161193+00
429	amankpemodeste761@gmail.com	td	t	\N	2026-09-15 00:39:35.540737+00
430	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 04:07:01.799311+00
431	jealexhouegbe	admin	t	\N	2026-09-15 04:56:34.935869+00
432	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-15 04:59:03.982198+00
433	degnonfrederics@gmail.com	td	f	\N	2026-09-15 05:08:47.078517+00
434	degnonfrederics@gmail.com	td	t	\N	2026-09-15 05:09:10.487664+00
435	akakpoenock00@gmail.com	td	t	\N	2026-09-15 05:27:01.58124+00
436	aremouramziath@gmail.com	td	t	\N	2026-09-15 05:39:19.151356+00
437	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 05:53:39.054546+00
438	louislucnou@gmail.com	td	t	\N	2026-09-15 06:00:45.081844+00
439	akakpoenock00@gmail.com	td	t	\N	2026-09-15 06:06:29.361792+00
440	jealexhouegbe	admin	t	\N	2026-09-15 06:08:34.872285+00
441	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 06:09:40.357533+00
442	akakpoenock00@gmail.com	td	t	\N	2026-09-15 06:10:01.633277+00
443	jealexhouegbe	admin	t	\N	2026-09-15 06:38:25.797637+00
444	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:11.29723+00
445	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:25.093319+00
446	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:43.038742+00
447	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:46:45.673678+00
448	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 06:48:15.905496+00
449	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 07:05:19.210638+00
450	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 07:05:44.8095+00
451	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:08:14.126559+00
452	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:08:29.266763+00
453	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:09:39.250525+00
454	jealexhouegbe	admin	t	\N	2026-09-15 07:09:47.267292+00
455	yessoufouassiath@gmail.com	td	f	\N	2026-09-15 07:09:58.425099+00
456	akakpoenock00@gmail.com	td	t	\N	2026-09-15 07:12:29.200605+00
457	amankpemodeste761@gmail.com	td	t	\N	2026-09-15 07:28:12.147881+00
458	mawougnongael91@gmail.com	td	t	\N	2026-09-15 07:30:40.572581+00
459	akakpoenock00@gmail.com	td	t	\N	2026-09-15 07:33:41.146011+00
460	piomedesse@gmail.com	td	t	\N	2026-09-15 07:47:34.54749+00
802	jealexhouegbe	admin	t	\N	2026-09-24 00:31:57.016876+00
461	leopoldchangodele@gmail.com	td	t	\N	2026-09-15 08:00:08.413757+00
462	aremouramziath@gmail.com	td	t	\N	2026-09-15 08:04:56.646635+00
463	aremouramziath@gmail.com	td	t	\N	2026-09-15 08:09:40.444156+00
464	akakpoenock00@gmail.com	td	t	\N	2026-09-15 08:26:32.625503+00
465	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-15 08:27:18.535341+00
466	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-15 08:39:36.161849+00
467	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:41:26.81277+00
468	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:41:35.125522+00
469	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:42:00.524111+00
470	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:42:05.578068+00
471	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 08:42:30.051832+00
472	jealexhouegbe	admin	t	\N	2026-09-15 08:53:00.798155+00
473	aldolalumiere80@gmail.com	td	t	\N	2026-09-15 08:59:01.989166+00
474	sedodeconstant@gmail.com	td	t	\N	2026-09-15 09:05:49.196522+00
475	charliehounkanrin@gmail.com	td	t	\N	2026-09-15 09:14:04.12642+00
476	degnonfrederics@gmail.com	td	f	\N	2026-09-15 09:16:40.101657+00
477	degnonfrederics@gmail.com	td	t	\N	2026-09-15 09:16:54.30772+00
478	claudekinninnon@gmail.com	td	t	\N	2026-09-15 09:26:30.168434+00
479	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:32:19.899545+00
480	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:32:25.211387+00
481	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:32:36.377973+00
482	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:36:09.17439+00
483	kpogbagislain323@gmail.com	td	f	\N	2026-09-15 09:41:45.0129+00
484	jealexhouegbe	admin	t	\N	2026-09-15 09:49:38.81699+00
485	magbondejerome@gmail.com	admin	f	\N	2026-09-15 10:14:11.381824+00
486	magbondejerome@gmail.com	admin	f	\N	2026-09-15 10:14:34.715164+00
487	magbondejerome@gmail.com	admin	f	\N	2026-09-15 10:15:46.24324+00
488	magbondejerome@gmail.com	td	t	\N	2026-09-15 10:18:27.829812+00
489	faroukaremou5@gmail.com	td	t	\N	2026-09-15 10:19:57.850876+00
490	holonoubienvenu@gmail.com	td	t	\N	2026-09-15 10:21:28.390004+00
491	jealexhouegbe	admin	t	\N	2026-09-15 10:29:43.415169+00
492	holonoubienvenu@gmail.com	td	t	\N	2026-09-15 10:38:20.492+00
493	jealexhouegbe	admin	t	\N	2026-09-15 12:46:37.981173+00
494	florenthinnou@gmail.com	td	t	\N	2026-09-15 13:22:38.114858+00
495	aldolalumiere80@gmail.com	td	t	\N	2026-09-15 13:30:40.015791+00
496	florenthinnou@gmail.com	td	t	\N	2026-09-15 13:31:03.004454+00
497	jealexhouegbe	admin	t	\N	2026-09-15 17:15:21.820908+00
498	piomedesse@gmail.com	td	t	\N	2026-09-15 19:20:26.200688+00
499	simkiki30@gmail.com	td	t	\N	2026-09-15 20:01:36.169551+00
500	jealexhouegbe	admin	t	\N	2026-09-15 20:28:53.529723+00
501	piomedesse@gmail.com	td	t	\N	2026-09-15 20:34:14.08046+00
502	jealexhouegbe	admin	t	\N	2026-09-15 22:05:28.421328+00
503	degnonfrederics@gmail.com	td	t	\N	2026-09-15 22:35:18.00474+00
504	ferdinandagossou03@gmail.com	td	t	\N	2026-09-16 05:50:23.009355+00
505	jealexhouegbe	admin	t	\N	2026-09-16 05:54:01.306439+00
506	ferdinandagossou03@gmail.com	td	t	\N	2026-09-16 05:59:43.680547+00
507	kouamitode@gmail.com	td	t	\N	2026-09-16 06:34:18.896389+00
508	urielhouegbe	admin	t	\N	2026-09-16 06:47:28.534511+00
509	urielhouegbe	admin	t	\N	2026-09-16 07:19:56.141006+00
510	ferdinandagossou03@gmail.com	td	t	\N	2026-09-16 07:35:32.0397+00
511	jealexhouegbe	admin	t	\N	2026-09-16 07:44:53.897668+00
512	urielhouegbe	admin	t	\N	2026-09-16 08:38:24.625272+00
513	charliehounkanrin@gmail.com	td	t	\N	2026-09-16 09:05:00.595052+00
514	urielhouegbe	admin	t	\N	2026-09-16 12:38:59.529242+00
515	piomedesse@gmail.com	td	t	\N	2026-09-16 15:19:22.943976+00
516	akakpoenock00@gmail.com	td	t	\N	2026-09-16 15:54:17.422352+00
517	urielhouegbe	admin	t	\N	2026-09-16 16:51:58.420869+00
518	yessoufouassiath@gmail.com	td	f	\N	2026-09-16 21:08:55.763691+00
519	yessoufouassiath@gmail.com	td	f	\N	2026-09-16 21:09:03.15793+00
520	yessoufouassiath@gmail.com	td	f	\N	2026-09-16 21:10:13.965369+00
521	jealexhouegbe	admin	t	\N	2026-09-16 21:41:30.427353+00
522	urielhouegbe	admin	t	\N	2026-09-16 22:16:13.499436+00
523	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-16 22:37:03.384314+00
524	urielhouegbe	admin	t	\N	2026-09-17 00:21:52.699146+00
525	aldolalumiere80@gmail.com	td	t	\N	2026-09-17 05:09:51.625892+00
526	jealexhouegbe	admin	t	\N	2026-09-17 06:29:43.919173+00
527	jealexhouegbe	admin	t	\N	2026-09-17 07:13:48.070833+00
528	urielhouegbe	admin	t	\N	2026-09-17 08:41:20.920998+00
529	jealexhouegbe	admin	t	\N	2026-09-17 09:59:47.871253+00
530	yessoufouassiath@gmail.com	td	f	\N	2026-09-17 10:54:14.629609+00
531	yessoufouassiath@gmail.com	td	f	\N	2026-09-17 10:54:34.353802+00
532	yessoufouassiath@gmail.com	td	t	\N	2026-09-17 10:55:14.853525+00
533	jealexhouegbe	admin	t	\N	2026-09-17 10:57:34.035749+00
534	jealexhouegbe	admin	t	\N	2026-09-17 13:40:39.189304+00
535	jealexhouegbe	admin	t	\N	2026-09-17 14:14:39.533782+00
536	jealexhouegbe	admin	t	\N	2026-09-17 14:46:04.594068+00
537	urielhouegbe	admin	t	\N	2026-09-17 20:30:41.876733+00
538	urielhouegbe	admin	t	\N	2026-09-17 21:45:17.500877+00
539	urielhouegbe	admin	t	\N	2026-09-17 21:51:42.506607+00
540	jealexhouegbe	admin	t	\N	2026-09-17 22:17:26.964582+00
541	urielhouegbe	admin	t	\N	2026-09-17 22:56:07.356109+00
542	urielhouegbe	admin	t	\N	2026-09-17 22:57:53.68002+00
543	urielhouegbe	admin	t	\N	2026-09-18 00:38:26.097269+00
544	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 04:45:38.99622+00
545	urielhouegbe	admin	t	\N	2026-09-18 06:47:59.320793+00
546	urielhouegbe	admin	t	\N	2026-09-18 07:04:00.839454+00
547	urielhouegbe	admin	t	\N	2026-09-18 07:08:47.007735+00
548	faroukaremou5@gmail.com	td	t	\N	2026-09-18 08:31:36.95279+00
549	quenumparfait	admin	f	\N	2026-09-18 09:00:41.180427+00
550	quenumparfait	admin	f	\N	2026-09-18 09:00:50.080869+00
551	quenumparfait	admin	f	\N	2026-09-18 09:01:32.361146+00
552	quenumparfait	admin	f	\N	2026-09-18 09:01:42.120826+00
553	quenumparfait	admin	f	\N	2026-09-18 09:01:44.922874+00
554	jealexhouegbe	admin	t	\N	2026-09-18 09:09:50.880836+00
555	quenumparfait	admin	t	\N	2026-09-18 10:39:58.30649+00
556	quenumparfait	admin	t	\N	2026-09-18 11:38:37.272266+00
557	faroukaremou5@gmail.com	td	t	\N	2026-09-18 13:18:37.8919+00
558	viptomtogbe@gmail.com	td	t	\N	2026-09-18 15:40:07.82417+00
559	viptomtogbe@gmail.com	td	t	\N	2026-09-18 15:43:21.876298+00
560	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 16:13:11.609829+00
561	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 17:56:40.413214+00
562	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 17:58:27.453133+00
563	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 18:12:46.956095+00
564	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 18:18:54.503289+00
565	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 18:58:10.15049+00
566	ferdinandagossou03@gmail.com	td	t	\N	2026-09-18 19:17:00.736874+00
567	quenumparfait	admin	t	\N	2026-09-18 20:00:26.812911+00
568	jealexhouegbe	admin	t	\N	2026-09-18 20:09:43.264873+00
569	jealexhouegbe	admin	t	\N	2026-09-18 20:12:45.466909+00
570	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 20:16:11.676172+00
571	quenumparfait	admin	t	\N	2026-09-18 20:18:19.866688+00
572	quenumparfait	admin	t	\N	2026-09-18 20:26:52.878544+00
573	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-18 20:50:55.495249+00
574	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 21:46:01.408132+00
575	charliehounkanrin@gmail.com	td	t	\N	2026-09-18 21:53:36.931866+00
576	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-18 21:57:47.330228+00
577	jealexhouegbe	admin	t	\N	2026-09-18 23:04:51.46287+00
578	quenumparfait	admin	t	\N	2026-09-19 00:00:36.673577+00
579	quenumparfait	admin	t	\N	2026-09-19 00:21:49.510363+00
580	quenumparfait	admin	t	\N	2026-09-19 00:23:52.178512+00
581	jealexhouegbe	admin	t	\N	2026-09-19 00:31:50.65233+00
582	jealexhouegbe	admin	t	\N	2026-09-19 03:59:08.55466+00
583	charliehounkanrin@gmail.com	td	t	\N	2026-09-19 05:13:46.631509+00
584	quenumparfait	admin	t	\N	2026-09-19 06:38:09.118844+00
585	mawougnongael91@gmail.com	td	t	\N	2026-09-19 07:20:34.268459+00
586	akakpoenock00@gmail.com	td	t	\N	2026-09-19 07:23:38.479629+00
587	degnonfrederics@gmail.com	td	f	\N	2026-09-19 07:25:46.266463+00
588	degnonfrederics@gmail.com	td	t	\N	2026-09-19 07:25:53.560794+00
589	quenumparfait	admin	t	\N	2026-09-19 08:00:09.485353+00
590	charliehounkanrin@gmail.com	td	t	\N	2026-09-19 08:37:12.55476+00
591	jealexhouegbe	admin	t	\N	2026-09-19 08:38:49.758004+00
592	urielhouegbe	admin	t	\N	2026-09-19 09:04:26.321409+00
593	quenumparfait	admin	t	\N	2026-09-19 09:05:39.215494+00
594	aremouramziath@gmail.com	td	t	\N	2026-09-19 09:16:13.106342+00
595	quenumparfait	admin	t	\N	2026-09-19 09:27:57.005945+00
596	padampierre@gmail.com	td	t	\N	2026-09-19 10:28:32.316665+00
597	degnonfrederics@gmail.com	td	t	\N	2026-09-19 10:29:27.90775+00
598	peter21	admin	f	\N	2026-09-19 10:30:12.207003+00
599	peter21	admin	f	\N	2026-09-19 10:30:53.983368+00
600	peter21	admin	f	\N	2026-09-19 10:31:07.742519+00
601	padampierre@gmail.com	admin	f	\N	2026-09-19 10:33:19.562825+00
602	peter21	admin	f	\N	2026-09-19 10:33:41.948272+00
603	peter21	admin	f	\N	2026-09-19 10:34:07.130362+00
604	Peter21	admin	f	\N	2026-09-19 10:35:40.955104+00
605	Peter21	admin	f	\N	2026-09-19 10:35:43.231535+00
606	Peter21	admin	t	\N	2026-09-19 10:37:43.441317+00
607	akakpoenock00@gmail.com	td	t	\N	2026-09-19 10:43:14.631566+00
608	faroukaremou5@gmail.com	td	t	\N	2026-09-19 11:16:01.096574+00
609	urielhouegbe	admin	t	\N	2026-09-19 12:09:18.502261+00
610	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-19 12:13:13.149981+00
611	aldolalumiere80@gmail.com	td	t	\N	2026-09-19 12:28:09.582062+00
612	piomedesse@gmail.com	td	t	\N	2026-09-19 13:14:00.904345+00
613	akakpoenock00@gmail.com	td	t	\N	2026-09-19 16:40:32.732899+00
614	degnonfrederics@gmail.com	td	f	\N	2026-09-19 17:21:51.549856+00
615	degnonfrederics@gmail.com	td	t	\N	2026-09-19 17:22:01.929853+00
616	faroukaremou5@gmail.com	td	t	\N	2026-09-19 19:01:29.538336+00
617	charliehounkanrin@gmail.com	td	t	\N	2026-09-19 22:18:55.475231+00
618	jealexhouegbe	admin	t	\N	2026-09-20 07:16:07.108822+00
619	jealexhouegbe	admin	t	\N	2026-09-20 07:46:23.200118+00
620	charliehounkanrin@gmail.com	td	t	\N	2026-09-20 09:20:50.362389+00
621	degnonfrederics@gmail.com	td	t	\N	2026-09-20 09:26:30.335328+00
622	akakpoenock00@gmail.com	td	t	\N	2026-09-20 09:43:15.088835+00
623	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 10:04:42.812199+00
624	viptomtogbe@gmail.com	td	t	\N	2026-09-20 10:14:26.174577+00
625	jealexhouegbe	admin	t	\N	2026-09-20 10:25:28.752378+00
626	kouamitode@gmail.com	td	t	\N	2026-09-20 11:11:52.362013+00
627	mawougnongael91@gmail.com	td	t	\N	2026-09-20 11:12:06.582752+00
628	jealexhouegbe	admin	t	\N	2026-09-20 11:13:14.247388+00
629	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 11:17:52.513866+00
630	leopoldchangodele@gmail.com	td	t	\N	2026-09-20 11:19:02.165555+00
631	viptomtogbe@gmail.com	td	t	\N	2026-09-20 11:28:23.259796+00
632	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-20 11:39:45.711076+00
633	kouamitode@gmail.com	td	t	\N	2026-09-20 11:43:27.187175+00
634	degnonfrederics@gmail.com	td	f	\N	2026-09-20 12:03:05.844224+00
635	degnonfrederics@gmail.com	td	t	\N	2026-09-20 12:03:15.505796+00
636	leopoldchangodele@gmail.com	td	t	\N	2026-09-20 13:00:34.422602+00
637	carlosbokononhoui@gmail.com	td	t	\N	2026-09-20 13:07:10.645152+00
638	carlosbokononhoui@gmail.com	td	t	\N	2026-09-20 13:07:58.626281+00
639	carlosbokononhoui@gmail.com	td	t	\N	2026-09-20 13:08:29.501287+00
640	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 13:20:12.064464+00
641	jealexhouegbe	admin	t	\N	2026-09-20 14:22:11.208248+00
642	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-20 15:26:03.210564+00
643	jealexhouegbe	admin	t	\N	2026-09-20 15:30:17.647904+00
644	charliehounkanrin@gmail.com	td	t	\N	2026-09-20 16:15:13.683793+00
645	jealexhouegbe	admin	t	\N	2026-09-20 18:18:43.699601+00
646	jealexhouegbe	admin	t	\N	2026-09-20 19:45:39.555992+00
647	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 19:51:41.88047+00
648	faroukaremou5@gmail.com	td	t	\N	2026-09-20 21:00:42.042149+00
649	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 22:37:49.158012+00
650	aldolalumiere80@gmail.com	td	t	\N	2026-09-20 23:56:52.251064+00
651	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 04:22:31.521749+00
652	akakpoenock00@gmail.com	td	t	\N	2026-09-21 05:23:06.366007+00
653	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 06:13:18.383983+00
654	jealexhouegbe	admin	t	\N	2026-09-21 06:26:50.54392+00
655	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 07:00:00.648211+00
656	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 07:13:34.271488+00
657	mawougnongael91@gmail.com	td	t	\N	2026-09-21 07:55:33.183759+00
658	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:04:45.079888+00
659	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 08:14:18.613803+00
660	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:34:21.437383+00
661	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:35:11.537207+00
662	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 08:39:59.286978+00
663	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 08:48:32.101492+00
664	mawougnongael91@gmail.com	td	t	\N	2026-09-21 08:58:59.625854+00
665	faroukaremou5@gmail.com	td	t	\N	2026-09-21 08:59:59.218462+00
666	carlosbokononhoui@gmail.com	td	t	\N	2026-09-21 09:02:16.220066+00
667	jealexhouegbe	admin	t	\N	2026-09-21 09:08:54.273639+00
668	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-21 09:34:32.121988+00
669	hounkponouhorus@gmail.com	td	t	\N	2026-09-21 09:45:06.135643+00
670	kouamitode@gmail.com	td	t	\N	2026-09-21 09:45:12.439303+00
671	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-21 09:45:47.167143+00
672	akakpoenock00@gmail.com	td	t	\N	2026-09-21 09:47:21.026693+00
673	aremouramziath@gmail.com	td	t	\N	2026-09-21 09:48:21.872944+00
674	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 09:51:26.735023+00
675	florenthinnou@gmail.com	td	t	\N	2026-09-21 10:04:51.271533+00
676	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 10:09:28.002011+00
677	leopoldchangodele@gmail.com	td	t	\N	2026-09-21 10:28:35.84869+00
678	mawougnongael91@gmail.com	td	t	\N	2026-09-21 10:36:12.242166+00
679	jealexhouegbe	admin	t	\N	2026-09-21 10:45:07.11784+00
680	jealexhouegbe	admin	t	\N	2026-09-21 10:49:32.297775+00
681	viptomtogbe@gmail.com	td	t	\N	2026-09-21 11:07:58.662933+00
682	degnonfrederics@gmail.com	td	t	\N	2026-09-21 11:13:11.444998+00
683	amankpemodeste761@gmail.com	td	t	\N	2026-09-21 11:17:49.479503+00
684	dkobahubert@gmail.com	td	t	\N	2026-09-21 11:20:44.047378+00
685	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 11:21:16.539557+00
686	dkobahubert@gmail.com	td	t	\N	2026-09-21 11:21:21.748433+00
687	claudekinninnon@gmail.com	td	t	\N	2026-09-21 11:41:54.098608+00
688	ferdinandagossou03@gmail.com	td	t	\N	2026-09-21 11:50:41.465952+00
689	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-21 12:30:22.433864+00
690	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 12:40:55.292635+00
691	yessoufouassiath@gmail.com	td	t	\N	2026-09-21 13:05:48.106133+00
692	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 13:13:21.729536+00
693	jealexhouegbe	admin	t	\N	2026-09-21 13:18:40.859992+00
694	jealexhouegbe	admin	t	\N	2026-09-21 14:11:06.721033+00
695	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 14:42:58.312733+00
696	charliehounkanrin@gmail.com	td	t	\N	2026-09-21 14:56:39.14915+00
697	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 15:15:47.540424+00
698	carlosbokononhoui@gmail.com	td	t	\N	2026-09-21 15:17:40.187382+00
699	akakpoenock00@gmail.com	td	t	\N	2026-09-21 15:39:40.373431+00
700	leopoldchangodele@gmail.com	td	t	\N	2026-09-21 15:44:21.905659+00
701	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-21 16:22:12.769817+00
702	amankpemodeste761@gmail.com	td	t	\N	2026-09-21 16:27:40.75787+00
703	piomedesse@gmail.com	td	t	\N	2026-09-21 17:07:10.13837+00
704	jealexhouegbe	admin	t	\N	2026-09-21 17:12:34.920753+00
705	mawougnongael91@gmail.com	td	t	\N	2026-09-21 18:11:19.886524+00
706	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 18:42:05.46564+00
707	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-21 18:48:39.820863+00
708	degnonfrederics@gmail.com	td	t	\N	2026-09-21 18:52:58.328667+00
709	yessoufouassiath@gmail.com	td	t	\N	2026-09-21 19:52:45.430887+00
710	carlosbokononhoui@gmail.com	td	t	\N	2026-09-21 19:55:40.372583+00
711	dkobahubert@gmail.com	td	t	\N	2026-09-21 20:31:29.86423+00
712	kouamitode@gmail.com	td	t	\N	2026-09-21 22:09:12.660567+00
713	aldolalumiere80@gmail.com	td	t	\N	2026-09-21 22:31:38.480372+00
714	jealexhouegbe	admin	f	\N	2026-09-22 03:14:11.599391+00
715	jealexhouegbe	admin	t	\N	2026-09-22 03:14:33.387369+00
716	jealexhouegbe	admin	t	\N	2026-09-22 03:26:30.982668+00
717	jealexhouegbe	admin	t	\N	2026-09-22 05:22:14.787766+00
718	degnonfrederics@gmail.com	td	f	\N	2026-09-22 05:38:43.990037+00
719	degnonfrederics@gmail.com	td	t	\N	2026-09-22 05:39:10.651486+00
720	ghics2000@gmail.com	td	f	\N	2026-09-22 06:09:18.173894+00
721	ghics2000@gmail.com	td	f	\N	2026-09-22 06:09:59.31258+00
722	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:11:40.632043+00
723	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:14:20.146326+00
724	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:19:02.534852+00
725	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:22:07.507141+00
726	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:25:06.149431+00
727	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:25:39.658213+00
728	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:25:53.577016+00
729	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:26:32.421267+00
730	ghics2000@yahoo.fr	td	t	\N	2026-09-22 06:31:30.11526+00
731	yessoufouassiath@gmail.com	td	t	\N	2026-09-22 06:34:30.042176+00
732	urielhouegbe	admin	t	\N	2026-09-22 07:24:58.898319+00
733	jealexhouegbe	admin	t	\N	2026-09-22 07:47:41.045295+00
734	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 08:01:08.28837+00
735	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-22 08:08:21.264897+00
736	urielhouegbe	admin	t	\N	2026-09-22 08:50:12.028718+00
737	jealexhouegbe	admin	t	\N	2026-09-22 08:52:37.119133+00
738	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 09:29:14.665171+00
739	dkobahubert@gmail.com	td	t	\N	2026-09-22 09:33:38.516413+00
740	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:03.104267+00
741	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:07.792615+00
742	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:45.208212+00
743	sedodeconstant@gmail.com	admin	f	\N	2026-09-22 09:51:48.903476+00
744	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 10:10:40.722216+00
745	degnonfrederics@gmail.com	td	f	\N	2026-09-22 10:58:42.525009+00
746	degnonfrederics@gmail.com	td	t	\N	2026-09-22 10:59:09.113603+00
747	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-22 11:08:16.963661+00
748	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 11:23:49.616765+00
749	dansoumika8@gmail.com	admin	f	\N	2026-09-22 11:33:22.085664+00
750	dansoumika8@gmail.com	admin	f	\N	2026-09-22 11:33:28.991237+00
751	dansoumika8@gmail.com	admin	f	\N	2026-09-22 11:33:46.389683+00
752	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:17:58.335261+00
753	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:18:12.163451+00
754	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:18:26.527632+00
755	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:18:55.406701+00
756	2026EN000063	admin	f	\N	2026-09-22 12:19:22.445348+00
757	degnonfrederics@gmail.com	admin	f	\N	2026-09-22 12:19:42.527346+00
758	degnonfrederics@gmail.com	td	t	\N	2026-09-22 12:20:25.383561+00
759	aremouramziath@gmail.com	td	t	\N	2026-09-22 12:47:22.556455+00
760	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 12:52:56.858291+00
761	aremouramziath@gmail.com	td	t	\N	2026-09-22 13:01:04.007867+00
762	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 13:59:22.918114+00
763	dkobahubert@gmail.com	td	t	\N	2026-09-22 14:11:21.187369+00
764	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 14:38:03.947205+00
765	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 15:08:57.409302+00
766	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 15:48:28.05652+00
767	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 16:35:50.697029+00
768	jealexhouegbe	admin	t	\N	2026-09-22 16:45:38.54814+00
769	degnonfrederics@gmail.com	td	t	\N	2026-09-22 17:30:47.112596+00
770	jealexhouegbe	admin	t	\N	2026-09-22 18:09:47.271998+00
771	djossougermain0@gmail.com	td	t	\N	2026-09-22 18:38:55.690776+00
772	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-22 18:41:44.483811+00
773	degnonfrederics@gmail.com	td	t	\N	2026-09-22 18:44:54.511497+00
774	aldolalumiere80@gmail.com	td	t	\N	2026-09-22 18:58:29.066525+00
775	piomedesse@gmail.com	td	t	\N	2026-09-22 19:06:18.95368+00
776	akakpoenock00@gmail.com	td	t	\N	2026-09-22 19:07:00.853812+00
777	dkobahubert@gmail.com	td	t	\N	2026-09-22 19:10:08.801389+00
778	leopoldchangodele@gmail.com	td	t	\N	2026-09-22 19:11:09.150577+00
779	holonoubienvenu@gmail.com	td	f	\N	2026-09-22 19:11:59.762983+00
780	holonoubienvenu@gmail.com	td	t	\N	2026-09-22 19:12:10.634667+00
781	holonoubienvenu@gmail.com	td	t	\N	2026-09-22 19:16:04.212906+00
782	amankpemodeste761@gmail.com	td	t	\N	2026-09-22 19:20:25.848577+00
783	charliehounkanrin@gmail.com	td	t	\N	2026-09-22 19:23:46.007984+00
784	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-22 19:24:58.182638+00
785	degnonfrederics@gmail.com	td	t	\N	2026-09-22 19:29:34.514938+00
786	hounkponouhorus@gmail.com	td	t	\N	2026-09-22 19:29:51.574866+00
787	faroukaremou5@gmail.com	td	t	\N	2026-09-22 19:51:24.903828+00
788	dansoumika8@gmail.com	td	t	\N	2026-09-22 20:11:21.796009+00
789	dkobahubert@gmail.com	td	t	\N	2026-09-22 21:00:35.490529+00
790	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-22 21:05:55.069274+00
791	kouamitode@gmail.com	td	t	\N	2026-09-22 21:10:45.262108+00
792	mawougnongael91@gmail.com	td	t	\N	2026-09-22 21:48:05.230105+00
793	armelnou@gmail.com	td	t	\N	2026-09-22 21:52:33.28886+00
794	jealexhouegbe	admin	t	\N	2026-09-23 04:31:43.818535+00
795	degnonfrederics@gmail.com	td	t	\N	2026-09-23 04:56:17.839335+00
796	degnonfrederics@gmail.com	td	t	\N	2026-09-23 05:09:17.330679+00
797	jealexhouegbe	admin	t	\N	2026-09-23 05:45:15.42257+00
798	akakpoenock00@gmail.com	td	t	\N	2026-09-23 06:03:19.502578+00
799	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-23 06:48:42.105729+00
800	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-23 07:10:29.457729+00
801	charliehounkanrin@gmail.com	td	t	\N	2026-09-23 14:25:34.699875+00
803	jealexhouegbe	admin	t	\N	2026-09-24 07:37:52.805655+00
804	jealexhouegbe	admin	t	\N	2026-09-24 08:14:27.686267+00
805	louislucnou@gmail.com	td	t	\N	2026-09-24 08:44:52.59898+00
806	simkiki30@gmail.com	td	t	\N	2026-09-24 09:08:09.585531+00
807	jealexhouegbe	admin	t	\N	2026-09-24 10:15:35.802607+00
808	simkiki30@gmail.com	td	t	\N	2026-09-24 10:22:58.90969+00
809	simkiki30@gmail.com	td	t	\N	2026-09-24 10:31:28.519736+00
810	aldolalumiere80@gmail.com	td	t	\N	2026-09-24 12:18:42.486364+00
811	jealexhouegbe	admin	t	\N	2026-09-24 13:06:13.417248+00
812	jealexhouegbe	admin	t	\N	2026-09-24 14:39:52.763397+00
813	jealexhouegbe	admin	t	\N	2026-09-24 16:16:59.64551+00
814	aldolalumiere80@gmail.com	td	t	\N	2026-09-24 16:47:44.996481+00
815	leopoldchangodele@gmail.com	td	t	\N	2026-09-24 18:17:49.209922+00
816	jealexhouegbe	admin	t	\N	2026-09-24 22:13:25.45618+00
817	jealexhouegbe	admin	t	\N	2026-09-24 22:16:49.204616+00
818	aldolalumiere80@gmail.com	td	t	\N	2026-09-24 23:07:41.230018+00
819	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-25 09:08:51.182638+00
820	jealexhouegbe	admin	t	\N	2026-09-25 12:09:07.90138+00
821	louislucnou@gmail.com	td	t	\N	2026-09-25 12:37:31.165624+00
822	louislucnou@gmail.com	td	t	\N	2026-09-25 12:38:21.296757+00
823	jealexhouegbe	admin	t	\N	2026-09-25 12:38:44.399774+00
824	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-25 12:53:29.367939+00
825	jealexhouegbe	admin	t	\N	2026-09-25 13:14:08.016772+00
826	jealexhouegbe	admin	t	\N	2026-09-25 14:49:26.011764+00
827	jealexhouegbe	admin	t	\N	2026-09-25 15:51:19.591006+00
828	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-25 16:56:22.567264+00
829	jealexhouegbe	admin	t	\N	2026-09-25 17:06:01.75304+00
830	codjoabel00@gmail.com	td	t	\N	2026-09-25 17:20:49.126687+00
831	mawougnongael91@gmail.com	td	t	\N	2026-09-25 18:01:07.593248+00
832	quenumparfait	admin	f	\N	2026-09-25 18:13:54.792178+00
833	quenumparfait	admin	f	\N	2026-09-25 18:13:59.92519+00
834	quenumparfait	admin	f	\N	2026-09-25 18:14:08.645716+00
835	quenumparfait	admin	f	\N	2026-09-25 18:14:33.927259+00
836	jealexhouegbe	admin	t	\N	2026-09-25 18:27:03.960406+00
837	quenumparfait	admin	f	\N	2026-09-25 18:28:35.074759+00
838	jealexhouegbe	admin	t	\N	2026-09-25 18:28:49.355065+00
839	charliehounkanrin@gmail.com	td	t	\N	2026-09-25 19:23:58.175672+00
840	quenumparfait	admin	f	\N	2026-09-25 19:26:18.656304+00
841	jealexhouegbe	admin	t	\N	2026-09-25 20:43:54.857646+00
842	padampierre@gmail.com	admin	f	\N	2026-09-25 21:28:10.791936+00
843	padampierre@gmail.com	admin	f	\N	2026-09-25 21:30:25.117672+00
844	padampierre@gmail.com	admin	f	\N	2026-09-25 21:30:39.703394+00
845	peter21	admin	f	\N	2026-09-25 21:31:22.100499+00
846	peter21	admin	f	\N	2026-09-25 21:31:26.493751+00
847	peter21	admin	f	\N	2026-09-25 21:31:40.064108+00
848	jealexhouegbe	admin	t	\N	2026-09-25 21:38:58.22936+00
849	jealexhouegbe	admin	t	\N	2026-09-25 21:41:06.124744+00
850	aldolalumiere80@gmail.com	td	t	\N	2026-09-25 22:12:40.753467+00
851	jealexhouegbe	admin	t	\N	2026-09-25 22:23:50.77617+00
852	jealexhouegbe	admin	t	\N	2026-09-25 23:35:53.157482+00
853	jealexhouegbe	admin	t	\N	2026-09-26 00:25:49.017246+00
854	jealexhouegbe	admin	t	\N	2026-09-26 03:04:24.356975+00
855	quenumparfait	admin	t	\N	2026-09-26 06:13:57.159559+00
856	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-26 06:30:57.714532+00
857	degnonfrederics@gmail.com	td	t	\N	2026-09-26 06:47:04.50451+00
858	claudekinninnon@gmail.com	td	t	\N	2026-09-26 07:29:48.410028+00
859	quenumparfait	admin	t	\N	2026-09-26 08:03:04.631734+00
860	jealexhouegbe	admin	t	\N	2026-09-26 08:06:53.522833+00
861	padampierre@gmail.com	admin	f	\N	2026-09-26 08:07:00.338484+00
862	Peter21	admin	t	\N	2026-09-26 08:08:06.054818+00
863	Peter21	admin	t	\N	2026-09-26 08:08:26.189999+00
864	aldolalumiere80@gmail.com	td	t	\N	2026-09-26 09:05:57.011036+00
865	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-26 10:44:06.051618+00
866	leopoldchangodele@gmail.com	td	t	\N	2026-09-26 11:37:11.869333+00
867	amankpemodeste761@gmail.com	td	t	\N	2026-09-26 13:40:46.062941+00
868	jealexhouegbe	admin	t	\N	2026-09-26 14:25:59.16964+00
869	charliehounkanrin@gmail.com	td	t	\N	2026-09-26 16:14:26.982525+00
870	jealexhouegbe	admin	t	\N	2026-09-26 16:33:42.596611+00
871	andersondoliveira	admin	t	\N	2026-09-26 16:44:41.456664+00
872	aldolalumiere80@gmail.com	td	t	\N	2026-09-26 18:39:59.835207+00
873	aldolalumiere80@gmail.com	td	t	\N	2026-09-26 18:42:04.716285+00
874	simkiki30@gmail.com	td	t	\N	2026-09-26 18:49:04.722854+00
875	jealexhouegbe	admin	t	\N	2026-09-26 19:02:28.679927+00
876	charliehounkanrin@gmail.com	td	t	\N	2026-09-26 20:33:32.822187+00
877	charliehounkanrin@gmail.com	td	t	\N	2026-09-26 22:12:58.195429+00
878	holonoubienvenu@gmail.com	admin	f	\N	2026-09-26 23:46:30.7811+00
879	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 05:16:55.031397+00
880	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 05:36:35.298819+00
881	jealexhouegbe	admin	t	\N	2026-09-27 05:36:35.306872+00
882	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 06:35:17.471916+00
883	jealexhouegbe	admin	t	\N	2026-09-27 06:57:41.194654+00
884	aldolalumiere80@gmail.com	td	t	\N	2026-09-27 07:55:31.884613+00
885	Peter21	admin	t	\N	2026-09-27 08:16:31.87493+00
886	charliehounkanrin@gmail.com	td	t	\N	2026-09-27 10:52:25.492249+00
887	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-27 11:17:23.5001+00
888	degnonfrederics@gmail.com	td	t	\N	2026-09-27 11:23:17.037678+00
889	jealexhouegbe	admin	t	\N	2026-09-27 12:34:52.405685+00
890	jealexhouegbe	admin	t	\N	2026-09-27 16:45:50.603129+00
891	piomedesse@gmail.com	td	t	\N	2026-09-27 18:05:31.600031+00
892	jealexhouegbe	admin	t	\N	2026-09-27 18:09:23.855996+00
893	jealexhouegbe	admin	t	\N	2026-09-27 21:40:15.921988+00
894	jealexhouegbe 	admin	f	\N	2026-09-28 02:22:55.23576+00
895	jealexhouegbe 	admin	f	\N	2026-09-28 02:44:44.808981+00
896	jealexhouegbe	admin	f	\N	2026-09-28 02:45:18.287681+00
897	jealexhouegbe	admin	t	\N	2026-09-28 02:46:00.466049+00
898	aremouramziath@gmail.com	td	t	\N	2026-09-28 07:06:43.914963+00
899	urielhouegbe	admin	t	\N	2026-09-28 07:25:15.949974+00
900	jealexhouegbe	admin	t	\N	2026-09-28 07:38:11.955329+00
901	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 08:12:13.456994+00
902	urielhouegbe	admin	t	\N	2026-09-28 08:21:55.313246+00
903	degnonfrederics@gmail.com	td	t	\N	2026-09-28 08:58:25.847896+00
904	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 09:12:27.397473+00
905	urielhouegbe	admin	t	\N	2026-09-28 09:25:30.589418+00
906	jealexhouegbe	admin	t	\N	2026-09-28 09:53:41.731619+00
907	jealexhouegbe	admin	t	\N	2026-09-28 10:10:01.437939+00
908	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 10:28:26.542615+00
909	jealexhouegbe	admin	t	\N	2026-09-28 10:33:40.5464+00
910	degnonfrederics@gmail.com	td	t	\N	2026-09-28 11:56:31.435797+00
911	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 11:57:11.462838+00
912	ghics2000@yahoo.fr	td	t	\N	2026-09-28 12:00:48.877366+00
913	jealexhouegbe	admin	t	\N	2026-09-28 12:04:33.242226+00
914	fauxence1994@gmail.com	td	f	\N	2026-09-28 12:05:11.606722+00
915	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-28 12:05:36.431875+00
916	aldolalumiere80@gmail.com	td	t	\N	2026-09-28 12:08:12.868778+00
917	amankpemodeste761@gmail.com	td	t	\N	2026-09-28 12:08:29.805651+00
918	viptomtogbe@gmail.com	td	t	\N	2026-09-28 12:10:42.977314+00
919	akakpoenock00@gmail.com	td	t	\N	2026-09-28 12:12:48.754333+00
920	ferdinandagossou03@gmail.com	td	t	\N	2026-09-28 12:15:26.424821+00
921	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:23:45.270668+00
922	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:24:08.864406+00
923	mawougnongael91@gmail.com	td	t	\N	2026-09-28 12:24:18.206716+00
924	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:24:28.598617+00
925	sedodeconstant@gmail.com	admin	f	\N	2026-09-28 12:25:33.292107+00
926	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-28 12:26:29.310467+00
927	sedodeconstant@gmail.com	td	f	\N	2026-09-28 12:28:26.734464+00
928	sedodeconstant@gmail.com	td	t	\N	2026-09-28 12:29:09.728243+00
929	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-28 12:31:03.433319+00
930	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-28 12:39:47.6184+00
931	claudekinninnon@gmail.com	admin	f	\N	2026-09-28 12:49:51.237527+00
932	aremouramziath@gmail.com	td	t	\N	2026-09-28 12:49:59.997199+00
933	ferdinandagossou03@gmail.com	td	t	\N	2026-09-28 12:50:03.901876+00
934	claudekinninnon@gmail.com	td	t	\N	2026-09-28 12:54:16.042229+00
935	dkobahubert@gmail.com	td	t	\N	2026-09-28 13:10:24.005644+00
936	leopoldchangodele@gmail.com	td	t	\N	2026-09-28 13:21:45.277726+00
937	adjahocamille249@gmail.com	td	f	\N	2026-09-28 13:45:28.140341+00
938	jealexhouegbe	admin	t	\N	2026-09-28 13:48:31.834918+00
939	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-28 13:57:34.985237+00
940	jealexhouegbe	admin	t	\N	2026-09-28 14:23:35.930469+00
941	akakpoenock00@gmail.com	td	t	\N	2026-09-28 14:30:00.679238+00
942	leopoldchangodele@gmail.com	td	t	\N	2026-09-28 14:32:04.555936+00
943	charliehounkanrin@gmail.com	td	t	\N	2026-09-28 14:52:40.972286+00
944	djossougermain0@gmail.com	td	t	\N	2026-09-28 15:13:41.885937+00
945	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-28 15:32:33.252928+00
946	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-28 15:59:59.422922+00
947	carlosbokononhoui@gmail.com	td	t	\N	2026-09-28 16:00:27.894438+00
948	carlosbokononhoui@gmail.com	td	t	\N	2026-09-28 16:00:40.769542+00
949	akakpoenock00@gmail.com	td	t	\N	2026-09-28 16:06:56.348371+00
950	jealexhouegbe	admin	t	\N	2026-09-28 16:15:57.454369+00
951	jealexhouegbe	admin	t	\N	2026-09-28 16:47:37.720738+00
952	piomedesse@gmail.com	td	t	\N	2026-09-28 16:56:41.308905+00
953	magbondejerome@gmail.com	td	t	\N	2026-09-28 17:00:30.19578+00
954	djossougermain0@gmail.com	td	t	\N	2026-09-28 17:04:22.09499+00
955	faroukaremou5@gmail.com	td	f	\N	2026-09-28 17:07:40.386422+00
956	faroukaremou5@gmail.com	td	t	\N	2026-09-28 17:08:41.253239+00
957	mawougnongael91@gmail.com	td	t	\N	2026-09-28 17:36:55.133281+00
958	ferdinandagossou03@gmail.com	td	t	\N	2026-09-28 17:46:38.897466+00
959	piomedesse@gmail.com	td	t	\N	2026-09-28 17:53:21.918739+00
960	magbondejerome@gmail.com	td	t	\N	2026-09-28 18:11:27.689911+00
961	holonoubienvenu@gmail.com	td	t	\N	2026-09-28 18:42:11.106318+00
962	simkiki30@gmail.com	td	t	\N	2026-09-28 19:16:07.972638+00
963	akakpoenock00@gmail.com	td	t	\N	2026-09-28 19:16:52.013134+00
964	simkiki30@gmail.com	td	t	\N	2026-09-28 19:19:38.978814+00
965	simkiki30@gmail.com	td	t	\N	2026-09-28 19:28:27.698074+00
966	simkiki30@gmail.com	td	t	\N	2026-09-28 20:01:55.680283+00
967	faroukaremou5@gmail.com	td	t	\N	2026-09-28 20:08:18.702277+00
968	florenthinnou@gmail.com	td	t	\N	2026-09-28 20:14:34.843304+00
969	piomedesse@gmail.com	td	t	\N	2026-09-28 21:19:18.922005+00
970	jealexhouegbe	admin	t	\N	2026-09-28 21:23:49.916652+00
971	aldolalumiere80@gmail.com	td	t	\N	2026-09-28 23:10:37.122487+00
972	mawougnongael91@gmail.com	td	t	\N	2026-09-28 23:23:47.467496+00
973	jealexhouegbe	admin	t	\N	2026-09-29 04:04:16.41575+00
974	faroukaremou5@gmail.com	td	t	\N	2026-09-29 04:23:04.252005+00
975	akakpoenock00@gmail.com	td	t	\N	2026-09-29 05:38:25.777566+00
976	jealexhouegbe	admin	t	\N	2026-09-29 06:01:06.793393+00
977	magbondejerome@gmail.com	td	t	\N	2026-09-29 06:22:20.391542+00
978	magbondejerome@gmail.com	td	t	\N	2026-09-29 06:24:22.577682+00
979	jealexhouegbe	admin	t	\N	2026-09-29 06:30:30.455479+00
980	marianototin@gmail.com	admin	f	\N	2026-09-29 06:35:16.285805+00
981	marianototin@gmail.com	admin	f	\N	2026-09-29 06:35:36.009177+00
982	marianototin@gmail.com	admin	f	\N	2026-09-29 06:35:43.592407+00
983	urielaxelhouegbe@gmail.com	td	t	\N	2026-09-29 06:38:22.540984+00
984	charliehounkanrin@gmail.com	td	t	\N	2026-09-29 06:39:09.234493+00
985	amankpemodeste761@gmail.com	td	t	\N	2026-09-29 06:39:39.403209+00
986	marianototin@gmail.com	td	t	\N	2026-09-29 06:43:54.160939+00
987	ghics2000@yahoo.fr	td	t	\N	2026-09-29 06:44:52.995318+00
988	gedeonfintovitchede@gmail.com	td	t	\N	2026-09-29 06:45:51.125232+00
989	ghics2000@yahoo.fr	td	t	\N	2026-09-29 06:46:33.556144+00
990	aremouramziath@gmail.com	td	t	\N	2026-09-29 06:50:53.408623+00
991	degnonfrederics@gmail.com	td	t	\N	2026-09-29 06:57:08.523945+00
992	akakpoenock00@gmail.com	td	t	\N	2026-09-29 07:02:13.669687+00
993	leopoldchangodele@gmail.com	td	t	\N	2026-09-29 07:04:22.636324+00
994	ferdinandagossou03@gmail.com	td	t	\N	2026-09-29 07:54:00.079497+00
995	urielhouegbe	admin	t	\N	2026-09-29 07:55:15.022187+00
996	dkobahubert@gmail.com	td	t	\N	2026-09-29 08:08:45.956821+00
997	jeremieabidegbekponou@gmail.com	td	t	\N	2026-09-29 08:11:06.565558+00
998	dkobahubert@gmail.com	td	t	\N	2026-09-29 08:18:52.816607+00
999	ekponnatonjeanclaude@gmail.com	td	t	\N	2026-09-29 08:19:44.632297+00
1000	dansoumika8@gmail.com	td	t	\N	2026-09-29 08:22:20.287373+00
1001	charliehounkanrin@gmail.com	td	t	\N	2026-09-29 08:28:54.686968+00
1002	jealexhouegbe	admin	t	\N	2026-09-29 08:35:00.971902+00
1003	florenthinnou@gmail.com	td	t	\N	2026-09-29 08:55:47.156151+00
1004	djossougermain0@gmail.com	td	t	\N	2026-09-29 08:58:45.843733+00
1005	akakpoenock00@gmail.com	td	t	\N	2026-09-29 08:58:48.104826+00
1006	viptomtogbe@gmail.com	td	t	\N	2026-09-29 09:20:00.046595+00
1007	jealexhouegbe	admin	t	\N	2026-09-29 09:22:20.485908+00
1008	sedodeconstant@gmail.com	td	t	41.216.54.238	2026-09-29 10:28:45.622688+00
1009	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 10:36:34.101808+00
1010	angekarson1@gmail.com	admin	f	41.216.54.126	2026-09-29 10:54:45.480217+00
1011	angekarson1@gmail.com	admin	f	41.216.54.126	2026-09-29 10:54:54.497937+00
1012	angekarson1@gmail.com	admin	f	41.216.54.126	2026-09-29 10:55:02.819993+00
1013	HOUETO Olou Dayo Fabrice 	admin	f	41.216.54.126	2026-09-29 10:55:30.642258+00
1014	HOUETO Olou Dayo Fabrice 	admin	f	41.216.54.126	2026-09-29 10:55:40.834811+00
1015	degnonfrederics@gmail.com	td	f	102.202.111.199	2026-09-29 10:57:17.870737+00
1016	degnonfrederics@gmail.com	td	t	102.202.111.199	2026-09-29 10:57:31.058467+00
1017	carlosbokononhoui@gmail.com	td	t	154.72.112.20	2026-09-29 10:57:58.560853+00
1018	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 11:30:39.280162+00
1019	viptomtogbe@gmail.com	td	t	197.234.223.204	2026-09-29 11:34:12.089982+00
1020	degnonfrederics@gmail.com	td	t	102.202.111.191	2026-09-29 11:41:39.631229+00
1021	degnonfrederics@gmail.com	td	t	102.202.111.185	2026-09-29 11:46:53.171151+00
1022	bienvenuedou112@gmail.com	td	t	137.255.28.225	2026-09-29 12:35:54.188959+00
1023	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 12:43:23.46701+00
1024	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-09-29 12:43:55.571472+00
1025	bienvenuedou112@gmail.com	td	t	137.255.28.225	2026-09-29 12:55:06.919339+00
1026	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-29 13:07:08.376315+00
1027	yessoufouassiath@gmail.com	td	t	102.202.111.110	2026-09-29 13:15:18.509154+00
1028	degnonfrederics@gmail.com	td	t	102.202.111.129	2026-09-29 13:48:02.303913+00
1029	piomedesse@gmail.com	td	t	102.202.111.115	2026-09-29 15:04:37.741476+00
1030	piomedesse@gmail.com	td	t	102.202.111.115	2026-09-29 15:06:58.313464+00
1031	M. HOUETO 	admin	f	102.202.111.157	2026-09-29 16:06:03.674673+00
1032	M. HOUETO 	admin	f	102.202.111.157	2026-09-29 16:06:17.159998+00
1033	jealexhouegbe	admin	t	102.202.111.96	2026-09-29 16:56:33.169206+00
1034	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-09-29 17:10:02.732765+00
1035	angekarson1@gmail.com	td	t	41.216.53.139	2026-09-29 17:11:33.552724+00
1036	mawougnongael91@gmail.com	td	t	154.66.133.55	2026-09-29 17:34:00.517869+00
1037	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 17:42:26.849922+00
1038	piomedesse@gmail.com	td	t	154.72.113.17	2026-09-29 18:08:20.500522+00
1039	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 18:34:51.287348+00
1040	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 21:03:48.076475+00
1041	degnonfrederics@gmail.com	td	t	102.202.111.19	2026-09-29 21:43:20.013902+00
1042	akakpoenock00@gmail.com	td	t	41.85.167.73	2026-09-29 22:05:38.340018+00
1043	jealexhouegbe	admin	t	154.66.142.115	2026-09-29 22:55:12.739169+00
1044	ferdinandagossou03@gmail.com	td	t	41.216.53.163	2026-09-29 23:10:53.490576+00
1045	jealexhouegbe	admin	t	154.66.142.115	2026-09-30 05:46:16.011542+00
1046	jealexhouegbe	admin	t	154.66.142.115	2026-09-30 06:20:47.630623+00
1047	bienvenuedou112@gmail.com	td	t	137.255.64.110	2026-09-30 07:16:25.866022+00
1048	bienvenuedou112@gmail.com	td	t	137.255.64.110	2026-09-30 07:20:45.327483+00
1049	jealexhouegbe	admin	t	154.66.142.115	2026-09-30 07:24:14.975305+00
1050	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-30 07:28:47.009343+00
1051	aldolalumiere80@gmail.com	td	t	197.234.223.235	2026-09-30 07:54:35.360188+00
1052	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-30 08:50:02.118825+00
1053	viptomtogbe@gmail.com	td	t	102.202.111.109	2026-09-30 11:02:37.198548+00
1054	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.30	2026-09-30 11:49:40.44796+00
1055	jealexhouegbe	admin	t	102.202.111.197	2026-09-30 12:00:25.995729+00
1056	piomedesse@gmail.com	td	t	102.202.111.215	2026-09-30 12:18:10.713659+00
1057	piomedesse@gmail.com	td	t	102.202.111.92	2026-09-30 12:34:37.632727+00
1058	marcepepe@gmail.com	td	t	41.138.91.163	2026-09-30 12:45:07.022253+00
1059	jealexhouegbe	admin	t	102.202.111.197	2026-09-30 12:46:36.679553+00
1060	marcepepe@gmail.com	td	t	41.138.91.163	2026-09-30 12:51:51.228897+00
1061	charliehounkanrin@gmail.com	td	t	197.234.223.228	2026-09-30 13:09:34.703728+00
1062	gedeonfintovitchede@gmail.com	td	t	41.85.163.244	2026-09-30 13:41:46.258743+00
1063	yessoufouassiath@gmail.com	td	t	102.202.111.50	2026-09-30 14:31:03.72259+00
1064	jealexhouegbe	admin	t	154.66.142.143	2026-09-30 14:33:31.496343+00
1065	yessoufouassiath@gmail.com	td	t	102.202.111.50	2026-09-30 14:38:19.364968+00
1066	nistani21@gmail.com	td	t	41.216.53.37	2026-09-30 14:45:49.060339+00
1067	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:46:10.969332+00
1068	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:46:54.694812+00
1069	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:54:22.513053+00
1070	nistani21@gmail.com	td	f	41.216.53.37	2026-09-30 14:54:35.045407+00
1071	jealexhouegbe	admin	t	154.66.142.143	2026-09-30 14:56:37.684629+00
1072	hotojules@gmail.com	td	t	41.216.54.91	2026-09-30 16:35:47.057553+00
1073	hotojules@gmail.com	td	f	41.216.54.91	2026-09-30 16:35:58.866363+00
1074	hotojules@gmail.com	td	f	41.216.54.91	2026-09-30 16:36:09.268705+00
1075	hotojules@gmail.com	td	f	41.216.54.91	2026-09-30 16:38:09.4865+00
1076	jealexhouegbe	admin	t	154.66.142.143	2026-09-30 16:46:52.608816+00
1077	hotojules@gmail.com	td	t	41.216.54.91	2026-09-30 16:48:54.066391+00
1078	bossouraoul82@gmail.com	td	t	41.138.89.222	2026-09-30 17:04:27.884109+00
1079	bossouraoul82@gmail.com	td	f	41.138.89.222	2026-09-30 17:05:36.404615+00
1080	bossouraoul82@gmail.com	td	f	41.138.89.222	2026-09-30 17:05:56.7929+00
1081	bossouraoul82@gmail.com	td	f	41.138.89.222	2026-09-30 17:06:21.107221+00
1082	bossouraoul82@gmail.com	td	t	41.138.89.222	2026-09-30 17:12:52.063283+00
1083	jeremieabidegbekponou@gmail.com	td	t	41.216.53.84	2026-09-30 18:36:27.04957+00
1084	degnonfrederics@gmail.com	td	t	197.234.219.136	2026-09-30 18:59:08.956023+00
1085	mawougnongael91@gmail.com	td	t	102.202.111.26	2026-09-30 19:28:45.162188+00
1086	louislucnou@gmail.com	td	t	102.202.111.158	2026-09-30 19:43:39.256769+00
1087	jealexhouegbe	admin	t	102.38.154.174	2026-09-30 21:34:40.265735+00
1088	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 03:12:33.618012+00
1089	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 03:59:27.980459+00
1090	nistani21@gmail.com	td	f	41.216.53.37	2026-10-01 04:34:17.234335+00
1091	nistani21@gmail.com	td	f	41.216.53.37	2026-10-01 04:34:34.976286+00
1092	nistani21@gmail.com	td	f	41.216.53.37	2026-10-01 04:36:52.061478+00
1093	nistani21@gmail.com	td	f	41.216.53.185	2026-10-01 04:40:50.653115+00
1094	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 04:41:20.990335+00
1095	nistani21@gmail.com	td	f	41.216.53.185	2026-10-01 04:41:26.533867+00
1096	nistani21@gmail.com	td	t	41.216.53.185	2026-10-01 04:45:06.614297+00
1097	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 05:47:16.155561+00
1098	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 08:00:24.15138+00
1099	leopoldchangodele@gmail.com	td	t	41.85.163.158	2026-10-01 08:27:46.192313+00
1100	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 08:28:47.96675+00
1101	amankpemodeste761@gmail.com	td	t	102.202.111.20	2026-10-01 08:33:41.369028+00
1102	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 09:20:57.503762+00
1103	ferdinandagossou03@gmail.com	td	t	41.85.163.107	2026-10-01 09:21:16.91992+00
1104	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 09:44:43.997461+00
1105	lucazandohounsi65@gmail.com	td	t	41.85.162.35	2026-10-01 11:27:50.686463+00
1106	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 11:53:00.787903+00
1107	gedeonfintovitchede@gmail.com	td	t	41.85.163.244	2026-10-01 12:41:46.320129+00
1108	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 12:51:07.910956+00
1109	lucazandohounsi65@gmail.com	td	t	41.85.162.35	2026-10-01 13:04:36.072975+00
1110	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 13:25:26.902587+00
1111	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 16:10:43.422594+00
1112	leopoldchangodele@gmail.com	td	t	197.234.219.245	2026-10-01 18:00:43.66035+00
1113	mawougnongael91@gmail.com	td	t	102.202.111.145	2026-10-01 20:31:18.842629+00
1114	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 20:36:32.257349+00
1115	jealexhouegbe	admin	t	102.38.154.174	2026-10-01 20:38:09.527241+00
1116	gedeonfintovitchede@gmail.com	td	t	41.216.54.171	2026-10-01 22:26:42.104564+00
1117	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 09:01:32.351303+00
1118	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 10:39:23.679406+00
1119	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 12:20:37.020475+00
1120	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 12:47:07.248473+00
1121	jealexhouegbe	admin	t	102.202.111.74	2026-10-02 13:11:44.914091+00
1122	leopoldchangodele@gmail.com	td	t	41.85.162.173	2026-10-02 13:22:07.606199+00
1123	jealexhouegbe	admin	t	102.202.111.236	2026-10-02 13:38:43.457981+00
1124	simkiki30@gmail.com	td	t	41.79.219.51	2026-10-02 15:19:03.40957+00
1125	urielaxelhouegbe@gmail.com	admin	f	102.215.138.253	2026-10-02 15:49:32.10139+00
1126	urielhouegbe	admin	t	102.215.138.253	2026-10-02 15:50:05.378861+00
1127	florenthinnou@gmail.com	td	t	41.85.163.192	2026-10-02 15:55:18.583028+00
1128	claudekinninnon@gmail.com	td	t	137.255.109.75	2026-10-02 16:00:39.061778+00
1129	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-02 18:32:22.720012+00
1130	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-02 18:34:02.611664+00
1131	ferdinandagossou03@gmail.com	td	t	41.85.163.226	2026-10-02 18:53:00.629351+00
1132	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-02 18:57:13.817202+00
1133	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-02 18:57:58.622073+00
1134	holonoubienvenu@gmail.com	td	t	41.216.54.249	2026-10-02 20:43:38.979221+00
1135	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-02 21:14:37.693336+00
1136	jeremieabidegbekponou@gmail.com	td	t	41.85.163.176	2026-10-02 22:14:29.402492+00
1137	jealexhouegbe	admin	t	154.66.138.55	2026-10-02 23:15:10.415599+00
1138	jealexhouegbe	admin	t	154.66.138.55	2026-10-03 00:10:18.548628+00
1139	urielhouegbe	admin	t	154.66.138.55	2026-10-03 00:39:43.641905+00
1140	leopoldchangodele@gmail.com	td	t	41.85.163.138	2026-10-03 01:56:09.460268+00
1141	urielhouegbe	admin	t	154.66.138.55	2026-10-03 02:47:12.235175+00
1142	jeremieabidegbekponou@gmail.com	td	t	41.85.162.207	2026-10-03 05:38:38.977445+00
1143	aremouramziath@gmail.com	td	t	41.85.163.68	2026-10-03 05:46:24.76686+00
1144	viptomtogbe@gmail.com	td	t	41.79.219.135	2026-10-03 06:11:39.083025+00
1145	viptomtogbe@gmail.com	td	t	41.79.219.135	2026-10-03 06:16:44.798254+00
1146	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.40	2026-10-03 06:16:45.462976+00
1147	quenumparfait	admin	t	41.85.162.115	2026-10-03 06:17:15.791457+00
1148	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-03 06:24:04.279511+00
1149	jealexhouegbe	admin	t	102.202.111.183	2026-10-03 06:39:31.968265+00
1150	quenumparfait	admin	t	41.216.54.89	2026-10-03 07:44:15.665691+00
1151	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 07:44:44.978292+00
1152	Peter21	admin	t	41.216.53.255	2026-10-03 08:09:31.010997+00
1153	quenumparfait	admin	t	41.216.53.109	2026-10-03 08:11:07.84098+00
1154	bienvenuedou112@gmail.com	td	t	102.202.111.147	2026-10-03 08:12:46.379127+00
1155	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 08:26:13.118554+00
1156	Peter21	admin	t	41.216.53.255	2026-10-03 08:50:25.907619+00
1157	bienvenuedou112@gmail.com	td	t	102.202.111.147	2026-10-03 09:04:18.757299+00
1158	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 09:23:12.606107+00
1159	Peter21	admin	t	41.216.53.255	2026-10-03 09:38:34.900232+00
1160	gedeonfintovitchede@gmail.com	td	t	41.85.162.137	2026-10-03 09:49:42.943375+00
1161	yetohoubago@gmail.com	td	f	156.0.213.149	2026-10-03 09:53:15.000708+00
1162	yetbaginn	admin	t	156.0.213.149	2026-10-03 09:55:51.535063+00
1163	charliehounkanrin@gmail.com	td	t	41.79.219.77	2026-10-03 10:21:24.526128+00
1164	leopoldchangodele@gmail.com	td	t	137.255.70.47	2026-10-03 10:45:00.319319+00
1165	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 11:45:29.681353+00
1166	gedeonfintovitchede@gmail.com	td	t	41.85.162.137	2026-10-03 11:52:50.820877+00
1167	amankpemodeste761@gmail.com	td	t	102.202.111.115	2026-10-03 12:17:58.486943+00
1168	jealexhouegbe	admin	t	102.202.111.236	2026-10-03 12:29:24.84766+00
1169	akakpoenock00@gmail.com	td	t	197.234.223.199	2026-10-03 13:03:51.878018+00
1170	jealexhouegbe	admin	t	154.66.141.195	2026-10-03 13:41:30.823277+00
1171	leopoldchangodele@gmail.com	td	t	137.255.70.47	2026-10-03 14:25:11.873633+00
1172	ekponnatonjeanclaude@gmail.com	td	t	137.255.119.27	2026-10-03 14:41:12.525038+00
1173	andersondoliveira	admin	f	41.216.54.90	2026-10-03 15:49:38.955877+00
1174	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:22.309694+00
1175	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:25.939161+00
1176	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:38.343284+00
1177	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:50:49.607542+00
1178	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 15:51:01.115253+00
1179	jealexhouegbe	admin	f	154.66.141.195	2026-10-03 15:54:07.304356+00
1180	jealexhouegbe	admin	t	154.66.141.195	2026-10-03 15:54:33.393734+00
1181	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:38:29.989066+00
1182	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:40:00.727379+00
1183	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:45:18.560868+00
1184	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:45:21.784251+00
1185	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:47:09.092983+00
1186	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:48:43.116249+00
1187	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:53:01.622844+00
1188	doliveiraanderson6@gmail.com	admin	f	41.216.54.90	2026-10-03 16:55:06.33359+00
1189	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:56:23.99427+00
1190	andersondoliveira	admin	f	41.216.54.90	2026-10-03 16:57:24.61667+00
1191	jealexhouegbe	admin	t	102.202.111.138	2026-10-03 16:58:07.449872+00
1192	andersondoliveira	admin	f	41.216.54.90	2026-10-03 16:58:07.931544+00
1193	Nabildoliveira	admin	f	41.216.54.90	2026-10-03 17:03:23.633994+00
1194	Nabildoliveira	admin	f	41.216.54.90	2026-10-03 17:03:55.72538+00
1195	nabildoliveira	admin	f	41.216.54.90	2026-10-03 17:04:15.927012+00
1196	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-03 21:14:20.062173+00
1197	gedeonfintovitchede@gmail.com	td	t	41.85.163.120	2026-10-03 21:33:40.314278+00
1198	magbondejerome@gmail.com	td	f	154.72.113.115	2026-10-03 22:24:50.884284+00
1199	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-03 22:25:07.672002+00
1200	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-04 03:59:19.836867+00
1201	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 04:26:36.641694+00
1202	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 05:05:22.829331+00
1203	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-04 05:45:50.635584+00
1204	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 07:45:04.226885+00
1205	bienvenuedou112@gmail.com	td	t	102.202.111.142	2026-10-04 07:59:45.679234+00
1206	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-04 08:00:24.531248+00
1207	charliehounkanrin@gmail.com	td	t	41.79.219.142	2026-10-04 08:02:07.104253+00
1208	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 08:33:09.063368+00
1209	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 09:12:29.547465+00
1210	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 10:19:08.686502+00
1211	bossouraoul82@gmail.com	td	t	41.138.89.155	2026-10-04 10:42:47.52612+00
1212	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-04 11:16:19.721013+00
1213	piomedesse@gmail.com	td	t	154.72.113.17	2026-10-04 11:33:24.535432+00
1214	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 11:38:54.641225+00
1215	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-04 12:44:01.158432+00
1216	charliehounkanrin@gmail.com	td	t	197.234.219.194	2026-10-04 13:33:19.894997+00
1217	jealexhouegbe	admin	t	102.202.111.106	2026-10-04 14:28:47.279936+00
1218	faroukaremou5@gmail.com	td	t	197.234.219.224	2026-10-04 15:42:06.412234+00
1219	dkobahubert@gmail.com	td	t	102.202.111.197	2026-10-04 17:31:48.467067+00
1220	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-04 17:32:27.794926+00
1221	akakpoenock00@gmail.com	td	t	137.255.134.243	2026-10-04 17:59:25.848947+00
1222	akakpoenock00@gmail.com	td	t	137.255.134.243	2026-10-04 18:27:43.47445+00
1223	mawougnongael91@gmail.com	td	t	197.234.219.129	2026-10-04 19:13:19.56934+00
1224	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 19:48:13.886396+00
1225	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-04 20:12:07.010956+00
1226	hotojules@gmail.com	td	t	41.85.162.167	2026-10-04 20:31:12.989849+00
1227	leopoldchangodele@gmail.com	td	t	41.85.162.194	2026-10-04 20:40:37.056035+00
1228	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-04 21:08:31.237202+00
1229	jealexhouegbe	admin	t	154.66.141.195	2026-10-04 21:44:32.570018+00
1230	amankpemodeste761@gmail.com	td	t	102.202.111.95	2026-10-04 22:36:20.434218+00
1231	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 00:16:43.952211+00
1232	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 02:51:37.010269+00
1233	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 06:57:36.328005+00
1234	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:08:33.950839+00
1235	akakpoenock00@gmail.com	td	t	197.234.219.228	2026-10-05 07:29:07.794312+00
1236	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:32:21.273252+00
1237	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:33:12.449231+00
1238	amankpemodeste761@gmail.com	td	t	102.202.111.95	2026-10-05 07:48:06.339221+00
1239	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 07:48:21.538355+00
1240	leopoldchangodele@gmail.com	td	t	137.255.186.214	2026-10-05 07:52:03.921681+00
1241	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-05 07:56:32.676646+00
1242	florenthinnou@gmail.com	td	t	41.85.163.250	2026-10-05 08:03:01.160886+00
1243	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:00.643661+00
1244	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:09.474723+00
1245	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:31.708826+00
1246	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:38.493202+00
1247	sedodeconstant@gmail.com	admin	f	102.202.111.157	2026-10-05 08:04:47.615135+00
1248	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 08:05:46.233887+00
1249	mawougnongael91@gmail.com	td	t	197.234.219.214	2026-10-05 08:06:37.585452+00
1250	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 08:19:06.364547+00
1251	carlosbokononhoui@gmail.com	td	t	102.202.111.43	2026-10-05 08:19:58.729016+00
1252	piomedesse@gmail.com	td	t	102.202.111.173	2026-10-05 08:21:07.058444+00
1253	Sedodeconstant@gmail.com 	admin	f	102.202.111.244	2026-10-05 08:31:15.192955+00
1254	Sedodeconstant@gmail.com 	admin	f	102.202.111.244	2026-10-05 08:32:08.926894+00
1255	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:33:09.919101+00
1256	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:35:25.254177+00
1257	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:35:34.391453+00
1258	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:36:31.12604+00
1259	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 08:41:21.026707+00
1260	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 08:45:30.160547+00
1261	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:48:48.377639+00
1262	sedodeconstant@gmail.com	admin	f	102.202.111.244	2026-10-05 08:49:01.38347+00
1263	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-05 08:52:16.631181+00
1264	gedeonfintovitchede@gmail.com	td	t	197.234.219.155	2026-10-05 08:53:26.297354+00
1265	sedodeconstant@gmail.com	td	t	154.66.141.195	2026-10-05 08:56:18.520952+00
1266	sedodeconstant@gmail.com	td	f	154.66.141.195	2026-10-05 08:57:06.79749+00
1267	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 09:01:23.255301+00
1268	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:03:16.565399+00
1269	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:03:25.962472+00
1270	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:04:13.337169+00
1271	Sedodeconstant@gmail.com 	admin	f	102.202.111.151	2026-10-05 09:05:21.589525+00
1272	viptomtogbe@gmail.com	td	t	41.216.54.44	2026-10-05 09:11:19.247147+00
1273	gedeonfintovitchede@gmail.com	td	t	197.234.219.155	2026-10-05 09:19:13.247309+00
1274	nistani21@gmail.com	td	t	137.255.53.254	2026-10-05 09:24:09.530115+00
1275	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 09:27:28.172528+00
1276	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 09:32:02.432105+00
1277	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 09:34:02.520194+00
1278	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 09:34:41.599843+00
1279	sedodeconstant@gmail.com 	admin	f	102.202.111.231	2026-10-05 09:57:56.800918+00
1280	sedodeconstant@gmail.com 	admin	f	102.202.111.231	2026-10-05 09:58:20.837906+00
1281	sedodeconstant@gmail.com	td	t	102.202.111.139	2026-10-05 10:03:55.955969+00
1282	ekponnatonjeanclaude@gmail.com	td	t	137.255.28.252	2026-10-05 10:06:39.222629+00
1283	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 10:22:25.833368+00
1284	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 10:26:25.703564+00
1285	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 10:42:26.78937+00
1286	aldolalumiere80@gmail.com	td	t	41.79.219.209	2026-10-05 10:48:31.359631+00
1287	faroukaremou5@gmail.com	td	t	197.234.219.242	2026-10-05 10:55:04.627468+00
1288	amankpemodeste761@gmail.com	td	t	102.202.111.95	2026-10-05 10:56:13.386974+00
1289	lucazandohounsi65@gmail.com	td	t	41.85.162.79	2026-10-05 11:01:12.321838+00
1290	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 11:05:00.964383+00
1291	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:09:52.783606+00
1292	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 11:10:12.10213+00
1293	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 11:10:14.324596+00
1294	leopoldchangodele@gmail.com	td	t	137.255.112.187	2026-10-05 11:12:51.048224+00
1295	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:15:19.6002+00
1296	ekponnatonjeanclaude@gmail.com	td	t	137.255.28.252	2026-10-05 11:22:39.336926+00
1297	mawougnongael91@gmail.com	td	t	197.234.219.214	2026-10-05 11:24:31.199932+00
1298	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 11:28:05.6044+00
1299	claudekinninnon@gmail.com	td	t	137.255.144.192	2026-10-05 11:29:48.756138+00
1300	urielhouegbe	admin	t	154.66.141.195	2026-10-05 11:32:13.625871+00
1301	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-05 11:33:23.39249+00
1302	MAGBONDEJEROME@GMAIL.COM	parent	f	154.72.113.115	2026-10-05 11:35:12.436228+00
1303	degnonfrederics@gmail.com	td	t	102.202.111.71	2026-10-05 11:35:34.179337+00
1304	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 11:35:42.165183+00
1305	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 11:36:35.127713+00
1306	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:41:06.114122+00
1307	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:43:50.898892+00
1308	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 11:45:25.625486+00
1309	ghics2000@yahoo.fr	td	t	137.255.144.192	2026-10-05 11:49:49.978701+00
1310	leopoldchangodele@gmail.com	td	t	137.255.112.187	2026-10-05 11:52:29.862782+00
1311	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 12:02:34.260154+00
1312	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 12:07:33.790546+00
1313	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 12:08:56.499903+00
1314	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 12:31:09.178885+00
1315	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 12:48:08.520067+00
1316	nistani21@gmail.com	td	t	41.216.54.151	2026-10-05 13:15:09.957654+00
1317	akakpoenock00@gmail.com	td	t	197.234.219.207	2026-10-05 13:15:21.609675+00
1318	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 14:51:19.240467+00
1319	sedodeconstant@gmail.com	td	t	137.255.144.192	2026-10-05 15:07:03.450301+00
1320	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-05 15:12:08.387495+00
1321	carlosbokononhoui@gmail.com	td	t	137.255.105.28	2026-10-05 15:24:33.363892+00
1322	faroukaremou5@gmail.com	td	t	154.72.113.193	2026-10-05 16:04:04.911536+00
1323	bossouraoul82@gmail.com	td	t	41.138.89.153	2026-10-05 16:18:51.959919+00
1324	gedeonfintovitchede@gmail.com	td	t	41.85.163.172	2026-10-05 16:30:25.7722+00
1325	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-05 16:42:37.971549+00
1326	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 16:54:09.872957+00
1327	charliehounkanrin@gmail.com	td	t	197.234.219.252	2026-10-05 17:38:57.494612+00
1328	leopoldchangodele@gmail.com	td	t	197.234.219.145	2026-10-05 17:55:12.123674+00
1329	piomedesse@gmail.com	td	t	154.72.113.17	2026-10-05 18:03:25.543839+00
1330	degnonfrederics@gmail.com	td	t	102.202.111.211	2026-10-05 18:07:10.922897+00
1331	aremouramziath@gmail.com	td	t	41.216.54.253	2026-10-05 18:22:29.618729+00
1332	simkiki30@gmail.com	td	t	41.79.219.30	2026-10-05 18:22:43.577615+00
1333	akakpoenock00@gmail.com	td	t	137.255.151.168	2026-10-05 18:55:46.301118+00
1334	akakpoenock00@gmail.com	td	t	137.255.151.168	2026-10-05 19:20:39.43176+00
1335	claudekinninnon@gmail.com	td	t	102.202.111.93	2026-10-05 19:21:03.780571+00
1336	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-05 19:25:50.360661+00
1337	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-05 19:36:12.836868+00
1338	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-05 19:36:37.627979+00
1339	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-05 19:37:23.923742+00
1340	jealexhouegbe	admin	t	154.66.141.195	2026-10-05 20:28:15.125467+00
1341	urielhouegbe	admin	t	154.66.141.195	2026-10-05 20:52:59.787978+00
1342	urielhouegbe	admin	t	154.66.141.195	2026-10-05 21:19:46.32682+00
1343	viptomtogbe@gmail.com	td	t	102.202.111.9	2026-10-05 21:34:51.724428+00
1344	urielhouegbe	admin	t	154.66.141.195	2026-10-05 21:36:48.417476+00
1345	dkobahubert@gmail.com	td	t	154.72.112.146	2026-10-05 21:49:20.158843+00
1346	djossougermain0@gmail.com	td	t	102.202.111.29	2026-10-05 22:23:37.788469+00
1347	urielhouegbe	admin	t	154.66.141.195	2026-10-05 22:43:54.97459+00
1348	urielhouegbe	admin	t	154.66.141.195	2026-10-05 23:19:03.56364+00
1349	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 03:00:08.578906+00
1350	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 04:24:33.697238+00
1351	akakpoenock00@gmail.com	td	t	137.255.151.168	2026-10-06 04:59:16.805699+00
1352	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 05:54:38.724794+00
1353	faroukaremou5@gmail.com	td	t	102.202.111.40	2026-10-06 06:52:59.548813+00
1354	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 07:05:07.252308+00
1355	sedodeconstant@gmail.com	admin	f	102.202.111.243	2026-10-06 07:48:19.278403+00
1356	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 07:49:28.250372+00
1357	sedodeconstant@gmail.com	td	t	102.202.111.243	2026-10-06 07:49:41.865767+00
1358	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 07:50:35.381888+00
1359	sedodeconstant@gmail.com	td	t	102.202.111.243	2026-10-06 07:50:56.452258+00
1360	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-06 08:04:29.649518+00
1361	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-06 08:05:22.459795+00
1362	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 08:29:14.548701+00
1363	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 08:34:13.183061+00
1364	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 08:41:14.163439+00
1365	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-06 08:52:07.711522+00
1366	gedeonfintovitchede@gmail.com	td	t	41.85.162.148	2026-10-06 09:08:30.213392+00
1367	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 09:13:54.561495+00
1368	degnonfrederics@gmail.com	td	t	102.202.111.217	2026-10-06 09:14:09.462753+00
1369	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 09:19:50.91596+00
1370	faroukaremou5@gmail.com	td	t	197.234.219.248	2026-10-06 09:26:06.077575+00
1371	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 10:19:54.446062+00
1372	ferdinandagossou03@gmail.com	td	t	41.85.162.91	2026-10-06 10:24:41.749936+00
1373	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 10:34:53.9726+00
1374	marianototin@gmail.com	td	t	102.202.111.83	2026-10-06 11:15:06.500989+00
1375	urielhouegbe	admin	t	154.66.141.195	2026-10-06 11:24:58.769558+00
1376	ekponnatonjeanclaude@gmail.com	td	t	102.202.111.96	2026-10-06 11:30:55.293362+00
1377	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 11:53:16.041718+00
1378	mawougnongael91@gmail.com	td	t	154.72.113.130	2026-10-06 12:02:18.784397+00
1379	jealexhouegbe	admin	t	154.66.141.195	2026-10-06 12:09:14.196858+00
1380	faroukaremou5@gmail.com	td	t	154.72.113.193	2026-10-06 12:19:25.853768+00
1381	urielhouegbe	admin	t	154.66.141.195	2026-10-06 12:23:48.109138+00
1382	urielaxelhouegbe@gmail.com	td	t	154.66.141.195	2026-10-06 12:24:19.850754+00
1383	amankpemodeste761@gmail.com	td	t	102.202.111.6	2026-10-06 12:55:38.366903+00
1384	leopoldchangodele@gmail.com	td	t	137.255.20.35	2026-10-06 14:08:02.675025+00
1385	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 14:11:35.355438+00
1386	angekarson1@gmail.com	td	t	41.216.53.94	2026-10-06 15:22:52.781101+00
1387	jealexhouegbe	admin	t	102.202.111.77	2026-10-06 16:37:22.737328+00
1388	holonoubienvenu@gmail.com	td	t	41.216.54.93	2026-10-06 16:45:48.913016+00
1389	charliehounkanrin@gmail.com	td	t	41.79.219.94	2026-10-06 18:12:41.639193+00
1390	akakpoenock00@gmail.com	td	t	197.234.219.207	2026-10-06 18:14:57.924687+00
1391	hotojules@gmail.com	td	t	41.216.54.148	2026-10-06 18:29:34.213241+00
1392	jealexhouegbe	admin	t	102.202.111.77	2026-10-06 19:18:25.449373+00
1393	jealexhouegbe	admin	t	102.202.111.77	2026-10-06 20:21:55.879355+00
1394	lucazandohounsi65@gmail.com	td	t	154.72.113.64	2026-10-06 20:36:30.598231+00
1395	jealexhouegbe	admin	t	102.202.111.51	2026-10-06 20:53:54.971938+00
1396	charliehounkanrin@gmail.com	td	t	197.234.219.200	2026-10-06 21:20:51.446111+00
1397	akakpoenock00@gmail.com	td	t	41.85.168.176	2026-10-06 23:34:58.961158+00
1398	jealexhouegbe	admin	t	154.66.142.100	2026-10-07 00:32:17.622824+00
1399	jealexhouegbe	admin	t	154.66.142.100	2026-10-07 01:30:16.651401+00
1400	charliehounkanrin@gmail.com	td	t	137.255.161.57	2026-10-07 05:59:44.844015+00
1401	jealexhouegbe	admin	t	102.202.111.51	2026-10-07 06:04:24.364367+00
1402	akakpoenock00@gmail.com	td	t	41.85.168.176	2026-10-07 06:06:59.728129+00
1403	akakpoenock00@gmail.com	td	t	197.234.219.203	2026-10-07 07:07:19.533526+00
1404	aremouramziath@gmail.com	td	t	41.216.54.253	2026-10-07 07:22:32.572046+00
1405	ghics2000@yahoo.fr	td	t	102.202.111.139	2026-10-07 07:29:24.730677+00
1406	jealexhouegbe	admin	t	102.215.137.220	2026-10-07 07:44:10.682611+00
1407	faroukaremou5@gmail.com	td	t	197.234.219.156	2026-10-07 08:58:55.013243+00
1408	bienvenuedou112@gmail.com	td	t	137.255.161.57	2026-10-07 09:08:45.592616+00
1409	bienvenuedou112@gmail.com	td	t	137.255.161.57	2026-10-07 09:10:09.061236+00
1410	viptomtogbe@gmail.com	td	t	41.85.163.40	2026-10-07 10:15:52.421052+00
1411	dkobahubert@gmail.com	td	t	137.255.20.136	2026-10-07 10:32:55.910404+00
1412	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-07 11:22:21.114992+00
1413	ferdinandagossou03@gmail.com	td	t	41.85.162.194	2026-10-07 12:56:00.178382+00
1414	charliehounkanrin@gmail.com	td	t	197.234.219.216	2026-10-07 13:09:59.116781+00
1415	ferdinandagossou03@gmail.com	td	f	41.85.162.194	2026-10-07 13:16:02.359913+00
1416	ferdinandagossou03@gmail.com	td	t	41.85.162.194	2026-10-07 13:16:17.111622+00
1417	charliehounkanrin@gmail.com	td	t	197.234.219.225	2026-10-07 13:23:51.277957+00
1418	piomedesse@gmail.com	td	t	154.72.113.37	2026-10-07 15:01:05.382204+00
1419	claudekinninnon@gmail.com	td	t	102.202.111.111	2026-10-07 15:12:19.771433+00
1420	akakpoenock00@gmail.com	td	t	197.234.219.203	2026-10-07 16:00:34.147321+00
1421	akakpoenock00@gmail.com	td	t	197.234.219.203	2026-10-07 17:02:16.163331+00
1422	bossouraoul82@gmail.com	td	t	41.138.90.87	2026-10-07 17:29:54.081524+00
1423	faroukaremou5@gmail.com	td	t	197.234.219.156	2026-10-07 17:58:00.401586+00
1424	florenthinnou@gmail.com	td	t	41.216.54.159	2026-10-07 18:37:02.219999+00
1425	charliehounkanrin@gmail.com	td	t	197.234.223.213	2026-10-07 19:29:14.829933+00
1426	jealexhouegbe	admin	t	41.79.217.109	2026-10-07 20:01:54.4158+00
1427	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-07 20:05:19.415406+00
1428	yessoufouassiath@gmail.com	td	t	102.202.111.56	2026-10-07 20:34:10.055686+00
1429	charliehounkanrin@gmail.com	td	t	197.234.223.213	2026-10-07 20:39:22.831324+00
1430	faroukaremou5@gmail.com	td	t	102.202.111.198	2026-10-07 20:48:31.359609+00
1431	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-07 21:05:05.473318+00
1432	faroukaremou5@gmail.com	td	t	102.202.111.198	2026-10-08 04:50:09.180557+00
1433	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 05:53:46.760589+00
1434	urielhouegbe	admin	t	41.85.162.154	2026-10-08 06:08:54.798362+00
1435	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-08 06:46:17.67669+00
1436	akakpoenock00@gmail.com	td	t	137.255.57.204	2026-10-08 06:46:39.409512+00
1437	magbondejerome@gmail.com	td	t	154.72.113.115	2026-10-08 07:12:16.259842+00
1438	leopoldchangodele@gmail.com	td	t	41.216.54.198	2026-10-08 07:45:39.668491+00
1439	charliehounkanrin@gmail.com	td	t	197.234.219.147	2026-10-08 07:53:01.987687+00
1440	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 08:31:18.160361+00
1441	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 09:08:06.415051+00
1442	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 10:48:34.235521+00
1443	florenthinnou@gmail.com	td	t	41.216.54.240	2026-10-08 11:15:01.099106+00
1444	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 12:04:17.891288+00
1445	gedeonfintovitchede@gmail.com	td	t	41.216.54.9	2026-10-08 12:19:08.724006+00
1446	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 12:56:25.215866+00
1447	akakpoenock00@gmail.com	td	t	154.66.133.55	2026-10-08 13:09:38.128784+00
1448	charliehounkanrin@gmail.com	td	t	197.234.219.201	2026-10-08 17:30:22.064754+00
1449	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 17:43:44.380368+00
1450	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 18:36:37.407715+00
1451	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 19:04:59.569608+00
1452	jealexhouegbe	admin	t	154.66.139.192	2026-10-08 20:54:08.049664+00
1453	florenthinnou@gmail.com	td	t	41.216.54.253	2026-10-08 20:54:25.765931+00
1454	nistani21@gmail.com	td	t	41.85.163.145	2026-10-08 20:55:58.870324+00
1455	ferdinandagossou03@gmail.com	td	t	41.216.53.136	2026-10-08 23:14:32.188779+00
1456	jealexhouegbe	admin	t	102.202.111.255	2026-10-09 00:32:53.011755+00
1457	jealexhouegbe	admin	t	102.202.111.255	2026-10-09 02:29:16.889698+00
1458	jealexhouegbe	admin	t	102.202.111.255	2026-10-09 05:23:31.44193+00
1459	jealexhouegbe	admin	t	102.202.111.21	2026-10-09 07:25:39.15503+00
1460	marcepepe@gmail.com	td	t	156.0.213.219	2026-10-09 07:59:43.816444+00
\.


--
-- Data for Name: matieres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matieres (id, nom, code, ordre, actif) FROM stdin;
1	Francais	FR	1	t
2	Mathematiques	MATHS	2	t
3	Anglais	ANG	3	t
5	SVT	SVT	5	t
6	Philosophie	PHILO	6	t
7	Histoire-Geographie	HG	7	t
8	Economie	ECO	8	t
9	Espagnol	ESP	9	t
10	Allemand	ALL	10	t
11	Com. Ecrite	COM_ECRITE	11	t
4	PCT	PCT	4	t
\.


--
-- Data for Name: mois_exoneres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mois_exoneres (id, eleve_id, mois_souscription, annee_scolaire_id, motif, exonere_par, date_exoneration) FROM stdin;
1	467	Octobre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
2	467	Novembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
3	467	Decembre	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
4	467	Janvier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
5	467	Fevrier	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
6	467	Mars	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
7	467	Avril	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
8	467	Mai	1	Exonération permanente : Enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-17 10:16:41.397475+00
9	855	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:22:05.079475+00
10	855	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:22:05.079475+00
11	878	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:23:04.275416+00
12	737	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:23:58.686231+00
13	51	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:24:37.841311+00
14	419	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:38:02.728866+00
15	72	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:14.642648+00
16	72	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:14.642648+00
17	215	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:37.179525+00
18	215	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:56:37.179525+00
19	11	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:57:17.641216+00
20	902	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-22 03:57:59.869182+00
21	621	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-24 00:55:53.870528+00
22	936	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-24 00:57:37.93378+00
23	977	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-27 16:49:33.343448+00
24	977	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-27 16:49:33.343448+00
25	1049	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:06:18.230057+00
26	972	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:08:16.872281+00
27	843	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:14:14.497711+00
28	550	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:15:47.070313+00
29	530	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:16:51.747933+00
30	588	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:17:09.399889+00
31	55	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:54.068454+00
32	55	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:54.068454+00
33	55	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:22:54.068454+00
34	209	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.304046+00
35	209	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.304046+00
36	209	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:00.304046+00
37	243	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:46.103177+00
38	243	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:46.103177+00
39	243	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:24:46.103177+00
40	334	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.929034+00
41	334	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.929034+00
42	334	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:25:19.929034+00
43	457	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.770753+00
44	457	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.770753+00
45	457	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:07.770753+00
46	487	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:48.04716+00
47	487	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:48.04716+00
48	487	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:26:48.04716+00
49	497	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:24.107326+00
50	497	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:24.107326+00
51	497	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:24.107326+00
52	501	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.827843+00
53	501	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.827843+00
54	501	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:27:59.827843+00
55	58	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:30:20.558852+00
56	58	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:30:20.558852+00
57	164	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:05.159222+00
58	164	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:05.159222+00
59	270	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:47.012443+00
60	270	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:31:47.012443+00
63	456	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:02.425967+00
64	456	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:02.425967+00
65	480	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:44.225683+00
66	480	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:33:44.225683+00
67	490	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:26.566471+00
68	490	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:26.566471+00
69	502	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:58.908046+00
70	502	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:34:58.908046+00
71	9	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:35:51.955016+00
72	193	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:36:33.104756+00
73	235	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:37:00.621702+00
74	449	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:24.850541+00
75	469	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:38:51.278798+00
76	491	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:19.441822+00
77	509	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:39:59.567692+00
78	980	Octobre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
79	980	Novembre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
80	980	Decembre	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
81	980	Janvier	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
82	980	Fevrier	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
83	980	Mars	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
84	980	Avril	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
85	980	Mai	1	Exonération permanente : enfant du personnel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:42:10.602316+00
86	549	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.360261+00
87	549	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.360261+00
88	549	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:43:50.360261+00
89	530	Fevrier	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:46:03.939152+00
90	530	Mars	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:46:03.939152+00
91	546	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:47:04.825636+00
92	560	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.840072+00
93	560	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.840072+00
94	560	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:05.840072+00
95	564	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:37.897925+00
96	564	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:48:37.897925+00
97	570	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:07.16807+00
98	625	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.754526+00
99	625	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.754526+00
100	625	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:50:36.754526+00
101	862	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:51:08.758264+00
102	862	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:51:08.758264+00
103	620	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:21.538583+00
104	650	Octobre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.636325+00
105	650	Novembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.636325+00
106	650	Decembre	1	Bourse (3 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:52:50.636325+00
107	657	Octobre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:53:18.870867+00
108	657	Novembre	1	Bourse (2 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:53:18.870867+00
109	659	Octobre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:53:56.264218+00
110	328	Novembre	1	Bourse (1 mois) : Boursier d'excellence	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-09-28 03:55:12.497769+00
111	243	Avril	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:38:47.083336+00
112	244	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:45:33.926076+00
113	848	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:46:43.469785+00
114	53	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:47:08.76016+00
115	961	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 00:47:52.555197+00
116	177	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-03 04:25:20.939924+00
117	959	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 09:13:36.445431+00
118	459	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:46:09.269885+00
119	251	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:53:16.266288+00
120	251	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:53:16.266288+00
121	156	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 21:58:53.869719+00
122	156	Mai	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:00:23.352356+00
123	623	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:09:43.37038+00
124	623	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:09:43.37038+00
125	604	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:23:42.219663+00
126	605	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:25:10.011343+00
127	574	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:35:36.356497+00
128	842	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:43:22.176691+00
129	1072	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:50:47.530783+00
130	1060	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 22:55:52.963461+00
131	133	Avril	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:00:40.989879+00
132	133	Mai	1	Offre 6 mois payés simultanément : mois offert (année complète soldée)	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:00:40.989879+00
133	873	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:08:29.303855+00
134	1026	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:31:41.9043+00
135	1004	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:37:50.257888+00
136	203	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-05 20:51:49.442606+00
137	729	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-06 04:25:54.090502+00
138	395	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-06 20:54:45.857517+00
139	839	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 12:56:57.771222+00
140	100	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 19:07:19.89949+00
141	101	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 19:07:59.5437+00
142	1028	Janvier	1	Offre 3 mois payés simultanément : mois offert	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-08 19:08:26.914104+00
\.


--
-- Data for Name: moyennes_semestrielles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.moyennes_semestrielles (id, eleve_id, annee_scolaire_id, semestre, moyenne_generale, cloture_par, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, eleve_id, matiere_id, type_note, valeur, annee_scolaire_id, updated_at, semestre) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, site_id, contenu, lu, date_creation, roles_cibles) FROM stdin;
1	2	⚠️ Alerte assiduité : ADECHOLA Saad (5ème, Y08261292) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
2	2	⚠️ Alerte assiduité : BANGO Emmanuel (5ème, Y08265886) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
3	2	⚠️ Alerte assiduité : BOGNON Isaac (5ème, Y08267046) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
4	2	⚠️ Alerte assiduité : HOUESSOU Emmanuel (5ème, Y08261959) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
5	2	⚠️ Alerte assiduité : ISSEKI Marie Thérèse (5ème, Y08262321) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
6	2	⚠️ Alerte assiduité : KEKE Florent (5ème, Y08268089) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
7	2	⚠️ Alerte assiduité : ODI Bernice (5ème, Y08263327) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
8	2	⚠️ Alerte assiduité : SALIOU Fridaous (5ème, Y08265146) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
9	2	⚠️ Alerte assiduité : SOHE Abebi (5ème, Y08265526) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
10	2	⚠️ Alerte assiduité : TAO Hidirou (5ème, Y08266928) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:08:28.318867+00	{coordonnateur,superviseur,chef_site}
11	2	⚠️ Alerte assiduité : ADAMON Assande (4ème, Y08264402) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
12	2	⚠️ Alerte assiduité : ADAMON Rossime (4ème, Y08268668) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
13	2	⚠️ Alerte assiduité : ALLODE Jérémie (4ème, Y08263589) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
14	2	⚠️ Alerte assiduité : BANKOLE Noel (4ème, Y08263174) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
15	2	⚠️ Alerte assiduité : DANSOU Laurence (4ème, Y08269579) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
16	2	⚠️ Alerte assiduité : HOUNDETON Silvia (4ème, Y08269420) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
17	2	⚠️ Alerte assiduité : HOUNDETON Louise (4ème, Y08263538) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
18	2	⚠️ Alerte assiduité : HOUNKPATIN Constance (4ème, Y08269245) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
19	2	⚠️ Alerte assiduité : KOUKOUI Mariette (4ème, Y08264713) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
20	2	⚠️ Alerte assiduité : LAKOUSSAN Josué (4ème, Y08268145) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
21	2	⚠️ Alerte assiduité : TCHANGOTADE Doris (4ème, Y08267413) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
22	2	⚠️ Alerte assiduité : TOLOFON Eben Ezer (4ème, Y08263533) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
23	2	⚠️ Alerte assiduité : ZANNOU Kephil (4ème, Y08261636) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
24	2	⚠️ Alerte assiduité : FASSINOU Esther (4ème, Y09264641) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
25	2	⚠️ Alerte assiduité : HOUNGA Océane (4ème, Y09263033) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:24:13.594348+00	{coordonnateur,superviseur,chef_site}
26	2	⚠️ Alerte assiduité : ADANHONDJI Osias (6ème, Y08268030) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
27	2	⚠️ Alerte assiduité : AGOSSOU Dossa Rosvald (6ème, Y08268870) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
28	2	⚠️ Alerte assiduité : AHLOU GOZO Exaucé (6ème, Y08266698) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
29	2	⚠️ Alerte assiduité : ALI Roubayatou (6ème, Y08261849) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
30	2	⚠️ Alerte assiduité : DANGBEDJI Cynthia Grâce (6ème, Y08267913) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
31	2	⚠️ Alerte assiduité : DOSSOU-KOKO Gentille (6ème, Y08261375) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
32	2	⚠️ Alerte assiduité : DOURODOLA Sofiath Adéola (6ème, Y08269847) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
33	2	⚠️ Alerte assiduité : GOUTHON Guillaume Guérin (6ème, Y08261805) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
34	2	⚠️ Alerte assiduité : HOUNGNANNOU Marius (6ème, Y08267369) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
35	2	⚠️ Alerte assiduité : HOUSSOU Eric Samuel (6ème, Y08265665) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
36	2	⚠️ Alerte assiduité : KANGNIDE Bénoit (6ème, Y08268529) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
37	2	⚠️ Alerte assiduité : KASSA Rock Kodjo (6ème, Y08268504) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
38	2	⚠️ Alerte assiduité : MAIGA Fatoumata (6ème, Y08262415) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
39	2	⚠️ Alerte assiduité : MAIGA Halimata (6ème, Y08263608) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
40	2	⚠️ Alerte assiduité : OUABI Romdonne (6ème, Y08264124) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
41	2	⚠️ Alerte assiduité : TITI Farida (6ème, Y08264735) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
42	2	⚠️ Alerte assiduité : OUMAROU Ramatou (6ème, Y09261630) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:29:07.990142+00	{coordonnateur,superviseur,chef_site}
43	2	⚠️ Alerte assiduité : ADANHONDJI Edith (3ème, Y08266767) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
44	2	⚠️ Alerte assiduité : ADJAGNISSOUDE Parfait (3ème, Y08264406) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
45	2	⚠️ Alerte assiduité : AKALA Achani (3ème, Y08263391) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
46	2	⚠️ Alerte assiduité : DANTODJI Amos (3ème, Y08263904) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
47	2	⚠️ Alerte assiduité : DANTON Emmanuella (3ème, Y08263449) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
48	2	⚠️ Alerte assiduité : DJIDENOU Elysée (3ème, Y08269761) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
49	2	⚠️ Alerte assiduité : DJODE Wilson (3ème, Y08269235) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
50	2	⚠️ Alerte assiduité : HOUNKPATIN Melvine (3ème, Y08262562) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
51	2	⚠️ Alerte assiduité : LANKPOEDJA Pascaline (3ème, Y08264767) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
52	2	⚠️ Alerte assiduité : MINTOKIN Bernadette (3ème, Y08266002) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
53	2	⚠️ Alerte assiduité : SAMOU Ashley (3ème, Y08265213) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
54	2	⚠️ Alerte assiduité : SOSSOU Ornella (3ème, Y08266220) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
55	2	⚠️ Alerte assiduité : YOLOU Chaidatou (3ème, Y08266195) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
56	2	⚠️ Alerte assiduité : ZANNOU Bilal (3ème, Y08261815) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
57	2	⚠️ Alerte assiduité : ADAMOU Rassida (3ème, Y09267706) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
58	2	⚠️ Alerte assiduité : DJIMASSA Caméria (3ème, Y09262133) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
59	2	⚠️ Alerte assiduité : HOUNNOU Sandrine (3ème, Y09268075) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
60	2	⚠️ Alerte assiduité : MINTOWANOU Christiane (3ème, Y09261514) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:34:29.796414+00	{coordonnateur,superviseur,chef_site}
61	1	⚠️ Alerte assiduité : ADANMAHO Ruth (6ème A, J08268022) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
62	1	⚠️ Alerte assiduité : AGOSSOU Gael (6ème A, J08262268) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
63	1	⚠️ Alerte assiduité : AHOTON Aristide (6ème A, J08268267) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
64	1	⚠️ Alerte assiduité : AHOUANDJINOU Mitricia (6ème A, J08261730) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
65	1	⚠️ Alerte assiduité : BODJOSSOU Chimène (6ème A, J08263536) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
66	1	⚠️ Alerte assiduité : DANNOUDO Joanita (6ème A, J08266999) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
67	1	⚠️ Alerte assiduité : DANSOU René (6ème A, J08262951) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
68	1	⚠️ Alerte assiduité : DEGBO Abel (6ème A, J08261500) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
69	1	⚠️ Alerte assiduité : EDIBO Haidou (6ème A, J08262766) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
70	1	⚠️ Alerte assiduité : GANGNON Abidémi Mourana (6ème A, J08263543) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
71	1	⚠️ Alerte assiduité : GODONOU Gloria Merveille (6ème A, J08264361) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
72	1	⚠️ Alerte assiduité : HONVOU Josué Norbert (6ème A, J08262551) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
73	1	⚠️ Alerte assiduité : HOUADJETO Rose (6ème A, J08268178) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
74	1	⚠️ Alerte assiduité : HOUADJETO Jéhovany (6ème A, J08265291) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
75	1	⚠️ Alerte assiduité : HOUESSOU Prince (6ème A, J08264295) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
76	1	⚠️ Alerte assiduité : HOUNGBO Urielle (6ème A, J08268757) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
77	1	⚠️ Alerte assiduité : HOUNSOU Béni (6ème A, J08262703) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
78	1	⚠️ Alerte assiduité : OLOUGBADE Fèmi Ruthe (6ème A, J08269413) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
79	1	⚠️ Alerte assiduité : SIMENOU M. Jérôme (6ème A, J08269042) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
80	1	⚠️ Alerte assiduité : THON Elians (6ème A, J08264309) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
81	1	⚠️ Alerte assiduité : TRAORE Azizé (6ème A, J08265282) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
82	1	⚠️ Alerte assiduité : YEHOUENOU Elisabeth (6ème A, J08263772) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
83	1	⚠️ Alerte assiduité : ZINHO Edwige (6ème A, J08267089) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
84	1	⚠️ Alerte assiduité : ADEYEMON Alphé (6ème A, J08263259) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
85	1	⚠️ Alerte assiduité : ADJOVI Gilles-Christ (6ème A, J08266080) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
86	1	⚠️ Alerte assiduité : AKINOCHO Espérancia (6ème A, J08263759) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
87	1	⚠️ Alerte assiduité : ALANGBOKINTO Christ-fort (6ème A, J08264362) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
88	1	⚠️ Alerte assiduité : ALI Nabilath (6ème A, J08266596) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
89	1	⚠️ Alerte assiduité : ALOSSE Mahutin (6ème A, J08265636) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
90	1	⚠️ Alerte assiduité : AZOUASSI Arielle (6ème A, J08268975) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
91	1	⚠️ Alerte assiduité : COUMASSOU Fifamè (6ème A, J08266460) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
92	1	⚠️ Alerte assiduité : DENAKPO Samuel (6ème A, J08268114) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
93	1	⚠️ Alerte assiduité : GNONLONFOUN Elisabeth (6ème A, J08266111) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
94	1	⚠️ Alerte assiduité : GNONLONFOUN Majoie (6ème A, J08268706) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
95	1	⚠️ Alerte assiduité : HESSOU Inès (6ème A, J08269126) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
96	1	⚠️ Alerte assiduité : HOUESSOU Brice (6ème A, J08262289) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
97	1	⚠️ Alerte assiduité : HOUNGBEDJI Christian (6ème A, J08266301) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
98	1	⚠️ Alerte assiduité : HOUNGBO Emannuel (6ème A, J08264399) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
99	1	⚠️ Alerte assiduité : IMOROU Arafat (6ème A, J08263486) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
100	1	⚠️ Alerte assiduité : KOUMA Patricia (6ème A, J08261761) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
101	1	⚠️ Alerte assiduité : MEGNIZIN Melvine (6ème A, J08262790) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
102	1	⚠️ Alerte assiduité : NASSARA Firmin Tobias (6ème A, J08262583) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
103	1	⚠️ Alerte assiduité : NASSARA Augustin (6ème A, J08264701) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
104	1	⚠️ Alerte assiduité : OTCHRAN Micheline (6ème A, J08266095) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
105	1	⚠️ Alerte assiduité : QUENUM Wahib (6ème A, J08264530) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
106	1	⚠️ Alerte assiduité : SOUNOUVOU Christophe (6ème A, J08265267) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
107	1	⚠️ Alerte assiduité : SOVIGUIDI Nadège (6ème A, J08263178) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 08:45:37.206307+00	{coordonnateur,superviseur,chef_site}
108	1	⚠️ Alerte assiduité : COSSE Florentine (6ème B, J08264120) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
109	1	⚠️ Alerte assiduité : NOUGBODJI Chantale (6ème B, J08264951) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
110	1	⚠️ Alerte assiduité : OYASIDI Amed (6ème B, J08261282) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
111	1	⚠️ Alerte assiduité : ABDOULAYE Anas (6ème B, J08268492) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
112	1	⚠️ Alerte assiduité : ADAM Hamirath (6ème B, J08262251) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
113	1	⚠️ Alerte assiduité : ADAN Ginette (6ème B, J08268011) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
114	1	⚠️ Alerte assiduité : ADINGNI Espoir (6ème B, J08264206) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
115	1	⚠️ Alerte assiduité : ADONON Agathe (6ème B, J08266648) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
116	1	⚠️ Alerte assiduité : AHOUMENOU Jephte (6ème B, J08262485) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
117	1	⚠️ Alerte assiduité : AYIVODJI Bernice (6ème B, J08261768) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
118	1	⚠️ Alerte assiduité : BEAHENOU Luchrist (6ème B, J08269030) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
119	1	⚠️ Alerte assiduité : BONI Gloire (6ème B, J08265020) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
120	1	⚠️ Alerte assiduité : CHOGOLOU Géovani (6ème B, J08261340) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
121	1	⚠️ Alerte assiduité : DAVI Elysée (6ème B, J08268419) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
122	1	⚠️ Alerte assiduité : DANSOU Constantin (6ème B, J08262136) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
123	1	⚠️ Alerte assiduité : DIAWARA Aicha (6ème B, J08269531) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
124	1	⚠️ Alerte assiduité : GANDJI Donald (6ème B, J08261370) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
125	1	⚠️ Alerte assiduité : GBETCHOEVI Ornela (6ème B, J08263929) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
126	1	⚠️ Alerte assiduité : GNANSOUNOU Angelo (6ème B, J08268290) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
127	1	⚠️ Alerte assiduité : GNITABOU Pierrette (6ème B, J08263073) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
128	1	⚠️ Alerte assiduité : HONFO Irène (6ème B, J08262823) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
129	1	⚠️ Alerte assiduité : HOUENOU Chrismel (6ème B, J08265639) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
130	1	⚠️ Alerte assiduité : HOUNGUE Huguette (6ème B, J08268864) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
131	1	⚠️ Alerte assiduité : HOUNGUIEVI Firmin (6ème B, J08262013) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
132	1	⚠️ Alerte assiduité : HOUNMENOU Urielle (6ème B, J08265471) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
133	1	⚠️ Alerte assiduité : LATEDJOU Arafat (6ème B, J08262492) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
134	1	⚠️ Alerte assiduité : LINDE Houeffa (6ème B, J08264113) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
135	1	⚠️ Alerte assiduité : MEGNIHA Darius (6ème B, J08261580) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
136	1	⚠️ Alerte assiduité : MONNOU Mariam (6ème B, J08264738) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
137	1	⚠️ Alerte assiduité : MOUSSA Souraimou (6ème B, J08265910) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
138	1	⚠️ Alerte assiduité : MOUTAIROU Sékinath (6ème B, J08265457) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
139	1	⚠️ Alerte assiduité : ODOUTAN Florent (6ème B, J08268253) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
140	1	⚠️ Alerte assiduité : OUSSA Soubela (6ème B, J08263689) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
141	1	⚠️ Alerte assiduité : SOKE Elisée (6ème B, J08268798) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
142	1	⚠️ Alerte assiduité : VOITAN Mirabelle (6ème B, J08262675) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
143	1	⚠️ Alerte assiduité : ZANNOU Hervé (6ème B, J08264158) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
144	1	⚠️ Alerte assiduité : ZOUNDJIEKPON Clément (6ème B, J08269788) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
145	1	⚠️ Alerte assiduité : AHIHA Antoine (6ème B, J08267999) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
146	1	⚠️ Alerte assiduité : AHIHA Joanès (6ème B, J08265432) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
147	1	⚠️ Alerte assiduité : AHOUANGONOU Pauline (6ème B, J08262391) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
148	1	⚠️ Alerte assiduité : AKAKPO Marie Jeanne (6ème B, J08263647) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
149	1	⚠️ Alerte assiduité : ADEOSSI Sergino (6ème B, J08269684) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
150	1	⚠️ Alerte assiduité : BOTON FATCHE Augustin (6ème B, J08266047) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
151	1	⚠️ Alerte assiduité : GNANSOUNOU William (6ème B, J08265023) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
152	1	⚠️ Alerte assiduité : HONFO Adjimon Jean (6ème B, J08264804) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
153	1	⚠️ Alerte assiduité : HOUNGA Eric (6ème B, J08263162) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
154	1	⚠️ Alerte assiduité : HOUNKONDE Christ (6ème B, J08269644) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
155	1	⚠️ Alerte assiduité : OGOUDJOBI Mounirath (6ème B, J08261480) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
156	1	⚠️ Alerte assiduité : QUENUM Miracle (6ème B, J08269868) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
157	1	⚠️ Alerte assiduité : TODE Alexandre (6ème B, J08263582) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
158	1	⚠️ Alerte assiduité : TOKPO Dieu donné (6ème B, J08262231) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
159	1	⚠️ Alerte assiduité : ZINSOU Sènami (6ème B, J08265238) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
160	1	⚠️ Alerte assiduité : VITIN Anath Elisée (6ème B, J09264694) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:02:07.024+00	{coordonnateur,superviseur,chef_site}
161	1	⚠️ Alerte assiduité : ADANZOUNNON Marie Louise (4ème B, J08265678) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
162	1	⚠️ Alerte assiduité : ALANGBOKINTO Marc Vivien (4ème B, J08264875) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
163	1	⚠️ Alerte assiduité : DANSOU Madeleine (4ème B, J08269655) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
164	1	⚠️ Alerte assiduité : DJIGBE Gédéon (4ème B, J08266833) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
165	1	⚠️ Alerte assiduité : HOUNTON Mathieu (4ème B, J08268053) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
166	1	⚠️ Alerte assiduité : HOUNVO Géronime (4ème B, J08267063) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
167	1	⚠️ Alerte assiduité : KLADJI Joinelle (4ème B, J08264987) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
168	1	⚠️ Alerte assiduité : KLOTOE Dénis (4ème B, J08263930) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
169	1	⚠️ Alerte assiduité : OKOU ADE Huguette (4ème B, J08267289) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
170	1	⚠️ Alerte assiduité : TODJINOU Bénoit (4ème B, J08266189) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
171	1	⚠️ Alerte assiduité : AHISSOU Marcolino (4ème B, J08264502) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
172	1	⚠️ Alerte assiduité : AWODJE Eric (4ème B, J08262903) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
173	1	⚠️ Alerte assiduité : CHEMITAN Widad (4ème B, J08266858) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
174	1	⚠️ Alerte assiduité : GNONLONFOUN José (4ème B, J08263141) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
175	1	⚠️ Alerte assiduité : KOULIHO Giovanie (4ème B, J08264286) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
176	1	⚠️ Alerte assiduité : MASSANGA Emmanuel (4ème B, J08266367) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
177	1	⚠️ Alerte assiduité : DANKE Junior (4ème B, J08264161) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
178	1	⚠️ Alerte assiduité : HONNAHO Jahsther (4ème B, J08269070) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
179	1	⚠️ Alerte assiduité : HOUNGBEMEY Emmanuella (4ème B, J08269518) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
180	1	⚠️ Alerte assiduité : ODJO Archimède (4ème B, J08268466) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:34:52.82597+00	{coordonnateur,superviseur,chef_site}
181	1	⚠️ Alerte assiduité : ABOUDOU Enock (4ème A, J08263316) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
182	1	⚠️ Alerte assiduité : ADJOVI Dylane (4ème A, J08269590) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
183	1	⚠️ Alerte assiduité : AGONYE Monique (4ème A, J08261424) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
184	1	⚠️ Alerte assiduité : AHOUAGA Fabrice (4ème A, J08262029) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
185	1	⚠️ Alerte assiduité : AMOUSSOU Elfrida (4ème A, J08264258) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
186	1	⚠️ Alerte assiduité : AVLESSI Sylvia (4ème A, J08267011) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
187	1	⚠️ Alerte assiduité : DAKOSSI Constance (4ème A, J08265577) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
188	1	⚠️ Alerte assiduité : DAVI Emmanuel (4ème A, J08266520) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
189	1	⚠️ Alerte assiduité : DAVI Elias (4ème A, J08261989) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
190	1	⚠️ Alerte assiduité : FOFANA Tidjani (4ème A, J08262738) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
191	1	⚠️ Alerte assiduité : KOUDJOU Alves (4ème A, J08261576) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
192	1	⚠️ Alerte assiduité : WINSAVI Nadège (4ème A, J08264859) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
193	1	⚠️ Alerte assiduité : AFO Fabienne (4ème A, J08263921) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
194	1	⚠️ Alerte assiduité : AGONZAN Victoire (4ème A, J08269613) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
195	1	⚠️ Alerte assiduité : ANAGONOU Lydwine Judith (4ème A, J08266187) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
196	1	⚠️ Alerte assiduité : DJOSSOU Adèle (4ème A, J08267492) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
197	1	⚠️ Alerte assiduité : GANDONOU Olivia (4ème A, J08262042) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
198	1	⚠️ Alerte assiduité : GANDONOU Olivier (4ème A, J08265175) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
199	1	⚠️ Alerte assiduité : GANKOU Nelda (4ème A, J08262658) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
200	1	⚠️ Alerte assiduité : HOUSSOU Grâce (4ème A, J08267619) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
201	1	⚠️ Alerte assiduité : HOUSSOU Jean Pascal (4ème A, J08264225) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
202	1	⚠️ Alerte assiduité : IJIDINAN Romain (4ème A, J08269487) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
203	1	⚠️ Alerte assiduité : KINSOU Wilsdom (4ème A, J08267503) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
204	1	⚠️ Alerte assiduité : KOUNNOU Chancelle (4ème A, J08261832) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
205	1	⚠️ Alerte assiduité : N'TIA Auristelle (4ème A, J08261907) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
206	1	⚠️ Alerte assiduité : PRINCE AGBODJAN Marius (4ème A, J08267045) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
207	1	⚠️ Alerte assiduité : SYLLA Alassane (4ème A, J08262326) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
208	1	⚠️ Alerte assiduité : SYLLA Fousséni (4ème A, J08269245) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
209	1	⚠️ Alerte assiduité : TCHIAKPE Exaucée (4ème A, J08269120) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
210	1	⚠️ Alerte assiduité : TCHOKOTI Peace (4ème A, J08269234) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
211	1	⚠️ Alerte assiduité : ZANNOU Géraldo (4ème A, J08266134) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
212	1	⚠️ Alerte assiduité : ZINLI Dario (4ème A, J08267300) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
213	1	⚠️ Alerte assiduité : AHOUANGANON Mariella (4ème A, J08263545) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
214	1	⚠️ Alerte assiduité : BATOSSI Alexia (4ème A, J08262861) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
215	1	⚠️ Alerte assiduité : HOUETO Madochée Pio (4ème A, J08268479) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
216	1	⚠️ Alerte assiduité : IMOROU Nabil (4ème A, J08267178) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
217	1	⚠️ Alerte assiduité : AYIDOKINHOU Kévine Junior (4ème A, J08267530) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
218	1	⚠️ Alerte assiduité : SALE Nicole (4ème A, J08265051) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
219	1	⚠️ Alerte assiduité : DJOSSOU Adèle (4ème A, J09264148) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 09:46:07.595471+00	{coordonnateur,superviseur,chef_site}
220	1	⚠️ Alerte assiduité : AGOSSOU Ashley (Première C, J08267214) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
221	1	⚠️ Alerte assiduité : DOVI Edwige (Première C, J08266270) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
222	1	⚠️ Alerte assiduité : HOUNGA Christian (Première C, J08266856) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
223	1	⚠️ Alerte assiduité : KANA Emmanuella (Première C, J08266085) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:13:58.796773+00	{coordonnateur,superviseur,chef_site}
224	1	⚠️ Alerte assiduité : LEGUEDE Emmanuel (Première D, J08262339) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
225	1	⚠️ Alerte assiduité : ADEKPODJOU Fatima (Première D, J08262634) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
226	1	⚠️ Alerte assiduité : ADIMOU Julie (Première D, J08265985) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
227	1	⚠️ Alerte assiduité : ADJAGNISSOUDE Pamella (Première D, J08261913) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
228	1	⚠️ Alerte assiduité : AHOUANGANON Nadège (Première D, J08262897) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
229	1	⚠️ Alerte assiduité : AMONDO Kiriya (Première D, J08262066) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
230	1	⚠️ Alerte assiduité : DJOCHOU Louise (Première D, J08267175) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
231	1	⚠️ Alerte assiduité : FAGNISSE Majoie (Première D, J08265173) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
232	1	⚠️ Alerte assiduité : KODJO Miracle (Première D, J08265430) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
233	1	⚠️ Alerte assiduité : KOUNNOU Jocelyne (Première D, J08263898) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
234	1	⚠️ Alerte assiduité : OLLIVIER DE MONTAGUERE Luce (Première D, J08266694) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
235	1	⚠️ Alerte assiduité : RADJEDO Pierrette (Première D, J08268728) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
236	1	⚠️ Alerte assiduité : AKPOTINKPE Jacqueline (Première D, J08267751) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
237	1	⚠️ Alerte assiduité : ASSONGBA Ruth (Première D, J08263781) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
238	1	⚠️ Alerte assiduité : ATEDJI Madine (Première D, J08263809) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
239	1	⚠️ Alerte assiduité : KOTTIN Modeste (Première D, J08261574) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
240	1	⚠️ Alerte assiduité : MEVOGNON Exelle (Première D, J08269599) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
241	1	⚠️ Alerte assiduité : MIFOKPO Jacqueline (Première D, J08267702) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
242	1	⚠️ Alerte assiduité : ZOSSOU YOVO Daniel (Première D, J08265326) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 10:21:28.53211+00	{coordonnateur,superviseur,chef_site}
243	1	⚠️ Alerte assiduité : ADJIWANOU Gérade (5ème B, J08269360) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
244	1	⚠️ Alerte assiduité : AGLO-HOUNGA Fèmi (5ème B, J08265248) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
245	1	⚠️ Alerte assiduité : AGUE Dolorès (5ème B, J08268059) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
246	1	⚠️ Alerte assiduité : AKPOVI Freshnelle (5ème B, J08267899) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
247	1	⚠️ Alerte assiduité : ATEDJI Fernand (5ème B, J08264845) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
248	1	⚠️ Alerte assiduité : DJIGBE Bernadin (5ème B, J08265241) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
249	1	⚠️ Alerte assiduité : DJOWADAN Christine (5ème B, J08266725) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
250	1	⚠️ Alerte assiduité : GANHOUNOUTO Marie Thérèse (5ème B, J08264321) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
251	1	⚠️ Alerte assiduité : GUELIFO Romuald (5ème B, J08268159) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
252	1	⚠️ Alerte assiduité : HOUENOU Abdias (5ème B, J08263744) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
253	1	⚠️ Alerte assiduité : HOUNSOU Adéline (5ème B, J08266932) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
254	1	⚠️ Alerte assiduité : HOYETON Daniel (5ème B, J08264360) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
255	1	⚠️ Alerte assiduité : IBRAHIM Mohamed (5ème B, J08263025) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
256	1	⚠️ Alerte assiduité : KOUTON Dorcas Mahugnon (5ème B, J08268081) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
257	1	⚠️ Alerte assiduité : LAHADE Christelle (5ème B, J08268611) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
258	1	⚠️ Alerte assiduité : MUIDEEN Adidjathou (5ème B, J08266524) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
259	1	⚠️ Alerte assiduité : MOUKAILA Adidjath (5ème B, J08267191) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
260	1	⚠️ Alerte assiduité : OUSSENI Ramdia (5ème B, J08262732) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
261	1	⚠️ Alerte assiduité : SAVIAKO Achille (5ème B, J08263366) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
262	1	⚠️ Alerte assiduité : TOKPANOU Osé (5ème B, J08265715) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
263	1	⚠️ Alerte assiduité : TOUNAOU Mohamed (5ème B, J08264817) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
264	1	⚠️ Alerte assiduité : VIGAN Horsman (5ème B, J08264526) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
265	1	⚠️ Alerte assiduité : YEVO EDO Bénédicte (5ème B, J08269533) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
266	1	⚠️ Alerte assiduité : ZOUNDJI Inès (5ème B, J08264376) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
267	1	⚠️ Alerte assiduité : HOUNTONDJI Gaspard (5ème B, J08265135) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
268	1	⚠️ Alerte assiduité : AYIMETON Pierrette (5ème B, J08267093) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
269	1	⚠️ Alerte assiduité : KANGNI Fernande (5ème B, J08266944) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 11:08:52.671505+00	{coordonnateur,superviseur,chef_site}
270	1	⚠️ Alerte assiduité : ADANDE Fifamè (5ème A, J08267193) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
271	1	⚠️ Alerte assiduité : AGBO Bénédicte (5ème A, J08268357) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
272	1	⚠️ Alerte assiduité : AGOGNON Junior (5ème A, J08263105) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
273	1	⚠️ Alerte assiduité : AHISSOU Exaucé (5ème A, J08269605) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
274	1	⚠️ Alerte assiduité : ALLOSSE Charafath (5ème A, J08264017) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
275	1	⚠️ Alerte assiduité : ATCHONDE Fednand (5ème A, J08263879) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
276	1	⚠️ Alerte assiduité : AYONOU Samuel (5ème A, J08262999) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
277	1	⚠️ Alerte assiduité : DE CAMPOS Lionel (5ème A, J08266153) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
278	1	⚠️ Alerte assiduité : DHESSIN Ingrid (5ème A, J08264331) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
279	1	⚠️ Alerte assiduité : DJOTCHOU Arnaud (5ème A, J08263996) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
280	1	⚠️ Alerte assiduité : FOHOU Eunice (5ème A, J08265816) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
281	1	⚠️ Alerte assiduité : HOUNSOU Grâce (5ème A, J08265404) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
282	1	⚠️ Alerte assiduité : HOYETON Diane (5ème A, J08267821) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
283	1	⚠️ Alerte assiduité : KABADE Doreil (5ème A, J08269582) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
284	1	⚠️ Alerte assiduité : KAKPO Précieuse (5ème A, J08265429) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
285	1	⚠️ Alerte assiduité : KPIKPONSOUHOU Chérif (5ème A, J08267855) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
286	1	⚠️ Alerte assiduité : LAWANI Nourou Dine (5ème A, J08262887) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
287	1	⚠️ Alerte assiduité : OLADELE Mukaram (5ème A, J08268326) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
288	1	⚠️ Alerte assiduité : OLOUGBADE Anne Yémissi (5ème A, J08269233) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
289	1	⚠️ Alerte assiduité : PADONOU Chancelle (5ème A, J08263282) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
290	1	⚠️ Alerte assiduité : SALAMI Mourtador (5ème A, J08267573) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
291	1	⚠️ Alerte assiduité : SEDJRO Abiba Fifamè (5ème A, J08264312) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
292	1	⚠️ Alerte assiduité : TIDJANI Imraan (5ème A, J08263674) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
293	1	⚠️ Alerte assiduité : TOSSA Kasmi (5ème A, J08267188) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
294	1	⚠️ Alerte assiduité : BOGNON Isaac (5ème A, J08263297) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
295	1	⚠️ Alerte assiduité : FOHOU Tite (5ème A, J08266114) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
296	1	⚠️ Alerte assiduité : VICTOR VITOHOUINDJI Appolinaire (5ème A, J08267310) a cumulé 2 absences au cours du mois de Septembre.	f	2026-09-26 15:08:25.764852+00	{coordonnateur,superviseur,chef_site}
297	1	Paiement supprimé : 2 500 F (Octobre) annulé pour MOIDE Fènou Jériel Antonio (J09266010) par jealexhouegbe — Motif : Erreur de saisie du montant normal payé	t	2026-10-04 23:29:12.353035+00	{coordonnateur,comptable}
298	1	Paiement supprimé : 5 000 F (Octobre) annulé pour CAPO-CHICHI Elysée Eléna Nathalie (J09261327) par jealexhouegbe — Motif : Erreur de saisie du montant payé	t	2026-10-04 23:36:39.712032+00	{coordonnateur,comptable}
299	1	Suppression définitive : ABOUDOU Enock (J08263316) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-08 21:05:18.002047+00	{coordonnateur,comptable}
300	1	Suppression définitive : AHISSOU Jean Eudes (J09262533) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-08 22:42:03.022836+00	{coordonnateur,comptable}
301	1	Suppression définitive : SIMENOU Jérôme (J10265483) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-08 22:50:29.32281+00	{coordonnateur,comptable}
302	1	Suppression définitive : AGBOGLO Landryne (J08262660) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-09 02:47:51.321478+00	{coordonnateur,comptable}
303	1	Suppression définitive : AGBOGLO Landréa (J08267224) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-09 02:48:15.393884+00	{coordonnateur,comptable}
304	1	Suppression définitive : AMEGAN Eliséi (J08263741) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-09 02:48:31.543393+00	{coordonnateur,comptable}
305	1	Suppression définitive : ADIMOU Julie (J08265985) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-09 05:34:27.479029+00	{coordonnateur,comptable}
306	1	Suppression définitive : ADJAGNISSOUDE Pamella (J08261913) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-09 05:34:43.07877+00	{coordonnateur,comptable}
307	1	Suppression définitive : AHOUANGANON Nadège (J08262897) supprimé(s) par le coordonnateur jealexhouegbe.	f	2026-10-09 05:35:16.421796+00	{coordonnateur,comptable}
\.


--
-- Data for Name: paiements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements (id, eleve_id, mois_souscription, montant_paye, date_paiement, mode_paiement, annee_scolaire_id, enregistre_par) FROM stdin;
1	871	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
2	870	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
3	872	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
4	855	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
5	855	Novembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
6	855	Decembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
7	855	Janvier	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
8	855	Fevrier	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
9	855	Mars	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
10	878	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
11	878	Novembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
12	878	Decembre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
13	737	Octobre	6000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
14	737	Novembre	6000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
15	737	Decembre	6000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
16	51	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
17	51	Novembre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
18	51	Decembre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
19	558	Octobre	1000	2026-09-22	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
20	222	Octobre	2000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
21	71	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
22	884	Octobre	5000	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
23	189	Octobre	2500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
24	318	Octobre	3500	2026-09-19	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
25	914	Octobre	1000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
26	915	Octobre	1000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
27	582	Octobre	2000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
28	606	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
29	946	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
30	419	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
31	419	Novembre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
32	419	Decembre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
33	385	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
34	528	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
35	750	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
36	423	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
37	364	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
38	332	Octobre	5000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
39	888	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
40	896	Octobre	1000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
41	486	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
42	275	Octobre	2000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
43	897	Octobre	1500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
44	72	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
45	72	Novembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
46	72	Decembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
47	72	Janvier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
48	72	Fevrier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
49	72	Mars	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
50	215	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
51	215	Novembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
52	215	Decembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
53	215	Janvier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
54	215	Fevrier	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
55	215	Mars	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
56	11	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
57	11	Novembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
58	11	Decembre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
59	902	Octobre	3500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
60	902	Novembre	3500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
61	902	Decembre	3500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
62	912	Octobre	3000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
63	893	Octobre	1500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
64	37	Octobre	2000	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
65	221	Octobre	2500	2026-09-19	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
66	621	Octobre	3000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
67	621	Novembre	3000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
68	621	Decembre	3000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
69	936	Octobre	2000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
70	936	Novembre	2000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
71	936	Decembre	2000	2026-09-23	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
73	563	Octobre	2000	2026-09-25	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
74	628	Octobre	3000	2026-09-26	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
75	977	Octobre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
76	977	Novembre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
77	977	Decembre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
78	977	Janvier	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
79	977	Fevrier	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
80	977	Mars	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
81	1050	Octobre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
82	328	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
83	1055	Octobre	4000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
86	896	Octobre	500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
87	1012	Octobre	6000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
88	1025	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
89	19	Octobre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
90	202	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
91	1049	Octobre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
92	1049	Novembre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
93	1049	Decembre	2500	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
94	972	Octobre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
95	972	Novembre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
96	972	Decembre	5000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
97	1047	Octobre	4000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
98	895	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
99	915	Octobre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
100	843	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
101	843	Novembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
102	843	Decembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
103	550	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
104	550	Novembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
105	550	Decembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
106	530	Octobre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
107	530	Novembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
108	530	Decembre	2000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
109	588	Octobre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
110	588	Novembre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
111	588	Decembre	3000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
112	943	Octobre	4000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
113	999	Octobre	1000	2026-09-26	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
114	418	Octobre	5000	2026-09-28	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
115	243	Janvier	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
116	243	Fevrier	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
117	243	Mars	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
118	244	Octobre	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
119	244	Novembre	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
120	244	Decembre	3500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
121	848	Octobre	5000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
122	848	Novembre	5000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
123	848	Decembre	5000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
124	53	Octobre	2500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
125	53	Novembre	2500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
126	53	Decembre	2500	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
127	961	Octobre	6000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
128	961	Novembre	6000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
129	961	Decembre	6000	2026-10-02	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
130	558	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
131	295	Octobre	3500	2026-10-01	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
132	847	Octobre	5000	2026-10-01	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
133	841	Octobre	2500	2026-10-01	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
134	177	Octobre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
135	177	Novembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
136	177	Decembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
137	959	Octobre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
138	959	Novembre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
139	959	Decembre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
140	459	Octobre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
141	459	Novembre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
142	459	Decembre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
143	951	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
144	1134	Octobre	3000	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
145	1065	Octobre	3000	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
146	251	Octobre	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
147	251	Novembre	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
148	251	Decembre	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
149	251	Janvier	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
150	251	Fevrier	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
151	251	Mars	3500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
152	156	Octobre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
153	156	Novembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
154	156	Decembre	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
155	156	Fevrier	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
156	156	Mars	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
157	156	Avril	2500	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
158	938	Octobre	3000	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
159	643	Octobre	4000	2026-10-03	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
160	886	Octobre	2500	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
161	379	Octobre	5000	2026-10-04	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
162	1088	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
163	623	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
164	623	Novembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
165	623	Decembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
166	623	Janvier	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
167	623	Fevrier	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
168	623	Mars	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
169	654	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
170	941	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
171	1086	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
172	1100	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
173	1083	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
174	1082	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
175	607	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
176	608	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
177	1092	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
178	594	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
179	604	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
180	604	Novembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
181	604	Decembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
182	605	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
183	605	Novembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
184	605	Decembre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
185	984	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
186	1093	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
187	644	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
188	574	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
189	574	Novembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
190	574	Decembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
191	663	Octobre	4000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
192	626	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
193	631	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
194	949	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
195	1066	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
196	641	Octobre	4000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
197	640	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
198	842	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
199	842	Novembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
200	842	Decembre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
201	1070	Octobre	4000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
202	432	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
203	328	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
204	1072	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
205	1072	Novembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
206	1072	Decembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
207	1060	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
208	1060	Novembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
209	1060	Decembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
210	1108	Octobre	6000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
211	1133	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
212	837	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
213	133	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
214	133	Novembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
215	133	Decembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
216	133	Janvier	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
217	133	Fevrier	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
218	133	Mars	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
219	1114	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
220	1113	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
221	1132	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
222	896	Octobre	500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
223	115	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
224	116	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
225	1120	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
226	873	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
227	873	Novembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
228	873	Decembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
229	190	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
230	1105	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
231	1026	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
232	1026	Novembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
233	1026	Decembre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
234	1004	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
235	1004	Novembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
236	1004	Decembre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
237	1016	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
238	1042	Octobre	3000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
239	1021	Octobre	3500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
240	915	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
241	895	Octobre	500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
242	206	Octobre	2500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
243	966	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
244	967	Octobre	1500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
245	968	Octobre	2000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
246	165	Octobre	1000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
247	846	Octobre	3500	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
248	840	Octobre	2500	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
249	1136	Octobre	2000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
250	1046	Octobre	6000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
251	739	Octobre	3000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
252	615	Octobre	3000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
253	989	Octobre	3000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
254	990	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
255	992	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
256	664	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
257	991	Octobre	2000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
258	996	Octobre	1000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
259	864	Octobre	2000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
260	958	Octobre	4000	2026-10-04	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
261	1057	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
262	1058	Octobre	5000	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
263	1115	Octobre	3500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
264	1115	Novembre	3500	2026-10-03	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
265	203	Octobre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
266	203	Novembre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
267	203	Decembre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
268	876	Octobre	2500	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
269	877	Octobre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
270	729	Octobre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
271	729	Novembre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
272	729	Decembre	5000	2026-10-05	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
273	545	Octobre	2000	2026-10-06	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
274	585	Octobre	3000	2026-10-06	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
275	882	Octobre	2500	2026-10-06	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
276	395	Octobre	5000	2026-10-05	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
277	395	Novembre	5000	2026-10-05	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
278	395	Decembre	5000	2026-10-05	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
279	381	Octobre	5000	2026-10-07	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
280	371	Octobre	5000	2026-10-07	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
281	634	Octobre	4000	2026-10-08	Presentiel	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
282	1007	Octobre	5000	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
283	839	Octobre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
284	839	Novembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
285	839	Decembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
286	100	Octobre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
287	100	Novembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
288	100	Decembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
289	101	Octobre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
290	101	Novembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
291	101	Decembre	2500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
292	1028	Octobre	3500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
293	1028	Novembre	3500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
294	1028	Decembre	3500	2026-10-08	MoMo	1	55899634-2a3d-4d0c-a169-c883ddd3b72f
\.


--
-- Data for Name: paiements_supprimes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements_supprimes (id, matricule, mois_souscription, montant_paye, date_paiement, mode_paiement, admin_id, date_suppression, motif) FROM stdin;
1	J09266010	Octobre	2500	2026-09-26	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:29:11.889364+00	Erreur de saisie du montant normal payé
2	J09261327	Octobre	5000	2026-09-26	Presentiel	55899634-2a3d-4d0c-a169-c883ddd3b72f	2026-10-04 23:36:39.443373+00	Erreur de saisie du montant payé
\.


--
-- Data for Name: penalites_reinscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.penalites_reinscription (id, eleve_id, montant, mode_paiement, date_paiement, enregistre_par, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: presences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.presences (id, eleve_id, date_presence, site_id, classe_id, present, annee_scolaire_id) FROM stdin;
1	556	2026-09-19	2	14	f	1
2	557	2026-09-19	2	14	t	1
3	558	2026-09-19	2	14	t	1
4	559	2026-09-19	2	14	t	1
5	560	2026-09-19	2	14	t	1
6	561	2026-09-19	2	14	f	1
7	562	2026-09-19	2	14	f	1
8	563	2026-09-19	2	14	t	1
9	564	2026-09-19	2	14	t	1
10	565	2026-09-19	2	14	t	1
11	566	2026-09-19	2	14	f	1
12	567	2026-09-19	2	14	t	1
13	568	2026-09-19	2	14	f	1
14	569	2026-09-19	2	14	f	1
15	570	2026-09-19	2	14	f	1
16	571	2026-09-19	2	14	f	1
17	572	2026-09-19	2	14	t	1
18	573	2026-09-19	2	14	t	1
19	574	2026-09-19	2	14	f	1
20	575	2026-09-19	2	14	t	1
21	850	2026-09-19	2	14	t	1
22	576	2026-09-19	2	14	f	1
23	577	2026-09-19	2	14	f	1
24	578	2026-09-19	2	14	f	1
25	579	2026-09-19	2	14	f	1
26	580	2026-09-19	2	14	t	1
27	581	2026-09-19	2	14	f	1
28	582	2026-09-19	2	14	t	1
29	584	2026-09-19	2	15	f	1
30	583	2026-09-19	2	15	f	1
31	585	2026-09-19	2	15	t	1
32	586	2026-09-19	2	15	f	1
33	587	2026-09-19	2	15	t	1
35	589	2026-09-19	2	15	f	1
36	859	2026-09-19	2	15	t	1
37	590	2026-09-19	2	15	t	1
38	591	2026-09-19	2	15	t	1
39	592	2026-09-19	2	15	f	1
40	593	2026-09-19	2	15	f	1
41	594	2026-09-19	2	15	t	1
42	595	2026-09-19	2	15	t	1
43	596	2026-09-19	2	15	f	1
44	597	2026-09-19	2	15	f	1
45	598	2026-09-19	2	15	f	1
46	599	2026-09-19	2	15	f	1
47	601	2026-09-19	2	15	t	1
48	600	2026-09-19	2	15	t	1
49	860	2026-09-19	2	15	f	1
50	602	2026-09-19	2	15	t	1
51	603	2026-09-19	2	15	t	1
52	604	2026-09-19	2	15	t	1
53	605	2026-09-19	2	15	t	1
54	606	2026-09-19	2	15	t	1
55	608	2026-09-19	2	15	t	1
56	607	2026-09-19	2	15	t	1
57	609	2026-09-19	2	15	t	1
58	610	2026-09-19	2	15	t	1
59	611	2026-09-19	2	15	t	1
60	613	2026-09-19	2	15	f	1
61	612	2026-09-19	2	15	f	1
62	861	2026-09-19	2	15	f	1
63	614	2026-09-19	2	15	f	1
64	615	2026-09-19	2	15	t	1
65	616	2026-09-19	2	15	f	1
66	617	2026-09-19	2	15	f	1
67	618	2026-09-19	2	15	t	1
68	862	2026-09-19	2	15	t	1
69	619	2026-09-19	2	15	t	1
70	620	2026-09-19	2	15	t	1
71	621	2026-09-19	2	15	t	1
72	622	2026-09-19	2	15	f	1
73	623	2026-09-19	2	15	t	1
74	624	2026-09-19	2	15	t	1
75	625	2026-09-19	2	15	t	1
76	626	2026-09-19	2	15	t	1
77	627	2026-09-19	2	15	f	1
78	628	2026-09-19	2	15	t	1
79	629	2026-09-19	2	15	f	1
80	630	2026-09-19	2	15	f	1
81	631	2026-09-19	2	15	t	1
82	632	2026-09-19	2	15	f	1
83	633	2026-09-19	2	15	t	1
84	529	2026-09-19	2	13	f	1
85	530	2026-09-19	2	13	f	1
86	843	2026-09-19	2	13	t	1
87	531	2026-09-19	2	13	f	1
88	532	2026-09-19	2	13	f	1
89	533	2026-09-19	2	13	f	1
90	858	2026-09-19	2	13	t	1
91	534	2026-09-19	2	13	f	1
92	535	2026-09-19	2	13	f	1
93	842	2026-09-19	2	13	t	1
94	536	2026-09-19	2	13	f	1
95	537	2026-09-19	2	13	f	1
96	538	2026-09-19	2	13	f	1
97	539	2026-09-19	2	13	f	1
98	540	2026-09-19	2	13	t	1
99	541	2026-09-19	2	13	f	1
100	542	2026-09-19	2	13	f	1
101	543	2026-09-19	2	13	f	1
102	544	2026-09-19	2	13	f	1
103	545	2026-09-19	2	13	f	1
104	546	2026-09-19	2	13	t	1
105	548	2026-09-19	2	13	f	1
106	549	2026-09-19	2	13	f	1
107	547	2026-09-19	2	13	f	1
108	550	2026-09-19	2	13	f	1
109	551	2026-09-19	2	13	t	1
110	552	2026-09-19	2	13	f	1
111	857	2026-09-19	2	13	f	1
112	838	2026-09-19	2	13	f	1
113	553	2026-09-19	2	13	t	1
114	554	2026-09-19	2	13	f	1
115	555	2026-09-19	2	13	t	1
116	634	2026-09-19	2	16	t	1
117	863	2026-09-19	2	16	f	1
118	635	2026-09-19	2	16	f	1
119	637	2026-09-19	2	16	f	1
120	636	2026-09-19	2	16	f	1
121	638	2026-09-19	2	16	f	1
122	639	2026-09-19	2	16	t	1
123	864	2026-09-19	2	16	t	1
124	640	2026-09-19	2	16	f	1
125	641	2026-09-19	2	16	f	1
126	642	2026-09-19	2	16	t	1
127	643	2026-09-19	2	16	f	1
128	644	2026-09-19	2	16	f	1
129	645	2026-09-19	2	16	f	1
130	646	2026-09-19	2	16	f	1
131	865	2026-09-19	2	16	f	1
132	647	2026-09-19	2	16	f	1
133	866	2026-09-19	2	16	t	1
134	648	2026-09-19	2	16	t	1
135	867	2026-09-19	2	16	t	1
136	649	2026-09-19	2	16	t	1
137	650	2026-09-19	2	16	t	1
138	651	2026-09-19	2	16	t	1
139	652	2026-09-19	2	16	f	1
140	653	2026-09-19	2	16	f	1
141	868	2026-09-19	2	16	f	1
142	654	2026-09-19	2	16	t	1
143	655	2026-09-19	2	16	t	1
144	656	2026-09-19	2	16	t	1
145	657	2026-09-19	2	16	f	1
146	658	2026-09-19	2	16	t	1
147	659	2026-09-19	2	16	f	1
148	869	2026-09-19	2	16	f	1
149	660	2026-09-19	2	16	t	1
150	661	2026-09-19	2	16	f	1
151	662	2026-09-19	2	16	f	1
152	663	2026-09-19	2	16	f	1
153	664	2026-09-19	2	16	t	1
154	665	2026-09-19	2	16	f	1
155	666	2026-09-19	2	16	f	1
156	3	2026-09-19	1	1	f	1
157	39	2026-09-19	1	1	f	1
158	40	2026-09-19	1	1	f	1
159	41	2026-09-19	1	1	t	1
160	42	2026-09-19	1	1	t	1
161	4	2026-09-19	1	1	f	1
162	43	2026-09-19	1	1	t	1
163	5	2026-09-19	1	1	f	1
164	6	2026-09-19	1	1	f	1
165	44	2026-09-19	1	1	f	1
166	45	2026-09-19	1	1	f	1
167	46	2026-09-19	1	1	f	1
168	7	2026-09-19	1	1	t	1
169	48	2026-09-19	1	1	t	1
170	47	2026-09-19	1	1	f	1
171	8	2026-09-19	1	1	t	1
172	49	2026-09-19	1	1	t	1
173	50	2026-09-19	1	1	f	1
174	51	2026-09-19	1	1	t	1
175	9	2026-09-19	1	1	f	1
176	10	2026-09-19	1	1	t	1
177	52	2026-09-19	1	1	t	1
178	11	2026-09-19	1	1	t	1
179	53	2026-09-19	1	1	t	1
180	54	2026-09-19	1	1	f	1
181	55	2026-09-19	1	1	t	1
182	12	2026-09-19	1	1	t	1
183	13	2026-09-19	1	1	f	1
184	14	2026-09-19	1	1	f	1
185	15	2026-09-19	1	1	f	1
186	56	2026-09-19	1	1	f	1
187	57	2026-09-19	1	1	f	1
188	16	2026-09-19	1	1	t	1
189	58	2026-09-19	1	1	t	1
190	17	2026-09-19	1	1	f	1
191	18	2026-09-19	1	1	f	1
192	59	2026-09-19	1	1	f	1
193	60	2026-09-19	1	1	f	1
194	19	2026-09-19	1	1	f	1
195	20	2026-09-19	1	1	t	1
196	21	2026-09-19	1	1	t	1
197	61	2026-09-19	1	1	f	1
198	69	2026-09-19	1	1	t	1
199	22	2026-09-19	1	1	f	1
200	24	2026-09-19	1	1	f	1
201	23	2026-09-19	1	1	f	1
202	62	2026-09-19	1	1	t	1
203	63	2026-09-19	1	1	f	1
204	25	2026-09-19	1	1	f	1
205	64	2026-09-19	1	1	t	1
206	66	2026-09-19	1	1	f	1
207	65	2026-09-19	1	1	f	1
208	26	2026-09-19	1	1	t	1
209	67	2026-09-19	1	1	f	1
210	27	2026-09-19	1	1	f	1
211	68	2026-09-19	1	1	t	1
212	28	2026-09-19	1	1	f	1
213	70	2026-09-19	1	1	f	1
214	71	2026-09-19	1	1	t	1
215	72	2026-09-19	1	1	t	1
216	29	2026-09-19	1	1	t	1
217	73	2026-09-19	1	1	f	1
218	30	2026-09-19	1	1	t	1
219	77	2026-09-19	1	1	t	1
220	74	2026-09-19	1	1	f	1
221	76	2026-09-19	1	1	f	1
222	75	2026-09-19	1	1	f	1
223	78	2026-09-19	1	1	t	1
224	31	2026-09-19	1	1	f	1
225	79	2026-09-19	1	1	f	1
226	80	2026-09-19	1	1	f	1
227	81	2026-09-19	1	1	t	1
228	32	2026-09-19	1	1	f	1
229	82	2026-09-19	1	1	f	1
230	83	2026-09-19	1	1	f	1
231	84	2026-09-19	1	1	t	1
232	33	2026-09-19	1	1	f	1
233	873	2026-09-19	1	1	t	1
234	34	2026-09-19	1	1	f	1
235	35	2026-09-19	1	1	f	1
236	36	2026-09-19	1	1	f	1
237	37	2026-09-19	1	1	t	1
238	38	2026-09-19	1	1	f	1
34	588	2026-09-19	2	15	t	1
240	90	2026-09-19	1	20	f	1
241	91	2026-09-19	1	20	f	1
242	92	2026-09-19	1	20	f	1
243	671	2026-09-19	1	20	f	1
244	93	2026-09-19	1	20	f	1
245	94	2026-09-19	1	20	f	1
246	95	2026-09-19	1	20	t	1
247	96	2026-09-19	1	20	t	1
248	839	2026-09-19	1	20	t	1
249	97	2026-09-19	1	20	t	1
250	841	2026-09-19	1	20	f	1
251	98	2026-09-19	1	20	f	1
252	667	2026-09-19	1	20	f	1
253	668	2026-09-19	1	20	f	1
254	669	2026-09-19	1	20	f	1
255	99	2026-09-19	1	20	f	1
256	100	2026-09-19	1	20	f	1
257	101	2026-09-19	1	20	f	1
258	670	2026-09-19	1	20	f	1
259	102	2026-09-19	1	20	t	1
260	103	2026-09-19	1	20	f	1
261	85	2026-09-19	1	20	t	1
262	672	2026-09-19	1	20	t	1
263	104	2026-09-19	1	20	f	1
264	105	2026-09-19	1	20	t	1
265	106	2026-09-19	1	20	f	1
266	107	2026-09-19	1	20	f	1
267	673	2026-09-19	1	20	f	1
268	108	2026-09-19	1	20	f	1
269	86	2026-09-19	1	20	f	1
270	844	2026-09-19	1	20	t	1
271	110	2026-09-19	1	20	f	1
272	109	2026-09-19	1	20	f	1
273	111	2026-09-19	1	20	t	1
274	112	2026-09-19	1	20	f	1
275	113	2026-09-19	1	20	t	1
276	114	2026-09-19	1	20	f	1
277	876	2026-09-19	1	20	t	1
278	115	2026-09-19	1	20	t	1
279	116	2026-09-19	1	20	t	1
280	882	2026-09-19	1	20	t	1
281	117	2026-09-19	1	20	f	1
282	674	2026-09-19	1	20	f	1
283	118	2026-09-19	1	20	f	1
284	119	2026-09-19	1	20	f	1
285	120	2026-09-19	1	20	f	1
286	675	2026-09-19	1	20	f	1
287	121	2026-09-19	1	20	f	1
288	676	2026-09-19	1	20	f	1
289	87	2026-09-19	1	20	t	1
290	122	2026-09-19	1	20	f	1
291	123	2026-09-19	1	20	f	1
292	677	2026-09-19	1	20	f	1
293	124	2026-09-19	1	20	f	1
294	125	2026-09-19	1	20	t	1
295	126	2026-09-19	1	20	t	1
296	127	2026-09-19	1	20	t	1
297	128	2026-09-19	1	20	t	1
298	129	2026-09-19	1	20	f	1
299	130	2026-09-19	1	20	f	1
300	820	2026-09-19	1	20	t	1
301	131	2026-09-19	1	20	f	1
302	132	2026-09-19	1	20	f	1
303	133	2026-09-19	1	20	f	1
304	134	2026-09-19	1	20	f	1
305	88	2026-09-19	1	20	f	1
306	135	2026-09-19	1	20	t	1
307	136	2026-09-19	1	20	f	1
308	678	2026-09-19	1	20	f	1
309	137	2026-09-19	1	20	t	1
310	138	2026-09-19	1	20	f	1
311	89	2026-09-19	1	20	f	1
312	679	2026-09-19	1	20	f	1
313	840	2026-09-19	1	20	t	1
314	139	2026-09-19	1	20	t	1
315	140	2026-09-19	1	20	f	1
316	141	2026-09-19	1	20	t	1
317	837	2026-09-19	1	20	t	1
318	680	2026-09-19	1	20	f	1
319	681	2026-09-19	1	20	f	1
320	682	2026-09-19	1	20	f	1
321	805	2026-09-19	1	20	f	1
322	142	2026-09-19	1	20	t	1
323	143	2026-09-19	1	20	f	1
324	144	2026-09-19	1	20	f	1
325	683	2026-09-19	1	20	f	1
326	145	2026-09-19	1	20	f	1
327	885	2026-09-19	1	2	t	1
328	146	2026-09-19	1	2	f	1
329	147	2026-09-19	1	2	f	1
330	148	2026-09-19	1	2	t	1
331	149	2026-09-19	1	2	f	1
332	150	2026-09-19	1	2	t	1
333	151	2026-09-19	1	2	f	1
334	152	2026-09-19	1	2	f	1
335	153	2026-09-19	1	2	t	1
336	154	2026-09-19	1	2	f	1
337	155	2026-09-19	1	2	f	1
338	156	2026-09-19	1	2	f	1
339	684	2026-09-19	1	2	f	1
340	157	2026-09-19	1	2	t	1
341	158	2026-09-19	1	2	f	1
342	159	2026-09-19	1	2	f	1
343	160	2026-09-19	1	2	f	1
344	161	2026-09-19	1	2	f	1
345	162	2026-09-19	1	2	t	1
346	872	2026-09-19	1	2	t	1
347	163	2026-09-19	1	2	f	1
348	685	2026-09-19	1	2	f	1
349	164	2026-09-19	1	2	t	1
350	165	2026-09-19	1	2	f	1
351	166	2026-09-19	1	2	t	1
352	167	2026-09-19	1	2	t	1
353	168	2026-09-19	1	2	f	1
354	169	2026-09-19	1	2	f	1
355	170	2026-09-19	1	2	f	1
356	171	2026-09-19	1	2	f	1
357	172	2026-09-19	1	2	f	1
358	173	2026-09-19	1	2	f	1
359	174	2026-09-19	1	2	f	1
360	175	2026-09-19	1	2	f	1
361	176	2026-09-19	1	2	f	1
362	177	2026-09-19	1	2	t	1
363	178	2026-09-19	1	2	t	1
364	179	2026-09-19	1	2	f	1
365	180	2026-09-19	1	2	f	1
366	181	2026-09-19	1	2	f	1
367	182	2026-09-19	1	2	f	1
368	183	2026-09-19	1	2	f	1
369	184	2026-09-19	1	2	t	1
370	185	2026-09-19	1	2	f	1
371	186	2026-09-19	1	2	f	1
372	686	2026-09-19	1	2	f	1
373	187	2026-09-19	1	2	f	1
374	188	2026-09-19	1	2	t	1
375	189	2026-09-19	1	2	t	1
376	283	2026-09-19	1	18	f	1
377	284	2026-09-19	1	18	t	1
378	285	2026-09-19	1	18	f	1
379	305	2026-09-19	1	18	f	1
380	306	2026-09-19	1	18	f	1
381	286	2026-09-19	1	18	t	1
382	287	2026-09-19	1	18	f	1
383	288	2026-09-19	1	18	t	1
384	289	2026-09-19	1	18	f	1
385	290	2026-09-19	1	18	f	1
386	698	2026-09-19	1	18	t	1
387	307	2026-09-19	1	18	t	1
388	308	2026-09-19	1	18	f	1
389	309	2026-09-19	1	18	f	1
390	699	2026-09-19	1	18	f	1
391	291	2026-09-19	1	18	f	1
392	292	2026-09-19	1	18	f	1
393	293	2026-09-19	1	18	t	1
394	310	2026-09-19	1	18	f	1
395	311	2026-09-19	1	18	f	1
396	312	2026-09-19	1	18	t	1
397	700	2026-09-19	1	18	f	1
398	294	2026-09-19	1	18	t	1
399	295	2026-09-19	1	18	f	1
400	701	2026-09-19	1	18	f	1
401	313	2026-09-19	1	18	t	1
402	296	2026-09-19	1	18	f	1
403	314	2026-09-19	1	18	t	1
404	297	2026-09-19	1	18	f	1
405	298	2026-09-19	1	18	f	1
406	299	2026-09-19	1	18	f	1
407	315	2026-09-19	1	18	f	1
408	316	2026-09-19	1	18	f	1
409	702	2026-09-19	1	18	f	1
410	300	2026-09-19	1	18	t	1
411	301	2026-09-19	1	18	f	1
412	302	2026-09-19	1	18	t	1
413	303	2026-09-19	1	18	f	1
414	304	2026-09-19	1	18	f	1
415	317	2026-09-19	1	18	t	1
416	874	2026-09-19	1	18	t	1
417	318	2026-09-19	1	18	t	1
418	319	2026-09-19	1	18	f	1
420	235	2026-09-19	1	3	f	1
421	255	2026-09-19	1	3	f	1
422	236	2026-09-19	1	3	f	1
423	256	2026-09-19	1	3	f	1
424	237	2026-09-19	1	3	f	1
425	692	2026-09-19	1	3	f	1
426	257	2026-09-19	1	3	t	1
427	238	2026-09-19	1	3	t	1
428	239	2026-09-19	1	3	f	1
429	258	2026-09-19	1	3	f	1
430	240	2026-09-19	1	3	f	1
431	696	2026-09-19	1	3	f	1
432	241	2026-09-19	1	3	t	1
433	242	2026-09-19	1	3	t	1
434	693	2026-09-19	1	3	f	1
435	244	2026-09-19	1	3	t	1
436	243	2026-09-19	1	3	t	1
437	245	2026-09-19	1	3	f	1
438	246	2026-09-19	1	3	f	1
439	247	2026-09-19	1	3	t	1
440	249	2026-09-19	1	3	f	1
441	248	2026-09-19	1	3	f	1
443	259	2026-09-19	1	3	f	1
444	250	2026-09-19	1	3	f	1
445	260	2026-09-19	1	3	f	1
446	261	2026-09-19	1	3	f	1
447	262	2026-09-19	1	3	f	1
448	263	2026-09-19	1	3	t	1
449	251	2026-09-19	1	3	t	1
450	694	2026-09-19	1	3	f	1
451	264	2026-09-19	1	3	t	1
452	266	2026-09-19	1	3	f	1
453	265	2026-09-19	1	3	f	1
454	267	2026-09-19	1	3	f	1
455	695	2026-09-19	1	3	f	1
456	268	2026-09-19	1	3	f	1
457	269	2026-09-19	1	3	f	1
458	252	2026-09-19	1	3	t	1
459	270	2026-09-19	1	3	t	1
460	253	2026-09-19	1	3	f	1
461	271	2026-09-19	1	3	f	1
462	849	2026-09-19	1	3	t	1
463	273	2026-09-19	1	3	f	1
464	272	2026-09-19	1	3	t	1
465	274	2026-09-19	1	3	f	1
466	846	2026-09-19	1	3	t	1
467	697	2026-09-19	1	3	f	1
468	275	2026-09-19	1	3	t	1
469	276	2026-09-19	1	3	f	1
470	277	2026-09-19	1	3	f	1
471	278	2026-09-19	1	3	f	1
472	279	2026-09-19	1	3	f	1
473	280	2026-09-19	1	3	f	1
474	254	2026-09-19	1	3	f	1
475	281	2026-09-19	1	3	f	1
476	282	2026-09-19	1	3	f	1
477	190	2026-09-19	1	19	f	1
478	191	2026-09-19	1	19	f	1
479	192	2026-09-19	1	19	f	1
480	193	2026-09-19	1	19	t	1
481	194	2026-09-19	1	19	f	1
482	195	2026-09-19	1	19	f	1
483	196	2026-09-19	1	19	f	1
484	197	2026-09-19	1	19	f	1
485	198	2026-09-19	1	19	t	1
486	199	2026-09-19	1	19	f	1
487	690	2026-09-19	1	19	f	1
488	200	2026-09-19	1	19	t	1
489	689	2026-09-19	1	19	t	1
490	202	2026-09-19	1	19	f	1
491	201	2026-09-19	1	19	t	1
492	203	2026-09-19	1	19	t	1
493	204	2026-09-19	1	19	f	1
494	205	2026-09-19	1	19	f	1
495	206	2026-09-19	1	19	t	1
496	207	2026-09-19	1	19	f	1
497	208	2026-09-19	1	19	f	1
498	209	2026-09-19	1	19	t	1
499	210	2026-09-19	1	19	f	1
500	211	2026-09-19	1	19	f	1
501	212	2026-09-19	1	19	f	1
502	688	2026-09-19	1	19	f	1
503	213	2026-09-19	1	19	f	1
504	214	2026-09-19	1	19	f	1
505	691	2026-09-19	1	19	f	1
506	215	2026-09-19	1	19	t	1
507	216	2026-09-19	1	19	f	1
508	217	2026-09-19	1	19	f	1
509	218	2026-09-19	1	19	f	1
510	220	2026-09-19	1	19	f	1
511	219	2026-09-19	1	19	f	1
512	221	2026-09-19	1	19	t	1
513	687	2026-09-19	1	19	t	1
514	222	2026-09-19	1	19	t	1
515	223	2026-09-19	1	19	f	1
516	224	2026-09-19	1	19	f	1
517	225	2026-09-19	1	19	f	1
518	226	2026-09-19	1	19	t	1
519	227	2026-09-19	1	19	t	1
520	228	2026-09-19	1	19	f	1
521	229	2026-09-19	1	19	f	1
522	230	2026-09-19	1	19	f	1
523	231	2026-09-19	1	19	t	1
524	232	2026-09-19	1	19	f	1
525	233	2026-09-19	1	19	f	1
526	447	2026-09-19	1	24	t	1
527	448	2026-09-19	1	24	f	1
528	449	2026-09-19	1	24	t	1
529	450	2026-09-19	1	24	f	1
530	451	2026-09-19	1	24	f	1
531	452	2026-09-19	1	24	t	1
532	453	2026-09-19	1	24	f	1
533	454	2026-09-19	1	24	f	1
534	455	2026-09-19	1	24	f	1
535	456	2026-09-19	1	24	t	1
536	457	2026-09-19	1	24	t	1
537	458	2026-09-19	1	24	t	1
538	459	2026-09-19	1	8	f	1
541	462	2026-09-19	1	8	f	1
542	732	2026-09-19	1	8	t	1
543	733	2026-09-19	1	8	t	1
544	463	2026-09-19	1	8	f	1
545	464	2026-09-19	1	8	t	1
547	734	2026-09-19	1	8	f	1
548	466	2026-09-19	1	8	f	1
549	467	2026-09-19	1	8	t	1
550	468	2026-09-19	1	8	f	1
551	845	2026-09-19	1	8	t	1
552	735	2026-09-19	1	8	f	1
553	736	2026-09-19	1	8	f	1
554	875	2026-09-19	1	8	t	1
555	469	2026-09-19	1	8	t	1
556	737	2026-09-19	1	8	t	1
557	471	2026-09-19	1	8	f	1
558	472	2026-09-19	1	8	f	1
559	852	2026-09-19	1	8	t	1
560	473	2026-09-19	1	8	f	1
561	474	2026-09-19	1	8	t	1
562	475	2026-09-19	1	8	f	1
563	477	2026-09-19	1	8	t	1
564	476	2026-09-19	1	8	t	1
565	478	2026-09-19	1	8	t	1
566	479	2026-09-19	1	8	f	1
567	738	2026-09-19	1	8	f	1
568	480	2026-09-19	1	8	f	1
569	481	2026-09-19	1	8	f	1
570	739	2026-09-19	1	8	t	1
571	740	2026-09-19	1	8	f	1
572	741	2026-09-19	1	8	f	1
573	742	2026-09-19	1	8	f	1
574	853	2026-09-19	1	8	t	1
575	482	2026-09-19	1	8	t	1
576	483	2026-09-19	1	8	f	1
577	484	2026-09-19	1	8	f	1
578	485	2026-09-19	1	8	t	1
579	486	2026-09-19	1	8	t	1
580	487	2026-09-19	1	8	t	1
581	881	2026-09-19	1	8	t	1
582	488	2026-09-19	1	8	f	1
583	489	2026-09-19	1	8	f	1
584	743	2026-09-19	1	8	f	1
585	556	2026-09-26	2	14	f	1
586	557	2026-09-26	2	14	t	1
587	558	2026-09-26	2	14	t	1
588	559	2026-09-26	2	14	t	1
589	560	2026-09-26	2	14	t	1
590	561	2026-09-26	2	14	f	1
591	562	2026-09-26	2	14	f	1
592	947	2026-09-26	2	14	t	1
593	563	2026-09-26	2	14	f	1
594	564	2026-09-26	2	14	t	1
595	565	2026-09-26	2	14	t	1
596	566	2026-09-26	2	14	f	1
597	567	2026-09-26	2	14	t	1
598	568	2026-09-26	2	14	t	1
599	569	2026-09-26	2	14	f	1
600	570	2026-09-26	2	14	t	1
601	571	2026-09-26	2	14	f	1
602	572	2026-09-26	2	14	t	1
603	573	2026-09-26	2	14	t	1
604	948	2026-09-26	2	14	f	1
605	575	2026-09-26	2	14	t	1
606	850	2026-09-26	2	14	t	1
607	576	2026-09-26	2	14	f	1
608	577	2026-09-26	2	14	f	1
609	578	2026-09-26	2	14	f	1
610	579	2026-09-26	2	14	f	1
611	581	2026-09-26	2	14	t	1
612	580	2026-09-26	2	14	t	1
613	582	2026-09-26	2	14	t	1
614	583	2026-09-26	2	15	f	1
615	584	2026-09-26	2	15	f	1
616	585	2026-09-26	2	15	t	1
617	586	2026-09-26	2	15	t	1
618	949	2026-09-26	2	15	t	1
619	588	2026-09-26	2	15	t	1
620	587	2026-09-26	2	15	t	1
621	589	2026-09-26	2	15	t	1
622	859	2026-09-26	2	15	t	1
623	590	2026-09-26	2	15	t	1
624	591	2026-09-26	2	15	t	1
625	593	2026-09-26	2	15	t	1
626	592	2026-09-26	2	15	f	1
627	946	2026-09-26	2	15	t	1
628	594	2026-09-26	2	15	t	1
629	595	2026-09-26	2	15	t	1
630	596	2026-09-26	2	15	t	1
631	598	2026-09-26	2	15	f	1
632	597	2026-09-26	2	15	t	1
633	945	2026-09-26	2	15	f	1
634	599	2026-09-26	2	15	f	1
635	600	2026-09-26	2	15	t	1
636	601	2026-09-26	2	15	t	1
637	860	2026-09-26	2	15	f	1
638	602	2026-09-26	2	15	t	1
639	603	2026-09-26	2	15	t	1
640	605	2026-09-26	2	15	t	1
641	604	2026-09-26	2	15	t	1
642	606	2026-09-26	2	15	t	1
643	608	2026-09-26	2	15	t	1
644	607	2026-09-26	2	15	t	1
645	609	2026-09-26	2	15	f	1
646	610	2026-09-26	2	15	t	1
647	611	2026-09-26	2	15	t	1
648	613	2026-09-26	2	15	f	1
649	612	2026-09-26	2	15	f	1
650	861	2026-09-26	2	15	f	1
651	614	2026-09-26	2	15	f	1
652	615	2026-09-26	2	15	t	1
653	616	2026-09-26	2	15	f	1
654	617	2026-09-26	2	15	f	1
655	618	2026-09-26	2	15	t	1
656	619	2026-09-26	2	15	t	1
657	862	2026-09-26	2	15	t	1
658	620	2026-09-26	2	15	t	1
659	940	2026-09-26	2	15	t	1
660	621	2026-09-26	2	15	t	1
661	937	2026-09-26	2	15	t	1
662	622	2026-09-26	2	15	t	1
663	623	2026-09-26	2	15	t	1
664	624	2026-09-26	2	15	t	1
665	625	2026-09-26	2	15	t	1
666	626	2026-09-26	2	15	t	1
667	627	2026-09-26	2	15	t	1
668	628	2026-09-26	2	15	t	1
669	629	2026-09-26	2	15	f	1
670	630	2026-09-26	2	15	f	1
671	631	2026-09-26	2	15	t	1
672	938	2026-09-26	2	15	t	1
673	632	2026-09-26	2	15	f	1
674	633	2026-09-26	2	15	t	1
675	529	2026-09-26	2	13	f	1
676	530	2026-09-26	2	13	t	1
677	531	2026-09-26	2	13	f	1
678	843	2026-09-26	2	13	t	1
679	532	2026-09-26	2	13	f	1
680	533	2026-09-26	2	13	f	1
681	858	2026-09-26	2	13	t	1
682	534	2026-09-26	2	13	t	1
683	535	2026-09-26	2	13	f	1
684	957	2026-09-26	2	13	f	1
685	842	2026-09-26	2	13	t	1
686	536	2026-09-26	2	13	f	1
687	537	2026-09-26	2	13	f	1
688	538	2026-09-26	2	13	f	1
689	539	2026-09-26	2	13	t	1
690	540	2026-09-26	2	13	t	1
691	541	2026-09-26	2	13	f	1
692	542	2026-09-26	2	13	f	1
693	543	2026-09-26	2	13	f	1
694	544	2026-09-26	2	13	f	1
695	545	2026-09-26	2	13	t	1
696	546	2026-09-26	2	13	t	1
697	935	2026-09-26	2	13	t	1
698	547	2026-09-26	2	13	f	1
699	548	2026-09-26	2	13	f	1
700	549	2026-09-26	2	13	t	1
701	574	2026-09-26	2	13	t	1
702	550	2026-09-26	2	13	t	1
703	963	2026-09-26	2	13	t	1
704	936	2026-09-26	2	13	t	1
705	551	2026-09-26	2	13	f	1
706	552	2026-09-26	2	13	f	1
707	857	2026-09-26	2	13	f	1
708	838	2026-09-26	2	13	t	1
709	553	2026-09-26	2	13	t	1
710	554	2026-09-26	2	13	f	1
711	555	2026-09-26	2	13	f	1
712	634	2026-09-26	2	16	t	1
713	863	2026-09-26	2	16	f	1
714	635	2026-09-26	2	16	f	1
715	636	2026-09-26	2	16	t	1
716	637	2026-09-26	2	16	f	1
717	933	2026-09-26	2	16	t	1
718	638	2026-09-26	2	16	f	1
719	639	2026-09-26	2	16	t	1
720	864	2026-09-26	2	16	t	1
721	640	2026-09-26	2	16	t	1
722	641	2026-09-26	2	16	t	1
723	939	2026-09-26	2	16	t	1
724	642	2026-09-26	2	16	t	1
725	643	2026-09-26	2	16	t	1
726	944	2026-09-26	2	16	f	1
727	941	2026-09-26	2	16	t	1
728	644	2026-09-26	2	16	f	1
729	645	2026-09-26	2	16	f	1
730	646	2026-09-26	2	16	f	1
731	865	2026-09-26	2	16	f	1
732	647	2026-09-26	2	16	f	1
733	866	2026-09-26	2	16	t	1
734	648	2026-09-26	2	16	t	1
735	867	2026-09-26	2	16	f	1
736	958	2026-09-26	2	16	t	1
737	649	2026-09-26	2	16	t	1
738	650	2026-09-26	2	16	t	1
739	651	2026-09-26	2	16	t	1
740	942	2026-09-26	2	16	t	1
741	652	2026-09-26	2	16	f	1
742	653	2026-09-26	2	16	t	1
743	868	2026-09-26	2	16	f	1
744	654	2026-09-26	2	16	f	1
745	655	2026-09-26	2	16	t	1
746	656	2026-09-26	2	16	t	1
747	657	2026-09-26	2	16	f	1
748	658	2026-09-26	2	16	t	1
749	943	2026-09-26	2	16	t	1
750	659	2026-09-26	2	16	f	1
751	869	2026-09-26	2	16	f	1
752	660	2026-09-26	2	16	t	1
753	934	2026-09-26	2	16	t	1
754	661	2026-09-26	2	16	f	1
755	662	2026-09-26	2	16	t	1
756	663	2026-09-26	2	16	f	1
757	664	2026-09-26	2	16	t	1
758	665	2026-09-26	2	16	f	1
759	666	2026-09-26	2	16	f	1
760	3	2026-09-26	1	1	f	1
761	39	2026-09-26	1	1	f	1
762	40	2026-09-26	1	1	f	1
763	41	2026-09-26	1	1	t	1
764	42	2026-09-26	1	1	t	1
765	4	2026-09-26	1	1	f	1
766	43	2026-09-26	1	1	t	1
767	5	2026-09-26	1	1	f	1
768	6	2026-09-26	1	1	f	1
769	44	2026-09-26	1	1	f	1
770	45	2026-09-26	1	1	f	1
771	46	2026-09-26	1	1	f	1
772	7	2026-09-26	1	1	t	1
773	48	2026-09-26	1	1	t	1
774	47	2026-09-26	1	1	f	1
775	8	2026-09-26	1	1	t	1
776	887	2026-09-26	1	1	t	1
777	49	2026-09-26	1	1	t	1
778	50	2026-09-26	1	1	f	1
779	51	2026-09-26	1	1	t	1
780	888	2026-09-26	1	1	t	1
781	9	2026-09-26	1	1	f	1
782	10	2026-09-26	1	1	t	1
783	52	2026-09-26	1	1	t	1
784	11	2026-09-26	1	1	t	1
785	53	2026-09-26	1	1	t	1
786	54	2026-09-26	1	1	f	1
787	55	2026-09-26	1	1	t	1
788	12	2026-09-26	1	1	t	1
789	13	2026-09-26	1	1	f	1
790	14	2026-09-26	1	1	f	1
791	15	2026-09-26	1	1	f	1
792	56	2026-09-26	1	1	t	1
793	57	2026-09-26	1	1	f	1
794	969	2026-09-26	1	1	t	1
795	16	2026-09-26	1	1	t	1
796	58	2026-09-26	1	1	t	1
797	17	2026-09-26	1	1	f	1
798	762	2026-09-26	1	1	t	1
799	18	2026-09-26	1	1	f	1
800	59	2026-09-26	1	1	f	1
801	60	2026-09-26	1	1	f	1
802	19	2026-09-26	1	1	f	1
803	20	2026-09-26	1	1	f	1
804	21	2026-09-26	1	1	t	1
805	61	2026-09-26	1	1	f	1
806	69	2026-09-26	1	1	t	1
807	22	2026-09-26	1	1	f	1
808	24	2026-09-26	1	1	f	1
809	23	2026-09-26	1	1	f	1
810	62	2026-09-26	1	1	f	1
811	63	2026-09-26	1	1	f	1
812	959	2026-09-26	1	1	t	1
813	25	2026-09-26	1	1	f	1
814	64	2026-09-26	1	1	t	1
815	66	2026-09-26	1	1	t	1
816	65	2026-09-26	1	1	f	1
817	27	2026-09-26	1	1	f	1
818	67	2026-09-26	1	1	f	1
819	26	2026-09-26	1	1	f	1
820	68	2026-09-26	1	1	t	1
821	28	2026-09-26	1	1	f	1
822	70	2026-09-26	1	1	f	1
823	71	2026-09-26	1	1	t	1
824	72	2026-09-26	1	1	t	1
825	29	2026-09-26	1	1	t	1
826	73	2026-09-26	1	1	f	1
827	30	2026-09-26	1	1	t	1
828	77	2026-09-26	1	1	t	1
829	74	2026-09-26	1	1	f	1
830	75	2026-09-26	1	1	f	1
831	76	2026-09-26	1	1	f	1
832	78	2026-09-26	1	1	f	1
833	31	2026-09-26	1	1	f	1
834	79	2026-09-26	1	1	f	1
835	80	2026-09-26	1	1	f	1
836	81	2026-09-26	1	1	t	1
837	886	2026-09-26	1	1	t	1
838	32	2026-09-26	1	1	f	1
839	82	2026-09-26	1	1	f	1
840	83	2026-09-26	1	1	f	1
841	84	2026-09-26	1	1	t	1
842	33	2026-09-26	1	1	f	1
844	34	2026-09-26	1	1	t	1
845	35	2026-09-26	1	1	f	1
846	36	2026-09-26	1	1	f	1
847	37	2026-09-26	1	1	t	1
848	38	2026-09-26	1	1	f	1
849	90	2026-09-26	1	20	f	1
850	91	2026-09-26	1	20	f	1
851	92	2026-09-26	1	20	f	1
852	892	2026-09-26	1	20	t	1
853	671	2026-09-26	1	20	f	1
854	93	2026-09-26	1	20	f	1
855	94	2026-09-26	1	20	f	1
856	95	2026-09-26	1	20	t	1
857	96	2026-09-26	1	20	t	1
858	839	2026-09-26	1	20	t	1
859	97	2026-09-26	1	20	t	1
860	841	2026-09-26	1	20	t	1
861	98	2026-09-26	1	20	t	1
862	668	2026-09-26	1	20	f	1
863	667	2026-09-26	1	20	f	1
865	808	2026-09-26	1	20	f	1
866	669	2026-09-26	1	20	f	1
867	99	2026-09-26	1	20	f	1
868	100	2026-09-26	1	20	t	1
869	101	2026-09-26	1	20	t	1
870	670	2026-09-26	1	20	f	1
871	102	2026-09-26	1	20	f	1
872	103	2026-09-26	1	20	t	1
873	85	2026-09-26	1	20	f	1
874	672	2026-09-26	1	20	f	1
875	104	2026-09-26	1	20	f	1
876	105	2026-09-26	1	20	f	1
877	106	2026-09-26	1	20	f	1
878	107	2026-09-26	1	20	f	1
879	673	2026-09-26	1	20	f	1
880	108	2026-09-26	1	20	f	1
881	86	2026-09-26	1	20	f	1
882	844	2026-09-26	1	20	t	1
883	110	2026-09-26	1	20	f	1
884	109	2026-09-26	1	20	f	1
885	111	2026-09-26	1	20	t	1
886	112	2026-09-26	1	20	f	1
887	113	2026-09-26	1	20	t	1
888	114	2026-09-26	1	20	f	1
889	876	2026-09-26	1	20	t	1
890	116	2026-09-26	1	20	t	1
891	115	2026-09-26	1	20	t	1
892	882	2026-09-26	1	20	t	1
893	117	2026-09-26	1	20	f	1
894	674	2026-09-26	1	20	f	1
895	118	2026-09-26	1	20	f	1
896	119	2026-09-26	1	20	f	1
897	120	2026-09-26	1	20	f	1
898	675	2026-09-26	1	20	f	1
899	121	2026-09-26	1	20	f	1
900	676	2026-09-26	1	20	f	1
901	87	2026-09-26	1	20	t	1
902	122	2026-09-26	1	20	f	1
903	123	2026-09-26	1	20	f	1
904	677	2026-09-26	1	20	f	1
905	124	2026-09-26	1	20	f	1
906	890	2026-09-26	1	20	t	1
907	891	2026-09-26	1	20	t	1
908	125	2026-09-26	1	20	t	1
909	126	2026-09-26	1	20	t	1
910	127	2026-09-26	1	20	t	1
911	128	2026-09-26	1	20	t	1
912	129	2026-09-26	1	20	f	1
913	130	2026-09-26	1	20	f	1
914	820	2026-09-26	1	20	t	1
915	131	2026-09-26	1	20	f	1
916	132	2026-09-26	1	20	f	1
917	133	2026-09-26	1	20	f	1
918	134	2026-09-26	1	20	f	1
919	88	2026-09-26	1	20	f	1
920	135	2026-09-26	1	20	t	1
921	136	2026-09-26	1	20	f	1
922	678	2026-09-26	1	20	f	1
923	137	2026-09-26	1	20	t	1
924	138	2026-09-26	1	20	f	1
925	89	2026-09-26	1	20	f	1
926	840	2026-09-26	1	20	t	1
927	679	2026-09-26	1	20	f	1
928	139	2026-09-26	1	20	f	1
929	140	2026-09-26	1	20	f	1
930	141	2026-09-26	1	20	t	1
931	837	2026-09-26	1	20	t	1
932	680	2026-09-26	1	20	f	1
933	681	2026-09-26	1	20	f	1
934	682	2026-09-26	1	20	t	1
935	805	2026-09-26	1	20	f	1
936	142	2026-09-26	1	20	t	1
937	143	2026-09-26	1	20	f	1
938	893	2026-09-26	1	20	t	1
939	144	2026-09-26	1	20	f	1
940	683	2026-09-26	1	20	f	1
941	889	2026-09-26	1	20	t	1
942	145	2026-09-26	1	20	f	1
943	970	2026-09-26	1	20	t	1
843	873	2026-09-26	1	1	t	1
945	880	2026-09-26	1	5	t	1
946	922	2026-09-26	1	5	t	1
947	870	2026-09-26	1	5	t	1
948	877	2026-09-26	1	5	t	1
949	971	2026-09-26	1	5	t	1
950	878	2026-09-26	1	6	t	1
951	925	2026-09-26	1	6	t	1
952	926	2026-09-26	1	6	t	1
953	973	2026-09-26	1	6	t	1
954	924	2026-09-26	1	6	t	1
955	972	2026-09-26	1	6	t	1
956	913	2026-09-26	1	23	t	1
957	914	2026-09-26	1	23	t	1
958	855	2026-09-26	1	23	t	1
959	470	2026-09-26	1	23	t	1
960	848	2026-09-26	1	23	t	1
961	851	2026-09-26	1	23	t	1
962	923	2026-09-26	1	23	t	1
963	871	2026-09-26	1	23	t	1
964	915	2026-09-26	1	23	t	1
965	927	2026-09-26	1	23	t	1
966	974	2026-09-26	1	23	t	1
967	916	2026-09-26	1	23	t	1
968	283	2026-09-26	1	18	f	1
969	284	2026-09-26	1	18	t	1
970	285	2026-09-26	1	18	t	1
971	305	2026-09-26	1	18	t	1
972	306	2026-09-26	1	18	f	1
973	286	2026-09-26	1	18	t	1
974	287	2026-09-26	1	18	t	1
975	288	2026-09-26	1	18	t	1
976	289	2026-09-26	1	18	f	1
977	290	2026-09-26	1	18	t	1
978	698	2026-09-26	1	18	f	1
979	307	2026-09-26	1	18	t	1
980	308	2026-09-26	1	18	f	1
981	309	2026-09-26	1	18	f	1
982	699	2026-09-26	1	18	f	1
983	291	2026-09-26	1	18	f	1
984	292	2026-09-26	1	18	f	1
985	293	2026-09-26	1	18	t	1
986	962	2026-09-26	1	18	t	1
987	311	2026-09-26	1	18	f	1
988	310	2026-09-26	1	18	t	1
989	312	2026-09-26	1	18	t	1
990	909	2026-09-26	1	18	f	1
991	700	2026-09-26	1	18	f	1
992	294	2026-09-26	1	18	t	1
993	295	2026-09-26	1	18	t	1
994	701	2026-09-26	1	18	f	1
995	313	2026-09-26	1	18	t	1
996	296	2026-09-26	1	18	f	1
997	314	2026-09-26	1	18	t	1
998	297	2026-09-26	1	18	f	1
999	298	2026-09-26	1	18	f	1
1000	299	2026-09-26	1	18	f	1
1001	315	2026-09-26	1	18	f	1
1002	316	2026-09-26	1	18	f	1
1003	702	2026-09-26	1	18	f	1
1004	300	2026-09-26	1	18	t	1
1005	301	2026-09-26	1	18	f	1
1006	302	2026-09-26	1	18	t	1
1007	303	2026-09-26	1	18	t	1
1008	304	2026-09-26	1	18	f	1
1009	910	2026-09-26	1	18	t	1
1010	874	2026-09-26	1	18	t	1
1011	317	2026-09-26	1	18	t	1
1012	318	2026-09-26	1	18	t	1
1013	319	2026-09-26	1	18	t	1
1015	908	2026-09-26	1	3	t	1
1016	930	2026-09-26	1	3	t	1
1017	235	2026-09-26	1	3	f	1
1018	255	2026-09-26	1	3	f	1
1019	236	2026-09-26	1	3	f	1
1020	256	2026-09-26	1	3	f	1
1021	905	2026-09-26	1	3	t	1
1022	237	2026-09-26	1	3	f	1
1023	692	2026-09-26	1	3	f	1
1024	257	2026-09-26	1	3	t	1
1025	238	2026-09-26	1	3	t	1
1026	931	2026-09-26	1	3	t	1
1027	239	2026-09-26	1	3	f	1
1028	258	2026-09-26	1	3	f	1
1029	240	2026-09-26	1	3	f	1
1030	903	2026-09-26	1	3	t	1
1031	696	2026-09-26	1	3	f	1
1032	241	2026-09-26	1	3	t	1
1033	242	2026-09-26	1	3	t	1
1034	693	2026-09-26	1	3	f	1
1035	243	2026-09-26	1	3	t	1
1036	244	2026-09-26	1	3	t	1
1037	245	2026-09-26	1	3	t	1
1038	906	2026-09-26	1	3	t	1
1039	968	2026-09-26	1	3	t	1
1040	246	2026-09-26	1	3	f	1
1041	247	2026-09-26	1	3	t	1
1042	249	2026-09-26	1	3	f	1
1043	248	2026-09-26	1	3	f	1
1044	907	2026-09-26	1	3	t	1
1045	901	2026-09-26	1	3	t	1
1046	928	2026-09-26	1	3	t	1
1048	259	2026-09-26	1	3	f	1
1049	900	2026-09-26	1	3	t	1
1050	250	2026-09-26	1	3	f	1
1051	261	2026-09-26	1	3	f	1
1052	260	2026-09-26	1	3	f	1
1053	262	2026-09-26	1	3	f	1
1054	929	2026-09-26	1	3	t	1
1055	263	2026-09-26	1	3	t	1
1056	251	2026-09-26	1	3	t	1
1057	694	2026-09-26	1	3	f	1
1058	902	2026-09-26	1	3	t	1
1059	264	2026-09-26	1	3	t	1
1060	266	2026-09-26	1	3	f	1
1061	265	2026-09-26	1	3	f	1
1062	267	2026-09-26	1	3	f	1
1063	695	2026-09-26	1	3	f	1
1064	268	2026-09-26	1	3	f	1
1065	269	2026-09-26	1	3	t	1
1066	252	2026-09-26	1	3	t	1
1067	270	2026-09-26	1	3	t	1
1068	253	2026-09-26	1	3	f	1
1069	271	2026-09-26	1	3	f	1
1070	904	2026-09-26	1	3	t	1
1071	849	2026-09-26	1	3	t	1
1072	273	2026-09-26	1	3	f	1
1073	272	2026-09-26	1	3	t	1
1074	728	2026-09-26	1	3	t	1
1075	950	2026-09-26	1	3	f	1
1076	274	2026-09-26	1	3	f	1
1077	846	2026-09-26	1	3	t	1
1078	697	2026-09-26	1	3	f	1
1079	275	2026-09-26	1	3	f	1
1080	276	2026-09-26	1	3	t	1
1081	278	2026-09-26	1	3	f	1
1082	277	2026-09-26	1	3	f	1
1083	279	2026-09-26	1	3	f	1
1084	280	2026-09-26	1	3	f	1
1085	254	2026-09-26	1	3	f	1
1086	281	2026-09-26	1	3	f	1
1087	282	2026-09-26	1	3	f	1
1088	975	2026-09-26	1	3	t	1
1089	447	2026-09-26	1	24	t	1
1090	448	2026-09-26	1	24	f	1
1091	449	2026-09-26	1	24	t	1
1092	450	2026-09-26	1	24	f	1
1093	452	2026-09-26	1	24	t	1
1094	453	2026-09-26	1	24	f	1
1095	454	2026-09-26	1	24	f	1
1096	739	2026-09-26	1	24	t	1
1097	456	2026-09-26	1	24	t	1
1098	457	2026-09-26	1	24	t	1
1099	458	2026-09-26	1	24	t	1
1100	459	2026-09-26	1	8	f	1
1103	462	2026-09-26	1	8	t	1
1104	732	2026-09-26	1	8	t	1
1105	733	2026-09-26	1	8	t	1
1106	463	2026-09-26	1	8	t	1
1107	464	2026-09-26	1	8	t	1
1109	734	2026-09-26	1	8	f	1
1110	466	2026-09-26	1	8	f	1
1111	467	2026-09-26	1	8	t	1
1112	468	2026-09-26	1	8	t	1
1113	845	2026-09-26	1	8	t	1
1114	735	2026-09-26	1	8	f	1
1115	736	2026-09-26	1	8	f	1
1116	875	2026-09-26	1	8	t	1
1117	469	2026-09-26	1	8	t	1
1118	737	2026-09-26	1	8	t	1
1119	471	2026-09-26	1	8	t	1
1120	472	2026-09-26	1	8	f	1
1121	852	2026-09-26	1	8	t	1
1122	451	2026-09-26	1	8	t	1
1123	473	2026-09-26	1	8	f	1
1124	474	2026-09-26	1	8	t	1
1125	920	2026-09-26	1	8	t	1
1126	475	2026-09-26	1	8	t	1
1127	919	2026-09-26	1	8	f	1
1128	476	2026-09-26	1	8	f	1
1129	477	2026-09-26	1	8	f	1
1130	478	2026-09-26	1	8	t	1
1131	479	2026-09-26	1	8	f	1
1132	738	2026-09-26	1	8	f	1
1133	480	2026-09-26	1	8	t	1
1134	481	2026-09-26	1	8	f	1
1135	918	2026-09-26	1	8	t	1
1136	455	2026-09-26	1	8	f	1
1137	740	2026-09-26	1	8	f	1
1138	741	2026-09-26	1	8	f	1
1139	742	2026-09-26	1	8	t	1
1140	853	2026-09-26	1	8	t	1
1141	482	2026-09-26	1	8	t	1
1142	483	2026-09-26	1	8	f	1
1143	951	2026-09-26	1	8	f	1
1144	484	2026-09-26	1	8	f	1
1145	485	2026-09-26	1	8	t	1
1146	486	2026-09-26	1	8	t	1
1147	487	2026-09-26	1	8	t	1
1148	881	2026-09-26	1	8	t	1
1149	488	2026-09-26	1	8	t	1
1150	489	2026-09-26	1	8	t	1
1151	743	2026-09-26	1	8	f	1
1152	917	2026-09-26	1	8	t	1
1153	964	2026-09-26	1	19	t	1
1154	897	2026-09-26	1	19	t	1
1155	190	2026-09-26	1	19	f	1
1156	191	2026-09-26	1	19	t	1
1157	192	2026-09-26	1	19	f	1
1158	193	2026-09-26	1	19	t	1
1159	194	2026-09-26	1	19	t	1
1160	195	2026-09-26	1	19	f	1
1161	196	2026-09-26	1	19	t	1
1162	197	2026-09-26	1	19	f	1
1163	198	2026-09-26	1	19	t	1
1164	199	2026-09-26	1	19	f	1
1165	690	2026-09-26	1	19	f	1
1166	200	2026-09-26	1	19	t	1
1167	689	2026-09-26	1	19	t	1
1168	202	2026-09-26	1	19	t	1
1169	966	2026-09-26	1	19	t	1
1170	201	2026-09-26	1	19	t	1
1171	203	2026-09-26	1	19	t	1
1172	204	2026-09-26	1	19	f	1
1173	205	2026-09-26	1	19	f	1
1174	206	2026-09-26	1	19	t	1
1175	207	2026-09-26	1	19	f	1
1176	208	2026-09-26	1	19	t	1
1177	209	2026-09-26	1	19	t	1
1178	210	2026-09-26	1	19	f	1
1179	967	2026-09-26	1	19	t	1
1180	211	2026-09-26	1	19	f	1
1181	212	2026-09-26	1	19	f	1
1182	688	2026-09-26	1	19	f	1
1183	213	2026-09-26	1	19	f	1
1184	214	2026-09-26	1	19	f	1
1185	691	2026-09-26	1	19	f	1
1186	215	2026-09-26	1	19	t	1
1187	899	2026-09-26	1	19	f	1
1188	216	2026-09-26	1	19	f	1
1189	217	2026-09-26	1	19	f	1
1190	218	2026-09-26	1	19	t	1
1191	932	2026-09-26	1	19	t	1
1192	220	2026-09-26	1	19	f	1
1193	219	2026-09-26	1	19	f	1
1194	221	2026-09-26	1	19	t	1
1195	898	2026-09-26	1	19	t	1
1196	687	2026-09-26	1	19	t	1
1197	222	2026-09-26	1	19	t	1
1198	223	2026-09-26	1	19	f	1
1199	224	2026-09-26	1	19	t	1
1200	225	2026-09-26	1	19	f	1
1201	226	2026-09-26	1	19	t	1
1202	227	2026-09-26	1	19	t	1
1203	228	2026-09-26	1	19	f	1
1204	229	2026-09-26	1	19	f	1
1205	230	2026-09-26	1	19	f	1
1206	231	2026-09-26	1	19	t	1
1207	232	2026-09-26	1	19	f	1
1208	233	2026-09-26	1	19	f	1
1209	885	2026-09-26	1	2	t	1
1210	896	2026-09-26	1	2	t	1
1211	146	2026-09-26	1	2	f	1
1212	147	2026-09-26	1	2	f	1
1213	148	2026-09-26	1	2	t	1
1214	149	2026-09-26	1	2	f	1
1215	150	2026-09-26	1	2	t	1
1216	151	2026-09-26	1	2	t	1
1217	152	2026-09-26	1	2	f	1
1218	153	2026-09-26	1	2	t	1
1219	154	2026-09-26	1	2	f	1
1220	155	2026-09-26	1	2	f	1
1221	156	2026-09-26	1	2	f	1
1222	684	2026-09-26	1	2	f	1
1223	157	2026-09-26	1	2	t	1
1224	158	2026-09-26	1	2	t	1
1225	159	2026-09-26	1	2	f	1
1226	160	2026-09-26	1	2	f	1
1227	161	2026-09-26	1	2	f	1
1228	162	2026-09-26	1	2	t	1
1229	872	2026-09-26	1	2	t	1
1230	685	2026-09-26	1	2	f	1
1231	163	2026-09-26	1	2	f	1
1232	895	2026-09-26	1	2	t	1
1233	164	2026-09-26	1	2	t	1
1234	165	2026-09-26	1	2	t	1
1235	166	2026-09-26	1	2	t	1
1236	167	2026-09-26	1	2	t	1
1237	168	2026-09-26	1	2	t	1
1238	169	2026-09-26	1	2	f	1
1239	170	2026-09-26	1	2	f	1
1240	171	2026-09-26	1	2	f	1
1241	172	2026-09-26	1	2	f	1
1242	173	2026-09-26	1	2	t	1
1243	174	2026-09-26	1	2	f	1
1244	175	2026-09-26	1	2	f	1
1245	176	2026-09-26	1	2	t	1
1246	177	2026-09-26	1	2	t	1
1247	178	2026-09-26	1	2	t	1
1248	179	2026-09-26	1	2	f	1
1249	180	2026-09-26	1	2	f	1
1250	181	2026-09-26	1	2	f	1
1251	182	2026-09-26	1	2	f	1
1252	183	2026-09-26	1	2	f	1
1253	184	2026-09-26	1	2	t	1
1254	185	2026-09-26	1	2	f	1
1255	186	2026-09-26	1	2	f	1
1256	686	2026-09-26	1	2	f	1
1257	894	2026-09-26	1	2	t	1
1258	187	2026-09-26	1	2	t	1
1259	188	2026-09-26	1	2	t	1
1260	189	2026-09-26	1	2	t	1
1261	976	2026-09-26	1	19	t	1
1262	490	2026-09-26	1	11	t	1
1263	491	2026-09-26	1	11	t	1
1264	492	2026-09-26	1	11	t	1
1265	744	2026-09-26	1	11	f	1
1266	493	2026-09-26	1	11	f	1
1267	745	2026-09-26	1	11	f	1
1268	494	2026-09-26	1	11	t	1
1269	495	2026-09-26	1	11	t	1
1270	496	2026-09-26	1	11	t	1
1271	497	2026-09-26	1	11	t	1
1272	498	2026-09-26	1	12	f	1
1273	746	2026-09-26	1	12	t	1
1274	747	2026-09-26	1	12	f	1
1275	499	2026-09-26	1	12	t	1
1276	500	2026-09-26	1	12	t	1
1277	501	2026-09-26	1	12	t	1
1278	502	2026-09-26	1	12	t	1
1279	505	2026-09-26	1	12	f	1
1280	506	2026-09-26	1	12	f	1
1281	507	2026-09-26	1	12	t	1
1282	503	2026-09-26	1	12	t	1
1283	748	2026-09-26	1	12	f	1
1284	504	2026-09-26	1	12	t	1
1285	749	2026-09-26	1	12	f	1
1286	508	2026-09-26	1	12	t	1
1287	510	2026-09-26	1	12	f	1
1288	509	2026-09-26	1	12	t	1
1289	511	2026-09-26	1	12	f	1
1290	512	2026-09-26	1	12	f	1
1291	750	2026-09-26	1	12	t	1
1292	513	2026-09-26	1	12	f	1
1293	751	2026-09-26	1	12	f	1
1294	517	2026-09-26	1	12	f	1
1295	514	2026-09-26	1	12	t	1
1296	515	2026-09-26	1	12	t	1
1297	516	2026-09-26	1	12	f	1
1298	752	2026-09-26	1	12	f	1
1299	753	2026-09-26	1	12	t	1
1300	518	2026-09-26	1	12	t	1
1301	754	2026-09-26	1	12	f	1
1302	519	2026-09-26	1	12	t	1
1303	520	2026-09-26	1	12	f	1
1304	521	2026-09-26	1	12	t	1
1305	522	2026-09-26	1	12	f	1
1306	523	2026-09-26	1	12	t	1
1307	524	2026-09-26	1	12	f	1
1308	525	2026-09-26	1	12	f	1
1309	527	2026-09-26	1	12	f	1
1310	526	2026-09-26	1	12	t	1
1311	528	2026-09-26	1	12	t	1
1312	387	2026-09-26	1	22	f	1
1313	388	2026-09-26	1	22	f	1
1314	389	2026-09-26	1	22	t	1
1315	391	2026-09-26	1	22	t	1
1316	392	2026-09-26	1	22	f	1
1317	393	2026-09-26	1	22	f	1
1318	394	2026-09-26	1	22	f	1
1319	395	2026-09-26	1	22	t	1
1322	720	2026-09-26	1	22	f	1
1323	960	2026-09-26	1	22	t	1
1324	398	2026-09-26	1	22	f	1
1325	399	2026-09-26	1	22	f	1
1326	400	2026-09-26	1	22	f	1
1327	401	2026-09-26	1	22	f	1
1328	402	2026-09-26	1	22	t	1
1329	721	2026-09-26	1	22	f	1
1330	722	2026-09-26	1	22	f	1
1331	403	2026-09-26	1	22	t	1
1332	404	2026-09-26	1	22	t	1
1333	405	2026-09-26	1	22	f	1
1334	406	2026-09-26	1	22	f	1
1335	723	2026-09-26	1	22	f	1
1336	705	2026-09-26	1	22	f	1
1337	407	2026-09-26	1	22	f	1
1338	408	2026-09-26	1	22	f	1
1339	409	2026-09-26	1	22	f	1
1340	911	2026-09-26	1	22	t	1
1341	410	2026-09-26	1	22	t	1
1342	724	2026-09-26	1	22	f	1
1343	411	2026-09-26	1	22	f	1
1344	412	2026-09-26	1	22	f	1
1345	413	2026-09-26	1	22	f	1
1346	725	2026-09-26	1	22	f	1
1347	414	2026-09-26	1	22	f	1
1348	726	2026-09-26	1	22	f	1
1349	415	2026-09-26	1	22	t	1
1350	416	2026-09-26	1	22	f	1
1351	417	2026-09-26	1	22	f	1
1352	418	2026-09-26	1	22	t	1
1353	419	2026-09-26	1	22	t	1
1354	706	2026-09-26	1	22	f	1
1355	420	2026-09-26	1	22	f	1
1356	421	2026-09-26	1	22	t	1
1357	422	2026-09-26	1	22	t	1
1358	423	2026-09-26	1	22	t	1
1359	707	2026-09-26	1	22	f	1
1360	424	2026-09-26	1	22	f	1
1361	425	2026-09-26	1	22	t	1
1321	397	2026-09-26	1	22	t	1
1362	426	2026-09-26	1	22	f	1
1363	727	2026-09-26	1	22	f	1
1364	427	2026-09-26	1	22	f	1
1365	428	2026-09-26	1	22	f	1
1366	429	2026-09-26	1	22	f	1
1367	430	2026-09-26	1	22	f	1
1368	431	2026-09-26	1	22	f	1
1369	432	2026-09-26	1	22	f	1
1370	433	2026-09-26	1	22	f	1
1371	434	2026-09-26	1	22	t	1
1372	435	2026-09-26	1	22	f	1
1373	436	2026-09-26	1	22	f	1
1374	729	2026-09-26	1	22	f	1
1375	730	2026-09-26	1	22	f	1
1376	731	2026-09-26	1	22	f	1
1377	437	2026-09-26	1	22	f	1
1378	438	2026-09-26	1	22	f	1
1379	439	2026-09-26	1	22	f	1
1380	440	2026-09-26	1	22	f	1
1381	441	2026-09-26	1	22	f	1
1382	442	2026-09-26	1	22	f	1
1383	443	2026-09-26	1	22	t	1
1384	444	2026-09-26	1	22	f	1
1385	965	2026-09-26	1	22	f	1
1386	445	2026-09-26	1	22	f	1
1387	912	2026-09-26	1	22	f	1
1388	446	2026-09-26	1	22	f	1
1392	322	2026-09-26	1	4	t	1
1393	332	2026-09-26	1	4	t	1
1394	323	2026-09-26	1	4	t	1
1395	324	2026-09-26	1	4	t	1
1396	325	2026-09-26	1	4	f	1
1397	326	2026-09-26	1	4	t	1
1398	327	2026-09-26	1	4	f	1
1399	333	2026-09-26	1	4	t	1
1400	328	2026-09-26	1	4	t	1
1401	334	2026-09-26	1	4	t	1
1402	329	2026-09-26	1	4	t	1
1403	330	2026-09-26	1	4	f	1
1404	335	2026-09-26	1	17	f	1
1405	884	2026-09-26	1	17	t	1
1406	336	2026-09-26	1	17	f	1
1407	337	2026-09-26	1	17	t	1
1408	338	2026-09-26	1	17	f	1
1409	339	2026-09-26	1	17	t	1
1410	340	2026-09-26	1	17	f	1
1411	708	2026-09-26	1	17	f	1
1412	709	2026-09-26	1	17	f	1
1413	341	2026-09-26	1	17	f	1
1414	847	2026-09-26	1	17	t	1
1415	342	2026-09-26	1	17	f	1
1416	710	2026-09-26	1	17	f	1
1417	711	2026-09-26	1	17	f	1
1418	343	2026-09-26	1	17	f	1
1419	344	2026-09-26	1	17	t	1
1420	345	2026-09-26	1	17	t	1
1421	346	2026-09-26	1	17	f	1
1422	347	2026-09-26	1	17	t	1
1423	348	2026-09-26	1	17	t	1
1424	349	2026-09-26	1	17	f	1
1425	879	2026-09-26	1	17	t	1
1426	350	2026-09-26	1	17	f	1
1427	351	2026-09-26	1	17	f	1
1428	352	2026-09-26	1	17	f	1
1429	353	2026-09-26	1	17	f	1
1430	354	2026-09-26	1	17	f	1
1431	355	2026-09-26	1	17	t	1
1432	356	2026-09-26	1	17	f	1
1433	357	2026-09-26	1	17	f	1
1434	703	2026-09-26	1	17	f	1
1435	358	2026-09-26	1	17	t	1
1436	712	2026-09-26	1	17	f	1
1437	359	2026-09-26	1	17	f	1
1438	954	2026-09-26	1	17	t	1
1439	360	2026-09-26	1	17	f	1
1440	361	2026-09-26	1	17	t	1
1441	713	2026-09-26	1	17	f	1
1442	704	2026-09-26	1	17	f	1
1443	362	2026-09-26	1	17	f	1
1444	363	2026-09-26	1	17	f	1
1445	364	2026-09-26	1	17	t	1
1446	365	2026-09-26	1	17	t	1
1447	366	2026-09-26	1	17	f	1
1448	714	2026-09-26	1	17	f	1
1449	367	2026-09-26	1	17	f	1
1450	368	2026-09-26	1	17	f	1
1451	715	2026-09-26	1	17	f	1
1452	369	2026-09-26	1	17	f	1
1453	370	2026-09-26	1	17	f	1
1454	371	2026-09-26	1	17	t	1
1455	372	2026-09-26	1	17	f	1
1456	883	2026-09-26	1	17	t	1
1457	373	2026-09-26	1	17	f	1
1458	952	2026-09-26	1	17	t	1
1459	716	2026-09-26	1	17	f	1
1460	854	2026-09-26	1	17	f	1
1461	374	2026-09-26	1	17	f	1
1462	717	2026-09-26	1	17	t	1
1463	375	2026-09-26	1	17	t	1
1464	376	2026-09-26	1	17	f	1
1465	377	2026-09-26	1	17	f	1
1466	378	2026-09-26	1	17	f	1
1467	718	2026-09-26	1	17	f	1
1468	379	2026-09-26	1	17	t	1
1469	380	2026-09-26	1	17	t	1
1470	381	2026-09-26	1	17	t	1
1471	953	2026-09-26	1	17	t	1
1472	382	2026-09-26	1	17	f	1
1473	383	2026-09-26	1	17	f	1
1474	384	2026-09-26	1	17	f	1
1475	385	2026-09-26	1	17	t	1
1476	719	2026-09-26	1	17	f	1
1477	386	2026-09-26	1	17	f	1
1320	396	2026-09-26	1	22	t	1
1480	556	2026-10-03	2	14	f	1
1481	557	2026-10-03	2	14	t	1
1482	987	2026-10-03	2	14	t	1
1483	558	2026-10-03	2	14	t	1
1484	559	2026-10-03	2	14	t	1
1485	560	2026-10-03	2	14	t	1
1486	561	2026-10-03	2	14	f	1
1487	598	2026-10-03	2	14	t	1
1488	562	2026-10-03	2	14	f	1
1489	999	2026-10-03	2	14	t	1
1490	947	2026-10-03	2	14	t	1
1491	563	2026-10-03	2	14	t	1
1492	564	2026-10-03	2	14	t	1
1493	565	2026-10-03	2	14	t	1
1494	983	2026-10-03	2	14	t	1
1495	566	2026-10-03	2	14	f	1
1496	567	2026-10-03	2	14	t	1
1497	568	2026-10-03	2	14	t	1
1498	569	2026-10-03	2	14	f	1
1499	570	2026-10-03	2	14	t	1
1500	571	2026-10-03	2	14	f	1
1501	572	2026-10-03	2	14	t	1
1502	573	2026-10-03	2	14	t	1
1503	948	2026-10-03	2	14	t	1
1504	575	2026-10-03	2	14	t	1
1505	850	2026-10-03	2	14	t	1
1506	576	2026-10-03	2	14	f	1
1507	577	2026-10-03	2	14	f	1
1508	578	2026-10-03	2	14	f	1
1509	579	2026-10-03	2	14	f	1
1510	580	2026-10-03	2	14	t	1
1511	581	2026-10-03	2	14	t	1
1512	582	2026-10-03	2	14	t	1
1513	982	2026-10-03	2	15	t	1
1514	583	2026-10-03	2	15	f	1
1515	584	2026-10-03	2	15	f	1
1516	585	2026-10-03	2	15	t	1
1517	586	2026-10-03	2	15	f	1
1518	949	2026-10-03	2	15	t	1
1519	588	2026-10-03	2	15	t	1
1520	587	2026-10-03	2	15	t	1
1521	589	2026-10-03	2	15	t	1
1522	859	2026-10-03	2	15	t	1
1523	590	2026-10-03	2	15	t	1
1524	591	2026-10-03	2	15	f	1
1525	593	2026-10-03	2	15	f	1
1526	592	2026-10-03	2	15	f	1
1527	946	2026-10-03	2	15	t	1
1528	594	2026-10-03	2	15	t	1
1529	595	2026-10-03	2	15	t	1
1530	596	2026-10-03	2	15	t	1
1531	597	2026-10-03	2	15	t	1
1532	945	2026-10-03	2	15	f	1
1533	599	2026-10-03	2	15	f	1
1534	989	2026-10-03	2	15	t	1
1535	601	2026-10-03	2	15	f	1
1536	600	2026-10-03	2	15	t	1
1537	860	2026-10-03	2	15	f	1
1538	602	2026-10-03	2	15	t	1
1539	603	2026-10-03	2	15	t	1
1540	605	2026-10-03	2	15	t	1
1541	604	2026-10-03	2	15	t	1
1542	606	2026-10-03	2	15	t	1
1543	607	2026-10-03	2	15	t	1
1544	608	2026-10-03	2	15	t	1
1545	609	2026-10-03	2	15	t	1
1546	610	2026-10-03	2	15	t	1
1547	611	2026-10-03	2	15	t	1
1548	613	2026-10-03	2	15	f	1
1549	612	2026-10-03	2	15	t	1
1550	861	2026-10-03	2	15	f	1
1551	614	2026-10-03	2	15	t	1
1552	615	2026-10-03	2	15	t	1
1553	616	2026-10-03	2	15	f	1
1554	617	2026-10-03	2	15	f	1
1555	618	2026-10-03	2	15	t	1
1556	619	2026-10-03	2	15	t	1
1557	862	2026-10-03	2	15	t	1
1558	993	2026-10-03	2	15	t	1
1559	620	2026-10-03	2	15	t	1
1560	940	2026-10-03	2	15	t	1
1561	621	2026-10-03	2	15	t	1
1562	1066	2026-10-03	2	15	t	1
1563	937	2026-10-03	2	15	t	1
1564	985	2026-10-03	2	15	t	1
1565	979	2026-10-03	2	15	t	1
1566	622	2026-10-03	2	15	f	1
1567	623	2026-10-03	2	15	t	1
1568	624	2026-10-03	2	15	t	1
1569	625	2026-10-03	2	15	f	1
1570	626	2026-10-03	2	15	t	1
1571	627	2026-10-03	2	15	t	1
1572	1002	2026-10-03	2	15	t	1
1573	628	2026-10-03	2	15	t	1
1574	629	2026-10-03	2	15	f	1
1575	630	2026-10-03	2	15	t	1
1576	631	2026-10-03	2	15	t	1
1577	633	2026-10-03	2	15	t	1
1578	938	2026-10-03	2	15	t	1
1579	632	2026-10-03	2	15	f	1
1580	991	2026-10-03	2	13	t	1
1581	529	2026-10-03	2	13	f	1
1582	988	2026-10-03	2	13	t	1
1583	530	2026-10-03	2	13	t	1
1584	843	2026-10-03	2	13	t	1
1585	531	2026-10-03	2	13	f	1
1586	532	2026-10-03	2	13	f	1
1587	533	2026-10-03	2	13	t	1
1588	858	2026-10-03	2	13	t	1
1589	534	2026-10-03	2	13	t	1
1590	535	2026-10-03	2	13	f	1
1591	957	2026-10-03	2	13	t	1
1592	842	2026-10-03	2	13	t	1
1593	536	2026-10-03	2	13	f	1
1594	537	2026-10-03	2	13	f	1
1595	994	2026-10-03	2	13	t	1
1596	995	2026-10-03	2	13	t	1
1597	538	2026-10-03	2	13	f	1
1598	539	2026-10-03	2	13	t	1
1599	540	2026-10-03	2	13	t	1
1600	541	2026-10-03	2	13	f	1
1601	542	2026-10-03	2	13	f	1
1602	543	2026-10-03	2	13	f	1
1603	544	2026-10-03	2	13	f	1
1604	545	2026-10-03	2	13	t	1
1605	546	2026-10-03	2	13	f	1
1606	935	2026-10-03	2	13	t	1
1607	549	2026-10-03	2	13	t	1
1608	548	2026-10-03	2	13	f	1
1609	547	2026-10-03	2	13	f	1
1610	574	2026-10-03	2	13	t	1
1611	550	2026-10-03	2	13	t	1
1612	963	2026-10-03	2	13	t	1
1613	936	2026-10-03	2	13	t	1
1614	551	2026-10-03	2	13	f	1
1615	552	2026-10-03	2	13	f	1
1616	857	2026-10-03	2	13	f	1
1617	1001	2026-10-03	2	13	t	1
1618	838	2026-10-03	2	13	t	1
1619	553	2026-10-03	2	13	t	1
1620	554	2026-10-03	2	13	f	1
1621	555	2026-10-03	2	13	f	1
1622	634	2026-10-03	2	16	t	1
1623	996	2026-10-03	2	16	t	1
1624	863	2026-10-03	2	16	t	1
1625	635	2026-10-03	2	16	t	1
1626	997	2026-10-03	2	16	t	1
1627	637	2026-10-03	2	16	t	1
1628	636	2026-10-03	2	16	t	1
1629	933	2026-10-03	2	16	t	1
1630	638	2026-10-03	2	16	t	1
1631	639	2026-10-03	2	16	t	1
1632	1000	2026-10-03	2	16	t	1
1633	864	2026-10-03	2	16	t	1
1634	640	2026-10-03	2	16	t	1
1635	641	2026-10-03	2	16	t	1
1636	939	2026-10-03	2	16	t	1
1637	642	2026-10-03	2	16	t	1
1638	643	2026-10-03	2	16	t	1
1639	944	2026-10-03	2	16	t	1
1640	981	2026-10-03	2	16	t	1
1641	941	2026-10-03	2	16	t	1
1642	644	2026-10-03	2	16	t	1
1643	645	2026-10-03	2	16	t	1
1644	990	2026-10-03	2	16	t	1
1645	646	2026-10-03	2	16	t	1
1646	865	2026-10-03	2	16	t	1
1647	647	2026-10-03	2	16	t	1
1648	992	2026-10-03	2	16	t	1
1649	978	2026-10-03	2	16	t	1
1650	866	2026-10-03	2	16	t	1
1651	986	2026-10-03	2	16	t	1
1652	998	2026-10-03	2	16	t	1
1653	648	2026-10-03	2	16	t	1
1654	867	2026-10-03	2	16	t	1
1655	958	2026-10-03	2	16	t	1
1656	650	2026-10-03	2	16	t	1
1657	649	2026-10-03	2	16	t	1
1658	651	2026-10-03	2	16	t	1
1659	942	2026-10-03	2	16	t	1
1660	652	2026-10-03	2	16	t	1
1661	653	2026-10-03	2	16	t	1
1662	868	2026-10-03	2	16	t	1
1663	654	2026-10-03	2	16	t	1
1664	656	2026-10-03	2	16	t	1
1665	655	2026-10-03	2	16	t	1
1666	657	2026-10-03	2	16	t	1
1667	1003	2026-10-03	2	16	t	1
1668	658	2026-10-03	2	16	t	1
1669	943	2026-10-03	2	16	t	1
1670	659	2026-10-03	2	16	t	1
1671	869	2026-10-03	2	16	t	1
1672	660	2026-10-03	2	16	t	1
1673	934	2026-10-03	2	16	t	1
1674	661	2026-10-03	2	16	t	1
1675	984	2026-10-03	2	16	t	1
1676	662	2026-10-03	2	16	t	1
1677	663	2026-10-03	2	16	t	1
1678	664	2026-10-03	2	16	t	1
1679	665	2026-10-03	2	16	t	1
1680	666	2026-10-03	2	16	t	1
1681	908	2026-10-03	1	3	t	1
1682	930	2026-10-03	1	3	t	1
1683	1018	2026-10-03	1	3	t	1
1684	905	2026-10-03	1	3	t	1
1685	1028	2026-10-03	1	3	t	1
1686	1031	2026-10-03	1	3	t	1
1687	257	2026-10-03	1	3	t	1
1688	238	2026-10-03	1	3	t	1
1689	1016	2026-10-03	1	3	t	1
1690	931	2026-10-03	1	3	t	1
1691	903	2026-10-03	1	3	t	1
1692	1035	2026-10-03	1	3	t	1
1693	241	2026-10-03	1	3	t	1
1694	242	2026-10-03	1	3	t	1
1695	1024	2026-10-03	1	3	t	1
1696	243	2026-10-03	1	3	t	1
1697	244	2026-10-03	1	3	t	1
1698	245	2026-10-03	1	3	t	1
1699	906	2026-10-03	1	3	t	1
1700	968	2026-10-03	1	3	t	1
1701	1029	2026-10-03	1	3	t	1
1702	247	2026-10-03	1	3	t	1
1703	907	2026-10-03	1	3	t	1
1704	901	2026-10-03	1	3	t	1
1705	928	2026-10-03	1	3	t	1
1706	900	2026-10-03	1	3	t	1
1707	1021	2026-10-03	1	3	t	1
1708	929	2026-10-03	1	3	t	1
1709	1015	2026-10-03	1	3	t	1
1710	1039	2026-10-03	1	3	t	1
1711	263	2026-10-03	1	3	t	1
1712	1019	2026-10-03	1	3	t	1
1713	251	2026-10-03	1	3	t	1
1714	1017	2026-10-03	1	3	t	1
1715	1032	2026-10-03	1	3	t	1
1716	902	2026-10-03	1	3	t	1
1717	264	2026-10-03	1	3	t	1
1718	1022	2026-10-03	1	3	t	1
1719	269	2026-10-03	1	3	t	1
1720	252	2026-10-03	1	3	t	1
1721	270	2026-10-03	1	3	t	1
1722	1040	2026-10-03	1	3	t	1
1723	1023	2026-10-03	1	3	t	1
1724	904	2026-10-03	1	3	t	1
1725	1037	2026-10-03	1	3	t	1
1726	849	2026-10-03	1	3	t	1
1727	1042	2026-10-03	1	3	t	1
1728	1033	2026-10-03	1	3	t	1
1729	1030	2026-10-03	1	3	t	1
1730	1038	2026-10-03	1	3	t	1
1731	1034	2026-10-03	1	3	t	1
1732	272	2026-10-03	1	3	t	1
1733	728	2026-10-03	1	3	t	1
1734	846	2026-10-03	1	3	t	1
1735	275	2026-10-03	1	3	t	1
1736	975	2026-10-03	1	3	t	1
1737	276	2026-10-03	1	3	t	1
1738	1014	2026-10-03	1	3	t	1
1739	1020	2026-10-03	1	3	t	1
1740	1036	2026-10-03	1	3	f	1
1742	283	2026-10-03	1	18	f	1
1743	284	2026-10-03	1	18	t	1
1744	235	2026-10-03	1	18	f	1
1745	255	2026-10-03	1	18	f	1
1746	285	2026-10-03	1	18	t	1
1747	236	2026-10-03	1	18	f	1
1748	256	2026-10-03	1	18	f	1
1749	305	2026-10-03	1	18	t	1
1750	306	2026-10-03	1	18	f	1
1751	286	2026-10-03	1	18	t	1
1752	287	2026-10-03	1	18	f	1
1753	237	2026-10-03	1	18	f	1
1754	692	2026-10-03	1	18	f	1
1755	288	2026-10-03	1	18	t	1
1756	289	2026-10-03	1	18	f	1
1757	239	2026-10-03	1	18	f	1
1758	258	2026-10-03	1	18	f	1
1759	290	2026-10-03	1	18	t	1
1760	698	2026-10-03	1	18	f	1
1761	240	2026-10-03	1	18	f	1
1762	307	2026-10-03	1	18	t	1
1763	308	2026-10-03	1	18	f	1
1764	696	2026-10-03	1	18	f	1
1765	693	2026-10-03	1	18	f	1
1766	309	2026-10-03	1	18	f	1
1767	246	2026-10-03	1	18	f	1
1768	699	2026-10-03	1	18	f	1
1769	291	2026-10-03	1	18	f	1
1770	249	2026-10-03	1	18	f	1
1771	248	2026-10-03	1	18	f	1
1772	292	2026-10-03	1	18	f	1
1773	259	2026-10-03	1	18	f	1
1774	250	2026-10-03	1	18	f	1
1775	293	2026-10-03	1	18	t	1
1776	260	2026-10-03	1	18	f	1
1777	261	2026-10-03	1	18	f	1
1778	262	2026-10-03	1	18	f	1
1779	962	2026-10-03	1	18	t	1
1780	311	2026-10-03	1	18	f	1
1781	310	2026-10-03	1	18	t	1
1782	312	2026-10-03	1	18	t	1
1783	909	2026-10-03	1	18	f	1
1784	700	2026-10-03	1	18	f	1
1785	294	2026-10-03	1	18	t	1
1786	295	2026-10-03	1	18	t	1
1787	694	2026-10-03	1	18	f	1
1788	701	2026-10-03	1	18	f	1
1789	1064	2026-10-03	1	18	t	1
1790	313	2026-10-03	1	18	t	1
1791	296	2026-10-03	1	18	f	1
1792	314	2026-10-03	1	18	t	1
1793	297	2026-10-03	1	18	f	1
1794	265	2026-10-03	1	18	f	1
1795	266	2026-10-03	1	18	f	1
1796	267	2026-10-03	1	18	f	1
1797	695	2026-10-03	1	18	f	1
1798	268	2026-10-03	1	18	f	1
1799	298	2026-10-03	1	18	f	1
1800	299	2026-10-03	1	18	f	1
1801	253	2026-10-03	1	18	f	1
1802	315	2026-10-03	1	18	f	1
1803	271	2026-10-03	1	18	f	1
1804	316	2026-10-03	1	18	f	1
1805	273	2026-10-03	1	18	f	1
1806	702	2026-10-03	1	18	f	1
1807	300	2026-10-03	1	18	t	1
1808	301	2026-10-03	1	18	f	1
1809	950	2026-10-03	1	18	f	1
1810	302	2026-10-03	1	18	t	1
1811	1041	2026-10-03	1	18	t	1
1812	303	2026-10-03	1	18	t	1
1813	697	2026-10-03	1	18	f	1
1814	277	2026-10-03	1	18	f	1
1815	278	2026-10-03	1	18	f	1
1816	279	2026-10-03	1	18	t	1
1817	280	2026-10-03	1	18	f	1
1818	304	2026-10-03	1	18	f	1
1819	910	2026-10-03	1	18	t	1
1820	254	2026-10-03	1	18	f	1
1821	874	2026-10-03	1	18	t	1
1822	317	2026-10-03	1	18	t	1
1823	281	2026-10-03	1	18	t	1
1824	282	2026-10-03	1	18	f	1
1825	318	2026-10-03	1	18	t	1
1826	319	2026-10-03	1	18	f	1
1827	92	2026-10-03	1	20	f	1
1828	892	2026-10-03	1	20	t	1
1829	93	2026-10-03	1	20	f	1
1830	95	2026-10-03	1	20	t	1
1831	96	2026-10-03	1	20	t	1
1832	839	2026-10-03	1	20	t	1
1833	97	2026-10-03	1	20	t	1
1834	841	2026-10-03	1	20	t	1
1835	98	2026-10-03	1	20	f	1
1837	808	2026-10-03	1	20	f	1
1838	669	2026-10-03	1	20	t	1
1839	99	2026-10-03	1	20	t	1
1840	101	2026-10-03	1	20	t	1
1841	100	2026-10-03	1	20	t	1
1842	103	2026-10-03	1	20	t	1
1843	672	2026-10-03	1	20	f	1
1844	104	2026-10-03	1	20	f	1
1845	105	2026-10-03	1	20	f	1
1846	673	2026-10-03	1	20	f	1
1847	86	2026-10-03	1	20	f	1
1848	844	2026-10-03	1	20	t	1
1849	111	2026-10-03	1	20	t	1
1850	815	2026-10-03	1	20	t	1
1851	113	2026-10-03	1	20	t	1
1852	876	2026-10-03	1	20	t	1
1853	115	2026-10-03	1	20	t	1
1854	116	2026-10-03	1	20	t	1
1855	882	2026-10-03	1	20	t	1
1856	118	2026-10-03	1	20	f	1
1857	1027	2026-10-03	1	20	t	1
1858	120	2026-10-03	1	20	t	1
1859	675	2026-10-03	1	20	f	1
1860	1025	2026-10-03	1	20	t	1
1861	87	2026-10-03	1	20	t	1
1862	891	2026-10-03	1	20	t	1
1863	890	2026-10-03	1	20	t	1
1864	125	2026-10-03	1	20	f	1
1865	126	2026-10-03	1	20	f	1
1866	127	2026-10-03	1	20	t	1
1867	128	2026-10-03	1	20	f	1
1868	129	2026-10-03	1	20	f	1
1869	820	2026-10-03	1	20	t	1
1870	1026	2026-10-03	1	20	t	1
1871	135	2026-10-03	1	20	t	1
1872	137	2026-10-03	1	20	t	1
1873	89	2026-10-03	1	20	f	1
1874	840	2026-10-03	1	20	t	1
1875	1062	2026-10-03	1	20	t	1
1877	970	2026-10-03	1	20	t	1
1878	141	2026-10-03	1	20	t	1
1879	837	2026-10-03	1	20	t	1
1880	680	2026-10-03	1	20	f	1
1881	682	2026-10-03	1	20	t	1
1882	805	2026-10-03	1	20	f	1
1883	142	2026-10-03	1	20	t	1
1884	143	2026-10-03	1	20	f	1
1885	893	2026-10-03	1	20	t	1
1886	683	2026-10-03	1	20	f	1
1887	889	2026-10-03	1	20	t	1
1888	145	2026-10-03	1	20	f	1
1889	39	2026-10-03	1	1	f	1
1890	40	2026-10-03	1	1	f	1
1891	41	2026-10-03	1	1	t	1
1892	4	2026-10-03	1	1	f	1
1893	42	2026-10-03	1	1	t	1
1894	43	2026-10-03	1	1	t	1
1895	5	2026-10-03	1	1	t	1
1896	6	2026-10-03	1	1	t	1
1897	45	2026-10-03	1	1	f	1
1898	46	2026-10-03	1	1	f	1
1899	7	2026-10-03	1	1	t	1
1900	48	2026-10-03	1	1	t	1
1901	47	2026-10-03	1	1	f	1
1902	8	2026-10-03	1	1	t	1
1903	887	2026-10-03	1	1	t	1
1904	49	2026-10-03	1	1	t	1
1905	51	2026-10-03	1	1	t	1
1906	888	2026-10-03	1	1	t	1
1907	9	2026-10-03	1	1	f	1
1908	10	2026-10-03	1	1	f	1
1909	52	2026-10-03	1	1	t	1
1910	11	2026-10-03	1	1	t	1
1911	53	2026-10-03	1	1	t	1
1912	55	2026-10-03	1	1	t	1
1913	13	2026-10-03	1	1	f	1
1914	12	2026-10-03	1	1	t	1
1915	14	2026-10-03	1	1	f	1
1916	15	2026-10-03	1	1	t	1
1917	56	2026-10-03	1	1	t	1
1918	57	2026-10-03	1	1	t	1
1919	969	2026-10-03	1	1	t	1
1920	16	2026-10-03	1	1	t	1
1921	58	2026-10-03	1	1	t	1
1922	17	2026-10-03	1	1	f	1
1923	762	2026-10-03	1	1	t	1
1924	18	2026-10-03	1	1	f	1
1925	59	2026-10-03	1	1	f	1
1926	19	2026-10-03	1	1	t	1
1927	20	2026-10-03	1	1	f	1
1928	21	2026-10-03	1	1	t	1
1929	69	2026-10-03	1	1	f	1
1930	22	2026-10-03	1	1	f	1
1931	62	2026-10-03	1	1	t	1
1932	63	2026-10-03	1	1	t	1
1933	959	2026-10-03	1	1	t	1
1934	64	2026-10-03	1	1	t	1
1935	66	2026-10-03	1	1	t	1
1936	27	2026-10-03	1	1	f	1
1937	26	2026-10-03	1	1	t	1
1938	68	2026-10-03	1	1	t	1
1939	28	2026-10-03	1	1	f	1
1940	71	2026-10-03	1	1	t	1
1941	72	2026-10-03	1	1	t	1
1942	29	2026-10-03	1	1	t	1
1943	30	2026-10-03	1	1	t	1
1944	77	2026-10-03	1	1	t	1
1945	75	2026-10-03	1	1	f	1
1946	78	2026-10-03	1	1	t	1
1947	31	2026-10-03	1	1	f	1
1948	81	2026-10-03	1	1	t	1
1949	886	2026-10-03	1	1	t	1
1950	32	2026-10-03	1	1	f	1
1951	84	2026-10-03	1	1	t	1
1952	873	2026-10-03	1	1	t	1
1953	34	2026-10-03	1	1	t	1
1954	36	2026-10-03	1	1	t	1
1955	37	2026-10-03	1	1	t	1
1956	880	2026-10-03	1	5	t	1
1957	922	2026-10-03	1	5	f	1
1958	870	2026-10-03	1	5	t	1
1959	877	2026-10-03	1	5	t	1
1960	1060	2026-10-03	1	5	t	1
1961	971	2026-10-03	1	5	t	1
1962	961	2026-10-03	1	7	t	1
1963	921	2026-10-03	1	7	t	1
1964	885	2026-10-03	1	2	t	1
1965	896	2026-10-03	1	2	t	1
1966	146	2026-10-03	1	2	f	1
1967	147	2026-10-03	1	2	f	1
1968	148	2026-10-03	1	2	t	1
1969	149	2026-10-03	1	2	f	1
1970	150	2026-10-03	1	2	t	1
1971	151	2026-10-03	1	2	f	1
1972	152	2026-10-03	1	2	f	1
1973	153	2026-10-03	1	2	t	1
1974	154	2026-10-03	1	2	f	1
1975	155	2026-10-03	1	2	f	1
1976	156	2026-10-03	1	2	t	1
1977	684	2026-10-03	1	2	f	1
1978	157	2026-10-03	1	2	t	1
1979	158	2026-10-03	1	2	t	1
1980	159	2026-10-03	1	2	f	1
1981	160	2026-10-03	1	2	f	1
1982	161	2026-10-03	1	2	f	1
1983	162	2026-10-03	1	2	t	1
1984	872	2026-10-03	1	2	t	1
1985	685	2026-10-03	1	2	f	1
1986	163	2026-10-03	1	2	f	1
1987	895	2026-10-03	1	2	t	1
1988	164	2026-10-03	1	2	t	1
1989	165	2026-10-03	1	2	t	1
1990	166	2026-10-03	1	2	t	1
1991	167	2026-10-03	1	2	t	1
1992	168	2026-10-03	1	2	t	1
1993	169	2026-10-03	1	2	f	1
1994	170	2026-10-03	1	2	f	1
1995	171	2026-10-03	1	2	f	1
1996	172	2026-10-03	1	2	f	1
1997	173	2026-10-03	1	2	t	1
1998	174	2026-10-03	1	2	f	1
1999	175	2026-10-03	1	2	f	1
2000	176	2026-10-03	1	2	t	1
2001	177	2026-10-03	1	2	t	1
2002	178	2026-10-03	1	2	t	1
2003	179	2026-10-03	1	2	f	1
2004	180	2026-10-03	1	2	f	1
2005	181	2026-10-03	1	2	f	1
2006	182	2026-10-03	1	2	f	1
2007	183	2026-10-03	1	2	f	1
2008	184	2026-10-03	1	2	t	1
2009	185	2026-10-03	1	2	f	1
2010	186	2026-10-03	1	2	t	1
2011	686	2026-10-03	1	2	f	1
2012	894	2026-10-03	1	2	t	1
2013	187	2026-10-03	1	2	t	1
2014	188	2026-10-03	1	2	t	1
2015	189	2026-10-03	1	2	t	1
2016	964	2026-10-03	1	19	t	1
2017	897	2026-10-03	1	19	t	1
2018	190	2026-10-03	1	19	t	1
2019	191	2026-10-03	1	19	t	1
2020	192	2026-10-03	1	19	f	1
2021	193	2026-10-03	1	19	t	1
2022	194	2026-10-03	1	19	f	1
2023	195	2026-10-03	1	19	f	1
2024	196	2026-10-03	1	19	t	1
2025	1043	2026-10-03	1	19	t	1
2026	197	2026-10-03	1	19	f	1
2027	980	2026-10-03	1	19	t	1
2028	198	2026-10-03	1	19	t	1
2029	199	2026-10-03	1	19	f	1
2030	690	2026-10-03	1	19	f	1
2031	200	2026-10-03	1	19	t	1
2032	689	2026-10-03	1	19	t	1
2033	202	2026-10-03	1	19	t	1
2034	966	2026-10-03	1	19	t	1
2035	201	2026-10-03	1	19	t	1
2036	1009	2026-10-03	1	19	t	1
2037	203	2026-10-03	1	19	t	1
2038	204	2026-10-03	1	19	f	1
2039	205	2026-10-03	1	19	f	1
2040	1010	2026-10-03	1	19	t	1
2041	206	2026-10-03	1	19	t	1
2042	207	2026-10-03	1	19	f	1
2043	208	2026-10-03	1	19	t	1
2044	209	2026-10-03	1	19	t	1
2045	210	2026-10-03	1	19	f	1
2046	967	2026-10-03	1	19	t	1
2047	211	2026-10-03	1	19	f	1
2048	1044	2026-10-03	1	19	f	1
2049	1045	2026-10-03	1	19	f	1
2050	212	2026-10-03	1	19	f	1
2051	688	2026-10-03	1	19	f	1
2052	213	2026-10-03	1	19	f	1
2053	214	2026-10-03	1	19	f	1
2054	691	2026-10-03	1	19	f	1
2055	215	2026-10-03	1	19	t	1
2056	899	2026-10-03	1	19	f	1
2057	216	2026-10-03	1	19	f	1
2058	217	2026-10-03	1	19	f	1
2059	218	2026-10-03	1	19	f	1
2060	932	2026-10-03	1	19	t	1
2061	220	2026-10-03	1	19	f	1
2062	219	2026-10-03	1	19	f	1
2063	221	2026-10-03	1	19	t	1
2064	898	2026-10-03	1	19	t	1
2065	687	2026-10-03	1	19	t	1
2066	222	2026-10-03	1	19	t	1
2067	223	2026-10-03	1	19	f	1
2068	274	2026-10-03	1	19	f	1
2069	224	2026-10-03	1	19	t	1
2070	225	2026-10-03	1	19	f	1
2071	1011	2026-10-03	1	19	t	1
2072	226	2026-10-03	1	19	f	1
2073	227	2026-10-03	1	19	f	1
2074	1061	2026-10-03	1	19	t	1
2075	976	2026-10-03	1	19	t	1
2076	1049	2026-10-03	1	19	f	1
2077	228	2026-10-03	1	19	f	1
2078	229	2026-10-03	1	19	f	1
2079	230	2026-10-03	1	19	f	1
2080	231	2026-10-03	1	19	t	1
2081	232	2026-10-03	1	19	f	1
2082	233	2026-10-03	1	19	f	1
2083	447	2026-10-03	1	24	t	1
2084	448	2026-10-03	1	24	f	1
2085	449	2026-10-03	1	24	t	1
2086	450	2026-10-03	1	24	t	1
2087	452	2026-10-03	1	24	t	1
2088	453	2026-10-03	1	24	f	1
2089	454	2026-10-03	1	24	t	1
2090	739	2026-10-03	1	24	t	1
2091	456	2026-10-03	1	24	t	1
2092	457	2026-10-03	1	24	t	1
2093	458	2026-10-03	1	24	t	1
2094	1046	2026-10-03	1	8	t	1
2095	459	2026-10-03	1	8	t	1
2098	462	2026-10-03	1	8	f	1
2099	732	2026-10-03	1	8	t	1
2100	733	2026-10-03	1	8	t	1
2101	463	2026-10-03	1	8	f	1
2102	464	2026-10-03	1	8	t	1
2104	1063	2026-10-03	1	8	t	1
2105	734	2026-10-03	1	8	t	1
2106	1012	2026-10-03	1	8	t	1
2107	466	2026-10-03	1	8	f	1
2108	467	2026-10-03	1	8	t	1
2109	468	2026-10-03	1	8	t	1
2110	1047	2026-10-03	1	8	t	1
2111	845	2026-10-03	1	8	t	1
2112	735	2026-10-03	1	8	f	1
2113	736	2026-10-03	1	8	f	1
2114	875	2026-10-03	1	8	t	1
2115	469	2026-10-03	1	8	t	1
2116	737	2026-10-03	1	8	t	1
2117	471	2026-10-03	1	8	t	1
2118	472	2026-10-03	1	8	f	1
2119	852	2026-10-03	1	8	t	1
2120	451	2026-10-03	1	8	f	1
2121	473	2026-10-03	1	8	f	1
2122	1048	2026-10-03	1	8	t	1
2123	474	2026-10-03	1	8	t	1
2124	920	2026-10-03	1	8	t	1
2125	475	2026-10-03	1	8	t	1
2126	919	2026-10-03	1	8	t	1
2127	477	2026-10-03	1	8	f	1
2128	476	2026-10-03	1	8	f	1
2129	478	2026-10-03	1	8	t	1
2130	479	2026-10-03	1	8	f	1
2131	738	2026-10-03	1	8	f	1
2132	480	2026-10-03	1	8	t	1
2133	481	2026-10-03	1	8	f	1
2134	918	2026-10-03	1	8	t	1
2135	455	2026-10-03	1	8	f	1
2136	1013	2026-10-03	1	8	t	1
2137	740	2026-10-03	1	8	f	1
2138	741	2026-10-03	1	8	f	1
2139	742	2026-10-03	1	8	t	1
2140	853	2026-10-03	1	8	t	1
2141	482	2026-10-03	1	8	t	1
2142	483	2026-10-03	1	8	f	1
2143	951	2026-10-03	1	8	t	1
2144	484	2026-10-03	1	8	f	1
2145	485	2026-10-03	1	8	t	1
2146	486	2026-10-03	1	8	t	1
2147	487	2026-10-03	1	8	t	1
2148	977	2026-10-03	1	8	t	1
2149	881	2026-10-03	1	8	t	1
2150	489	2026-10-03	1	8	t	1
2151	488	2026-10-03	1	8	t	1
2152	743	2026-10-03	1	8	f	1
2153	917	2026-10-03	1	8	t	1
2154	913	2026-10-03	1	23	t	1
2155	914	2026-10-03	1	23	t	1
2156	855	2026-10-03	1	23	t	1
2157	470	2026-10-03	1	23	t	1
2158	848	2026-10-03	1	23	t	1
2159	851	2026-10-03	1	23	t	1
2160	923	2026-10-03	1	23	t	1
2161	871	2026-10-03	1	23	t	1
2162	915	2026-10-03	1	23	t	1
2163	927	2026-10-03	1	23	t	1
2164	974	2026-10-03	1	23	f	1
2165	916	2026-10-03	1	23	t	1
2166	878	2026-10-03	1	6	t	1
2167	925	2026-10-03	1	6	t	1
2168	926	2026-10-03	1	6	t	1
2169	973	2026-10-03	1	6	t	1
2170	924	2026-10-03	1	6	t	1
2171	972	2026-10-03	1	6	t	1
2175	322	2026-10-03	1	4	t	1
2176	332	2026-10-03	1	4	t	1
2177	1007	2026-10-03	1	4	t	1
2178	323	2026-10-03	1	4	t	1
2179	324	2026-10-03	1	4	t	1
2180	325	2026-10-03	1	4	f	1
2181	326	2026-10-03	1	4	t	1
2182	327	2026-10-03	1	4	f	1
2183	333	2026-10-03	1	4	t	1
2184	328	2026-10-03	1	4	t	1
2185	334	2026-10-03	1	4	t	1
2186	329	2026-10-03	1	4	f	1
2187	330	2026-10-03	1	4	t	1
2188	335	2026-10-03	1	17	f	1
2189	884	2026-10-03	1	17	t	1
2190	336	2026-10-03	1	17	f	1
2191	337	2026-10-03	1	17	t	1
2192	338	2026-10-03	1	17	f	1
2193	339	2026-10-03	1	17	t	1
2194	340	2026-10-03	1	17	f	1
2195	708	2026-10-03	1	17	f	1
2196	709	2026-10-03	1	17	f	1
2197	341	2026-10-03	1	17	f	1
2198	847	2026-10-03	1	17	t	1
2199	342	2026-10-03	1	17	f	1
2200	710	2026-10-03	1	17	f	1
2201	711	2026-10-03	1	17	f	1
2202	343	2026-10-03	1	17	f	1
2203	344	2026-10-03	1	17	t	1
2204	345	2026-10-03	1	17	t	1
2205	346	2026-10-03	1	17	t	1
2206	347	2026-10-03	1	17	t	1
2207	348	2026-10-03	1	17	f	1
2208	349	2026-10-03	1	17	f	1
2209	879	2026-10-03	1	17	t	1
2210	350	2026-10-03	1	17	f	1
2211	351	2026-10-03	1	17	f	1
2212	352	2026-10-03	1	17	f	1
2213	353	2026-10-03	1	17	f	1
2214	354	2026-10-03	1	17	f	1
2215	355	2026-10-03	1	17	t	1
2216	356	2026-10-03	1	17	f	1
2217	357	2026-10-03	1	17	f	1
2218	703	2026-10-03	1	17	f	1
2220	712	2026-10-03	1	17	f	1
2221	359	2026-10-03	1	17	f	1
2222	954	2026-10-03	1	17	t	1
2223	360	2026-10-03	1	17	f	1
2224	361	2026-10-03	1	17	t	1
2225	713	2026-10-03	1	17	f	1
2226	704	2026-10-03	1	17	f	1
2227	362	2026-10-03	1	17	f	1
2228	363	2026-10-03	1	17	f	1
2229	364	2026-10-03	1	17	t	1
2230	365	2026-10-03	1	17	t	1
2231	366	2026-10-03	1	17	f	1
2232	714	2026-10-03	1	17	f	1
2233	367	2026-10-03	1	17	f	1
2234	368	2026-10-03	1	17	f	1
2235	715	2026-10-03	1	17	f	1
2236	369	2026-10-03	1	17	t	1
2237	370	2026-10-03	1	17	f	1
2238	371	2026-10-03	1	17	t	1
2239	372	2026-10-03	1	17	f	1
2240	883	2026-10-03	1	17	t	1
2241	373	2026-10-03	1	17	f	1
2242	952	2026-10-03	1	17	t	1
2243	716	2026-10-03	1	17	f	1
2244	854	2026-10-03	1	17	f	1
2245	374	2026-10-03	1	17	f	1
2246	717	2026-10-03	1	17	t	1
2247	375	2026-10-03	1	17	t	1
2248	376	2026-10-03	1	17	f	1
2249	377	2026-10-03	1	17	f	1
2250	378	2026-10-03	1	17	f	1
2251	718	2026-10-03	1	17	f	1
2252	379	2026-10-03	1	17	t	1
2253	380	2026-10-03	1	17	t	1
2254	381	2026-10-03	1	17	t	1
2255	953	2026-10-03	1	17	t	1
2256	382	2026-10-03	1	17	f	1
2257	383	2026-10-03	1	17	f	1
2258	384	2026-10-03	1	17	f	1
2259	385	2026-10-03	1	17	t	1
2260	719	2026-10-03	1	17	f	1
2261	386	2026-10-03	1	17	f	1
2219	358	2026-10-03	1	17	t	1
2263	387	2026-10-03	1	22	f	1
2264	388	2026-10-03	1	22	f	1
2265	389	2026-10-03	1	22	t	1
2266	391	2026-10-03	1	22	t	1
2267	392	2026-10-03	1	22	f	1
2268	393	2026-10-03	1	22	f	1
2269	394	2026-10-03	1	22	f	1
2270	1050	2026-10-03	1	22	t	1
2271	395	2026-10-03	1	22	t	1
2272	397	2026-10-03	1	22	t	1
2273	396	2026-10-03	1	22	t	1
2274	720	2026-10-03	1	22	f	1
2275	960	2026-10-03	1	22	t	1
2276	398	2026-10-03	1	22	f	1
2277	1054	2026-10-03	1	22	t	1
2278	399	2026-10-03	1	22	t	1
2279	400	2026-10-03	1	22	f	1
2280	401	2026-10-03	1	22	t	1
2281	1052	2026-10-03	1	22	t	1
2282	402	2026-10-03	1	22	t	1
2283	1008	2026-10-03	1	22	t	1
2284	721	2026-10-03	1	22	f	1
2285	722	2026-10-03	1	22	f	1
2286	404	2026-10-03	1	22	t	1
2287	403	2026-10-03	1	22	t	1
2288	405	2026-10-03	1	22	f	1
2289	406	2026-10-03	1	22	f	1
2290	1051	2026-10-03	1	22	t	1
2291	723	2026-10-03	1	22	f	1
2292	705	2026-10-03	1	22	f	1
2293	407	2026-10-03	1	22	t	1
2294	408	2026-10-03	1	22	f	1
2295	1004	2026-10-03	1	22	t	1
2296	409	2026-10-03	1	22	t	1
2297	911	2026-10-03	1	22	t	1
2298	410	2026-10-03	1	22	t	1
2299	724	2026-10-03	1	22	f	1
2300	1053	2026-10-03	1	22	t	1
2301	411	2026-10-03	1	22	f	1
2302	1059	2026-10-03	1	22	t	1
2303	412	2026-10-03	1	22	f	1
2304	413	2026-10-03	1	22	f	1
2305	414	2026-10-03	1	22	f	1
2306	726	2026-10-03	1	22	f	1
2307	725	2026-10-03	1	22	f	1
2308	415	2026-10-03	1	22	t	1
2309	416	2026-10-03	1	22	f	1
2310	417	2026-10-03	1	22	f	1
2311	1055	2026-10-03	1	22	t	1
2312	418	2026-10-03	1	22	t	1
2313	419	2026-10-03	1	22	t	1
2314	706	2026-10-03	1	22	f	1
2315	420	2026-10-03	1	22	f	1
2316	421	2026-10-03	1	22	t	1
2317	422	2026-10-03	1	22	t	1
2318	423	2026-10-03	1	22	t	1
2319	707	2026-10-03	1	22	f	1
2320	424	2026-10-03	1	22	f	1
2321	425	2026-10-03	1	22	t	1
2322	426	2026-10-03	1	22	f	1
2323	727	2026-10-03	1	22	f	1
2324	427	2026-10-03	1	22	f	1
2325	1005	2026-10-03	1	22	t	1
2326	428	2026-10-03	1	22	f	1
2327	429	2026-10-03	1	22	f	1
2328	1065	2026-10-03	1	22	t	1
2329	430	2026-10-03	1	22	f	1
2330	431	2026-10-03	1	22	f	1
2331	432	2026-10-03	1	22	t	1
2332	433	2026-10-03	1	22	f	1
2333	434	2026-10-03	1	22	t	1
2334	1006	2026-10-03	1	22	t	1
2335	435	2026-10-03	1	22	f	1
2336	436	2026-10-03	1	22	f	1
2337	729	2026-10-03	1	22	t	1
2338	730	2026-10-03	1	22	f	1
2339	731	2026-10-03	1	22	f	1
2340	437	2026-10-03	1	22	f	1
2341	1057	2026-10-03	1	22	t	1
2342	1058	2026-10-03	1	22	t	1
2343	438	2026-10-03	1	22	f	1
2344	439	2026-10-03	1	22	f	1
2345	440	2026-10-03	1	22	f	1
2346	441	2026-10-03	1	22	f	1
2347	442	2026-10-03	1	22	f	1
2348	1056	2026-10-03	1	22	t	1
2349	443	2026-10-03	1	22	t	1
2350	444	2026-10-03	1	22	f	1
2351	965	2026-10-03	1	22	f	1
2352	445	2026-10-03	1	22	f	1
2353	912	2026-10-03	1	22	f	1
2354	446	2026-10-03	1	22	f	1
2355	498	2026-10-03	1	12	f	1
2356	746	2026-10-03	1	12	t	1
2357	747	2026-10-03	1	12	f	1
2358	499	2026-10-03	1	12	t	1
2359	500	2026-10-03	1	12	t	1
2360	501	2026-10-03	1	12	f	1
2361	502	2026-10-03	1	12	t	1
2362	505	2026-10-03	1	12	f	1
2363	506	2026-10-03	1	12	f	1
2364	507	2026-10-03	1	12	t	1
2365	503	2026-10-03	1	12	t	1
2366	748	2026-10-03	1	12	f	1
2367	504	2026-10-03	1	12	t	1
2368	749	2026-10-03	1	12	f	1
2369	508	2026-10-03	1	12	t	1
2370	510	2026-10-03	1	12	f	1
2371	509	2026-10-03	1	12	t	1
2372	511	2026-10-03	1	12	f	1
2373	512	2026-10-03	1	12	f	1
2374	750	2026-10-03	1	12	t	1
2375	513	2026-10-03	1	12	f	1
2376	751	2026-10-03	1	12	f	1
2377	517	2026-10-03	1	12	f	1
2378	514	2026-10-03	1	12	t	1
2379	515	2026-10-03	1	12	t	1
2380	516	2026-10-03	1	12	f	1
2381	752	2026-10-03	1	12	f	1
2382	753	2026-10-03	1	12	t	1
2383	518	2026-10-03	1	12	t	1
2384	754	2026-10-03	1	12	f	1
2385	519	2026-10-03	1	12	t	1
2386	520	2026-10-03	1	12	f	1
2387	521	2026-10-03	1	12	t	1
2388	522	2026-10-03	1	12	f	1
2389	523	2026-10-03	1	12	f	1
2390	524	2026-10-03	1	12	f	1
2391	525	2026-10-03	1	12	f	1
2392	527	2026-10-03	1	12	f	1
2393	526	2026-10-03	1	12	f	1
2394	528	2026-10-03	1	12	t	1
2395	490	2026-10-03	1	11	t	1
2396	491	2026-10-03	1	11	t	1
2397	492	2026-10-03	1	11	t	1
2398	744	2026-10-03	1	11	f	1
2399	493	2026-10-03	1	11	f	1
2400	745	2026-10-03	1	11	f	1
2401	494	2026-10-03	1	11	t	1
2402	495	2026-10-03	1	11	f	1
2403	496	2026-10-03	1	11	f	1
2404	497	2026-10-03	1	11	t	1
\.


--
-- Data for Name: recompenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recompenses (id, note_id, eleve_id, annee_scolaire_id, mois, type_gain, montant, depense_id, paye_par, date_paiement, created_at) FROM stdin;
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, nom_site, initiale) FROM stdin;
2	Yagbé	Y
1	Jéricho	J
\.


--
-- Data for Name: user_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sites (user_id, site_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, role, site_id, actif) FROM stdin;
55899634-2a3d-4d0c-a169-c883ddd3b72f	jealexhouegbe	jucaljealexhouegbe@gmail.com	coordonnateur	\N	t
7277c3e9-2515-4a1a-8fe1-06f0e3c14e77	urielhouegbe	urielaxelhouegbe@gmail.com	comptable	\N	t
4152793a-6298-424b-b06d-790e10e483df	Nanildoliveira	doliveiraanderson6@gmail.com	chef_site	1	f
a473d5c2-6be2-4da5-9872-edf1586ab202	Peter21	padampierre@gmail.com	chef_site	1	f
bbef52c8-3a68-4d24-9714-7563440edc56	quenumparfait	parfaitquenum91@gmail.com	chef_site	2	f
576e1d68-860c-4ef9-bd53-773709e47df0	yetbaginn	yetohoubago@gmail.com	chef_site	1	f
\.


--
-- Data for Name: creneaux; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.creneaux (id, semaine_id, classe_id, matiere_id, date_td, heure_debut, heure_fin, montant_prevu, statut_creneau) FROM stdin;
21	13	1	5	2026-09-19	08:30:00	11:30:00	4500.00	cloture
23	13	2	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
25	13	3	4	2026-09-19	08:30:00	11:30:00	4500.00	cloture
26	13	18	4	2026-09-19	08:30:00	11:30:00	4500.00	cloture
30	13	8	3	2026-09-19	08:30:00	11:30:00	5100.00	cloture
27	13	17	2	2026-09-19	15:30:00	18:30:00	4500.00	cloture
28	13	22	2	2026-09-19	15:30:00	18:30:00	4500.00	cloture
31	13	12	5	2026-09-19	15:30:00	18:30:00	6000.00	cloture
34	13	15	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
35	13	16	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
32	13	13	3	2026-09-19	08:30:00	11:30:00	4500.00	cloture
33	13	14	4	2026-09-19	08:30:00	11:30:00	4500.00	cloture
24	13	19	2	2026-09-19	08:30:00	11:30:00	4500.00	cloture
29	13	23	1	2026-09-19	08:30:00	11:30:00	5100.00	cloture
22	13	20	5	2026-09-19	08:30:00	11:30:00	4500.00	cloture
38	14	2	4	2026-09-26	08:30:00	11:30:00	4500.00	cloture
39	14	19	4	2026-09-26	08:30:00	11:30:00	4500.00	cloture
40	14	3	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
41	14	18	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
44	14	17	2	2026-09-26	15:30:00	18:30:00	4500.00	cloture
43	14	22	2	2026-09-26	15:30:00	18:30:00	4500.00	cloture
46	14	23	5	2026-09-26	08:30:00	11:30:00	5100.00	cloture
49	14	13	5	2026-09-26	08:30:00	11:30:00	4500.00	cloture
51	14	15	4	2026-09-26	08:30:00	11:30:00	4500.00	cloture
52	14	16	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
50	14	14	2	2026-09-26	08:30:00	11:30:00	4500.00	cloture
36	14	1	3	2026-09-26	08:30:00	11:30:00	4500.00	cloture
48	14	12	4	2026-09-26	15:30:00	18:30:00	6000.00	cloture
37	14	20	3	2026-09-26	08:30:00	11:30:00	4500.00	cloture
47	14	8	4	2026-09-26	08:30:00	11:30:00	5100.00	cloture
119	16	18	4	2026-10-10	07:30:00	09:30:00	3000.00	cloture
105	16	15	2	2026-10-10	07:30:00	09:30:00	3000.00	cloture
103	16	14	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
101	16	13	2	2026-10-10	07:30:00	09:30:00	3000.00	cloture
123	16	22	2	2026-10-10	14:50:00	16:50:00	3000.00	cloture
125	16	6	2	2026-10-10	07:00:00	09:45:00	5100.00	cloture
113	16	2	4	2026-10-10	07:30:00	09:30:00	3000.00	cloture
127	16	8	5	2026-10-10	07:00:00	09:45:00	5100.00	cloture
117	16	3	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
107	16	16	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
129	16	12	1	2026-10-10	14:00:00	16:50:00	6000.00	cloture
121	16	17	11	2026-10-10	14:50:00	16:50:00	3000.00	cloture
111	16	20	3	2026-10-10	07:30:00	09:30:00	3000.00	cloture
109	16	1	5	2026-10-10	07:30:00	09:30:00	3000.00	cloture
115	16	19	2	2026-10-10	07:30:00	09:30:00	3000.00	cloture
79	15	22	2	2026-10-03	14:50:00	16:50:00	3000.00	cloture
78	15	17	2	2026-10-03	17:00:00	19:00:00	3000.00	cloture
66	15	16	4	2026-10-04	15:00:00	18:00:00	4500.00	cloture
70	15	19	3	2026-10-03	10:00:00	12:00:00	3000.00	cloture
67	15	2	3	2026-10-03	07:30:00	09:30:00	3000.00	cloture
65	15	15	4	2026-10-04	15:00:00	18:00:00	4500.00	cloture
74	15	18	4	2026-10-03	10:00:00	12:00:00	3000.00	cloture
71	15	3	4	2026-10-03	07:30:00	09:30:00	3000.00	cloture
63	15	20	4	2026-10-03	07:30:00	09:30:00	3000.00	cloture
84	15	23	4	2026-10-03	10:15:00	13:00:00	5100.00	cloture
69	15	19	5	2026-10-03	07:30:00	09:30:00	3000.00	cloture
68	15	2	5	2026-10-03	10:00:00	12:00:00	3000.00	cloture
64	15	20	2	2026-10-03	10:00:00	12:00:00	3000.00	cloture
81	15	5	2	2026-10-03	07:00:00	09:45:00	5100.00	cloture
85	15	5	8	2026-10-04	15:00:00	18:00:00	5100.00	cloture
75	15	3	2	2026-10-04	15:00:00	18:00:00	4500.00	cloture
77	15	17	1	2026-10-03	14:50:00	16:50:00	3000.00	cloture
80	15	22	1	2026-10-03	17:00:00	19:00:00	3000.00	cloture
83	15	23	6	2026-10-03	07:00:00	09:45:00	5100.00	cloture
72	15	3	1	2026-10-03	10:00:00	12:00:00	3000.00	cloture
73	15	18	1	2026-10-03	07:30:00	09:30:00	3000.00	cloture
82	15	5	1	2026-10-03	10:15:00	13:00:00	5100.00	cloture
76	15	18	2	2026-10-04	15:00:00	18:00:00	4500.00	cloture
60	15	16	2	2026-10-03	10:00:00	12:00:00	3000.00	cloture
57	15	15	2	2026-10-03	07:30:00	09:30:00	3000.00	cloture
89	15	8	4	2026-10-03	07:00:00	09:45:00	5100.00	cloture
62	15	1	4	2026-10-03	10:00:00	12:00:00	3000.00	cloture
53	15	13	4	2026-10-03	07:30:00	09:30:00	3000.00	cloture
56	15	14	4	2026-10-03	10:00:00	12:00:00	3000.00	cloture
54	15	13	3	2026-10-03	10:00:00	12:00:00	3000.00	cloture
55	15	14	3	2026-10-03	07:30:00	09:30:00	3000.00	cloture
61	15	1	2	2026-10-03	07:30:00	09:30:00	3000.00	cloture
94	15	12	3	2026-10-03	17:00:00	19:00:00	4000.00	cloture
93	15	12	5	2026-10-03	14:00:00	16:50:00	6000.00	cloture
88	15	7	2	2026-10-03	10:15:00	13:00:00	5100.00	cloture
86	15	23	2	2026-10-04	15:00:00	18:00:00	5100.00	cloture
92	15	8	2	2026-10-04	15:00:00	18:00:00	5100.00	cloture
58	15	15	1	2026-10-03	10:00:00	12:00:00	3000.00	cloture
59	15	16	1	2026-10-03	07:30:00	09:30:00	3000.00	cloture
90	15	8	6	2026-10-03	10:15:00	13:00:00	5100.00	cloture
91	15	7	8	2026-10-04	15:00:00	18:00:00	5100.00	cloture
87	15	7	1	2026-10-03	07:00:00	09:45:00	5100.00	cloture
97	16	22	4	2026-10-07	14:50:00	16:50:00	3000.00	cloture
96	16	17	4	2026-10-07	17:00:00	19:00:00	3000.00	cloture
99	16	11	2	2026-10-07	15:00:00	18:00:00	6000.00	cloture
118	16	3	4	2026-10-10	10:00:00	12:00:00	3000.00	cloture
108	16	16	2	2026-10-10	10:00:00	12:00:00	3000.00	cloture
102	16	13	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
104	16	14	2	2026-10-10	10:00:00	12:00:00	3000.00	cloture
122	16	17	2	2026-10-10	17:00:00	19:00:00	3000.00	cloture
116	16	19	4	2026-10-10	10:00:00	12:00:00	3000.00	cloture
130	16	12	7	2026-10-10	17:00:00	19:00:00	4000.00	cloture
126	16	23	5	2026-10-10	10:15:00	13:00:00	5100.00	cloture
100	16	12	2	2026-10-07	15:00:00	18:00:00	6000.00	cloture
128	16	24	2	2026-10-10	10:15:00	13:00:00	5100.00	cloture
95	16	17	5	2026-10-07	14:50:00	16:50:00	3000.00	cloture
98	16	22	5	2026-10-07	17:00:00	19:00:00	3000.00	cloture
120	16	18	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
106	16	15	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
124	16	22	11	2026-10-10	17:00:00	19:00:00	3000.00	cloture
110	16	1	3	2026-10-10	10:00:00	12:00:00	3000.00	cloture
112	16	20	5	2026-10-10	10:00:00	12:00:00	3000.00	cloture
114	16	2	2	2026-10-10	10:00:00	12:00:00	3000.00	cloture
\.


--
-- Data for Name: matieres_td; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.matieres_td (id, nom_matiere) FROM stdin;
1	Francais
2	Mathematiques
3	Anglais
5	SVT
6	Philosophie
7	Histoire-Geographie
8	Economie
9	Espagnol
10	Allemand
11	Communication écrite
4	PCT
\.


--
-- Data for Name: postulations; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.postulations (id, creneau_id, professeur_id, statut_validation, date_postulation, motif_retrait) FROM stdin;
24	34	26	Valide	2026-09-14 07:55:27.94048+00	\N
33	34	1	Refuse	2026-09-14 08:46:32.228351+00	\N
23	24	26	Refuse	2026-09-14 07:55:15.793452+00	\N
25	35	26	Refuse	2026-09-14 07:55:34.725746+00	\N
40	35	18	Valide	2026-09-14 13:56:33.631836+00	\N
52	35	27	Refuse	2026-09-15 00:42:59.700917+00	\N
21	32	25	Valide	2026-09-14 07:52:43.094525+00	\N
45	33	19	Valide	2026-09-14 20:30:43.45198+00	\N
53	24	45	Valide	2026-09-15 10:22:38.683524+00	\N
54	24	36	Refuse	2026-09-15 10:23:56.475103+00	\N
32	24	1	Refuse	2026-09-14 08:46:19.175797+00	\N
56	29	7	Valide	2026-09-15 20:34:49.077562+00	\N
57	22	22	Valide	2026-09-16 05:51:10.896145+00	\N
20	22	6	Refuse	2026-09-14 06:42:27.657757+00	\N
36	21	13	Valide	2026-09-14 10:13:47.61354+00	\N
18	21	6	Refuse	2026-09-14 06:40:09.294897+00	\N
37	22	13	Refuse	2026-09-14 10:13:51.013178+00	\N
27	23	20	Valide	2026-09-14 07:58:54.847394+00	\N
22	23	26	Refuse	2026-09-14 07:55:06.354792+00	\N
31	23	1	Refuse	2026-09-14 08:46:15.159058+00	\N
39	25	33	Valide	2026-09-14 12:03:06.386845+00	\N
29	25	52	Refuse	2026-09-14 08:17:41.232102+00	\N
35	25	9	Refuse	2026-09-14 09:14:44.95257+00	\N
43	25	19	Refuse	2026-09-14 20:30:29.09114+00	\N
47	25	8	Refuse	2026-09-14 21:37:36.500733+00	\N
30	26	52	Valide	2026-09-14 08:17:51.032422+00	\N
44	26	19	Refuse	2026-09-14 20:30:38.948733+00	\N
49	30	21	Valide	2026-09-14 22:22:26.036596+00	\N
48	32	21	Refuse	2026-09-14 22:21:03.98771+00	\N
51	27	27	Valide	2026-09-15 00:42:52.91367+00	\N
42	27	18	Refuse	2026-09-14 14:00:57.269771+00	\N
50	27	20	Refuse	2026-09-14 22:31:42.009517+00	\N
34	28	1	Valide	2026-09-14 08:46:54.2162+00	\N
19	31	6	Valide	2026-09-14 06:40:28.365589+00	\N
71	38	52	Valide	2026-09-21 11:13:54.968875+00	\N
58	38	19	Refuse	2026-09-21 09:47:41.63285+00	\N
72	39	52	Refuse	2026-09-21 11:13:58.659186+00	\N
73	51	52	Refuse	2026-09-21 11:14:48.434891+00	\N
85	39	33	Valide	2026-09-22 11:09:25.699564+00	\N
60	39	19	Refuse	2026-09-21 09:48:11.882132+00	\N
59	40	20	Valide	2026-09-21 09:47:59.158184+00	\N
76	40	29	Refuse	2026-09-21 11:40:12.054843+00	\N
77	41	29	Valide	2026-09-21 11:40:36.510158+00	\N
75	44	27	Valide	2026-09-21 11:19:21.806645+00	\N
68	44	18	Refuse	2026-09-21 10:10:18.781645+00	\N
81	44	29	Refuse	2026-09-21 11:45:09.398764+00	\N
67	43	18	Valide	2026-09-21 10:10:04.765107+00	\N
80	43	29	Refuse	2026-09-21 11:45:08.276877+00	\N
64	46	6	Valide	2026-09-21 09:51:42.464998+00	\N
69	46	13	Refuse	2026-09-21 10:36:31.798984+00	\N
65	49	6	Refuse	2026-09-21 09:51:47.983176+00	\N
70	49	13	Valide	2026-09-21 10:36:39.067731+00	\N
61	51	19	Valide	2026-09-21 09:48:33.440835+00	\N
66	52	18	Valide	2026-09-21 10:09:55.639792+00	\N
86	50	45	Valide	2026-09-22 19:13:37.838915+00	\N
78	36	21	Valide	2026-09-21 11:43:17.994973+00	\N
79	37	21	Refuse	2026-09-21 11:43:19.291009+00	\N
82	48	28	Valide	2026-09-21 12:31:25.839137+00	\N
88	37	37	Valide	2026-09-24 10:23:10.234128+00	\N
90	47	54	Valide	2026-09-25 17:21:27.420101+00	\N
83	47	28	Refuse	2026-09-21 12:31:29.631687+00	\N
87	47	8	Refuse	2026-09-24 08:45:17.010898+00	\N
138	60	29	Valide	2026-09-28 13:11:19.660736+00	\N
152	60	26	Refuse	2026-09-28 17:26:05.553999+00	\N
137	57	29	Valide	2026-09-28 13:11:01.936381+00	\N
150	57	26	Refuse	2026-09-28 17:25:37.13087+00	\N
109	79	27	Valide	2026-09-28 12:10:12.150182+00	\N
108	78	27	Valide	2026-09-28 12:10:06.845444+00	\N
145	66	19	Valide	2026-09-28 14:07:07.092581+00	\N
164	66	9	Refuse	2026-09-28 20:16:14.761766+00	\N
104	66	52	Refuse	2026-09-28 12:07:58.605313+00	\N
107	70	17	Valide	2026-09-28 12:09:27.474939+00	\N
133	70	21	Refuse	2026-09-28 12:57:39.485741+00	\N
130	70	25	Refuse	2026-09-28 12:51:29.411403+00	\N
99	67	17	Valide	2026-09-28 12:06:02.865616+00	\N
132	67	21	Refuse	2026-09-28 12:56:27.540837+00	\N
131	67	25	Refuse	2026-09-28 12:51:34.856851+00	\N
165	65	9	Valide	2026-09-28 20:16:32.005069+00	\N
102	65	52	Refuse	2026-09-28 12:07:19.926134+00	\N
106	89	28	Valide	2026-09-28 12:08:29.81752+00	\N
147	89	36	Refuse	2026-09-28 17:03:30.430284+00	\N
166	74	28	Valide	2026-09-28 23:08:56.95161+00	\N
142	74	19	Refuse	2026-09-28 14:05:13.000929+00	\N
139	71	19	Refuse	2026-09-28 13:58:13.022433+00	\N
127	71	33	Refuse	2026-09-28 12:32:28.215651+00	\N
95	71	52	Refuse	2026-09-28 12:04:51.178726+00	\N
144	62	19	Refuse	2026-09-28 14:05:31.831552+00	\N
101	62	52	Refuse	2026-09-28 12:06:52.049587+00	\N
140	63	19	Refuse	2026-09-28 13:58:46.416606+00	\N
96	63	52	Refuse	2026-09-28 12:05:21.30514+00	\N
126	84	33	Valide	2026-09-28 12:31:42.301727+00	\N
115	69	4	Valide	2026-09-28 12:17:03.68576+00	\N
91	69	6	Refuse	2026-09-28 11:57:28.793072+00	\N
118	69	22	Refuse	2026-09-28 12:20:55.411791+00	\N
114	68	4	Valide	2026-09-28 12:16:07.381757+00	\N
92	68	6	Refuse	2026-09-28 11:57:51.647021+00	\N
123	68	13	Refuse	2026-09-28 12:24:51.623536+00	\N
141	53	19	Valide	2026-09-28 14:04:40.662615+00	\N
97	53	52	Refuse	2026-09-28 12:05:32.525329+00	\N
143	56	19	Valide	2026-09-28 14:05:19.212541+00	\N
100	56	52	Refuse	2026-09-28 12:06:43.427252+00	\N
136	54	21	Valide	2026-09-28 13:06:49.501885+00	\N
163	54	37	Refuse	2026-09-28 20:02:28.736473+00	\N
135	55	21	Valide	2026-09-28 13:06:39.786139+00	\N
160	55	37	Refuse	2026-09-28 19:16:39.721423+00	\N
151	64	26	Valide	2026-09-28 17:25:55.813837+00	\N
117	64	27	Refuse	2026-09-28 12:20:10.894047+00	\N
149	61	26	Valide	2026-09-28 17:25:33.235352+00	\N
116	61	27	Refuse	2026-09-28 12:19:42.159364+00	\N
161	94	37	Valide	2026-09-28 19:18:02.905469+00	\N
134	94	21	Refuse	2026-09-28 12:59:15.788148+00	\N
93	93	6	Valide	2026-09-28 11:58:06.501797+00	\N
113	93	4	Refuse	2026-09-28 12:15:37.500074+00	\N
125	93	13	Refuse	2026-09-28 12:27:54.856467+00	\N
124	81	27	Valide	2026-09-28 12:25:08.124102+00	\N
122	81	20	Refuse	2026-09-28 12:24:33.056296+00	\N
120	88	20	Valide	2026-09-28 12:23:59.831463+00	\N
121	88	27	Refuse	2026-09-28 12:24:32.381234+00	\N
159	88	45	Refuse	2026-09-28 18:51:56.428949+00	\N
110	86	27	Valide	2026-09-28 12:11:29.309013+00	\N
119	92	27	Refuse	2026-09-28 12:23:07.755712+00	\N
155	82	7	Refuse	2026-09-28 17:56:09.330164+00	\N
154	73	7	Refuse	2026-09-28 17:55:44.848521+00	\N
146	74	36	Refuse	2026-09-28 17:01:07.669468+00	\N
98	74	52	Refuse	2026-09-28 12:05:51.66951+00	\N
105	84	28	Refuse	2026-09-28 12:08:13.761246+00	\N
167	71	36	Valide	2026-09-28 23:10:26.590243+00	\N
168	62	36	Valide	2026-09-28 23:11:34.152657+00	\N
169	63	33	Valide	2026-09-28 23:12:40.357285+00	\N
158	61	45	Refuse	2026-09-28 18:51:39.550732+00	\N
148	81	26	Refuse	2026-09-28 17:25:23.500226+00	\N
171	85	53	Valide	2026-09-29 06:44:24.523175+00	\N
170	91	53	Refuse	2026-09-29 06:44:21.773715+00	\N
173	92	44	Valide	2026-09-29 08:22:56.079104+00	\N
172	92	20	Refuse	2026-09-29 07:12:47.28487+00	\N
174	75	20	Valide	2026-09-29 12:44:53.603344+00	\N
175	76	20	Refuse	2026-09-29 12:44:58.617775+00	\N
178	77	15	Valide	2026-09-29 17:12:27.041491+00	\N
179	80	15	Valide	2026-09-29 17:13:20.688174+00	\N
182	58	7	Valide	2026-09-29 18:30:55.322723+00	\N
181	59	7	Valide	2026-09-29 18:30:27.585481+00	\N
184	83	56	Valide	2026-09-30 07:18:18.384756+00	\N
183	90	56	Valide	2026-09-30 07:18:11.931424+00	\N
186	91	57	Valide	2026-09-30 12:52:14.264177+00	\N
187	72	48	Valide	2026-09-30 14:31:33.254397+00	\N
176	82	48	Refuse	2026-09-29 13:16:30.500104+00	\N
177	73	48	Valide	2026-09-29 13:17:42.384279+00	\N
188	82	60	Valide	2026-09-30 17:19:07.44251+00	\N
190	87	61	Valide	2026-10-01 12:47:50.428148+00	\N
185	87	7	Refuse	2026-09-30 12:35:37.887189+00	\N
191	76	36	Valide	2026-10-03 22:27:28.551201+00	\N
189	76	8	Refuse	2026-09-30 19:43:56.128943+00	\N
197	97	19	Valide	2026-10-05 09:19:53.687298+00	\N
241	97	52	Refuse	2026-10-05 11:36:02.801817+00	\N
198	96	19	Valide	2026-10-05 09:20:03.011539+00	\N
242	96	52	Refuse	2026-10-05 11:36:10.54856+00	\N
267	117	51	Valide	2026-10-06 08:24:39.654397+00	\N
228	109	51	Refuse	2026-10-05 11:14:04.130675+00	\N
268	120	51	Valide	2026-10-06 08:24:46.863834+00	\N
270	120	6	Refuse	2026-10-06 08:30:21.772821+00	\N
227	112	51	Refuse	2026-10-05 11:13:31.875526+00	\N
251	99	20	Valide	2026-10-05 11:50:26.530009+00	\N
217	99	26	Refuse	2026-10-05 10:57:46.390062+00	\N
261	100	20	Refuse	2026-10-05 19:20:48.331756+00	\N
250	118	36	Valide	2026-10-05 11:37:19.863444+00	\N
257	118	19	Refuse	2026-10-05 16:32:08.436618+00	\N
244	119	36	Valide	2026-10-05 11:36:35.015132+00	\N
255	119	19	Refuse	2026-10-05 16:31:42.02923+00	\N
235	102	13	Refuse	2026-10-05 11:26:30.929633+00	\N
280	129	61	Valide	2026-10-06 20:37:32.325212+00	\N
237	112	13	Refuse	2026-10-05 11:26:46.569699+00	\N
238	126	13	Refuse	2026-10-05 11:26:59.421184+00	\N
231	103	13	Refuse	2026-10-05 11:26:01.664533+00	\N
253	129	60	Refuse	2026-10-05 16:24:55.504524+00	\N
233	109	13	Refuse	2026-10-05 11:26:13.527966+00	\N
229	127	13	Refuse	2026-10-05 11:25:05.712595+00	\N
265	105	29	Valide	2026-10-05 21:52:40.000876+00	\N
208	105	26	Refuse	2026-10-05 10:56:17.903531+00	\N
264	108	29	Valide	2026-10-05 21:52:18.060699+00	\N
211	108	26	Refuse	2026-10-05 10:56:44.691716+00	\N
263	103	4	Valide	2026-10-05 21:37:53.617604+00	\N
262	102	4	Valide	2026-10-05 21:36:45.483784+00	\N
210	104	26	Valide	2026-10-05 10:56:39.191708+00	\N
212	114	26	Refuse	2026-10-05 10:56:50.514997+00	\N
213	128	26	Refuse	2026-10-05 10:57:03.846706+00	\N
207	101	26	Valide	2026-10-05 10:56:01.926824+00	\N
209	115	26	Refuse	2026-10-05 10:56:28.281775+00	\N
219	125	26	Refuse	2026-10-05 10:58:43.402102+00	\N
222	123	27	Valide	2026-10-05 11:01:39.481616+00	\N
214	123	26	Refuse	2026-10-05 10:57:16.138691+00	\N
221	122	27	Valide	2026-10-05 11:01:38.356706+00	\N
215	122	26	Refuse	2026-10-05 10:57:23.938496+00	\N
220	125	27	Valide	2026-10-05 11:00:10.94946+00	\N
245	125	20	Refuse	2026-10-05 11:36:50.600486+00	\N
256	113	19	Valide	2026-10-05 16:32:00.244943+00	\N
258	116	19	Valide	2026-10-05 16:32:33.984521+00	\N
226	130	10	Valide	2026-10-05 11:13:22.878226+00	\N
252	126	58	Valide	2026-10-05 13:18:02.23499+00	\N
225	126	6	Refuse	2026-10-05 11:11:58.225314+00	\N
224	127	6	Valide	2026-10-05 11:11:03.322368+00	\N
216	100	26	Valide	2026-10-05 10:57:45.303928+00	\N
196	100	4	Refuse	2026-10-05 09:16:48.794927+00	\N
249	128	20	Valide	2026-10-05 11:37:18.623572+00	\N
199	95	51	Retiree	2026-10-05 10:04:35.306032+00	Indisponibilité de dernière minute
232	107	13	Valide	2026-10-05 11:26:10.444769+00	\N
273	107	1	Refuse	2026-10-06 12:24:43.182832+00	\N
200	98	51	Retiree	2026-10-05 10:04:49.325266+00	Indisponibilité de dernière minute
236	106	13	Valide	2026-10-05 11:26:40.488052+00	\N
272	106	1	Refuse	2026-10-06 12:24:32.912568+00	\N
230	117	13	Retiree	2026-10-05 11:25:44.78057+00	Indisponibilité de dernière minute du professeur
234	120	13	Retiree	2026-10-05 11:26:28.528447+00	Indisponibilité de dernière minute du professeur
193	95	6	Valide	2026-10-05 07:52:53.812015+00	\N
195	95	13	Refuse	2026-10-05 08:07:06.655038+00	\N
192	98	6	Valide	2026-10-05 07:48:52.506936+00	\N
194	98	13	Refuse	2026-10-05 08:07:00.212971+00	\N
276	121	15	Valide	2026-10-06 15:24:14.620736+00	\N
277	124	15	Valide	2026-10-06 15:24:15.753378+00	\N
254	124	60	Refuse	2026-10-05 16:26:24.286911+00	\N
203	110	17	Valide	2026-10-05 10:23:09.333568+00	\N
240	110	21	Refuse	2026-10-05 11:33:35.047106+00	\N
260	110	25	Refuse	2026-10-05 18:23:16.736784+00	\N
223	111	17	Valide	2026-10-05 11:06:16.919246+00	\N
239	111	21	Refuse	2026-10-05 11:33:17.178253+00	\N
259	111	25	Refuse	2026-10-05 18:23:00.466728+00	\N
271	112	22	Valide	2026-10-06 10:33:36.246804+00	\N
269	112	6	Refuse	2026-10-06 08:30:13.188288+00	\N
281	109	22	Valide	2026-10-07 13:16:51.515975+00	\N
283	115	9	Valide	2026-10-07 18:38:24.328837+00	\N
278	115	20	Refuse	2026-10-06 18:15:22.08837+00	\N
282	114	9	Valide	2026-10-07 18:37:38.094181+00	\N
\.


--
-- Data for Name: professeurs; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.professeurs (id, nom, prenom, telephone, email, mot_de_passe, zone_id, matiere_principale_id, actif, date_inscription, valide) FROM stdin;
5	DAH HELOKONON	Pierre Padam	+2290161645378	padampierre@gmail.com	$2b$10$4IsqUEYwNHCTp53p9LgmUOUEyPS9Mt.RB01VtbMPne6fYc0wUmSyC	1	2	t	2026-09-07 15:20:07.03306+00	t
3	ZADJI	BIDOSSESSI ARNAUD	+2290166554564	arnaudzadji066@gmail.com	$2b$10$MdonLvpwbxKOt9uglF/db.8hQqgieTlmNai5cKfmk5eXx7rktFzwi	1	5	t	2026-09-07 15:09:05.591699+00	t
4	TOGBE	FINAGNON JOSEPH	+2290166452845	viptomtogbe@gmail.com	$2b$10$xxQgRaWKfkMIm8n8VIQ7sOoswkNCtQFOumKuW5wkOreT/eOZJBopi	1	5	t	2026-09-07 15:16:43.116863+00	t
6	HOUNKANRIN	Yélignan Charlie	+2290196726109	charliehounkanrin@gmail.com	$2b$10$r1foxUzvsAXyOk7f.9VK2ejCifzvT9h1dshzNd0oCpmgvcSTu84z.	1	5	t	2026-09-07 15:30:45.251101+00	t
7	ASSOGBA	Urbain	+2290196236082	piomedesse@gmail.com	$2b$10$Ou536r4hD.VP5tUKswtU1u2rOd8sFoE7R1CZ8aJYgkORZ/Q2Z11Zy	1	1	t	2026-09-07 15:37:54.254276+00	t
8	NOUTAÏ	Louis	+2290162701029	louislucnou@gmail.com	$2b$10$HfMzrB9Jz8VMb7wNmD.UEOPMD.ko1ms7AdiKhOX/fj7AHFQ9gnjA2	1	4	t	2026-09-07 15:47:20.464196+00	t
9	HINNOU	Florent	+2290166448873	florenthinnou@gmail.com	$2b$10$uwCZhDpx/bRNzn28gHgiXeb9Imu2TXcu9eXsbUYNazseNLEklTew2	1	4	t	2026-09-07 16:04:01.597518+00	t
10	CHANGODELE	Léopold	+2290196882898	leopoldchangodele@gmail.com	$2b$10$DVOIIPh9QL8ep4RCL.sti.Cld.kUX7..WCmgZDXuU0IwMUFKfWStK	1	7	t	2026-09-07 16:09:39.14622+00	t
11	FASSINOU	Auxence	+2290197778213	fauxence1994@gmail.com	$2b$10$9MTSxYbg9fTo2BfLqmkkxuEOZbc7VET0igMsdpZcoMWwPTX7hLWpa	1	5	t	2026-09-07 16:22:49.585802+00	t
12	ZOUTOUNNOU	A. Francis	+2290197843025	zoutounnouf@gmail.com	$2b$10$uWzL5ec5kKSvTK/IxmuFcO9jrV.AuJg5nPRGXpi.RFY8NAGo62gry	1	7	t	2026-09-07 16:26:55.709301+00	t
13	TOHON	Gaël	+2290166934654	mawougnongael91@gmail.com	$2b$10$VnupuCco55fmXRjV0gmJpuVfMio3GD/KnLqcObhL8CYcZXikw.kay	1	5	t	2026-09-07 16:33:23.410967+00	t
15	HOUETO	Olou Dayo Fabrice	+2290197307394	angekarson1@gmail.com	$2b$10$QR0f2.B7tWfZmHz40Iblm.ZDgJGlKpmBIFeYtZFey/VHXzNuMLMh.	1	1	t	2026-09-07 16:40:45.166297+00	t
14	KINNOUMIN	Sagbo William	+2290196777101	sagbowilliam@gmail.com	$2b$10$HF9LXbY6lUEw6t0KqQMN4eDYPkkz051bRsx0IPey0RQOXmyfsC0am	1	3	t	2026-09-07 16:39:31.016318+00	t
20	AKAKPO	CHARBEL ENOCK GERRY COMLAN	+2290155128706	akakpoenock00@gmail.com	$2b$10$TDGISQTfKwPIx48SmRevKOjyO6JinUpWR2IsAuQJfBvXXvlApmSuK	1	2	t	2026-09-07 17:50:27.251345+00	t
1	HOUEGBE	Uriel	+2290169974527	urielaxelhouegbe@gmail.com	$2b$10$kTFT24SIP1kiTHh.450jdepLCViUKeP/iN8GqsSu7snvTAROKciG.	1	2	t	2026-08-09 23:16:20.976307+00	t
16	HOUNZANDJI	Franck M.	+2290162209623	ricoferno@gmail.com	$2b$10$dW5PllkUYnVYjrJvYrToxOz0N60KyFC9S3M6zHaPJYp5B/O5cN1OC	1	1	t	2026-09-07 16:51:13.100552+00	t
17	DAASSI	Médesssè Ghislain	+2290197262346	ghics2000@yahoo.fr	$2b$10$YAMGptZYqPxCKZa/p4yd7Of07/LX75i27eKjJHkKbHEfubvfA0wsi	1	3	t	2026-09-07 16:59:02.36753+00	t
19	TOVITCHEDE	Gédéon	+2290167740109	gedeonfintovitchede@gmail.com	$2b$10$dAtyaDKOBBMEC.MqO67HKOEUPDDeCKircgaFkQop9Ga1ht18nf022	1	4	t	2026-09-07 17:16:05.838767+00	t
18	AGBO	ALDO GERANCE	+2290197860770	aldolalumiere80@gmail.com	$2b$10$r63GiFspBvXC9YTwlpP8vOMccqIj9CF2GzEo0od3jQE8JBqRcZhF2	1	2	t	2026-09-07 17:16:00.073685+00	t
22	AGOSSOU	Ferdinand Virgile	+2290161654101	ferdinandagossou03@gmail.com	$2b$10$5hMOkA8AXzTeziZzmzLLOegWNOPzYwoz/a/NMeKhLmbqK/CGbtOP.	1	5	t	2026-09-07 19:30:57.180675+00	t
21	KINNINNON	Claude	+2290166879680	claudekinninnon@gmail.com	$2b$10$.L6Tx/VUxqKBoThhgm013ese5/oN9h/FHvroJTKjuuxDxZkvn8jLG	1	3	t	2026-09-07 18:53:08.382903+00	t
23	BOKONONHOUI	Eddy Carlos	+2290194259272	carlosbokononhoui@gmail.com	$2b$10$4VHjI5OOFmYdWEGH.YeMsOrIJN0RYwaxbO8/prB/ygHBRljcGcC56	1	3	t	2026-09-07 19:54:56.654117+00	t
24	Noutahi	Augustin	+2290196346526	enagnonaugustinnoutahi@gmail.com	$2b$10$V2.cPe76c7/.38fsbguRf.ed7lS858x.yzwPBAjpAbeImoATlmtoi	1	7	t	2026-09-07 20:08:08.23039+00	t
25	AREMOU	Ramziath	+2290140566832	aremouramziath@gmail.com	$2b$10$CzZJc1rMNsnOumuw7kTSIOGm/kmZn4YkzMC0IRbZ/MAWKUjwRbepy	1	3	t	2026-09-07 20:33:07.194578+00	t
26	Aremou	Farouk	+2290196684830	faroukaremou5@gmail.com	$2b$10$QCeLd.Y7lETDpHSy/Yry2uRllU9T./THbVuhGfoa5M6c/Cp89bkxq	1	2	t	2026-09-07 20:57:10.268132+00	t
30	AZANKPO	Aurel Godfrid	+2290196753761	aurelgodfrid2@gmail.com	$2b$10$yea0eflWIT0ctpBgzdWra.XtDH3iC2fXU006OuHIsHMC1hjiFXroO	1	3	t	2026-09-08 11:33:12.545915+00	t
29	DOSSA	Koba Hubert	+2290166890982	dkobahubert@gmail.com	$2b$10$5cT6jt5..Zf3QV4flbu4/ONTyvTkfzvfyz20t9Z9CbKyCyvauay3y	1	2	t	2026-09-08 00:28:39.3725+00	t
28	EKPONNATON	Comalan Jean-Claude	+2290166243602	ekponnatonjeanclaude@gmail.com	$2b$10$ETcYHDbK1pdCbv57ut.HPexsKMq6HCCEWSceShPXRD7il3Qb05Ts.	1	4	t	2026-09-07 22:51:24.68692+00	t
32	HOUNKPONOU	Horus	+2290167190204	hounkponouhorus@gmail.com	$2b$10$oksIl8RT8TrmV3eQ278avOOdazZKZLysNZpI4haZCopLA27AsF2n.	1	4	t	2026-09-08 17:24:50.376996+00	t
31	Lassissi	Saïbou Adéhoumi	+2290197477948	lassissisaibouadehoumi@gmail.com	$2b$10$zbNRVhUvwIGKV0VdsEso.uOwQwwgzJ5AwH1YcmHXk3bX8YOedKdZ.	1	2	t	2026-09-08 17:15:32.395144+00	t
34	HOUNKOKOE	Saho paul	+2290196979325	sahopaulh@gmail.com	$2b$10$LxKQYrPcoleDMv6GOUl4mOUCZpLFLUEnwBN5QT20Rp82qhMHRsJEG	1	4	t	2026-09-08 17:38:02.222383+00	t
33	ABIDEGBE KPONOU	Jérémie	+2290195932270	jeremieabidegbekponou@gmail.com	$2b$10$TDZbm4d4MMr3o8JAL2wlcOFOVdcFqlnnTkR9sR5ck3YgMsTOst4c6	1	4	t	2026-09-08 17:36:35.177963+00	t
35	ADJOVI	Romaric Cédrick	+2290156848593	romaricadjovi12@gmail.com	$2b$10$1JOrDSN.GwBC0tFvKFqVZO9MVgexr3fxX02g.C.V9l0CurQsWz3dK	1	7	t	2026-09-08 17:50:25.484868+00	t
36	MAGBONDE	Samson	+2290169002846	magbondejerome@gmail.com	$2b$10$.VDc2YJMS.LWzLj0/3XEEOb9cfHq/DH3GkKxKKZwWdf9j.8As0zzm	1	4	t	2026-09-08 17:53:11.112175+00	t
41	HOUESSOU	Evance Samuel	+2290196535520	houess86@gmail.com	$2b$10$vT2ED/UCpqr9zlp9ETSUG.qdTcpuDICI5pK.cY6cCBjFeQi.bB8Zu	1	5	t	2026-09-08 19:30:31.281232+00	t
40	Avocevou	Emmanuel	+2290154916157	avocevouemmanuel5@gmail.com	$2b$10$kWrvQlHex6kv9Z93e2AXmOpzejxeeHGTrVyr8T9/zQoqAqOv9mCci	1	10	t	2026-09-08 19:26:44.260507+00	t
39	NOUDOFININ	ARMEL	+2290167814221	armelnou@gmail.com	$2b$10$T9/gKmTE8PnrcEXRrtE6senSL5jAlabjkg5OxLyixoOTzg0DnIWhC	1	4	t	2026-09-08 18:36:37.661067+00	t
38	SOGLOHOUN	Fortuné	+2290161221159	soglohounfortun93@gmail.com	$2b$10$jhjqqcq7e3X2EpLUfw5E7uVZ4JtffeUxIfmwq7yhSiVYVO.beauIW	1	4	t	2026-09-08 18:28:36.420445+00	t
37	KIKI	S. Siméon	+2290197300324	simkiki30@gmail.com	$2b$10$XCoAcD5U91s6Vsw5MxH48.3i9N8Qd7EFaOG6bG/J.lNlKq3V.EhUi	1	3	t	2026-09-08 18:12:30.520562+00	t
42	DOMESSI	LEON	+2290161366184	leondomessi04@gmail.com	$2b$10$3EtkWHQ5uCMUeV4dhlGlreFdAO1DzLmPfNda5z0rzK/gE545AiGYK	1	5	t	2026-09-08 21:07:27.12653+00	t
43	KOUTON	Jesugnon Anicet	+2290196058903	anicetjesougnon@gmail.com	$2b$10$fW5tR00i6aEu2smXwGHGouYNgBdS8JxUmgRNIlxhG8KPL0o.yOOiG	1	2	t	2026-09-08 21:16:12.672996+00	t
27	AMANKPE	Modeste	+2290169264439	amankpemodeste761@gmail.com	$2b$10$eQPgW/zir60GII0LFG1EyOiwec8VNHZe7Eth/saTeh0a69NFjXY0a	1	2	t	2026-09-07 21:05:16.709715+00	t
60	BOSSOU	Kossoun Raoul	+2290194737866	bossouraoul82@gmail.com	$2b$10$e2u07LvxMbGLJ3mOTICRtOdMQqqxPoHF2RADPzESlmQQMRi25BeHe	1	1	t	2026-09-30 17:04:27.540989+00	t
45	HOLONOU	Maougnon Bienvenu	+2290161111852	holonoubienvenu@gmail.com	$2b$10$fHsjJeEr9x3lzdVk9Bk.mO4QvSnUGcqXNkhmzc8NCNBDz861u0COu	1	2	t	2026-09-08 21:49:05.914602+00	t
44	Dansou	Mika	+2290167361065	dansoumika8@gmail.com	$2b$10$l7/KgSOdNoLEPWSh8x1Zrumyj/dzBeNZfJM9NSKKP6R.Gp.KAfn9O	1	2	t	2026-09-08 21:38:33.941449+00	t
58	HLANNON	Yévèdo Paulin	+2290196023399	nistani21@gmail.com	$2b$10$AQgmGwHMYjDhhG3ASl3t.e5q5DEU/3vjHwRSaiL2LRUMgf68iKTAa	1	5	t	2026-09-30 14:45:48.918509+00	t
46	AHOUNHOSSE	Merveille	+2290190830964	merveilleahounhosse54@gmail.com	$2b$10$VIRoeiFptU5JJalxkoVxy.ndQwqyHonWQ9QfuBofpeisd6waQelMK	1	1	t	2026-09-08 22:54:00.098572+00	t
61	AZANDOHOUNSI	Luc	+2290140167020	lucazandohounsi65@gmail.com	$2b$10$A1/xrUl0OWkYNSHQJBI4iORgyAz6pUV2WoMaFlzQY8PR6PIzX2kXa	1	1	t	2026-10-01 11:27:50.341128+00	t
51	SEDODE	Godfroy	+2290167290755	sedodeconstant@gmail.com	$2b$10$iDRpD3wOcQ1bLWNJJsK0eefJRg0XDvjy2Fiol.FOLfluyU.T6OlD.	1	5	t	2026-09-09 15:53:54.532273+00	t
50	TODE	Kouami Mauriéna	+2290166052359	kouamitode@gmail.com	$2b$10$SvHi.h25LbKxtssJdJabPOiAKegHzxMa.FpXlQ27Aln.8Pxoa6pDq	1	4	t	2026-09-09 10:34:32.483812+00	t
49	DOSSOU	Brice	+2290197186706	doskice@gmail.com	$2b$10$Z4tnxUMEx82Gq0REEHWSCeKzo0p1czDxZ2sdwzmfQ7n4J3RedHtKa	1	9	t	2026-09-09 07:58:53.677396+00	t
47	DJOSSOU	GERMAIN	+2290166583113	djossougermain0@gmail.com	$2b$10$bLLFCJvxryVygRBV3XAhr.K4aJpyixpglBm5/raNBiAYDJ5vpLbfO	1	4	t	2026-09-09 06:05:16.756917+00	t
52	SEFAN	Dègnon Frédéric	+2290161335492	degnonfrederics@gmail.com	$2b$10$u9g9RH41q1k05DcN39E6aOetO6A70c1SPdNOEEEm.zSH4mowBJpMO	1	4	t	2026-09-09 18:22:50.704256+00	t
53	TOTIN	MARIANO	+2290197243191	marianototin@gmail.com	$2b$10$Fqbd8hRT2tVmJbNFeldk1ehe2hCOT8vlj9h.9saSNyMoTxVkPn7ei	1	8	t	2026-09-11 07:17:19.032568+00	t
48	YESSOUFOU	Assiath	+2290194001802	yessoufouassiath@gmail.com	$2b$10$w3THhZeA8Hig0Tf.sqL5jutQBBBN/TchGYnql5NrYkzXRn9cU328m	1	1	t	2026-09-09 06:50:20.100978+00	t
54	Codjo	Jean Eudes	+2290196386249	codjoabel00@gmail.com	$2b$10$cSehywwb.ASIbmpIBvU7cefzCMgzU3Z6QO6OiAzIjf4uxaHfF8GwG	1	4	t	2026-09-25 17:05:04.634948+00	t
56	EDOU	Louis Bienvenu	+2290152266712	bienvenuedou112@gmail.com	$2b$10$lgs580QoOWHKWG7YHYLXgOXDxqLMnD98AzJQy9prX3izH9TZGurEC	1	6	t	2026-09-29 08:40:33.51473+00	t
57	DOVENON	Cossi Marcellin	+2290164234947	marcepepe@gmail.com	$2b$10$40eSYDYjjZHugTfDF4u7lenEViSuSnedAbr/YrKHkumwqUMJM7d/2	1	8	t	2026-09-30 12:45:06.666461+00	t
59	HOTO	Jules Akpé	+2290196976220	hotojules@gmail.com	$2b$10$V3vxVdjfYgxu8gfGR0Wz/e5KKJDReN3tLcGuha1/IabPtp0mx2lvi	1	1	t	2026-09-30 16:35:46.604622+00	t
55	Adjaho	Camille	+2290155963714	adjahocamille249@gmail.com	$2b$10$GKuBfsr/h9Qi3ZsSsdjOaOJg9TPZyypDviAbzB68tVVxsvU7kNQ7q	1	4	t	2026-09-28 13:45:14.1173+00	t
\.


--
-- Data for Name: semaines; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.semaines (id, libelle, date_debut, date_fin, statut, date_creation, date_cloture) FROM stdin;
13	Semaine 1	2026-09-14	2026-09-20	cloturee	2026-09-14 02:28:21.066135+00	2026-09-20 09:11:44.09+00
14	Semaine 2	2026-09-21	2026-09-27	cloturee	2026-09-21 09:09:35.939759+00	2026-09-27 06:26:54.599+00
15	Semaine 3	2026-09-28	2026-10-04	cloturee	2026-09-28 10:12:52.58795+00	2026-10-05 07:02:01.277+00
16	Semaine 4	2026-10-05	2026-10-11	publiee	2026-10-05 07:04:46.486298+00	\N
\.


--
-- Data for Name: zones; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.zones (id, nom_zone) FROM stdin;
1	Cotonou 
3	Parakou 
\.


--
-- Name: actualites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_id_seq', 3, true);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_images_id_seq', 3, true);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.annees_scolaires_id_seq', 1, true);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_depenses_id_seq', 12, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.classes_id_seq', 28, true);


--
-- Name: coefficients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.coefficients_id_seq', 186, true);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comptes_parents_id_seq', 1, false);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.decisions_passage_id_seq', 2, true);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.depenses_annexes_id_seq', 14, true);


--
-- Name: eleves_exonerations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_exonerations_id_seq', 38, true);


--
-- Name: eleves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_id_seq', 1162, true);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_suspendus_id_seq', 1, false);


--
-- Name: frais_td_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frais_td_id_seq', 28, true);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_admin_id_seq', 2, true);


--
-- Name: galerie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_id_seq', 1, false);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_whatsapp_id_seq', 1, false);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_attempts_id_seq', 1460, true);


--
-- Name: matieres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matieres_id_seq', 11, true);


--
-- Name: mois_exoneres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mois_exoneres_id_seq', 142, true);


--
-- Name: moyennes_semestrielles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.moyennes_semestrielles_id_seq', 2, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 307, true);


--
-- Name: paiements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_id_seq', 294, true);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_supprimes_id_seq', 2, true);


--
-- Name: penalites_reinscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.penalites_reinscription_id_seq', 1, false);


--
-- Name: presences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.presences_id_seq', 2404, true);


--
-- Name: recompenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recompenses_id_seq', 1, false);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 2, true);


--
-- Name: creneaux_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.creneaux_id_seq', 130, true);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.matieres_td_id_seq', 11, true);


--
-- Name: postulations_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.postulations_id_seq', 283, true);


--
-- Name: professeurs_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.professeurs_id_seq', 61, true);


--
-- Name: semaines_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.semaines_id_seq', 16, true);


--
-- Name: zones_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.zones_id_seq', 3, true);


--
-- Name: actualites_images actualites_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_pkey PRIMARY KEY (id);


--
-- Name: actualites actualites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_pkey PRIMARY KEY (id);


--
-- Name: annees_scolaires annees_scolaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires
    ADD CONSTRAINT annees_scolaires_pkey PRIMARY KEY (id);


--
-- Name: categories_depenses categories_depenses_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_nom_key UNIQUE (nom);


--
-- Name: categories_depenses categories_depenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_pkey PRIMARY KEY (id);


--
-- Name: classes classes_nom_classe_site_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_nom_classe_site_id_key UNIQUE (nom_classe, site_id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: coefficients coefficients_classe_id_matiere_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_matiere_id_key UNIQUE (classe_id, matiere_id);


--
-- Name: coefficients coefficients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_pkey PRIMARY KEY (id);


--
-- Name: comptes_parents comptes_parents_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_matricule_key UNIQUE (matricule);


--
-- Name: comptes_parents comptes_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_pkey PRIMARY KEY (id);


--
-- Name: decisions_passage decisions_passage_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_key UNIQUE (eleve_id);


--
-- Name: decisions_passage decisions_passage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_pkey PRIMARY KEY (id);


--
-- Name: depenses_annexes depenses_annexes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_pkey PRIMARY KEY (id);


--
-- Name: eleves_exonerations eleves_exonerations_eleve_id_annee_scolaire_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_eleve_id_annee_scolaire_id_key UNIQUE (eleve_id, annee_scolaire_id);


--
-- Name: eleves_exonerations eleves_exonerations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_pkey PRIMARY KEY (id);


--
-- Name: eleves eleves_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_matricule_key UNIQUE (matricule);


--
-- Name: eleves eleves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_pkey PRIMARY KEY (id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_key UNIQUE (eleve_id);


--
-- Name: eleves_suspendus eleves_suspendus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_pkey PRIMARY KEY (id);


--
-- Name: frais_td frais_td_classe_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_key UNIQUE (classe_id);


--
-- Name: frais_td frais_td_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_pkey PRIMARY KEY (id);


--
-- Name: galerie_admin galerie_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_pkey PRIMARY KEY (id);


--
-- Name: galerie galerie_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie
    ADD CONSTRAINT galerie_pkey PRIMARY KEY (id);


--
-- Name: log_whatsapp log_whatsapp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: matieres matieres_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_code_key UNIQUE (code);


--
-- Name: matieres matieres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_pkey PRIMARY KEY (id);


--
-- Name: mois_exoneres mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_mois_souscription_annee_scolaire_id_key UNIQUE (eleve_id, mois_souscription, annee_scolaire_id);


--
-- Name: mois_exoneres mois_exoneres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_pkey PRIMARY KEY (id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_annee_scolaire_id_semestre_key UNIQUE (eleve_id, annee_scolaire_id, semestre);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_pkey PRIMARY KEY (id);


--
-- Name: notes notes_eleve_matiere_type_annee_semestre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_matiere_type_annee_semestre_key UNIQUE (eleve_id, matiere_id, type_note, annee_scolaire_id, semestre);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: paiements paiements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_pkey PRIMARY KEY (id);


--
-- Name: paiements_supprimes paiements_supprimes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_pkey PRIMARY KEY (id);


--
-- Name: penalites_reinscription penalites_reinscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_pkey PRIMARY KEY (id);


--
-- Name: presences presences_eleve_id_date_presence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_date_presence_key UNIQUE (eleve_id, date_presence);


--
-- Name: presences presences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_pkey PRIMARY KEY (id);


--
-- Name: recompenses recompenses_note_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_key UNIQUE (note_id);


--
-- Name: recompenses recompenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_pkey PRIMARY KEY (id);


--
-- Name: sites sites_initiale_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_initiale_key UNIQUE (initiale);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: user_sites user_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_pkey PRIMARY KEY (user_id, site_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: creneaux creneaux_classe_id_date_td_heure_debut_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_date_td_heure_debut_key UNIQUE (classe_id, date_td, heure_debut);


--
-- Name: creneaux creneaux_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_pkey PRIMARY KEY (id);


--
-- Name: matieres_td matieres_td_nom_matiere_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_nom_matiere_key UNIQUE (nom_matiere);


--
-- Name: matieres_td matieres_td_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_pkey PRIMARY KEY (id);


--
-- Name: postulations postulations_creneau_id_professeur_id_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_professeur_id_key UNIQUE (creneau_id, professeur_id);


--
-- Name: postulations postulations_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_email_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_email_key UNIQUE (email);


--
-- Name: professeurs professeurs_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_telephone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_telephone_key UNIQUE (telephone);


--
-- Name: semaines semaines_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines
    ADD CONSTRAINT semaines_pkey PRIMARY KEY (id);


--
-- Name: zones zones_nom_zone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_nom_zone_key UNIQUE (nom_zone);


--
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id);


--
-- Name: idx_login_attempts_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_attempts_lookup ON public.login_attempts USING btree (identifiant, portail, date_tentative);


--
-- Name: idx_professeurs_valide; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_professeurs_valide ON td.professeurs USING btree (valide) WHERE (valide = false);


--
-- Name: frais_td trg_frais_td_lock_period; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_frais_td_lock_period BEFORE UPDATE OF montant ON public.frais_td FOR EACH ROW EXECUTE FUNCTION public.trg_frais_td_lock_period_fn();


--
-- Name: annees_scolaires trg_unique_annee_en_cours; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_unique_annee_en_cours BEFORE INSERT OR UPDATE ON public.annees_scolaires FOR EACH ROW EXECUTE FUNCTION public.trg_unique_annee_en_cours_fn();


--
-- Name: users trg_users_scope_coherence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_scope_coherence BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.trg_users_scope_coherence_fn();


--
-- Name: postulations trg_check_max_postulations; Type: TRIGGER; Schema: td; Owner: -
--

CREATE TRIGGER trg_check_max_postulations BEFORE INSERT ON td.postulations FOR EACH ROW EXECUTE FUNCTION td.check_max_postulations();


--
-- Name: actualites actualites_cree_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_cree_par_fkey FOREIGN KEY (cree_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: actualites_images actualites_images_actualite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_actualite_id_fkey FOREIGN KEY (actualite_id) REFERENCES public.actualites(id) ON DELETE CASCADE;


--
-- Name: classes classes_classe_suivante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_classe_suivante_id_fkey FOREIGN KEY (classe_suivante_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: classes classes_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: decisions_passage decisions_passage_decide_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_decide_par_fkey FOREIGN KEY (decide_par) REFERENCES public.users(id);


--
-- Name: decisions_passage decisions_passage_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_nouvelle_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_nouvelle_classe_id_fkey FOREIGN KEY (nouvelle_classe_id) REFERENCES public.classes(id);


--
-- Name: depenses_annexes depenses_annexes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_categorie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_categorie_id_fkey FOREIGN KEY (categorie_id) REFERENCES public.categories_depenses(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_saisi_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_saisi_par_fkey FOREIGN KEY (saisi_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: eleves eleves_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: eleves_exonerations eleves_exonerations_accorde_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_accorde_par_fkey FOREIGN KEY (accorde_par) REFERENCES public.users(id);


--
-- Name: eleves_exonerations eleves_exonerations_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: eleves_exonerations eleves_exonerations_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_exonerations
    ADD CONSTRAINT eleves_exonerations_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_suspendu_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_suspendu_par_fkey FOREIGN KEY (suspendu_par) REFERENCES public.users(id);


--
-- Name: frais_td frais_td_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: galerie_admin galerie_admin_ajoute_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_ajoute_par_fkey FOREIGN KEY (ajoute_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: log_whatsapp log_whatsapp_envoye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_envoye_par_fkey FOREIGN KEY (envoye_par) REFERENCES public.users(id);


--
-- Name: mois_exoneres mois_exoneres_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: mois_exoneres mois_exoneres_exonere_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mois_exoneres
    ADD CONSTRAINT mois_exoneres_exonere_par_fkey FOREIGN KEY (exonere_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: moyennes_semestrielles moyennes_semestrielles_cloture_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_cloture_par_fkey FOREIGN KEY (cloture_par) REFERENCES public.users(id);


--
-- Name: moyennes_semestrielles moyennes_semestrielles_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.moyennes_semestrielles
    ADD CONSTRAINT moyennes_semestrielles_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: notes notes_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: paiements_supprimes paiements_supprimes_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: penalites_reinscription penalites_reinscription_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: penalites_reinscription penalites_reinscription_enregistre_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalites_reinscription
    ADD CONSTRAINT penalites_reinscription_enregistre_par_fkey FOREIGN KEY (enregistre_par) REFERENCES public.users(id);


--
-- Name: presences presences_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: presences presences_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: presences presences_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: presences presences_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_depense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_depense_id_fkey FOREIGN KEY (depense_id) REFERENCES public.depenses_annexes(id) ON DELETE SET NULL;


--
-- Name: recompenses recompenses_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(id) ON DELETE CASCADE;


--
-- Name: recompenses recompenses_paye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recompenses
    ADD CONSTRAINT recompenses_paye_par_fkey FOREIGN KEY (paye_par) REFERENCES public.users(id);


--
-- Name: user_sites user_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: user_sites user_sites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users users_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: creneaux creneaux_classe_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_matiere_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_semaine_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_semaine_id_fkey FOREIGN KEY (semaine_id) REFERENCES td.semaines(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_creneau_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_fkey FOREIGN KEY (creneau_id) REFERENCES td.creneaux(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_professeur_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_professeur_id_fkey FOREIGN KEY (professeur_id) REFERENCES td.professeurs(id) ON DELETE CASCADE;


--
-- Name: professeurs professeurs_matiere_principale_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_matiere_principale_id_fkey FOREIGN KEY (matiere_principale_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: professeurs professeurs_zone_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES td.zones(id) ON DELETE RESTRICT;


--
-- Name: actualites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites_images ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images actualites_images_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_images_lecture_publique ON public.actualites_images FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.actualites a
  WHERE ((a.id = actualites_images.actualite_id) AND (a.statut = 'publie'::text)))));


--
-- Name: actualites actualites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_lecture_publique ON public.actualites FOR SELECT USING ((statut = 'publie'::text));


--
-- Name: annees_scolaires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.annees_scolaires ENABLE ROW LEVEL SECURITY;

--
-- Name: annees_scolaires annees_scolaires_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY annees_scolaires_lecture_staff ON public.annees_scolaires FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: categories_depenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.categories_depenses ENABLE ROW LEVEL SECURITY;

--
-- Name: categories_depenses categories_depenses_lecture_global; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY categories_depenses_lecture_global ON public.categories_depenses FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: classes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;

--
-- Name: classes classes_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_publique ON public.classes FOR SELECT TO anon USING (true);


--
-- Name: classes classes_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_staff ON public.classes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: coefficients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coefficients ENABLE ROW LEVEL SECURITY;

--
-- Name: coefficients coefficients_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY coefficients_lecture_staff ON public.coefficients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: comptes_parents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.comptes_parents ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decisions_passage ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage decisions_passage_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY decisions_passage_lecture ON public.decisions_passage FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: depenses_annexes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.depenses_annexes ENABLE ROW LEVEL SECURITY;

--
-- Name: depenses_annexes depenses_annexes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY depenses_annexes_lecture ON public.depenses_annexes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: eleves; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves eleves_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_acces ON public.eleves USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM (public.user_sites us
             JOIN public.classes c ON ((c.id = eleves.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM public.classes c
          WHERE ((c.id = eleves.classe_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: eleves_exonerations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves_exonerations ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves_exonerations eleves_exonerations_ecriture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_exonerations_ecriture ON public.eleves_exonerations USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: eleves_exonerations eleves_exonerations_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_exonerations_lecture ON public.eleves_exonerations FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = eleves_exonerations.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: eleves_suspendus; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves_suspendus ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves_suspendus eleves_suspendus_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_suspendus_acces ON public.eleves_suspendus USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = eleves_suspendus.site_id))))))))));


--
-- Name: frais_td; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.frais_td ENABLE ROW LEVEL SECURITY;

--
-- Name: frais_td frais_td_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY frais_td_lecture_staff ON public.frais_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: galerie; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie_admin ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin galerie_admin_ajout; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_ajout ON public.galerie_admin FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_lecture ON public.galerie_admin FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text]))))));


--
-- Name: galerie_admin galerie_admin_suppression; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_suppression ON public.galerie_admin FOR DELETE USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text])) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (galerie_admin.ajoute_par = auth.uid())))))));


--
-- Name: galerie galerie_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_lecture_publique ON public.galerie FOR SELECT USING (true);


--
-- Name: log_whatsapp; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.log_whatsapp ENABLE ROW LEVEL SECURITY;

--
-- Name: log_whatsapp log_whatsapp_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY log_whatsapp_acces ON public.log_whatsapp FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON (((e.matricule)::text = (log_whatsapp.matricule)::text)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: login_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.matieres ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres matieres_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY matieres_lecture_staff ON public.matieres FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: mois_exoneres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mois_exoneres ENABLE ROW LEVEL SECURITY;

--
-- Name: mois_exoneres mois_exoneres_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mois_exoneres_acces ON public.mois_exoneres USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = mois_exoneres.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: moyennes_semestrielles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.moyennes_semestrielles ENABLE ROW LEVEL SECURITY;

--
-- Name: moyennes_semestrielles moyennes_semestrielles_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY moyennes_semestrielles_acces ON public.moyennes_semestrielles USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = moyennes_semestrielles.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = moyennes_semestrielles.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: notes notes_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notes_acces ON public.notes USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = notes.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = notes.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_acces ON public.notifications FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((notifications.roles_cibles IS NULL) OR (u.role = ANY (notifications.roles_cibles))) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = notifications.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = notifications.site_id)))))));


--
-- Name: paiements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements paiements_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_acces ON public.paiements USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = paiements.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: paiements_supprimes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements_supprimes ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements_supprimes paiements_supprimes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_supprimes_lecture ON public.paiements_supprimes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: penalites_reinscription; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.penalites_reinscription ENABLE ROW LEVEL SECURITY;

--
-- Name: penalites_reinscription penalites_reinscription_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY penalites_reinscription_acces ON public.penalites_reinscription USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = penalites_reinscription.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: presences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.presences ENABLE ROW LEVEL SECURITY;

--
-- Name: presences presences_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY presences_acces ON public.presences USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = presences.site_id))))) OR ((u.role = ANY (ARRAY['chef_site'::text, 'secretaire'::text])) AND (u.site_id = presences.site_id)))))));


--
-- Name: recompenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recompenses ENABLE ROW LEVEL SECURITY;

--
-- Name: recompenses recompenses_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY recompenses_acces ON public.recompenses USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = recompenses.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: sites sites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_publique ON public.sites FOR SELECT TO anon USING (true);


--
-- Name: sites sites_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_staff ON public.sites FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: user_sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_sites ENABLE ROW LEVEL SECURITY;

--
-- Name: user_sites user_sites_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_sites_lecture_soi_meme ON public.user_sites FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_soi_meme ON public.users FOR SELECT USING ((id = auth.uid()));


--
-- Name: users users_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_staff ON public.users FOR SELECT USING ((auth.role() = 'authenticated'::text));


--
-- Name: creneaux; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.creneaux ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres_td; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.matieres_td ENABLE ROW LEVEL SECURITY;

--
-- Name: postulations; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.postulations ENABLE ROW LEVEL SECURITY;

--
-- Name: professeurs; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.professeurs ENABLE ROW LEVEL SECURITY;

--
-- Name: semaines; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.semaines ENABLE ROW LEVEL SECURITY;

--
-- Name: creneaux td_creneaux_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_coordonnateur ON td.creneaux FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: creneaux td_creneaux_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_publique ON td.creneaux FOR SELECT TO anon USING (((statut_creneau = ANY (ARRAY['public'::text, 'cloture'::text])) AND (EXISTS ( SELECT 1
   FROM td.semaines s
  WHERE ((s.id = creneaux.semaine_id) AND (s.statut = 'publiee'::text))))));


--
-- Name: matieres_td td_matieres_td_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_coordonnateur ON td.matieres_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: matieres_td td_matieres_td_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_publique ON td.matieres_td FOR SELECT TO anon USING (true);


--
-- Name: postulations td_postulations_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_postulations_lecture_coordonnateur ON td.postulations FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: professeurs td_professeurs_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_professeurs_lecture_coordonnateur ON td.professeurs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_coordonnateur ON td.semaines FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_publique; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_publique ON td.semaines FOR SELECT TO anon USING ((statut = 'publiee'::text));


--
-- Name: zones td_zones_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_zones_lecture_coordonnateur ON td.zones FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: zones; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.zones ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict H4jzywpEmueTgd9JZYe8oIysI6hupx8qvgqOK1R0BBvgLyq5meU1nRu7Up1JMOg


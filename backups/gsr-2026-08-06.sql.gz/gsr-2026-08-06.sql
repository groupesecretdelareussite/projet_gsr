--
-- PostgreSQL database dump
--

\restrict m9pQybpele2TZmps7xIuSImG3z4qVVOS1SBAm2gsATTFuS8QDjqjNSYPn8QfRKG

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS td_zones_lecture_coordonnateur ON td.zones;
DROP POLICY IF EXISTS td_semaines_lecture_coordonnateur ON td.semaines;
DROP POLICY IF EXISTS td_professeurs_lecture_coordonnateur ON td.professeurs;
DROP POLICY IF EXISTS td_postulations_lecture_coordonnateur ON td.postulations;
DROP POLICY IF EXISTS td_matieres_td_lecture_coordonnateur ON td.matieres_td;
DROP POLICY IF EXISTS td_creneaux_lecture_coordonnateur ON td.creneaux;
DROP POLICY IF EXISTS td_classes_td_lecture_coordonnateur ON td.classes_td;
DROP POLICY IF EXISTS users_lecture_soi_meme ON public.users;
DROP POLICY IF EXISTS user_sites_lecture_soi_meme ON public.user_sites;
DROP POLICY IF EXISTS sites_lecture_staff ON public.sites;
DROP POLICY IF EXISTS presences_acces ON public.presences;
DROP POLICY IF EXISTS paiements_supprimes_lecture ON public.paiements_supprimes;
DROP POLICY IF EXISTS paiements_acces ON public.paiements;
DROP POLICY IF EXISTS notifications_acces ON public.notifications;
DROP POLICY IF EXISTS notes_acces ON public.notes;
DROP POLICY IF EXISTS matieres_lecture_staff ON public.matieres;
DROP POLICY IF EXISTS log_whatsapp_acces ON public.log_whatsapp;
DROP POLICY IF EXISTS galerie_lecture_publique ON public.galerie;
DROP POLICY IF EXISTS galerie_admin_acces ON public.galerie_admin;
DROP POLICY IF EXISTS frais_td_lecture_staff ON public.frais_td;
DROP POLICY IF EXISTS eleves_suspendus_acces ON public.eleves_suspendus;
DROP POLICY IF EXISTS eleves_acces ON public.eleves;
DROP POLICY IF EXISTS depenses_annexes_lecture ON public.depenses_annexes;
DROP POLICY IF EXISTS decisions_passage_lecture ON public.decisions_passage;
DROP POLICY IF EXISTS coefficients_lecture_staff ON public.coefficients;
DROP POLICY IF EXISTS classes_lecture_staff ON public.classes;
DROP POLICY IF EXISTS categories_depenses_lecture_global ON public.categories_depenses;
DROP POLICY IF EXISTS annees_scolaires_lecture_staff ON public.annees_scolaires;
DROP POLICY IF EXISTS actualites_lecture_publique ON public.actualites;
DROP POLICY IF EXISTS actualites_images_lecture_publique ON public.actualites_images;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_zone_id_fkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_matiere_principale_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_professeur_id_fkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_semaine_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_admin_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_envoye_par_fkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_ajoute_par_fkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_suspendu_par_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_saisi_par_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_categorie_id_fkey;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_nouvelle_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_decide_par_fkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_annee_scolaire_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_matiere_id_fkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_classe_suivante_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_actualite_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_cree_par_fkey;
DROP TRIGGER IF EXISTS trg_users_scope_coherence ON public.users;
DROP TRIGGER IF EXISTS trg_unique_annee_en_cours ON public.annees_scolaires;
DROP TRIGGER IF EXISTS trg_frais_td_lock_period ON public.frais_td;
DROP INDEX IF EXISTS td.idx_postulations_professeur;
DROP INDEX IF EXISTS td.idx_creneaux_semaine;
DROP INDEX IF EXISTS public.idx_login_attempts_lookup;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_pkey;
ALTER TABLE IF EXISTS ONLY td.zones DROP CONSTRAINT IF EXISTS zones_nom_zone_key;
ALTER TABLE IF EXISTS ONLY td.semaines DROP CONSTRAINT IF EXISTS semaines_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_telephone_key;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_pkey;
ALTER TABLE IF EXISTS ONLY td.professeurs DROP CONSTRAINT IF EXISTS professeurs_email_key;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_pkey;
ALTER TABLE IF EXISTS ONLY td.postulations DROP CONSTRAINT IF EXISTS postulations_creneau_id_professeur_id_key;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_pkey;
ALTER TABLE IF EXISTS ONLY td.matieres_td DROP CONSTRAINT IF EXISTS matieres_td_nom_matiere_key;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_pkey;
ALTER TABLE IF EXISTS ONLY td.creneaux DROP CONSTRAINT IF EXISTS creneaux_classe_id_date_td_heure_debut_key;
ALTER TABLE IF EXISTS ONLY td.classes_td DROP CONSTRAINT IF EXISTS classes_td_pkey;
ALTER TABLE IF EXISTS ONLY td.classes_td DROP CONSTRAINT IF EXISTS classes_td_nom_classe_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_sites DROP CONSTRAINT IF EXISTS user_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_initiale_key;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_pkey;
ALTER TABLE IF EXISTS ONLY public.presences DROP CONSTRAINT IF EXISTS presences_eleve_id_date_presence_key;
ALTER TABLE IF EXISTS ONLY public.paiements_supprimes DROP CONSTRAINT IF EXISTS paiements_supprimes_pkey;
ALTER TABLE IF EXISTS ONLY public.paiements DROP CONSTRAINT IF EXISTS paiements_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_eleve_id_matiere_id_type_note_annee_scolaire_id_key;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_pkey;
ALTER TABLE IF EXISTS ONLY public.matieres DROP CONSTRAINT IF EXISTS matieres_code_key;
ALTER TABLE IF EXISTS ONLY public.login_attempts DROP CONSTRAINT IF EXISTS login_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.log_whatsapp DROP CONSTRAINT IF EXISTS log_whatsapp_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie DROP CONSTRAINT IF EXISTS galerie_pkey;
ALTER TABLE IF EXISTS ONLY public.galerie_admin DROP CONSTRAINT IF EXISTS galerie_admin_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_pkey;
ALTER TABLE IF EXISTS ONLY public.frais_td DROP CONSTRAINT IF EXISTS frais_td_classe_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves_suspendus DROP CONSTRAINT IF EXISTS eleves_suspendus_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_pkey;
ALTER TABLE IF EXISTS ONLY public.eleves DROP CONSTRAINT IF EXISTS eleves_matricule_key;
ALTER TABLE IF EXISTS ONLY public.depenses_annexes DROP CONSTRAINT IF EXISTS depenses_annexes_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_pkey;
ALTER TABLE IF EXISTS ONLY public.decisions_passage DROP CONSTRAINT IF EXISTS decisions_passage_eleve_id_key;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_pkey;
ALTER TABLE IF EXISTS ONLY public.comptes_parents DROP CONSTRAINT IF EXISTS comptes_parents_matricule_key;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_pkey;
ALTER TABLE IF EXISTS ONLY public.coefficients DROP CONSTRAINT IF EXISTS coefficients_classe_id_matiere_id_key;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_pkey;
ALTER TABLE IF EXISTS ONLY public.classes DROP CONSTRAINT IF EXISTS classes_nom_classe_site_id_key;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_pkey;
ALTER TABLE IF EXISTS ONLY public.categories_depenses DROP CONSTRAINT IF EXISTS categories_depenses_nom_key;
ALTER TABLE IF EXISTS ONLY public.annees_scolaires DROP CONSTRAINT IF EXISTS annees_scolaires_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites DROP CONSTRAINT IF EXISTS actualites_pkey;
ALTER TABLE IF EXISTS ONLY public.actualites_images DROP CONSTRAINT IF EXISTS actualites_images_pkey;
ALTER TABLE IF EXISTS td.zones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.semaines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.professeurs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.postulations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.matieres_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.creneaux ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS td.classes_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.presences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements_supprimes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paiements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matieres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.login_attempts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.log_whatsapp ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie_admin ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galerie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.frais_td ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves_suspendus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eleves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.depenses_annexes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.decisions_passage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comptes_parents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.coefficients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories_depenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.annees_scolaires ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actualites ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS td.zones_id_seq;
DROP TABLE IF EXISTS td.zones;
DROP SEQUENCE IF EXISTS td.semaines_id_seq;
DROP TABLE IF EXISTS td.semaines;
DROP SEQUENCE IF EXISTS td.professeurs_id_seq;
DROP TABLE IF EXISTS td.professeurs;
DROP SEQUENCE IF EXISTS td.postulations_id_seq;
DROP TABLE IF EXISTS td.postulations;
DROP SEQUENCE IF EXISTS td.matieres_td_id_seq;
DROP TABLE IF EXISTS td.matieres_td;
DROP SEQUENCE IF EXISTS td.creneaux_id_seq;
DROP TABLE IF EXISTS td.creneaux;
DROP SEQUENCE IF EXISTS td.classes_td_id_seq;
DROP TABLE IF EXISTS td.classes_td;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_sites;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.presences_id_seq;
DROP TABLE IF EXISTS public.presences;
DROP SEQUENCE IF EXISTS public.paiements_supprimes_id_seq;
DROP TABLE IF EXISTS public.paiements_supprimes;
DROP SEQUENCE IF EXISTS public.paiements_id_seq;
DROP TABLE IF EXISTS public.paiements;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notes_id_seq;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.matieres_id_seq;
DROP TABLE IF EXISTS public.matieres;
DROP SEQUENCE IF EXISTS public.login_attempts_id_seq;
DROP TABLE IF EXISTS public.login_attempts;
DROP SEQUENCE IF EXISTS public.log_whatsapp_id_seq;
DROP TABLE IF EXISTS public.log_whatsapp;
DROP SEQUENCE IF EXISTS public.galerie_id_seq;
DROP SEQUENCE IF EXISTS public.galerie_admin_id_seq;
DROP TABLE IF EXISTS public.galerie_admin;
DROP TABLE IF EXISTS public.galerie;
DROP SEQUENCE IF EXISTS public.frais_td_id_seq;
DROP TABLE IF EXISTS public.frais_td;
DROP SEQUENCE IF EXISTS public.eleves_suspendus_id_seq;
DROP TABLE IF EXISTS public.eleves_suspendus;
DROP SEQUENCE IF EXISTS public.eleves_id_seq;
DROP TABLE IF EXISTS public.eleves;
DROP SEQUENCE IF EXISTS public.depenses_annexes_id_seq;
DROP TABLE IF EXISTS public.depenses_annexes;
DROP SEQUENCE IF EXISTS public.decisions_passage_id_seq;
DROP TABLE IF EXISTS public.decisions_passage;
DROP SEQUENCE IF EXISTS public.comptes_parents_id_seq;
DROP TABLE IF EXISTS public.comptes_parents;
DROP SEQUENCE IF EXISTS public.coefficients_id_seq;
DROP TABLE IF EXISTS public.coefficients;
DROP SEQUENCE IF EXISTS public.classes_id_seq;
DROP TABLE IF EXISTS public.classes;
DROP SEQUENCE IF EXISTS public.categories_depenses_id_seq;
DROP TABLE IF EXISTS public.categories_depenses;
DROP SEQUENCE IF EXISTS public.annees_scolaires_id_seq;
DROP TABLE IF EXISTS public.annees_scolaires;
DROP SEQUENCE IF EXISTS public.actualites_images_id_seq;
DROP TABLE IF EXISTS public.actualites_images;
DROP SEQUENCE IF EXISTS public.actualites_id_seq;
DROP TABLE IF EXISTS public.actualites;
DROP FUNCTION IF EXISTS td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer);
DROP FUNCTION IF EXISTS public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date);
DROP FUNCTION IF EXISTS public.trg_users_scope_coherence_fn();
DROP FUNCTION IF EXISTS public.trg_unique_annee_en_cours_fn();
DROP FUNCTION IF EXISTS public.trg_frais_td_lock_period_fn();
DROP FUNCTION IF EXISTS public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]);
DROP SCHEMA IF EXISTS td;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: td; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA td;


--
-- Name: assigner_sites_superviseur(uuid, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assigner_sites_superviseur(p_user_id uuid, p_site_ids integer[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  delete from public.user_sites where user_id = p_user_id;
  insert into public.user_sites (user_id, site_id)
  select p_user_id, unnest(p_site_ids);
end;
$$;


--
-- Name: trg_frais_td_lock_period_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_frais_td_lock_period_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_debut date;
  v_fin   date;
begin
  select date_debut, date_fin into v_debut, v_fin
  from public.annees_scolaires where statut = 'en_cours';

  if v_debut is not null and current_date between v_debut and v_fin then
    raise exception 'Modification du montant interdite pendant l''année scolaire en cours — uniquement en période de vacances, après l''arbitrage de fin d''année';
  end if;

  return new;
end;
$$;


--
-- Name: trg_unique_annee_en_cours_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_unique_annee_en_cours_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.statut = 'en_cours' and exists (
    select 1 from public.annees_scolaires
    where statut = 'en_cours' and id <> new.id
  ) then
    raise exception 'Une année scolaire est déjà en_cours';
  end if;

  return new;
end;
$$;


--
-- Name: trg_users_scope_coherence_fn(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_users_scope_coherence_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.role = 'chef_site' and new.site_id is null then
    raise exception 'site_id obligatoire pour le rôle chef_site';
  end if;

  if new.role in ('coordonnateur','comptable','secretaire','superviseur') and new.site_id is not null then
    raise exception 'site_id doit être NULL pour le rôle %', new.role;
  end if;

  return new;
end;
$$;


--
-- Name: valider_fin_annee(text, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.valider_fin_annee(p_nouvelle_libelle text, p_nouvelle_date_debut date, p_nouvelle_date_fin date) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  -- 1. Créer la nouvelle année scolaire
  insert into public.annees_scolaires (libelle, date_debut, date_fin, statut)
  values (p_nouvelle_libelle, p_nouvelle_date_debut, p_nouvelle_date_fin, 'en_cours');

  -- 2. Clôturer l'ancienne
  update public.annees_scolaires set statut = 'terminee' where statut = 'en_pause';

  -- 3. Appliquer les décisions "passe"
  update public.eleves e
  set classe_id = d.nouvelle_classe_id
  from public.decisions_passage d
  where d.eleve_id = e.id
    and d.decision = 'passe'
    and d.nouvelle_classe_id is not null;

  -- 4. Supprimer définitivement les élèves sortant / encore suspendus
  delete from public.eleves e
  where e.id in (select eleve_id from public.decisions_passage where decision = 'sortant')
     or e.statut = 'suspendu';

  -- 5. Purger les logs applicatifs des élèves désormais absents de `eleves`
  delete from public.log_whatsapp
  where matricule not in (select matricule from public.eleves);

  delete from public.paiements_supprimes
  where matricule not in (select matricule from public.eleves);

  -- 6. Purger la table tampon des décisions
  truncate public.decisions_passage;

exception when others then
  raise;
end;
$$;


--
-- Name: arbitrer_creneau(integer, integer); Type: FUNCTION; Schema: td; Owner: -
--

CREATE FUNCTION td.arbitrer_creneau(p_creneau_id integer, p_professeur_id integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if (select role from public.users where id = auth.uid()) != 'coordonnateur' then
    raise exception 'Non autorisé : réservé au coordonnateur';
  end if;

  -- 1. Valider la postulation choisie
  update td.postulations
  set statut_validation = 'Valide'
  where creneau_id = p_creneau_id and professeur_id = p_professeur_id;

  -- 2. Refuser les autres candidats sur ce créneau
  update td.postulations
  set statut_validation = 'Refuse'
  where creneau_id = p_creneau_id and professeur_id != p_professeur_id;

  -- 3. Règle A — Refuser les autres candidatures En attente du même prof au même horaire
  update td.postulations
  set statut_validation = 'Refuse'
  where professeur_id = p_professeur_id
    and statut_validation = 'En attente'
    and creneau_id in (
      select c_autre.id
      from td.creneaux c_autre
      join td.creneaux c_ref on c_ref.id = p_creneau_id
      where c_autre.id != p_creneau_id
        and c_autre.date_td = c_ref.date_td
        and c_autre.heure_debut = c_ref.heure_debut
    );

  -- 4. Clôturer le créneau
  update td.creneaux set statut_creneau = 'cloture' where id = p_creneau_id;

exception when others then
  raise;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actualites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites (
    id integer NOT NULL,
    titre character varying(200) NOT NULL,
    categorie text NOT NULL,
    extrait text NOT NULL,
    contenu text NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    a_la_une_jusqu_au date,
    date_publication timestamp with time zone DEFAULT now() NOT NULL,
    cree_par uuid,
    CONSTRAINT actualites_categorie_check CHECK ((categorie = ANY (ARRAY['Vie scolaire'::text, 'Événement'::text, 'Réussite'::text, 'Cours'::text, 'Examens/Contrôle'::text]))),
    CONSTRAINT actualites_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publie'::text])))
);


--
-- Name: actualites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_id_seq OWNED BY public.actualites.id;


--
-- Name: actualites_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actualites_images (
    id integer NOT NULL,
    actualite_id integer NOT NULL,
    storage_path text NOT NULL,
    ordre integer DEFAULT 0 NOT NULL
);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actualites_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actualites_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actualites_images_id_seq OWNED BY public.actualites_images.id;


--
-- Name: annees_scolaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.annees_scolaires (
    id integer NOT NULL,
    libelle character varying(10) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'en_cours'::text NOT NULL,
    CONSTRAINT annees_scolaires_statut_check CHECK ((statut = ANY (ARRAY['en_cours'::text, 'en_pause'::text, 'terminee'::text])))
);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.annees_scolaires_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.annees_scolaires_id_seq OWNED BY public.annees_scolaires.id;


--
-- Name: categories_depenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories_depenses (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    systeme boolean DEFAULT false NOT NULL
);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_depenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_depenses_id_seq OWNED BY public.categories_depenses.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.classes (
    id integer NOT NULL,
    nom_classe character varying(50) NOT NULL,
    site_id integer NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    classe_suivante_id integer
);


--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.classes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: coefficients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coefficients (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    coefficient numeric(4,2) NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT coefficients_coefficient_check CHECK ((coefficient > (0)::numeric))
);


--
-- Name: coefficients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coefficients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coefficients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coefficients_id_seq OWNED BY public.coefficients.id;


--
-- Name: comptes_parents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comptes_parents (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mot_de_passe text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    derniere_connexion timestamp with time zone
);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comptes_parents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comptes_parents_id_seq OWNED BY public.comptes_parents.id;


--
-- Name: decisions_passage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.decisions_passage (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    decision text NOT NULL,
    nouvelle_classe_id integer,
    annee_scolaire_id integer NOT NULL,
    date_decision timestamp with time zone DEFAULT now() NOT NULL,
    decide_par uuid NOT NULL,
    CONSTRAINT decisions_passage_decision_check CHECK ((decision = ANY (ARRAY['passe'::text, 'redouble'::text, 'sortant'::text])))
);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.decisions_passage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.decisions_passage_id_seq OWNED BY public.decisions_passage.id;


--
-- Name: depenses_annexes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.depenses_annexes (
    id integer NOT NULL,
    categorie_id integer NOT NULL,
    libelle character varying(255) NOT NULL,
    montant numeric(10,2) NOT NULL,
    date_depense date NOT NULL,
    saisi_par uuid NOT NULL,
    date_saisie timestamp with time zone DEFAULT now() NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.depenses_annexes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.depenses_annexes_id_seq OWNED BY public.depenses_annexes.id;


--
-- Name: eleves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    nom character varying(100) NOT NULL,
    prenoms character varying(150) NOT NULL,
    contact_parent character varying(25) NOT NULL,
    classe_id integer NOT NULL,
    college character varying(150) NOT NULL,
    option_m character varying(10),
    statut text DEFAULT 'actif'::text NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT eleves_statut_check CHECK ((statut = ANY (ARRAY['actif'::text, 'suspendu'::text])))
);


--
-- Name: eleves_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_id_seq OWNED BY public.eleves.id;


--
-- Name: eleves_suspendus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eleves_suspendus (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    site_id integer NOT NULL,
    raison text NOT NULL,
    motif text NOT NULL,
    montant_du integer DEFAULT 0 NOT NULL,
    date_suspension timestamp with time zone DEFAULT now() NOT NULL,
    suspendu_par uuid NOT NULL,
    annee_scolaire_id integer NOT NULL,
    CONSTRAINT eleves_suspendus_raison_check CHECK ((raison = ANY (ARRAY['maladie'::text, 'renvoi'::text, 'defaut_paiement'::text, 'autre'::text])))
);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eleves_suspendus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eleves_suspendus_id_seq OWNED BY public.eleves_suspendus.id;


--
-- Name: frais_td; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frais_td (
    id integer NOT NULL,
    classe_id integer NOT NULL,
    montant numeric(10,2) NOT NULL
);


--
-- Name: frais_td_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frais_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frais_td_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frais_td_id_seq OWNED BY public.frais_td.id;


--
-- Name: galerie; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie (
    id integer NOT NULL,
    storage_path text NOT NULL,
    date_insertion timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galerie_admin (
    id integer NOT NULL,
    storage_path text NOT NULL,
    nom_fichier text NOT NULL,
    taille_octets integer,
    ajoute_par uuid NOT NULL,
    date_ajout timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_admin_id_seq OWNED BY public.galerie_admin.id;


--
-- Name: galerie_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.galerie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: galerie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.galerie_id_seq OWNED BY public.galerie.id;


--
-- Name: log_whatsapp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_whatsapp (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_restant integer NOT NULL,
    contact_parent character varying(25) NOT NULL,
    envoye_par uuid NOT NULL,
    date_envoi timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_whatsapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_whatsapp_id_seq OWNED BY public.log_whatsapp.id;


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id integer NOT NULL,
    identifiant text NOT NULL,
    portail text NOT NULL,
    reussi boolean NOT NULL,
    ip inet,
    date_tentative timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT login_attempts_portail_check CHECK ((portail = ANY (ARRAY['admin'::text, 'parent'::text, 'td'::text])))
);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_attempts_id_seq OWNED BY public.login_attempts.id;


--
-- Name: matieres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matieres (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    code character varying(10) NOT NULL,
    ordre integer DEFAULT 0 NOT NULL,
    actif boolean DEFAULT true NOT NULL
);


--
-- Name: matieres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matieres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matieres_id_seq OWNED BY public.matieres.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    matiere_id integer NOT NULL,
    type_note text NOT NULL,
    valeur numeric(4,2) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notes_type_note_check CHECK ((type_note = ANY (ARRAY['I1'::text, 'I2'::text, 'I3'::text, 'D1'::text, 'D2'::text, 'Ctrl'::text]))),
    CONSTRAINT notes_valeur_check CHECK (((valeur >= (0)::numeric) AND (valeur <= (20)::numeric)))
);


--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    site_id integer NOT NULL,
    contenu text NOT NULL,
    lu boolean DEFAULT false NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: paiements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    annee_scolaire_id integer NOT NULL,
    CONSTRAINT paiements_mode_paiement_check CHECK (((mode_paiement)::text = ANY ((ARRAY['MoMo'::character varying, 'Presentiel'::character varying])::text[]))),
    CONSTRAINT paiements_mois_souscription_check CHECK (((mois_souscription)::text = ANY ((ARRAY['Octobre'::character varying, 'Novembre'::character varying, 'Decembre'::character varying, 'Janvier'::character varying, 'Fevrier'::character varying, 'Mars'::character varying, 'Avril'::character varying, 'Mai'::character varying])::text[])))
);


--
-- Name: paiements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_id_seq OWNED BY public.paiements.id;


--
-- Name: paiements_supprimes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paiements_supprimes (
    id integer NOT NULL,
    matricule character varying(9) NOT NULL,
    mois_souscription character varying(20) NOT NULL,
    montant_paye integer NOT NULL,
    date_paiement date NOT NULL,
    mode_paiement character varying(20) NOT NULL,
    admin_id uuid NOT NULL,
    date_suppression timestamp with time zone DEFAULT now() NOT NULL,
    motif text NOT NULL
);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paiements_supprimes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paiements_supprimes_id_seq OWNED BY public.paiements_supprimes.id;


--
-- Name: presences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.presences (
    id integer NOT NULL,
    eleve_id integer NOT NULL,
    date_presence date NOT NULL,
    site_id integer NOT NULL,
    classe_id integer NOT NULL,
    present boolean DEFAULT true NOT NULL,
    annee_scolaire_id integer NOT NULL
);


--
-- Name: presences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.presences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: presences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.presences_id_seq OWNED BY public.presences.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    nom_site character varying(100) NOT NULL,
    initiale character(1) NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: user_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sites (
    user_id uuid NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    site_id integer,
    actif boolean DEFAULT true NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text, 'chef_site'::text, 'secretaire'::text])))
);


--
-- Name: classes_td; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.classes_td (
    id integer NOT NULL,
    nom_classe character varying(50) NOT NULL
);


--
-- Name: classes_td_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.classes_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: classes_td_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.classes_td_id_seq OWNED BY td.classes_td.id;


--
-- Name: creneaux; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.creneaux (
    id integer NOT NULL,
    semaine_id integer NOT NULL,
    classe_id integer NOT NULL,
    matiere_id integer NOT NULL,
    date_td date NOT NULL,
    heure_debut time without time zone NOT NULL,
    heure_fin time without time zone NOT NULL,
    montant_prevu numeric(10,2) DEFAULT 0 NOT NULL,
    statut_creneau text DEFAULT 'brouillon'::text NOT NULL,
    CONSTRAINT creneaux_statut_creneau_check CHECK ((statut_creneau = ANY (ARRAY['brouillon'::text, 'public'::text, 'cloture'::text])))
);


--
-- Name: creneaux_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.creneaux_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: creneaux_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.creneaux_id_seq OWNED BY td.creneaux.id;


--
-- Name: matieres_td; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.matieres_td (
    id integer NOT NULL,
    nom_matiere character varying(100) NOT NULL
);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.matieres_td_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matieres_td_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.matieres_td_id_seq OWNED BY td.matieres_td.id;


--
-- Name: postulations; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.postulations (
    id integer NOT NULL,
    creneau_id integer NOT NULL,
    professeur_id integer NOT NULL,
    statut_validation text DEFAULT 'En attente'::text NOT NULL,
    date_postulation timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT postulations_statut_validation_check CHECK ((statut_validation = ANY (ARRAY['En attente'::text, 'Valide'::text, 'Refuse'::text])))
);


--
-- Name: postulations_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.postulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: postulations_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.postulations_id_seq OWNED BY td.postulations.id;


--
-- Name: professeurs; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.professeurs (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    prenom character varying(100) NOT NULL,
    telephone character varying(25) NOT NULL,
    email character varying(150) NOT NULL,
    mot_de_passe text NOT NULL,
    zone_id integer NOT NULL,
    matiere_principale_id integer NOT NULL,
    actif boolean DEFAULT true NOT NULL,
    date_inscription timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: professeurs_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.professeurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professeurs_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.professeurs_id_seq OWNED BY td.professeurs.id;


--
-- Name: semaines; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.semaines (
    id integer NOT NULL,
    libelle character varying(100) NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    statut text DEFAULT 'brouillon'::text NOT NULL,
    date_creation timestamp with time zone DEFAULT now() NOT NULL,
    date_cloture timestamp with time zone,
    CONSTRAINT semaines_statut_check CHECK ((statut = ANY (ARRAY['brouillon'::text, 'publiee'::text, 'cloturee'::text])))
);


--
-- Name: semaines_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.semaines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semaines_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.semaines_id_seq OWNED BY td.semaines.id;


--
-- Name: zones; Type: TABLE; Schema: td; Owner: -
--

CREATE TABLE td.zones (
    id integer NOT NULL,
    nom_zone character varying(100) NOT NULL
);


--
-- Name: zones_id_seq; Type: SEQUENCE; Schema: td; Owner: -
--

CREATE SEQUENCE td.zones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zones_id_seq; Type: SEQUENCE OWNED BY; Schema: td; Owner: -
--

ALTER SEQUENCE td.zones_id_seq OWNED BY td.zones.id;


--
-- Name: actualites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites ALTER COLUMN id SET DEFAULT nextval('public.actualites_id_seq'::regclass);


--
-- Name: actualites_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images ALTER COLUMN id SET DEFAULT nextval('public.actualites_images_id_seq'::regclass);


--
-- Name: annees_scolaires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires ALTER COLUMN id SET DEFAULT nextval('public.annees_scolaires_id_seq'::regclass);


--
-- Name: categories_depenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses ALTER COLUMN id SET DEFAULT nextval('public.categories_depenses_id_seq'::regclass);


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: coefficients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients ALTER COLUMN id SET DEFAULT nextval('public.coefficients_id_seq'::regclass);


--
-- Name: comptes_parents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents ALTER COLUMN id SET DEFAULT nextval('public.comptes_parents_id_seq'::regclass);


--
-- Name: decisions_passage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage ALTER COLUMN id SET DEFAULT nextval('public.decisions_passage_id_seq'::regclass);


--
-- Name: depenses_annexes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes ALTER COLUMN id SET DEFAULT nextval('public.depenses_annexes_id_seq'::regclass);


--
-- Name: eleves id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves ALTER COLUMN id SET DEFAULT nextval('public.eleves_id_seq'::regclass);


--
-- Name: eleves_suspendus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus ALTER COLUMN id SET DEFAULT nextval('public.eleves_suspendus_id_seq'::regclass);


--
-- Name: frais_td id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td ALTER COLUMN id SET DEFAULT nextval('public.frais_td_id_seq'::regclass);


--
-- Name: galerie id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie ALTER COLUMN id SET DEFAULT nextval('public.galerie_id_seq'::regclass);


--
-- Name: galerie_admin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin ALTER COLUMN id SET DEFAULT nextval('public.galerie_admin_id_seq'::regclass);


--
-- Name: log_whatsapp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp ALTER COLUMN id SET DEFAULT nextval('public.log_whatsapp_id_seq'::regclass);


--
-- Name: login_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts ALTER COLUMN id SET DEFAULT nextval('public.login_attempts_id_seq'::regclass);


--
-- Name: matieres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres ALTER COLUMN id SET DEFAULT nextval('public.matieres_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: paiements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements ALTER COLUMN id SET DEFAULT nextval('public.paiements_id_seq'::regclass);


--
-- Name: paiements_supprimes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes ALTER COLUMN id SET DEFAULT nextval('public.paiements_supprimes_id_seq'::regclass);


--
-- Name: presences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences ALTER COLUMN id SET DEFAULT nextval('public.presences_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: classes_td id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.classes_td ALTER COLUMN id SET DEFAULT nextval('td.classes_td_id_seq'::regclass);


--
-- Name: creneaux id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux ALTER COLUMN id SET DEFAULT nextval('td.creneaux_id_seq'::regclass);


--
-- Name: matieres_td id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td ALTER COLUMN id SET DEFAULT nextval('td.matieres_td_id_seq'::regclass);


--
-- Name: postulations id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations ALTER COLUMN id SET DEFAULT nextval('td.postulations_id_seq'::regclass);


--
-- Name: professeurs id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs ALTER COLUMN id SET DEFAULT nextval('td.professeurs_id_seq'::regclass);


--
-- Name: semaines id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines ALTER COLUMN id SET DEFAULT nextval('td.semaines_id_seq'::regclass);


--
-- Name: zones id; Type: DEFAULT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones ALTER COLUMN id SET DEFAULT nextval('td.zones_id_seq'::regclass);


--
-- Data for Name: actualites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites (id, titre, categorie, extrait, contenu, statut, a_la_une_jusqu_au, date_publication, cree_par) FROM stdin;
1	Démarrage des Cours Intensifs Préparatoires — Édition 2026	Cours	Le GSR lance sa nouvelle édition des Cours Intensifs Préparatoires sur ses 3 sites. Un programme pensé pour combler les lacunes et aborder la suite de l'année en confiance.	Le Groupe Secret de la Réussite ouvre officiellement sa nouvelle édition des Cours Intensifs Préparatoires, sur ses trois sites de Jéricho, Yagbé et Vèdoko. Ce programme, pensé pour la période de vacances, s'adresse à tous les élèves de la 6ème à la Terminale qui souhaitent consolider leurs acquis avant la reprise.\n\nL'objectif est simple : identifier les lacunes accumulées durant l'année écoulée et les corriger méthodiquement, tout en abordant en douceur les nouvelles notions du programme à venir. Chaque séance s'appuie sur des documents de cours structurés et des évaluations ciblées, pour que chaque élève progresse à son rythme sans se sentir dépassé.\n\nNos enseignants, sélectionnés pour leur rigueur et leur pédagogie, encadrent des groupes à taille humaine afin d'assurer un vrai suivi individuel. Les tarifs, accessibles et adaptés à chaque niveau, sont disponibles en détail sur notre page Tarifs.\n\nLes places étant limitées sur chaque site, nous invitons les parents à inscrire rapidement leurs enfants en se rendant directement sur l'un de nos trois centres, ou en nous contactant par téléphone pour toute question sur le programme et les horaires.	publie	2026-08-19	2026-08-05 14:59:03.897193+00	\N
2	Démarrage des séances de révision BEPC 2026	Examens/Contrôle	À l'approche des épreuves, le GSR met en place un dispositif de révision intensif et méthodique dédié aux candidats au BEPC 2026.	À quelques mois d'une échéance décisive, le Groupe Secret de la Réussite lance ses séances de révision dédiées aux candidats au BEPC 2026. Ce dispositif vise à consolider les acquis sur l'ensemble du programme officiel, avec un accent particulier sur les matières fondamentales : Mathématiques, Français, Physique-Chimie, SVT et Anglais.\n\nLe format retenu combine rappels de cours structurés, exercices ciblés et examens blancs réguliers, chacun suivi d'une correction méthodique en groupe. Cette approche permet à chaque candidat de mesurer précisément ses progrès et d'identifier les points qui demandent encore du travail avant le jour J.\n\nNos enseignants, habitués aux exigences de l'examen, accompagnent les élèves avec des conseils pratiques de gestion du temps et de méthodologie de rédaction, deux facteurs qui font souvent la différence le jour de l'épreuve.\n\nLes séances se déroulent sur nos trois sites, selon un calendrier communiqué aux familles inscrites. Pour rejoindre le dispositif ou obtenir plus d'informations, contactez-nous ou rendez-vous directement sur l'un de nos centres.	publie	\N	2026-07-29 14:59:03.897193+00	\N
3	Séance de Coaching et de Motivation des candidats aux examens 2026	Vie scolaire	Au-delà des révisions académiques, le GSR accompagne aussi ses candidats sur le plan psychologique avec une séance de coaching et de motivation.	La réussite aux examens ne se joue pas uniquement sur les connaissances académiques : la confiance en soi, la gestion du stress et la discipline personnelle jouent un rôle tout aussi déterminant. C'est dans cet esprit que le Groupe Secret de la Réussite a organisé une séance de coaching et de motivation dédiée à ses candidats aux examens 2026.\n\nAnimée par notre équipe pédagogique, cette rencontre a permis d'aborder des sujets essentiels à l'approche des épreuves : techniques de gestion du stress, organisation efficace du temps de révision, et surtout, comment garder confiance face à la pression des examens.\n\nLes élèves ont pu échanger librement sur leurs appréhensions et repartir avec des outils concrets pour aborder sereinement les semaines à venir. Cette dimension d'accompagnement humain fait partie intégrante de notre philosophie : préparer nos élèves non seulement académiquement, mais aussi mentalement, à affronter les moments décisifs de leur parcours scolaire.\n\nD'autres séances de ce type seront organisées à l'approche des sessions d'examens. Les élèves inscrits dans nos programmes en seront informés directement sur leur site.	publie	\N	2026-07-22 14:59:03.897193+00	\N
\.


--
-- Data for Name: actualites_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actualites_images (id, actualite_id, storage_path, ordre) FROM stdin;
1	1	vitrine/accueil/img_cip.jpg	0
2	2	vitrine/accueil/img_prepa.jpg	0
3	3	vitrine/sites/img_site_jericho.jpg	0
\.


--
-- Data for Name: annees_scolaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.annees_scolaires (id, libelle, date_debut, date_fin, statut) FROM stdin;
1	2026-2027	2026-10-01	2027-05-31	en_cours
\.


--
-- Data for Name: categories_depenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories_depenses (id, nom, systeme) FROM stdin;
1	Location Site	t
2	Paiement Prof	t
3	Fournitures	t
4	Transport	t
5	Communication	t
6	Maintenance	t
7	Frais bancaires	t
8	Autre	t
\.


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.classes (id, nom_classe, site_id, ordre, classe_suivante_id) FROM stdin;
4	3ème	1	4	\N
9	Terminale A	1	7	\N
10	Terminale B	1	7	\N
11	Terminale C	1	7	\N
12	Terminale D	1	7	\N
1	6ème	1	1	2
2	5ème	1	2	3
3	4ème	1	3	4
5	Seconde AB	1	5	7
6	Seconde CD	1	5	8
7	Première AB	1	6	9
8	Première CD	1	6	11
16	3ème	2	4	\N
13	6ème	2	1	14
14	5ème	2	2	15
15	4ème	2	3	16
\.


--
-- Data for Name: coefficients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coefficients (id, classe_id, matiere_id, coefficient, updated_at) FROM stdin;
\.


--
-- Data for Name: comptes_parents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comptes_parents (id, matricule, mot_de_passe, date_creation, derniere_connexion) FROM stdin;
\.


--
-- Data for Name: decisions_passage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.decisions_passage (id, eleve_id, decision, nouvelle_classe_id, annee_scolaire_id, date_decision, decide_par) FROM stdin;
\.


--
-- Data for Name: depenses_annexes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.depenses_annexes (id, categorie_id, libelle, montant, date_depense, saisi_par, date_saisie, annee_scolaire_id) FROM stdin;
\.


--
-- Data for Name: eleves; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves (id, matricule, nom, prenoms, contact_parent, classe_id, college, option_m, statut, date_inscription) FROM stdin;
3	J07262186	DOSSOU	Rodrigue	+229 97 92 17 81	1	COLLEGE DEMO	\N	actif	2026-07-28 12:09:14.486233+00
4	J07261667	TOSSOU	Kossi	+229 62 64 66 56	2	COLLEGE DEMO	\N	actif	2026-07-28 12:09:15.030274+00
5	J07261927	DEGBEY	Rachelle	+229 62 22 32 14	3	COLLEGE DEMO	\N	actif	2026-07-28 12:09:15.547619+00
7	J07262468	GLELE	Prisca	+229 90 70 30 52	5	COLLEGE DEMO	\N	actif	2026-07-28 12:09:16.616871+00
9	J07264751	HOUNKPE	Grâce	+229 61 85 91 47	8	COLLEGE DEMO	\N	actif	2026-07-28 12:09:17.67575+00
13	J07264019	HOUNSOU	Prudencio	+229 96 62 39 48	10	COLLEGE DEMO	\N	actif	2026-07-28 12:09:19.800325+00
15	Y07265404	ZINSOU	Prince Gilchrist	+229 61 74 80 74	13	COLLEGE DEMO	\N	actif	2026-07-28 12:09:20.799341+00
18	Y07265761	SEDJRO	Fabrice Junior	+229 67 98 34 84	16	COLLEGE DEMO	\N	actif	2026-07-28 12:09:22.311003+00
19	J07262025	DAGBA	Kossi Marcellin	+229 96 41 91 95	1	COLLEGE DEMO	\N	actif	2026-07-28 12:09:22.871759+00
20	J07264863	HOUNKPE	Rodrigue	+229 97 38 66 50	2	COLLEGE DEMO	\N	actif	2026-07-28 12:09:23.426214+00
22	J07267963	TOSSOU	Grâce	+229 96 91 70 35	4	COLLEGE DEMO	\N	actif	2026-07-28 12:09:24.453948+00
28	J07266782	AHOYO	Wilfried	+229 97 39 55 78	12	COLLEGE DEMO	\N	actif	2026-07-28 12:09:27.570433+00
30	J07268391	KPOTIN	Gilchrist	+229 61 29 50 56	11	COLLEGE DEMO	\N	actif	2026-07-28 12:09:28.576584+00
32	Y07268109	HODONOU	Judith Rachelle	+229 97 37 49 10	14	COLLEGE DEMO	\N	actif	2026-07-28 12:09:29.577162+00
34	Y07269060	KOUDJO	Christelle Grâce	+229 62 90 90 39	16	COLLEGE DEMO	\N	actif	2026-07-28 12:09:30.703027+00
35	J07265911	ZINSOU	Carole Reine	+229 62 37 92 90	1	COLLEGE DEMO	\N	actif	2026-07-28 12:09:31.215731+00
36	J07262271	ASSOGBA	Merveille	+229 67 46 34 86	2	COLLEGE DEMO	\N	actif	2026-07-28 12:09:31.762582+00
39	J07265766	TOKPONOU	Franck	+229 69 43 71 96	5	COLLEGE DEMO	\N	actif	2026-07-28 12:09:33.35464+00
41	J07261878	AGBOTON	Merveille	+229 64 44 36 88	8	COLLEGE DEMO	\N	actif	2026-07-28 12:09:34.35888+00
42	J07262116	ALLADATIN	Elie	+229 67 97 57 56	7	COLLEGE DEMO	\N	actif	2026-07-28 12:09:34.883308+00
43	J07266699	AGOSSOU	Rachelle	+229 64 46 22 86	9	COLLEGE DEMO	\N	actif	2026-07-28 12:09:35.385297+00
45	J07262856	ADANDE	Osée	+229 69 78 11 61	10	COLLEGE DEMO	\N	actif	2026-07-28 12:09:36.388661+00
46	J07264935	HOUNTONDJI	Sandrine	+229 97 90 61 13	11	COLLEGE DEMO	\N	actif	2026-07-28 12:09:36.893792+00
47	Y07268356	DAGBA	Nadège	+229 64 84 22 77	13	COLLEGE DEMO	\N	actif	2026-07-28 12:09:37.395247+00
49	Y07268344	GNANSOUNOU	Gilchrist	+229 96 24 99 21	15	COLLEGE DEMO	\N	actif	2026-07-28 12:09:38.401273+00
50	Y07269026	ADANDE	Judith Bénie	+229 67 12 51 85	16	COLLEGE DEMO	\N	actif	2026-07-28 12:09:38.894807+00
52	J07263950	ADANDE	Elie	+229 64 10 23 43	2	COLLEGE DEMO	\N	actif	2026-07-28 12:09:39.928727+00
11	J07267248	AKPOVI	Rachelle	+229 69 28 64 78	9	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:18.726128+00
27	J07267492	AVOCE	Rachelle	+229 91 57 42 47	9	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:27.063875+00
44	J07267236	TOSSOU	Franck	+229 96 37 26 74	12	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:35.891753+00
6	J07263885	GNANSOUNOU	Franck Anicet	+229 90 54 39 15	4	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:16.064777+00
8	J07263911	HOUNSOU	Marcellin	+229 96 78 34 26	6	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:17.168807+00
10	J07263489	SOSSOU	Elie	+229 90 68 55 98	7	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:18.223703+00
12	J07264683	GLELE	Divin	+229 61 87 90 75	12	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:19.294262+00
14	J07261910	HOUNSOU	Kossi	+229 91 57 60 75	11	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:20.29971+00
16	Y07261650	AGOSSOU	Comlan	+229 90 96 62 14	14	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:21.300025+00
17	Y07266408	DJOSSOU	Carole Marlène	+229 91 38 69 99	15	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:21.799732+00
21	J07264591	AGBODJOGBE	Prisca	+229 96 66 40 27	3	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:23.940657+00
23	J07265729	HODONOU	Emmanuel	+229 90 73 98 77	5	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:25.012682+00
24	J07266825	ALLADATIN	Merveille Prisca	+229 67 91 92 96	6	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:25.512117+00
25	J07267070	DEGBEY	Sandra	+229 91 79 30 20	8	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:26.05095+00
26	J07267741	DOSSOU	Anicet Comlan	+229 97 78 97 49	7	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:26.552444+00
29	J07268815	AVOCE	Christelle	+229 61 67 31 86	10	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:28.069282+00
31	Y07265053	AVOCE	Judith	+229 61 94 60 42	13	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:29.074365+00
33	Y07263190	KPOTIN	Chimène	+229 69 90 54 53	15	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:30.141445+00
37	J07264427	AHOYO	Prudencio	+229 61 85 12 67	3	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:32.286339+00
38	J07262873	HOUNKPE	Merveille Grâce	+229 64 11 31 75	4	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:32.786203+00
40	J07269208	DEGBEY	Sandrine	+229 66 98 53 32	6	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:33.859135+00
48	Y07266323	TOKPONOU	Wilfried	+229 61 11 43 77	14	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:37.893971+00
51	J07268443	AGOSSOU	Carole	+229 97 16 99 63	1	COLLEGE DEMO	\N	suspendu	2026-07-28 12:09:39.40824+00
\.


--
-- Data for Name: eleves_suspendus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eleves_suspendus (id, eleve_id, site_id, raison, motif, montant_du, date_suspension, suspendu_par, annee_scolaire_id) FROM stdin;
1	11	1	maladie	Suspension de démonstration — jeu de données de test.	7029	2026-07-28 12:09:40.437131+00	8a3ec1da-561d-403a-b092-92190861d201	1
2	27	1	renvoi	Suspension de démonstration — jeu de données de test.	4588	2026-07-28 12:09:40.437131+00	8a3ec1da-561d-403a-b092-92190861d201	1
3	44	1	maladie	Suspension de démonstration — jeu de données de test.	3985	2026-07-28 12:09:40.437131+00	8a3ec1da-561d-403a-b092-92190861d201	1
4	6	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-07-28 12:51:20.03471+00	8a3ec1da-561d-403a-b092-92190861d201	1
5	8	1	defaut_paiement	Defaut de paiement — 2050 F restants pour le mois de Octobre	2050	2026-07-28 12:51:20.496225+00	8a3ec1da-561d-403a-b092-92190861d201	1
6	10	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-07-28 12:51:20.941448+00	8a3ec1da-561d-403a-b092-92190861d201	1
7	12	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-07-28 12:51:21.372653+00	8a3ec1da-561d-403a-b092-92190861d201	1
8	14	1	defaut_paiement	Defaut de paiement — 3120 F restants pour le mois de Octobre	3120	2026-07-28 12:51:21.801763+00	8a3ec1da-561d-403a-b092-92190861d201	1
9	16	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-07-28 12:51:22.226073+00	8a3ec1da-561d-403a-b092-92190861d201	1
10	17	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-07-28 12:51:22.646211+00	8a3ec1da-561d-403a-b092-92190861d201	1
11	21	1	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-07-28 12:51:23.081208+00	8a3ec1da-561d-403a-b092-92190861d201	1
12	23	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-07-28 12:51:23.506114+00	8a3ec1da-561d-403a-b092-92190861d201	1
13	24	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-07-28 12:51:23.929137+00	8a3ec1da-561d-403a-b092-92190861d201	1
14	25	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-07-28 12:51:24.358865+00	8a3ec1da-561d-403a-b092-92190861d201	1
15	26	1	defaut_paiement	Defaut de paiement — 6000 F restants pour le mois de Octobre	6000	2026-07-28 12:51:24.826412+00	8a3ec1da-561d-403a-b092-92190861d201	1
16	29	1	defaut_paiement	Defaut de paiement — 8000 F restants pour le mois de Octobre	8000	2026-07-28 12:51:25.267337+00	8a3ec1da-561d-403a-b092-92190861d201	1
17	31	2	defaut_paiement	Defaut de paiement — 960 F restants pour le mois de Octobre	960	2026-07-28 12:51:25.687185+00	8a3ec1da-561d-403a-b092-92190861d201	1
18	33	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-07-28 12:51:26.116071+00	8a3ec1da-561d-403a-b092-92190861d201	1
19	37	1	defaut_paiement	Defaut de paiement — 1680 F restants pour le mois de Octobre	1680	2026-07-28 12:51:26.545669+00	8a3ec1da-561d-403a-b092-92190861d201	1
20	38	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-07-28 12:51:26.970008+00	8a3ec1da-561d-403a-b092-92190861d201	1
21	40	1	defaut_paiement	Defaut de paiement — 5000 F restants pour le mois de Octobre	5000	2026-07-28 12:51:27.388963+00	8a3ec1da-561d-403a-b092-92190861d201	1
22	48	2	defaut_paiement	Defaut de paiement — 3000 F restants pour le mois de Octobre	3000	2026-07-28 12:51:27.8142+00	8a3ec1da-561d-403a-b092-92190861d201	1
23	51	1	defaut_paiement	Defaut de paiement — 960 F restants pour le mois de Octobre	960	2026-07-28 12:51:28.23431+00	8a3ec1da-561d-403a-b092-92190861d201	1
\.


--
-- Data for Name: frais_td; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.frais_td (id, classe_id, montant) FROM stdin;
1	1	2000.00
2	13	2000.00
3	2	3000.00
4	14	3000.00
5	3	3000.00
6	15	3000.00
7	4	5000.00
8	16	5000.00
9	5	5000.00
10	6	5000.00
11	7	6000.00
12	8	6000.00
13	9	8000.00
14	10	8000.00
15	11	8000.00
16	12	8000.00
\.


--
-- Data for Name: galerie; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie (id, storage_path, date_insertion) FROM stdin;
\.


--
-- Data for Name: galerie_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galerie_admin (id, storage_path, nom_fichier, taille_octets, ajoute_par, date_ajout) FROM stdin;
\.


--
-- Data for Name: log_whatsapp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_whatsapp (id, matricule, mois_souscription, montant_restant, contact_parent, envoye_par, date_envoi) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (id, identifiant, portail, reussi, ip, date_tentative) FROM stdin;
1	devtesteur	admin	t	\N	2026-07-17 04:17:49.4899+00
2	devtesteur	admin	t	\N	2026-07-17 04:53:06.496601+00
3	devtesteur	admin	t	\N	2026-07-28 09:37:42.312298+00
4	devtesteur	admin	t	\N	2026-07-28 12:23:28.791909+00
5	devtesteur	admin	t	\N	2026-07-28 19:55:44.394708+00
6	devtesteur	admin	t	\N	2026-07-28 21:00:48.393903+00
7	devtesteur	admin	t	\N	2026-07-29 04:42:07.134577+00
8	devtesteur	admin	t	\N	2026-07-29 05:45:44.038591+00
9	devtesteur	admin	t	\N	2026-07-29 11:50:22.392165+00
10	devtesteur	admin	t	\N	2026-08-01 19:07:26.145421+00
11	devtesteur	admin	f	\N	2026-08-01 19:52:58.599866+00
12	devtesteur	admin	t	\N	2026-08-01 19:53:13.806557+00
13	devtesteur	admin	t	\N	2026-08-05 20:14:12.805504+00
14	devtesteur	admin	t	\N	2026-08-05 20:26:35.501833+00
\.


--
-- Data for Name: matieres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matieres (id, nom, code, ordre, actif) FROM stdin;
39	Francais	FR	1	t
40	Mathematiques	MATHS	2	t
41	Anglais	ANG	3	t
42	Physique-Chimie	PCT	4	t
43	SVT	SVT	5	t
44	Philosophie	PHILO	6	t
45	Histoire-Geographie	HG	7	t
46	Economie	ECO	8	t
47	Espagnol	ESP	9	t
48	Allemand	ALL	10	t
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (id, eleve_id, matiere_id, type_note, valeur, annee_scolaire_id, updated_at) FROM stdin;
1	5	39	D1	9.20	1	2026-07-28 12:09:41.516787+00
2	5	39	Ctrl	6.80	1	2026-07-28 12:09:41.516787+00
3	5	40	I1	15.00	1	2026-07-28 12:09:41.516787+00
4	5	40	D1	9.60	1	2026-07-28 12:09:41.516787+00
5	5	40	Ctrl	7.00	1	2026-07-28 12:09:41.516787+00
6	5	41	I1	9.70	1	2026-07-28 12:09:41.516787+00
7	5	41	D1	18.40	1	2026-07-28 12:09:41.516787+00
8	5	41	Ctrl	12.40	1	2026-07-28 12:09:41.516787+00
9	6	39	I1	6.60	1	2026-07-28 12:09:41.516787+00
10	6	39	D1	9.30	1	2026-07-28 12:09:41.516787+00
11	6	39	Ctrl	14.60	1	2026-07-28 12:09:41.516787+00
12	6	40	I1	15.80	1	2026-07-28 12:09:41.516787+00
13	6	40	D1	13.50	1	2026-07-28 12:09:41.516787+00
14	6	40	Ctrl	15.50	1	2026-07-28 12:09:41.516787+00
15	6	41	I1	15.20	1	2026-07-28 12:09:41.516787+00
16	6	41	D1	15.00	1	2026-07-28 12:09:41.516787+00
17	6	41	Ctrl	14.30	1	2026-07-28 12:09:41.516787+00
18	7	39	I1	17.30	1	2026-07-28 12:09:41.516787+00
19	7	39	D1	15.80	1	2026-07-28 12:09:41.516787+00
20	7	39	Ctrl	16.30	1	2026-07-28 12:09:41.516787+00
21	7	40	D1	11.40	1	2026-07-28 12:09:41.516787+00
22	7	40	Ctrl	16.20	1	2026-07-28 12:09:41.516787+00
23	7	41	I1	10.90	1	2026-07-28 12:09:41.516787+00
24	7	41	D1	11.50	1	2026-07-28 12:09:41.516787+00
25	7	41	Ctrl	16.50	1	2026-07-28 12:09:41.516787+00
26	8	39	I1	18.80	1	2026-07-28 12:09:41.516787+00
27	8	39	Ctrl	12.50	1	2026-07-28 12:09:41.516787+00
28	8	41	I1	13.80	1	2026-07-28 12:09:41.516787+00
29	8	41	D1	12.70	1	2026-07-28 12:09:41.516787+00
30	8	41	Ctrl	14.90	1	2026-07-28 12:09:41.516787+00
31	9	39	I1	18.60	1	2026-07-28 12:09:41.516787+00
32	9	39	D1	8.20	1	2026-07-28 12:09:41.516787+00
33	9	39	Ctrl	7.00	1	2026-07-28 12:09:41.516787+00
34	9	40	I1	14.50	1	2026-07-28 12:09:41.516787+00
35	9	40	D1	13.80	1	2026-07-28 12:09:41.516787+00
36	9	40	Ctrl	9.00	1	2026-07-28 12:09:41.516787+00
37	9	41	I1	15.10	1	2026-07-28 12:09:41.516787+00
38	9	41	Ctrl	6.50	1	2026-07-28 12:09:41.516787+00
39	10	39	I1	10.00	1	2026-07-28 12:09:41.516787+00
40	10	39	D1	12.10	1	2026-07-28 12:09:41.516787+00
41	10	40	I1	10.60	1	2026-07-28 12:09:41.516787+00
42	10	40	Ctrl	17.20	1	2026-07-28 12:09:41.516787+00
43	10	41	I1	13.10	1	2026-07-28 12:09:41.516787+00
44	12	39	I1	6.10	1	2026-07-28 12:09:41.516787+00
45	12	39	D1	9.90	1	2026-07-28 12:09:41.516787+00
46	12	39	Ctrl	15.60	1	2026-07-28 12:09:41.516787+00
47	12	40	I1	18.90	1	2026-07-28 12:09:41.516787+00
48	12	40	D1	10.60	1	2026-07-28 12:09:41.516787+00
49	12	40	Ctrl	15.60	1	2026-07-28 12:09:41.516787+00
50	12	41	I1	7.30	1	2026-07-28 12:09:41.516787+00
51	12	41	D1	11.00	1	2026-07-28 12:09:41.516787+00
52	12	41	Ctrl	16.40	1	2026-07-28 12:09:41.516787+00
53	15	39	D1	11.30	1	2026-07-28 12:09:41.516787+00
54	15	39	Ctrl	8.50	1	2026-07-28 12:09:41.516787+00
55	15	40	I1	11.10	1	2026-07-28 12:09:41.516787+00
56	15	40	D1	10.90	1	2026-07-28 12:09:41.516787+00
57	15	40	Ctrl	15.20	1	2026-07-28 12:09:41.516787+00
58	15	41	I1	10.60	1	2026-07-28 12:09:41.516787+00
59	15	41	D1	15.00	1	2026-07-28 12:09:41.516787+00
60	15	41	Ctrl	7.20	1	2026-07-28 12:09:41.516787+00
61	16	39	I1	13.90	1	2026-07-28 12:09:41.516787+00
62	16	39	D1	15.00	1	2026-07-28 12:09:41.516787+00
63	16	39	Ctrl	6.50	1	2026-07-28 12:09:41.516787+00
64	16	40	I1	6.30	1	2026-07-28 12:09:41.516787+00
65	16	40	D1	11.20	1	2026-07-28 12:09:41.516787+00
66	16	40	Ctrl	8.10	1	2026-07-28 12:09:41.516787+00
67	16	41	I1	9.80	1	2026-07-28 12:09:41.516787+00
68	16	41	D1	17.40	1	2026-07-28 12:09:41.516787+00
69	17	39	I1	18.80	1	2026-07-28 12:09:41.516787+00
70	17	39	D1	14.90	1	2026-07-28 12:09:41.516787+00
71	17	39	Ctrl	16.30	1	2026-07-28 12:09:41.516787+00
72	17	40	I1	12.30	1	2026-07-28 12:09:41.516787+00
73	17	40	D1	13.60	1	2026-07-28 12:09:41.516787+00
74	17	41	D1	18.10	1	2026-07-28 12:09:41.516787+00
75	17	41	Ctrl	13.20	1	2026-07-28 12:09:41.516787+00
76	18	39	I1	12.70	1	2026-07-28 12:09:41.516787+00
77	18	39	D1	10.00	1	2026-07-28 12:09:41.516787+00
78	18	40	D1	7.90	1	2026-07-28 12:09:41.516787+00
79	18	40	Ctrl	12.00	1	2026-07-28 12:09:41.516787+00
80	18	41	I1	11.90	1	2026-07-28 12:09:41.516787+00
81	18	41	Ctrl	15.00	1	2026-07-28 12:09:41.516787+00
82	19	39	D1	18.90	1	2026-07-28 12:09:41.516787+00
83	19	39	Ctrl	17.40	1	2026-07-28 12:09:41.516787+00
84	19	40	I1	13.70	1	2026-07-28 12:09:41.516787+00
85	19	40	D1	18.20	1	2026-07-28 12:09:41.516787+00
86	19	41	I1	8.80	1	2026-07-28 12:09:41.516787+00
87	19	41	Ctrl	16.60	1	2026-07-28 12:09:41.516787+00
88	21	39	D1	7.20	1	2026-07-28 12:09:41.516787+00
89	21	39	Ctrl	12.20	1	2026-07-28 12:09:41.516787+00
90	21	40	I1	10.50	1	2026-07-28 12:09:41.516787+00
91	21	40	Ctrl	12.60	1	2026-07-28 12:09:41.516787+00
92	21	41	I1	17.40	1	2026-07-28 12:09:41.516787+00
93	21	41	D1	14.20	1	2026-07-28 12:09:41.516787+00
94	22	39	I1	6.00	1	2026-07-28 12:09:41.516787+00
95	22	39	D1	7.30	1	2026-07-28 12:09:41.516787+00
96	22	39	Ctrl	9.70	1	2026-07-28 12:09:41.516787+00
97	22	40	I1	12.40	1	2026-07-28 12:09:41.516787+00
98	22	40	D1	13.60	1	2026-07-28 12:09:41.516787+00
99	22	40	Ctrl	9.90	1	2026-07-28 12:09:41.516787+00
100	22	41	I1	7.30	1	2026-07-28 12:09:41.516787+00
101	24	39	I1	9.60	1	2026-07-28 12:09:41.516787+00
102	24	39	D1	6.00	1	2026-07-28 12:09:41.516787+00
103	24	39	Ctrl	13.70	1	2026-07-28 12:09:41.516787+00
104	24	40	I1	13.40	1	2026-07-28 12:09:41.516787+00
105	24	40	D1	12.90	1	2026-07-28 12:09:41.516787+00
106	24	40	Ctrl	10.00	1	2026-07-28 12:09:41.516787+00
107	24	41	D1	16.00	1	2026-07-28 12:09:41.516787+00
108	24	41	Ctrl	14.80	1	2026-07-28 12:09:41.516787+00
109	25	39	Ctrl	13.60	1	2026-07-28 12:09:41.516787+00
110	25	41	I1	13.50	1	2026-07-28 12:09:41.516787+00
111	25	41	D1	10.80	1	2026-07-28 12:09:41.516787+00
112	25	41	Ctrl	13.10	1	2026-07-28 12:09:41.516787+00
113	26	39	D1	9.70	1	2026-07-28 12:09:41.516787+00
114	26	39	Ctrl	9.00	1	2026-07-28 12:09:41.516787+00
115	26	40	I1	8.30	1	2026-07-28 12:09:41.516787+00
116	26	40	D1	7.60	1	2026-07-28 12:09:41.516787+00
117	26	40	Ctrl	18.10	1	2026-07-28 12:09:41.516787+00
118	26	41	I1	11.80	1	2026-07-28 12:09:41.516787+00
119	29	39	D1	15.40	1	2026-07-28 12:09:41.516787+00
120	29	39	Ctrl	12.10	1	2026-07-28 12:09:41.516787+00
121	29	40	I1	14.10	1	2026-07-28 12:09:41.516787+00
122	29	40	Ctrl	11.60	1	2026-07-28 12:09:41.516787+00
123	29	41	I1	7.60	1	2026-07-28 12:09:41.516787+00
124	29	41	D1	10.60	1	2026-07-28 12:09:41.516787+00
125	31	39	I1	16.20	1	2026-07-28 12:09:41.516787+00
126	31	39	D1	11.00	1	2026-07-28 12:09:41.516787+00
127	31	39	Ctrl	10.80	1	2026-07-28 12:09:41.516787+00
128	31	40	I1	9.00	1	2026-07-28 12:09:41.516787+00
129	31	40	D1	7.20	1	2026-07-28 12:09:41.516787+00
130	31	40	Ctrl	8.20	1	2026-07-28 12:09:41.516787+00
131	31	41	I1	13.30	1	2026-07-28 12:09:41.516787+00
132	31	41	D1	18.00	1	2026-07-28 12:09:41.516787+00
133	31	41	Ctrl	13.20	1	2026-07-28 12:09:41.516787+00
134	32	40	I1	14.20	1	2026-07-28 12:09:41.516787+00
135	32	40	D1	14.00	1	2026-07-28 12:09:41.516787+00
136	32	41	I1	8.70	1	2026-07-28 12:09:41.516787+00
137	32	41	Ctrl	13.30	1	2026-07-28 12:09:41.516787+00
138	33	39	I1	14.40	1	2026-07-28 12:09:41.516787+00
139	33	39	Ctrl	10.90	1	2026-07-28 12:09:41.516787+00
140	33	40	I1	12.00	1	2026-07-28 12:09:41.516787+00
141	33	40	D1	11.10	1	2026-07-28 12:09:41.516787+00
142	33	40	Ctrl	8.70	1	2026-07-28 12:09:41.516787+00
143	33	41	Ctrl	7.70	1	2026-07-28 12:09:41.516787+00
144	34	39	I1	12.90	1	2026-07-28 12:09:41.516787+00
145	34	39	D1	18.20	1	2026-07-28 12:09:41.516787+00
146	34	39	Ctrl	12.20	1	2026-07-28 12:09:41.516787+00
147	34	40	I1	12.10	1	2026-07-28 12:09:41.516787+00
148	34	40	D1	9.60	1	2026-07-28 12:09:41.516787+00
149	34	40	Ctrl	15.40	1	2026-07-28 12:09:41.516787+00
150	34	41	I1	18.50	1	2026-07-28 12:09:41.516787+00
151	34	41	Ctrl	16.00	1	2026-07-28 12:09:41.516787+00
152	35	39	I1	13.20	1	2026-07-28 12:09:41.516787+00
153	35	39	D1	16.80	1	2026-07-28 12:09:41.516787+00
154	35	40	I1	10.90	1	2026-07-28 12:09:41.516787+00
155	35	40	D1	15.60	1	2026-07-28 12:09:41.516787+00
156	35	40	Ctrl	14.50	1	2026-07-28 12:09:41.516787+00
157	35	41	I1	11.80	1	2026-07-28 12:09:41.516787+00
158	35	41	D1	8.50	1	2026-07-28 12:09:41.516787+00
159	35	41	Ctrl	13.90	1	2026-07-28 12:09:41.516787+00
160	36	39	I1	12.50	1	2026-07-28 12:09:41.516787+00
161	36	39	D1	6.30	1	2026-07-28 12:09:41.516787+00
162	36	39	Ctrl	13.10	1	2026-07-28 12:09:41.516787+00
163	36	40	D1	12.00	1	2026-07-28 12:09:41.516787+00
164	36	41	I1	12.20	1	2026-07-28 12:09:41.516787+00
165	36	41	D1	12.60	1	2026-07-28 12:09:41.516787+00
166	36	41	Ctrl	18.00	1	2026-07-28 12:09:41.516787+00
167	37	39	D1	10.70	1	2026-07-28 12:09:41.516787+00
168	37	39	Ctrl	15.50	1	2026-07-28 12:09:41.516787+00
169	37	40	I1	7.50	1	2026-07-28 12:09:41.516787+00
170	37	40	D1	6.70	1	2026-07-28 12:09:41.516787+00
171	37	40	Ctrl	7.70	1	2026-07-28 12:09:41.516787+00
172	37	41	I1	14.60	1	2026-07-28 12:09:41.516787+00
173	37	41	D1	9.50	1	2026-07-28 12:09:41.516787+00
174	37	41	Ctrl	16.40	1	2026-07-28 12:09:41.516787+00
175	38	39	I1	16.60	1	2026-07-28 12:09:41.516787+00
176	38	39	Ctrl	16.90	1	2026-07-28 12:09:41.516787+00
177	38	40	Ctrl	13.00	1	2026-07-28 12:09:41.516787+00
178	38	41	I1	12.10	1	2026-07-28 12:09:41.516787+00
179	38	41	D1	8.40	1	2026-07-28 12:09:41.516787+00
180	38	41	Ctrl	11.90	1	2026-07-28 12:09:41.516787+00
181	39	39	I1	18.00	1	2026-07-28 12:09:41.516787+00
182	39	39	D1	9.50	1	2026-07-28 12:09:41.516787+00
183	39	40	I1	17.40	1	2026-07-28 12:09:41.516787+00
184	39	40	D1	16.10	1	2026-07-28 12:09:41.516787+00
185	39	40	Ctrl	16.10	1	2026-07-28 12:09:41.516787+00
186	39	41	I1	18.90	1	2026-07-28 12:09:41.516787+00
187	39	41	D1	14.00	1	2026-07-28 12:09:41.516787+00
188	40	39	D1	6.50	1	2026-07-28 12:09:41.516787+00
189	40	39	Ctrl	10.50	1	2026-07-28 12:09:41.516787+00
190	40	40	Ctrl	7.40	1	2026-07-28 12:09:41.516787+00
191	40	41	I1	6.90	1	2026-07-28 12:09:41.516787+00
192	40	41	Ctrl	13.50	1	2026-07-28 12:09:41.516787+00
193	41	39	D1	6.80	1	2026-07-28 12:09:41.516787+00
194	41	39	Ctrl	11.30	1	2026-07-28 12:09:41.516787+00
195	41	40	D1	10.40	1	2026-07-28 12:09:41.516787+00
196	41	40	Ctrl	15.60	1	2026-07-28 12:09:41.516787+00
197	41	41	I1	15.70	1	2026-07-28 12:09:41.516787+00
198	41	41	D1	18.40	1	2026-07-28 12:09:41.516787+00
199	41	41	Ctrl	14.10	1	2026-07-28 12:09:41.516787+00
200	42	39	I1	15.10	1	2026-07-28 12:09:41.516787+00
201	42	39	D1	10.30	1	2026-07-28 12:09:41.671801+00
202	42	39	Ctrl	8.80	1	2026-07-28 12:09:41.671801+00
203	42	40	I1	12.70	1	2026-07-28 12:09:41.671801+00
204	42	40	D1	10.60	1	2026-07-28 12:09:41.671801+00
205	42	41	I1	11.40	1	2026-07-28 12:09:41.671801+00
206	42	41	D1	7.20	1	2026-07-28 12:09:41.671801+00
207	42	41	Ctrl	10.10	1	2026-07-28 12:09:41.671801+00
208	45	39	D1	12.60	1	2026-07-28 12:09:41.671801+00
209	45	39	Ctrl	13.50	1	2026-07-28 12:09:41.671801+00
210	45	40	I1	9.50	1	2026-07-28 12:09:41.671801+00
211	45	40	D1	12.10	1	2026-07-28 12:09:41.671801+00
212	45	41	I1	11.70	1	2026-07-28 12:09:41.671801+00
213	45	41	D1	17.90	1	2026-07-28 12:09:41.671801+00
214	45	41	Ctrl	11.60	1	2026-07-28 12:09:41.671801+00
215	47	39	I1	7.50	1	2026-07-28 12:09:41.671801+00
216	47	39	D1	12.00	1	2026-07-28 12:09:41.671801+00
217	47	39	Ctrl	10.50	1	2026-07-28 12:09:41.671801+00
218	47	40	I1	18.20	1	2026-07-28 12:09:41.671801+00
219	47	40	D1	17.80	1	2026-07-28 12:09:41.671801+00
220	47	41	I1	6.80	1	2026-07-28 12:09:41.671801+00
221	47	41	Ctrl	16.70	1	2026-07-28 12:09:41.671801+00
222	48	39	I1	11.20	1	2026-07-28 12:09:41.671801+00
223	48	39	D1	10.70	1	2026-07-28 12:09:41.671801+00
224	48	40	I1	6.80	1	2026-07-28 12:09:41.671801+00
225	48	40	D1	13.20	1	2026-07-28 12:09:41.671801+00
226	48	40	Ctrl	7.50	1	2026-07-28 12:09:41.671801+00
227	48	41	I1	14.00	1	2026-07-28 12:09:41.671801+00
228	48	41	D1	6.70	1	2026-07-28 12:09:41.671801+00
229	48	41	Ctrl	16.50	1	2026-07-28 12:09:41.671801+00
230	50	39	D1	17.40	1	2026-07-28 12:09:41.671801+00
231	50	39	Ctrl	19.00	1	2026-07-28 12:09:41.671801+00
232	50	40	I1	7.90	1	2026-07-28 12:09:41.671801+00
233	50	40	D1	6.20	1	2026-07-28 12:09:41.671801+00
234	50	40	Ctrl	10.60	1	2026-07-28 12:09:41.671801+00
235	50	41	I1	8.80	1	2026-07-28 12:09:41.671801+00
236	50	41	Ctrl	12.00	1	2026-07-28 12:09:41.671801+00
237	51	39	I1	12.30	1	2026-07-28 12:09:41.671801+00
238	51	39	D1	14.70	1	2026-07-28 12:09:41.671801+00
239	51	39	Ctrl	17.30	1	2026-07-28 12:09:41.671801+00
240	51	40	I1	7.30	1	2026-07-28 12:09:41.671801+00
241	51	40	D1	16.90	1	2026-07-28 12:09:41.671801+00
242	51	40	Ctrl	7.90	1	2026-07-28 12:09:41.671801+00
243	51	41	I1	12.60	1	2026-07-28 12:09:41.671801+00
244	51	41	Ctrl	7.60	1	2026-07-28 12:09:41.671801+00
245	52	39	I1	11.40	1	2026-07-28 12:09:41.671801+00
246	52	39	D1	18.40	1	2026-07-28 12:09:41.671801+00
247	52	39	Ctrl	6.00	1	2026-07-28 12:09:41.671801+00
248	52	40	I1	10.20	1	2026-07-28 12:09:41.671801+00
249	52	40	D1	12.40	1	2026-07-28 12:09:41.671801+00
250	52	40	Ctrl	13.50	1	2026-07-28 12:09:41.671801+00
251	52	41	I1	18.80	1	2026-07-28 12:09:41.671801+00
252	52	41	D1	16.30	1	2026-07-28 12:09:41.671801+00
253	52	41	Ctrl	8.30	1	2026-07-28 12:09:41.671801+00
254	3	39	I1	12.00	1	2026-07-29 05:06:13.25941+00
255	52	44	I1	12.00	1	2026-08-01 20:27:06.522447+00
256	52	39	D2	5.00	1	2026-08-01 20:37:54.657949+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, site_id, contenu, lu, date_creation) FROM stdin;
1	1	Suspension automatique : GNANSOUNOU Franck Anicet (J07263885) — défaut de paiement Octobre, 5000 F restants.	f	2026-07-28 12:51:20.202754+00
2	1	Suspension automatique : HOUNSOU Marcellin (J07263911) — défaut de paiement Octobre, 2050 F restants.	f	2026-07-28 12:51:20.652908+00
3	1	Suspension automatique : SOSSOU Elie (J07263489) — défaut de paiement Octobre, 6000 F restants.	f	2026-07-28 12:51:21.087461+00
4	1	Suspension automatique : GLELE Divin (J07264683) — défaut de paiement Octobre, 8000 F restants.	f	2026-07-28 12:51:21.513636+00
5	1	Suspension automatique : HOUNSOU Kossi (J07261910) — défaut de paiement Octobre, 3120 F restants.	f	2026-07-28 12:51:21.944265+00
6	2	Suspension automatique : AGOSSOU Comlan (Y07261650) — défaut de paiement Octobre, 3000 F restants.	f	2026-07-28 12:51:22.368132+00
7	2	Suspension automatique : DJOSSOU Carole Marlène (Y07266408) — défaut de paiement Octobre, 3000 F restants.	f	2026-07-28 12:51:22.785173+00
8	1	Suspension automatique : AGBODJOGBE Prisca (J07264591) — défaut de paiement Octobre, 3000 F restants.	f	2026-07-28 12:51:23.225145+00
9	1	Suspension automatique : HODONOU Emmanuel (J07265729) — défaut de paiement Octobre, 5000 F restants.	f	2026-07-28 12:51:23.646646+00
10	1	Suspension automatique : ALLADATIN Merveille Prisca (J07266825) — défaut de paiement Octobre, 5000 F restants.	f	2026-07-28 12:51:24.078635+00
11	1	Suspension automatique : DEGBEY Sandra (J07267070) — défaut de paiement Octobre, 6000 F restants.	f	2026-07-28 12:51:24.498545+00
12	1	Suspension automatique : DOSSOU Anicet Comlan (J07267741) — défaut de paiement Octobre, 6000 F restants.	f	2026-07-28 12:51:24.971107+00
13	1	Suspension automatique : AVOCE Christelle (J07268815) — défaut de paiement Octobre, 8000 F restants.	f	2026-07-28 12:51:25.408209+00
14	2	Suspension automatique : AVOCE Judith (Y07265053) — défaut de paiement Octobre, 960 F restants.	f	2026-07-28 12:51:25.833341+00
15	2	Suspension automatique : KPOTIN Chimène (Y07263190) — défaut de paiement Octobre, 3000 F restants.	f	2026-07-28 12:51:26.257544+00
16	1	Suspension automatique : AHOYO Prudencio (J07264427) — défaut de paiement Octobre, 1680 F restants.	f	2026-07-28 12:51:26.692572+00
17	1	Suspension automatique : HOUNKPE Merveille Grâce (J07262873) — défaut de paiement Octobre, 5000 F restants.	f	2026-07-28 12:51:27.110621+00
18	1	Suspension automatique : DEGBEY Sandrine (J07269208) — défaut de paiement Octobre, 5000 F restants.	f	2026-07-28 12:51:27.532365+00
19	2	Suspension automatique : TOKPONOU Wilfried (Y07266323) — défaut de paiement Octobre, 3000 F restants.	f	2026-07-28 12:51:27.95408+00
20	1	Suspension automatique : AGOSSOU Carole (J07268443) — défaut de paiement Octobre, 960 F restants.	f	2026-07-28 12:51:28.375492+00
\.


--
-- Data for Name: paiements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements (id, eleve_id, mois_souscription, montant_paye, date_paiement, mode_paiement, annee_scolaire_id) FROM stdin;
1	3	Octobre	2000	2026-10-08	MoMo	1
2	3	Novembre	960	2026-11-18	Presentiel	1
3	3	Decembre	2000	2026-12-06	Presentiel	1
4	3	Janvier	2000	2027-01-08	Presentiel	1
5	3	Fevrier	2000	2027-02-22	Presentiel	1
6	3	Mars	2000	2027-03-24	MoMo	1
7	3	Mai	740	2027-05-07	MoMo	1
8	4	Octobre	3000	2026-10-05	Presentiel	1
9	4	Novembre	3000	2026-11-02	Presentiel	1
10	4	Decembre	3000	2026-12-20	MoMo	1
11	4	Janvier	3000	2027-01-26	MoMo	1
12	4	Fevrier	3000	2027-02-08	Presentiel	1
13	4	Avril	3000	2027-04-03	MoMo	1
14	4	Mai	3000	2027-05-26	Presentiel	1
15	5	Octobre	3000	2026-10-04	MoMo	1
16	5	Novembre	3000	2026-11-02	MoMo	1
17	6	Novembre	2900	2026-11-21	MoMo	1
18	6	Mars	2800	2027-03-19	MoMo	1
19	6	Mai	5000	2027-05-18	MoMo	1
20	7	Octobre	5000	2026-10-19	Presentiel	1
21	7	Novembre	5000	2026-11-10	MoMo	1
22	8	Octobre	2950	2026-10-17	MoMo	1
23	8	Decembre	5000	2026-12-13	MoMo	1
24	8	Janvier	2500	2027-01-17	MoMo	1
25	8	Mars	3350	2027-03-05	MoMo	1
26	9	Octobre	6000	2026-10-04	MoMo	1
27	10	Novembre	6000	2026-11-09	Presentiel	1
28	10	Decembre	6000	2026-12-05	Presentiel	1
29	10	Fevrier	4140	2027-02-13	MoMo	1
30	10	Mars	3420	2027-03-25	MoMo	1
31	10	Avril	6000	2027-04-24	Presentiel	1
32	12	Decembre	8000	2026-12-22	Presentiel	1
33	12	Janvier	4240	2027-01-15	MoMo	1
34	12	Fevrier	3920	2027-02-18	Presentiel	1
35	13	Octobre	8000	2026-10-07	MoMo	1
36	13	Novembre	8000	2026-11-11	Presentiel	1
37	13	Decembre	8000	2026-12-25	MoMo	1
38	13	Janvier	4320	2027-01-20	Presentiel	1
39	13	Fevrier	2560	2027-02-03	MoMo	1
40	13	Mars	8000	2027-03-03	Presentiel	1
41	13	Avril	8000	2027-04-11	MoMo	1
42	13	Mai	8000	2027-05-26	MoMo	1
43	14	Octobre	4880	2026-10-18	Presentiel	1
44	14	Novembre	8000	2026-11-07	Presentiel	1
45	14	Decembre	3760	2026-12-23	Presentiel	1
46	14	Janvier	8000	2027-01-05	Presentiel	1
47	14	Fevrier	8000	2027-02-26	MoMo	1
48	14	Mars	8000	2027-03-03	Presentiel	1
49	14	Avril	8000	2027-04-16	MoMo	1
50	14	Mai	8000	2027-05-25	MoMo	1
51	15	Octobre	2000	2026-10-07	Presentiel	1
52	15	Decembre	2000	2026-12-05	Presentiel	1
53	15	Janvier	2000	2027-01-02	Presentiel	1
54	15	Fevrier	2000	2027-02-11	Presentiel	1
55	15	Mars	2000	2027-03-07	MoMo	1
56	15	Avril	2000	2027-04-11	MoMo	1
57	15	Mai	2000	2027-05-23	MoMo	1
58	16	Novembre	1590	2026-11-12	MoMo	1
59	16	Fevrier	1050	2027-02-15	MoMo	1
60	16	Avril	2010	2027-04-13	MoMo	1
61	16	Mai	1230	2027-05-25	Presentiel	1
62	17	Fevrier	3000	2027-02-05	Presentiel	1
63	17	Mars	1470	2027-03-16	Presentiel	1
64	17	Mai	3000	2027-05-12	MoMo	1
65	18	Octobre	5000	2026-10-15	MoMo	1
66	18	Novembre	5000	2026-11-08	Presentiel	1
67	19	Octobre	2000	2026-10-22	MoMo	1
68	19	Novembre	880	2026-11-17	MoMo	1
69	19	Janvier	2000	2027-01-07	MoMo	1
70	19	Fevrier	2000	2027-02-06	MoMo	1
71	19	Mars	1020	2027-03-15	MoMo	1
72	19	Avril	2000	2027-04-23	MoMo	1
73	19	Mai	2000	2027-05-10	MoMo	1
74	20	Octobre	3000	2026-10-04	MoMo	1
75	20	Novembre	3000	2026-11-03	MoMo	1
76	21	Novembre	1290	2026-11-07	MoMo	1
77	21	Decembre	3000	2026-12-24	Presentiel	1
78	21	Fevrier	1950	2027-02-02	MoMo	1
79	21	Mars	3000	2027-03-13	MoMo	1
80	21	Mai	3000	2027-05-20	MoMo	1
81	22	Octobre	5000	2026-10-13	MoMo	1
82	22	Novembre	5000	2026-11-21	MoMo	1
83	22	Decembre	5000	2026-12-06	Presentiel	1
84	22	Janvier	5000	2027-01-04	MoMo	1
85	22	Fevrier	5000	2027-02-18	Presentiel	1
86	22	Mars	5000	2027-03-24	MoMo	1
87	22	Avril	5000	2027-04-21	Presentiel	1
88	23	Novembre	1600	2026-11-03	Presentiel	1
89	23	Janvier	5000	2027-01-25	MoMo	1
90	23	Fevrier	1550	2027-02-16	Presentiel	1
91	23	Mars	5000	2027-03-12	MoMo	1
92	23	Mai	1750	2027-05-07	Presentiel	1
93	24	Novembre	5000	2026-11-04	Presentiel	1
94	24	Mars	2250	2027-03-25	Presentiel	1
95	24	Avril	5000	2027-04-23	MoMo	1
96	25	Novembre	1980	2026-11-03	MoMo	1
97	25	Decembre	2940	2026-12-02	MoMo	1
98	25	Janvier	6000	2027-01-19	MoMo	1
99	25	Mars	3360	2027-03-04	MoMo	1
100	25	Mai	6000	2027-05-14	MoMo	1
101	26	Fevrier	3000	2027-02-18	MoMo	1
102	26	Mars	1800	2027-03-21	Presentiel	1
103	26	Avril	2100	2027-04-23	MoMo	1
104	28	Octobre	8000	2026-10-18	MoMo	1
105	28	Novembre	8000	2026-11-10	Presentiel	1
106	29	Novembre	4400	2026-11-19	MoMo	1
107	29	Decembre	8000	2026-12-03	Presentiel	1
108	29	Fevrier	5200	2027-02-11	MoMo	1
109	29	Mars	4320	2027-03-12	MoMo	1
110	29	Avril	8000	2027-04-17	MoMo	1
111	30	Octobre	8000	2026-10-24	MoMo	1
112	31	Octobre	1040	2026-10-24	Presentiel	1
113	31	Decembre	900	2026-12-22	MoMo	1
114	31	Fevrier	1320	2027-02-17	MoMo	1
115	31	Mars	800	2027-03-17	Presentiel	1
116	31	Mai	2000	2027-05-19	MoMo	1
117	32	Octobre	3000	2026-10-23	Presentiel	1
118	32	Novembre	3000	2026-11-22	MoMo	1
119	33	Novembre	3000	2026-11-20	MoMo	1
120	33	Decembre	3000	2026-12-15	Presentiel	1
121	33	Janvier	3000	2027-01-10	Presentiel	1
122	33	Fevrier	3000	2027-02-14	MoMo	1
123	33	Mai	3000	2027-05-23	Presentiel	1
124	34	Octobre	5000	2026-10-08	Presentiel	1
125	34	Novembre	5000	2026-11-24	Presentiel	1
126	35	Octobre	2000	2026-10-03	MoMo	1
127	35	Novembre	2000	2026-11-19	Presentiel	1
128	35	Janvier	2000	2027-01-22	MoMo	1
129	35	Mars	2000	2027-03-07	MoMo	1
130	35	Avril	2000	2027-04-17	Presentiel	1
131	35	Mai	2000	2027-05-02	MoMo	1
132	36	Octobre	3000	2026-10-15	MoMo	1
133	37	Octobre	1320	2026-10-07	MoMo	1
134	37	Novembre	1440	2026-11-19	MoMo	1
135	37	Janvier	1440	2027-01-23	Presentiel	1
136	37	Fevrier	1080	2027-02-05	Presentiel	1
137	38	Decembre	2650	2026-12-08	Presentiel	1
138	38	Fevrier	3350	2027-02-10	MoMo	1
139	38	Avril	5000	2027-04-20	MoMo	1
140	39	Octobre	5000	2026-10-11	MoMo	1
141	39	Novembre	1600	2026-11-21	MoMo	1
142	39	Decembre	2500	2026-12-23	MoMo	1
143	39	Janvier	2900	2027-01-05	MoMo	1
144	39	Mars	2200	2027-03-10	Presentiel	1
145	40	Decembre	1750	2026-12-16	MoMo	1
146	40	Avril	5000	2027-04-20	MoMo	1
147	41	Octobre	6000	2026-10-23	Presentiel	1
148	41	Novembre	2880	2026-11-24	Presentiel	1
149	41	Decembre	6000	2026-12-10	Presentiel	1
150	41	Janvier	6000	2027-01-20	MoMo	1
151	41	Fevrier	6000	2027-02-10	MoMo	1
152	41	Mars	6000	2027-03-16	Presentiel	1
153	41	Avril	6000	2027-04-02	MoMo	1
154	41	Mai	6000	2027-05-16	Presentiel	1
155	42	Octobre	6000	2026-10-05	Presentiel	1
156	42	Novembre	6000	2026-11-08	MoMo	1
157	42	Decembre	6000	2026-12-02	MoMo	1
158	42	Janvier	6000	2027-01-10	Presentiel	1
159	42	Fevrier	6000	2027-02-24	MoMo	1
160	42	Mars	6000	2027-03-22	Presentiel	1
161	42	Avril	6000	2027-04-18	Presentiel	1
162	42	Mai	3900	2027-05-15	Presentiel	1
163	43	Octobre	8000	2026-10-08	MoMo	1
164	43	Novembre	3200	2026-11-11	MoMo	1
165	43	Mars	3600	2027-03-16	Presentiel	1
166	43	Mai	3600	2027-05-12	Presentiel	1
167	45	Octobre	8000	2026-10-22	Presentiel	1
168	45	Novembre	8000	2026-11-23	MoMo	1
169	46	Octobre	8000	2026-10-12	Presentiel	1
170	47	Octobre	2000	2026-10-06	MoMo	1
171	47	Novembre	2000	2026-11-12	MoMo	1
172	47	Decembre	2000	2026-12-23	Presentiel	1
173	47	Janvier	2000	2027-01-11	MoMo	1
174	47	Fevrier	2000	2027-02-04	Presentiel	1
175	47	Mars	2000	2027-03-22	Presentiel	1
176	47	Avril	2000	2027-04-03	MoMo	1
177	47	Mai	1320	2027-05-11	Presentiel	1
178	48	Novembre	3000	2026-11-25	MoMo	1
179	48	Decembre	3000	2026-12-24	Presentiel	1
180	48	Janvier	3000	2027-01-03	Presentiel	1
181	48	Fevrier	3000	2027-02-04	MoMo	1
182	48	Mars	3000	2027-03-19	Presentiel	1
183	48	Avril	3000	2027-04-24	MoMo	1
184	48	Mai	3000	2027-05-22	MoMo	1
185	49	Octobre	3000	2026-10-26	MoMo	1
186	49	Novembre	900	2026-11-24	MoMo	1
187	49	Decembre	3000	2026-12-06	MoMo	1
188	49	Janvier	3000	2027-01-10	Presentiel	1
189	49	Fevrier	3000	2027-02-05	Presentiel	1
190	49	Mars	3000	2027-03-07	Presentiel	1
191	49	Avril	3000	2027-04-21	MoMo	1
192	49	Mai	3000	2027-05-20	MoMo	1
193	50	Octobre	5000	2026-10-15	Presentiel	1
194	50	Novembre	5000	2026-11-13	MoMo	1
195	50	Decembre	5000	2026-12-10	MoMo	1
196	50	Janvier	5000	2027-01-07	MoMo	1
197	50	Fevrier	5000	2027-02-22	Presentiel	1
198	50	Mars	5000	2027-03-05	MoMo	1
199	50	Avril	5000	2027-04-17	MoMo	1
200	50	Mai	2250	2027-05-06	MoMo	1
201	51	Octobre	1040	2026-10-13	MoMo	1
202	51	Decembre	1140	2026-12-08	Presentiel	1
203	51	Fevrier	640	2027-02-17	Presentiel	1
204	51	Mars	2000	2027-03-14	Presentiel	1
205	51	Avril	2000	2027-04-24	MoMo	1
206	51	Mai	2000	2027-05-16	Presentiel	1
207	52	Octobre	3000	2026-10-08	MoMo	1
208	52	Novembre	3000	2026-11-05	MoMo	1
209	52	Decembre	3000	2026-12-03	Presentiel	1
210	52	Fevrier	3000	2027-02-02	MoMo	1
211	52	Mars	3000	2027-03-23	Presentiel	1
212	52	Mai	3000	2027-05-14	MoMo	1
\.


--
-- Data for Name: paiements_supprimes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paiements_supprimes (id, matricule, mois_souscription, montant_paye, date_paiement, mode_paiement, admin_id, date_suppression, motif) FROM stdin;
\.


--
-- Data for Name: presences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.presences (id, eleve_id, date_presence, site_id, classe_id, present, annee_scolaire_id) FROM stdin;
1	3	2026-11-10	1	1	t	1
2	3	2026-12-10	1	1	t	1
3	3	2027-01-10	1	1	t	1
4	3	2027-02-10	1	1	t	1
5	3	2027-03-10	1	1	t	1
6	3	2027-05-10	1	1	t	1
7	4	2026-10-10	1	2	t	1
8	4	2026-11-10	1	2	t	1
9	4	2026-12-10	1	2	t	1
10	4	2027-01-10	1	2	t	1
11	4	2027-02-10	1	2	t	1
12	4	2027-03-10	1	2	t	1
13	4	2027-04-10	1	2	t	1
14	4	2027-05-10	1	2	t	1
15	5	2026-10-10	1	3	t	1
16	5	2026-11-10	1	3	t	1
17	5	2026-12-10	1	3	t	1
18	5	2027-01-10	1	3	t	1
19	5	2027-02-10	1	3	t	1
20	5	2027-03-10	1	3	t	1
21	5	2027-04-10	1	3	t	1
22	5	2027-05-10	1	3	t	1
23	6	2026-10-10	1	4	t	1
24	6	2026-12-10	1	4	t	1
25	6	2027-01-10	1	4	t	1
26	6	2027-02-10	1	4	t	1
27	6	2027-03-10	1	4	t	1
28	6	2027-05-10	1	4	t	1
29	7	2026-11-10	1	5	t	1
30	7	2026-12-10	1	5	t	1
31	7	2027-01-10	1	5	t	1
32	7	2027-03-10	1	5	t	1
33	7	2027-04-10	1	5	t	1
34	7	2027-05-10	1	5	t	1
35	8	2026-10-10	1	6	t	1
36	8	2026-11-10	1	6	t	1
37	8	2026-12-10	1	6	t	1
38	8	2027-01-10	1	6	t	1
39	8	2027-03-10	1	6	t	1
40	8	2027-04-10	1	6	f	1
41	8	2027-05-10	1	6	t	1
42	9	2026-10-10	1	8	t	1
43	9	2026-11-10	1	8	t	1
44	9	2026-12-10	1	8	t	1
45	9	2027-01-10	1	8	t	1
46	9	2027-02-10	1	8	t	1
47	9	2027-03-10	1	8	t	1
48	9	2027-04-10	1	8	t	1
49	9	2027-05-10	1	8	t	1
50	10	2026-10-10	1	7	t	1
51	10	2026-11-10	1	7	t	1
52	10	2026-12-10	1	7	t	1
53	10	2027-02-10	1	7	t	1
54	10	2027-03-10	1	7	t	1
55	10	2027-04-10	1	7	t	1
56	10	2027-05-10	1	7	t	1
57	12	2026-10-10	1	12	t	1
58	12	2026-11-10	1	12	f	1
59	12	2026-12-10	1	12	t	1
60	12	2027-01-10	1	12	f	1
61	12	2027-02-10	1	12	t	1
62	12	2027-03-10	1	12	t	1
63	12	2027-04-10	1	12	t	1
64	12	2027-05-10	1	12	t	1
65	13	2026-10-10	1	10	t	1
66	13	2026-11-10	1	10	t	1
67	13	2027-01-10	1	10	f	1
68	13	2027-02-10	1	10	f	1
69	13	2027-03-10	1	10	t	1
70	13	2027-04-10	1	10	t	1
71	13	2027-05-10	1	10	t	1
72	14	2026-10-10	1	11	t	1
73	14	2026-11-10	1	11	t	1
74	14	2027-01-10	1	11	t	1
75	14	2027-03-10	1	11	t	1
76	14	2027-04-10	1	11	f	1
77	14	2027-05-10	1	11	t	1
78	15	2026-10-10	2	13	t	1
79	15	2026-11-10	2	13	t	1
80	15	2026-12-10	2	13	t	1
81	15	2027-01-10	2	13	f	1
82	15	2027-02-10	2	13	t	1
83	15	2027-03-10	2	13	t	1
84	15	2027-04-10	2	13	f	1
85	15	2027-05-10	2	13	t	1
86	16	2026-10-10	2	14	t	1
87	16	2026-11-10	2	14	t	1
88	16	2026-12-10	2	14	t	1
89	16	2027-01-10	2	14	t	1
90	16	2027-02-10	2	14	f	1
91	16	2027-03-10	2	14	t	1
92	16	2027-04-10	2	14	t	1
93	16	2027-05-10	2	14	t	1
94	17	2026-11-10	2	15	f	1
95	17	2026-12-10	2	15	t	1
96	17	2027-01-10	2	15	t	1
97	17	2027-02-10	2	15	t	1
98	17	2027-04-10	2	15	t	1
99	17	2027-05-10	2	15	t	1
100	18	2026-10-10	2	16	t	1
101	18	2026-11-10	2	16	t	1
102	18	2026-12-10	2	16	t	1
103	18	2027-01-10	2	16	t	1
104	18	2027-02-10	2	16	t	1
105	18	2027-03-10	2	16	t	1
106	18	2027-04-10	2	16	t	1
107	18	2027-05-10	2	16	f	1
108	19	2026-10-10	1	1	t	1
109	19	2026-12-10	1	1	t	1
110	19	2027-02-10	1	1	t	1
111	19	2027-04-10	1	1	t	1
112	20	2026-10-10	1	2	t	1
113	20	2026-11-10	1	2	t	1
114	20	2026-12-10	1	2	t	1
115	20	2027-01-10	1	2	t	1
116	20	2027-02-10	1	2	t	1
117	20	2027-03-10	1	2	t	1
118	20	2027-04-10	1	2	t	1
119	21	2026-10-10	1	3	t	1
120	21	2026-11-10	1	3	t	1
121	21	2026-12-10	1	3	t	1
122	21	2027-01-10	1	3	f	1
123	21	2027-02-10	1	3	t	1
124	21	2027-03-10	1	3	t	1
125	21	2027-04-10	1	3	t	1
126	22	2026-10-10	1	4	t	1
127	22	2027-01-10	1	4	t	1
128	22	2027-02-10	1	4	t	1
129	22	2027-03-10	1	4	t	1
130	23	2026-10-10	1	5	t	1
131	23	2026-11-10	1	5	t	1
132	23	2026-12-10	1	5	t	1
133	23	2027-01-10	1	5	t	1
134	23	2027-02-10	1	5	t	1
135	23	2027-04-10	1	5	f	1
136	23	2027-05-10	1	5	f	1
137	24	2026-10-10	1	6	t	1
138	24	2026-11-10	1	6	t	1
139	24	2026-12-10	1	6	t	1
140	24	2027-01-10	1	6	t	1
141	24	2027-03-10	1	6	t	1
142	24	2027-04-10	1	6	t	1
143	24	2027-05-10	1	6	f	1
144	25	2026-10-10	1	8	t	1
145	25	2026-11-10	1	8	t	1
146	25	2026-12-10	1	8	t	1
147	25	2027-01-10	1	8	t	1
148	25	2027-03-10	1	8	t	1
149	25	2027-04-10	1	8	t	1
150	25	2027-05-10	1	8	f	1
151	26	2026-10-10	1	7	t	1
152	26	2026-11-10	1	7	t	1
153	26	2026-12-10	1	7	t	1
154	26	2027-01-10	1	7	t	1
155	26	2027-02-10	1	7	t	1
156	26	2027-03-10	1	7	t	1
157	26	2027-05-10	1	7	t	1
158	28	2026-10-10	1	12	t	1
159	28	2026-11-10	1	12	t	1
160	28	2026-12-10	1	12	t	1
161	28	2027-02-10	1	12	t	1
162	28	2027-03-10	1	12	t	1
163	28	2027-05-10	1	12	t	1
164	29	2026-10-10	1	10	t	1
165	29	2026-11-10	1	10	t	1
166	29	2027-01-10	1	10	t	1
167	29	2027-02-10	1	10	t	1
168	29	2027-03-10	1	10	t	1
169	30	2026-11-10	1	11	t	1
170	30	2026-12-10	1	11	t	1
171	30	2027-01-10	1	11	t	1
172	30	2027-02-10	1	11	t	1
173	30	2027-03-10	1	11	t	1
174	30	2027-05-10	1	11	t	1
175	31	2026-10-10	2	13	t	1
176	31	2026-12-10	2	13	t	1
177	31	2027-01-10	2	13	t	1
178	31	2027-02-10	2	13	t	1
179	31	2027-03-10	2	13	t	1
180	31	2027-05-10	2	13	t	1
181	32	2026-10-10	2	14	t	1
182	32	2026-11-10	2	14	f	1
183	32	2026-12-10	2	14	t	1
184	32	2027-01-10	2	14	t	1
185	32	2027-02-10	2	14	t	1
186	32	2027-03-10	2	14	t	1
187	32	2027-04-10	2	14	t	1
188	32	2027-05-10	2	14	t	1
189	33	2026-10-10	2	15	t	1
190	33	2026-12-10	2	15	t	1
191	33	2027-01-10	2	15	t	1
192	33	2027-02-10	2	15	t	1
193	33	2027-03-10	2	15	t	1
194	34	2026-10-10	2	16	t	1
195	34	2026-11-10	2	16	t	1
196	34	2027-01-10	2	16	f	1
197	34	2027-02-10	2	16	t	1
198	34	2027-03-10	2	16	t	1
199	34	2027-04-10	2	16	t	1
200	34	2027-05-10	2	16	t	1
201	35	2026-10-10	1	1	t	1
202	35	2026-11-10	1	1	t	1
203	35	2026-12-10	1	1	t	1
204	35	2027-04-10	1	1	t	1
205	35	2027-05-10	1	1	t	1
206	36	2026-10-10	1	2	t	1
207	36	2026-11-10	1	2	f	1
208	36	2026-12-10	1	2	t	1
209	36	2027-01-10	1	2	t	1
210	36	2027-02-10	1	2	t	1
211	36	2027-03-10	1	2	t	1
212	36	2027-04-10	1	2	t	1
213	36	2027-05-10	1	2	t	1
214	37	2026-10-10	1	3	f	1
215	37	2026-12-10	1	3	t	1
216	37	2027-02-10	1	3	t	1
217	37	2027-03-10	1	3	f	1
218	37	2027-04-10	1	3	t	1
219	37	2027-05-10	1	3	t	1
220	38	2026-10-10	1	4	t	1
221	38	2026-11-10	1	4	t	1
222	38	2026-12-10	1	4	t	1
223	38	2027-02-10	1	4	t	1
224	38	2027-03-10	1	4	t	1
225	38	2027-04-10	1	4	t	1
226	38	2027-05-10	1	4	t	1
227	39	2026-10-10	1	5	t	1
228	39	2026-12-10	1	5	t	1
229	39	2027-01-10	1	5	t	1
230	39	2027-02-10	1	5	t	1
231	39	2027-03-10	1	5	f	1
232	39	2027-04-10	1	5	t	1
233	39	2027-05-10	1	5	t	1
234	40	2026-10-10	1	6	t	1
235	40	2026-11-10	1	6	f	1
236	40	2026-12-10	1	6	t	1
237	40	2027-01-10	1	6	t	1
238	40	2027-02-10	1	6	t	1
239	40	2027-04-10	1	6	t	1
240	40	2027-05-10	1	6	t	1
241	41	2026-10-10	1	8	f	1
242	41	2026-11-10	1	8	t	1
243	41	2026-12-10	1	8	t	1
244	41	2027-01-10	1	8	t	1
245	41	2027-02-10	1	8	t	1
246	41	2027-03-10	1	8	t	1
247	41	2027-04-10	1	8	t	1
248	41	2027-05-10	1	8	t	1
249	42	2026-11-10	1	7	t	1
250	42	2026-12-10	1	7	t	1
251	42	2027-01-10	1	7	t	1
252	42	2027-02-10	1	7	t	1
253	42	2027-03-10	1	7	t	1
254	42	2027-04-10	1	7	t	1
255	42	2027-05-10	1	7	t	1
256	43	2026-10-10	1	9	t	1
257	43	2026-11-10	1	9	t	1
258	43	2026-12-10	1	9	t	1
259	43	2027-02-10	1	9	t	1
260	43	2027-03-10	1	9	t	1
261	43	2027-04-10	1	9	t	1
262	43	2027-05-10	1	9	t	1
263	45	2026-11-10	1	10	t	1
264	45	2026-12-10	1	10	t	1
265	45	2027-01-10	1	10	t	1
266	45	2027-02-10	1	10	t	1
267	45	2027-03-10	1	10	t	1
268	45	2027-04-10	1	10	t	1
269	45	2027-05-10	1	10	t	1
270	46	2026-10-10	1	11	t	1
271	46	2026-11-10	1	11	t	1
272	46	2026-12-10	1	11	t	1
273	46	2027-01-10	1	11	f	1
274	46	2027-02-10	1	11	t	1
275	46	2027-03-10	1	11	t	1
276	46	2027-04-10	1	11	t	1
277	46	2027-05-10	1	11	t	1
278	47	2026-10-10	2	13	t	1
279	47	2026-12-10	2	13	t	1
280	47	2027-01-10	2	13	t	1
281	47	2027-02-10	2	13	f	1
282	47	2027-03-10	2	13	t	1
283	47	2027-04-10	2	13	t	1
284	47	2027-05-10	2	13	t	1
285	48	2026-11-10	2	14	t	1
286	48	2026-12-10	2	14	t	1
287	48	2027-02-10	2	14	t	1
288	49	2026-10-10	2	15	t	1
289	49	2026-12-10	2	15	t	1
290	49	2027-01-10	2	15	f	1
291	49	2027-02-10	2	15	t	1
292	49	2027-03-10	2	15	t	1
293	50	2026-10-10	2	16	t	1
294	50	2026-11-10	2	16	t	1
295	50	2026-12-10	2	16	f	1
296	50	2027-01-10	2	16	t	1
297	50	2027-03-10	2	16	t	1
298	50	2027-05-10	2	16	t	1
299	51	2026-10-10	1	1	t	1
300	51	2026-11-10	1	1	t	1
301	51	2027-02-10	1	1	t	1
302	51	2027-03-10	1	1	t	1
303	51	2027-04-10	1	1	t	1
304	51	2027-05-10	1	1	t	1
305	52	2026-10-10	1	2	t	1
306	52	2026-11-10	1	2	t	1
307	52	2026-12-10	1	2	t	1
308	52	2027-01-10	1	2	t	1
309	52	2027-02-10	1	2	t	1
310	52	2027-03-10	1	2	t	1
311	52	2027-04-10	1	2	t	1
312	52	2027-05-10	1	2	t	1
313	3	2026-07-29	1	1	t	1
316	36	2026-08-01	1	2	t	1
319	20	2026-08-01	1	2	t	1
320	4	2026-08-01	1	2	t	1
315	52	2026-08-01	1	2	f	1
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, nom_site, initiale) FROM stdin;
1	Jéricho	J
2	Yagbé	Y
\.


--
-- Data for Name: user_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sites (user_id, site_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, role, site_id, actif) FROM stdin;
8a3ec1da-561d-403a-b092-92190861d201	devtesteur	urielaxelhouegbe@gmail.com	coordonnateur	\N	t
3f2a5bd3-6ebd-4f0e-a8c3-fbc818006939	test-chefsite	test-chefsite@gsr-tests.local	chef_site	1	t
\.


--
-- Data for Name: classes_td; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.classes_td (id, nom_classe) FROM stdin;
1	6ème
2	5ème
3	4ème
4	3ème
5	Seconde
6	Première
7	Terminale
\.


--
-- Data for Name: creneaux; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.creneaux (id, semaine_id, classe_id, matiere_id, date_td, heure_debut, heure_fin, montant_prevu, statut_creneau) FROM stdin;
\.


--
-- Data for Name: matieres_td; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.matieres_td (id, nom_matiere) FROM stdin;
1	Francais
2	Mathematiques
3	Anglais
4	Physique-Chimie
5	SVT
6	Philosophie
7	Histoire-Geographie
8	Economie
22	Espagnol
23	Allemand
\.


--
-- Data for Name: postulations; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.postulations (id, creneau_id, professeur_id, statut_validation, date_postulation) FROM stdin;
\.


--
-- Data for Name: professeurs; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.professeurs (id, nom, prenom, telephone, email, mot_de_passe, zone_id, matiere_principale_id, actif, date_inscription) FROM stdin;
1	TESTAUTO	testauto-prof1	+22900000091	testauto-prof1@gsr-tests.local	$2b$10$K21WkMH5kJ9Kk3AppNSK.e3p/CUI68L0geUwuDYpYi2LV5p1KQkKO	1	1	t	2026-08-01 19:07:14.760666+00
2	TESTAUTO	testauto-prof2	+22900000092	testauto-prof2@gsr-tests.local	$2b$10$KBnJq92JhxCWKUWFgatbYOeS0OdLnGTFoXVHhMslvKmPNs6wDFSli	1	1	t	2026-08-01 19:07:15.356208+00
\.


--
-- Data for Name: semaines; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.semaines (id, libelle, date_debut, date_fin, statut, date_creation, date_cloture) FROM stdin;
5	Semaine 1	2026-08-05	2026-08-08	brouillon	2026-08-05 20:36:19.116336+00	\N
\.


--
-- Data for Name: zones; Type: TABLE DATA; Schema: td; Owner: -
--

COPY td.zones (id, nom_zone) FROM stdin;
2	Akpakpa
1	Jéricho
3	Vedoko
4	Agla
5	Houeyiho
\.


--
-- Name: actualites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_id_seq', 3, true);


--
-- Name: actualites_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actualites_images_id_seq', 3, true);


--
-- Name: annees_scolaires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.annees_scolaires_id_seq', 1, true);


--
-- Name: categories_depenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_depenses_id_seq', 8, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.classes_id_seq', 16, true);


--
-- Name: coefficients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.coefficients_id_seq', 1, false);


--
-- Name: comptes_parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comptes_parents_id_seq', 1, false);


--
-- Name: decisions_passage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.decisions_passage_id_seq', 73, true);


--
-- Name: depenses_annexes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.depenses_annexes_id_seq', 1, false);


--
-- Name: eleves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_id_seq', 54, true);


--
-- Name: eleves_suspendus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eleves_suspendus_id_seq', 23, true);


--
-- Name: frais_td_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.frais_td_id_seq', 16, true);


--
-- Name: galerie_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_admin_id_seq', 1, false);


--
-- Name: galerie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.galerie_id_seq', 1, false);


--
-- Name: log_whatsapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_whatsapp_id_seq', 1, false);


--
-- Name: login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_attempts_id_seq', 14, true);


--
-- Name: matieres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matieres_id_seq', 48, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_id_seq', 256, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 20, true);


--
-- Name: paiements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_id_seq', 212, true);


--
-- Name: paiements_supprimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paiements_supprimes_id_seq', 1, false);


--
-- Name: presences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.presences_id_seq', 329, true);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 2, true);


--
-- Name: classes_td_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.classes_td_id_seq', 7, true);


--
-- Name: creneaux_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.creneaux_id_seq', 6, true);


--
-- Name: matieres_td_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.matieres_td_id_seq', 23, true);


--
-- Name: postulations_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.postulations_id_seq', 10, true);


--
-- Name: professeurs_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.professeurs_id_seq', 2, true);


--
-- Name: semaines_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.semaines_id_seq', 5, true);


--
-- Name: zones_id_seq; Type: SEQUENCE SET; Schema: td; Owner: -
--

SELECT pg_catalog.setval('td.zones_id_seq', 7, true);


--
-- Name: actualites_images actualites_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_pkey PRIMARY KEY (id);


--
-- Name: actualites actualites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_pkey PRIMARY KEY (id);


--
-- Name: annees_scolaires annees_scolaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annees_scolaires
    ADD CONSTRAINT annees_scolaires_pkey PRIMARY KEY (id);


--
-- Name: categories_depenses categories_depenses_nom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_nom_key UNIQUE (nom);


--
-- Name: categories_depenses categories_depenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories_depenses
    ADD CONSTRAINT categories_depenses_pkey PRIMARY KEY (id);


--
-- Name: classes classes_nom_classe_site_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_nom_classe_site_id_key UNIQUE (nom_classe, site_id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: coefficients coefficients_classe_id_matiere_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_matiere_id_key UNIQUE (classe_id, matiere_id);


--
-- Name: coefficients coefficients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_pkey PRIMARY KEY (id);


--
-- Name: comptes_parents comptes_parents_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_matricule_key UNIQUE (matricule);


--
-- Name: comptes_parents comptes_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comptes_parents
    ADD CONSTRAINT comptes_parents_pkey PRIMARY KEY (id);


--
-- Name: decisions_passage decisions_passage_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_key UNIQUE (eleve_id);


--
-- Name: decisions_passage decisions_passage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_pkey PRIMARY KEY (id);


--
-- Name: depenses_annexes depenses_annexes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_pkey PRIMARY KEY (id);


--
-- Name: eleves eleves_matricule_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_matricule_key UNIQUE (matricule);


--
-- Name: eleves eleves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_pkey PRIMARY KEY (id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_key UNIQUE (eleve_id);


--
-- Name: eleves_suspendus eleves_suspendus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_pkey PRIMARY KEY (id);


--
-- Name: frais_td frais_td_classe_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_key UNIQUE (classe_id);


--
-- Name: frais_td frais_td_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_pkey PRIMARY KEY (id);


--
-- Name: galerie_admin galerie_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_pkey PRIMARY KEY (id);


--
-- Name: galerie galerie_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie
    ADD CONSTRAINT galerie_pkey PRIMARY KEY (id);


--
-- Name: log_whatsapp log_whatsapp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: matieres matieres_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_code_key UNIQUE (code);


--
-- Name: matieres matieres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matieres
    ADD CONSTRAINT matieres_pkey PRIMARY KEY (id);


--
-- Name: notes notes_eleve_id_matiere_id_type_note_annee_scolaire_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_id_matiere_id_type_note_annee_scolaire_id_key UNIQUE (eleve_id, matiere_id, type_note, annee_scolaire_id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: paiements paiements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_pkey PRIMARY KEY (id);


--
-- Name: paiements_supprimes paiements_supprimes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_pkey PRIMARY KEY (id);


--
-- Name: presences presences_eleve_id_date_presence_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_date_presence_key UNIQUE (eleve_id, date_presence);


--
-- Name: presences presences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_pkey PRIMARY KEY (id);


--
-- Name: sites sites_initiale_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_initiale_key UNIQUE (initiale);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: user_sites user_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_pkey PRIMARY KEY (user_id, site_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: classes_td classes_td_nom_classe_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.classes_td
    ADD CONSTRAINT classes_td_nom_classe_key UNIQUE (nom_classe);


--
-- Name: classes_td classes_td_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.classes_td
    ADD CONSTRAINT classes_td_pkey PRIMARY KEY (id);


--
-- Name: creneaux creneaux_classe_id_date_td_heure_debut_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_date_td_heure_debut_key UNIQUE (classe_id, date_td, heure_debut);


--
-- Name: creneaux creneaux_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_pkey PRIMARY KEY (id);


--
-- Name: matieres_td matieres_td_nom_matiere_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_nom_matiere_key UNIQUE (nom_matiere);


--
-- Name: matieres_td matieres_td_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.matieres_td
    ADD CONSTRAINT matieres_td_pkey PRIMARY KEY (id);


--
-- Name: postulations postulations_creneau_id_professeur_id_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_professeur_id_key UNIQUE (creneau_id, professeur_id);


--
-- Name: postulations postulations_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_email_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_email_key UNIQUE (email);


--
-- Name: professeurs professeurs_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_pkey PRIMARY KEY (id);


--
-- Name: professeurs professeurs_telephone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_telephone_key UNIQUE (telephone);


--
-- Name: semaines semaines_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.semaines
    ADD CONSTRAINT semaines_pkey PRIMARY KEY (id);


--
-- Name: zones zones_nom_zone_key; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_nom_zone_key UNIQUE (nom_zone);


--
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id);


--
-- Name: idx_login_attempts_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_attempts_lookup ON public.login_attempts USING btree (identifiant, portail, date_tentative);


--
-- Name: idx_creneaux_semaine; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_creneaux_semaine ON td.creneaux USING btree (semaine_id);


--
-- Name: idx_postulations_professeur; Type: INDEX; Schema: td; Owner: -
--

CREATE INDEX idx_postulations_professeur ON td.postulations USING btree (professeur_id, statut_validation);


--
-- Name: frais_td trg_frais_td_lock_period; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_frais_td_lock_period BEFORE UPDATE OF montant ON public.frais_td FOR EACH ROW EXECUTE FUNCTION public.trg_frais_td_lock_period_fn();


--
-- Name: annees_scolaires trg_unique_annee_en_cours; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_unique_annee_en_cours BEFORE INSERT OR UPDATE ON public.annees_scolaires FOR EACH ROW EXECUTE FUNCTION public.trg_unique_annee_en_cours_fn();


--
-- Name: users trg_users_scope_coherence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_scope_coherence BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.trg_users_scope_coherence_fn();


--
-- Name: actualites actualites_cree_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites
    ADD CONSTRAINT actualites_cree_par_fkey FOREIGN KEY (cree_par) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: actualites_images actualites_images_actualite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actualites_images
    ADD CONSTRAINT actualites_images_actualite_id_fkey FOREIGN KEY (actualite_id) REFERENCES public.actualites(id) ON DELETE CASCADE;


--
-- Name: classes classes_classe_suivante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_classe_suivante_id_fkey FOREIGN KEY (classe_suivante_id) REFERENCES public.classes(id) ON DELETE SET NULL;


--
-- Name: classes classes_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: coefficients coefficients_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coefficients
    ADD CONSTRAINT coefficients_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: decisions_passage decisions_passage_decide_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_decide_par_fkey FOREIGN KEY (decide_par) REFERENCES public.users(id);


--
-- Name: decisions_passage decisions_passage_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: decisions_passage decisions_passage_nouvelle_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.decisions_passage
    ADD CONSTRAINT decisions_passage_nouvelle_classe_id_fkey FOREIGN KEY (nouvelle_classe_id) REFERENCES public.classes(id);


--
-- Name: depenses_annexes depenses_annexes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_categorie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_categorie_id_fkey FOREIGN KEY (categorie_id) REFERENCES public.categories_depenses(id) ON DELETE RESTRICT;


--
-- Name: depenses_annexes depenses_annexes_saisi_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depenses_annexes
    ADD CONSTRAINT depenses_annexes_saisi_par_fkey FOREIGN KEY (saisi_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: eleves eleves_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves
    ADD CONSTRAINT eleves_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id);


--
-- Name: eleves_suspendus eleves_suspendus_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: eleves_suspendus eleves_suspendus_suspendu_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eleves_suspendus
    ADD CONSTRAINT eleves_suspendus_suspendu_par_fkey FOREIGN KEY (suspendu_par) REFERENCES public.users(id);


--
-- Name: frais_td frais_td_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frais_td
    ADD CONSTRAINT frais_td_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: galerie_admin galerie_admin_ajoute_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galerie_admin
    ADD CONSTRAINT galerie_admin_ajoute_par_fkey FOREIGN KEY (ajoute_par) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: log_whatsapp log_whatsapp_envoye_par_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_whatsapp
    ADD CONSTRAINT log_whatsapp_envoye_par_fkey FOREIGN KEY (envoye_par) REFERENCES public.users(id);


--
-- Name: notes notes_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: notes notes_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: notes notes_matiere_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES public.matieres(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: paiements paiements_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements
    ADD CONSTRAINT paiements_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: paiements_supprimes paiements_supprimes_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paiements_supprimes
    ADD CONSTRAINT paiements_supprimes_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: presences presences_annee_scolaire_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_annee_scolaire_id_fkey FOREIGN KEY (annee_scolaire_id) REFERENCES public.annees_scolaires(id) ON DELETE CASCADE;


--
-- Name: presences presences_classe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES public.classes(id) ON DELETE CASCADE;


--
-- Name: presences presences_eleve_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_eleve_id_fkey FOREIGN KEY (eleve_id) REFERENCES public.eleves(id) ON DELETE CASCADE;


--
-- Name: presences presences_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presences
    ADD CONSTRAINT presences_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: user_sites user_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE CASCADE;


--
-- Name: user_sites user_sites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sites
    ADD CONSTRAINT user_sites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users users_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: creneaux creneaux_classe_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_classe_id_fkey FOREIGN KEY (classe_id) REFERENCES td.classes_td(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_matiere_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_matiere_id_fkey FOREIGN KEY (matiere_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: creneaux creneaux_semaine_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.creneaux
    ADD CONSTRAINT creneaux_semaine_id_fkey FOREIGN KEY (semaine_id) REFERENCES td.semaines(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_creneau_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_creneau_id_fkey FOREIGN KEY (creneau_id) REFERENCES td.creneaux(id) ON DELETE CASCADE;


--
-- Name: postulations postulations_professeur_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.postulations
    ADD CONSTRAINT postulations_professeur_id_fkey FOREIGN KEY (professeur_id) REFERENCES td.professeurs(id) ON DELETE CASCADE;


--
-- Name: professeurs professeurs_matiere_principale_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_matiere_principale_id_fkey FOREIGN KEY (matiere_principale_id) REFERENCES td.matieres_td(id) ON DELETE RESTRICT;


--
-- Name: professeurs professeurs_zone_id_fkey; Type: FK CONSTRAINT; Schema: td; Owner: -
--

ALTER TABLE ONLY td.professeurs
    ADD CONSTRAINT professeurs_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES td.zones(id) ON DELETE RESTRICT;


--
-- Name: actualites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.actualites_images ENABLE ROW LEVEL SECURITY;

--
-- Name: actualites_images actualites_images_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_images_lecture_publique ON public.actualites_images FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.actualites a
  WHERE ((a.id = actualites_images.actualite_id) AND (a.statut = 'publie'::text)))));


--
-- Name: actualites actualites_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY actualites_lecture_publique ON public.actualites FOR SELECT USING ((statut = 'publie'::text));


--
-- Name: annees_scolaires; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.annees_scolaires ENABLE ROW LEVEL SECURITY;

--
-- Name: annees_scolaires annees_scolaires_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY annees_scolaires_lecture_staff ON public.annees_scolaires FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: categories_depenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.categories_depenses ENABLE ROW LEVEL SECURITY;

--
-- Name: categories_depenses categories_depenses_lecture_global; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY categories_depenses_lecture_global ON public.categories_depenses FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: classes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;

--
-- Name: classes classes_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY classes_lecture_staff ON public.classes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: coefficients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coefficients ENABLE ROW LEVEL SECURITY;

--
-- Name: coefficients coefficients_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY coefficients_lecture_staff ON public.coefficients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: comptes_parents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.comptes_parents ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.decisions_passage ENABLE ROW LEVEL SECURITY;

--
-- Name: decisions_passage decisions_passage_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY decisions_passage_lecture ON public.decisions_passage FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: depenses_annexes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.depenses_annexes ENABLE ROW LEVEL SECURITY;

--
-- Name: depenses_annexes depenses_annexes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY depenses_annexes_lecture ON public.depenses_annexes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: eleves; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves eleves_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_acces ON public.eleves USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM (public.user_sites us
             JOIN public.classes c ON ((c.id = eleves.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = 'chef_site'::text) AND (EXISTS ( SELECT 1
           FROM public.classes c
          WHERE ((c.id = eleves.classe_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: eleves_suspendus; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.eleves_suspendus ENABLE ROW LEVEL SECURITY;

--
-- Name: eleves_suspendus eleves_suspendus_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eleves_suspendus_acces ON public.eleves_suspendus USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = eleves_suspendus.site_id))))))))));


--
-- Name: frais_td; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.frais_td ENABLE ROW LEVEL SECURITY;

--
-- Name: frais_td frais_td_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY frais_td_lecture_staff ON public.frais_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: galerie; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.galerie_admin ENABLE ROW LEVEL SECURITY;

--
-- Name: galerie_admin galerie_admin_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_admin_acces ON public.galerie_admin USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text, 'superviseur'::text]))))));


--
-- Name: galerie galerie_lecture_publique; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY galerie_lecture_publique ON public.galerie FOR SELECT USING (true);


--
-- Name: log_whatsapp; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.log_whatsapp ENABLE ROW LEVEL SECURITY;

--
-- Name: log_whatsapp log_whatsapp_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY log_whatsapp_acces ON public.log_whatsapp FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON (((e.matricule)::text = (log_whatsapp.matricule)::text)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: login_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.matieres ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres matieres_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY matieres_lecture_staff ON public.matieres FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

--
-- Name: notes notes_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notes_acces ON public.notes USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = notes.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))) OR ((u.role = 'chef_site'::text) AND (EXISTS ( SELECT 1
           FROM (public.eleves e
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((e.id = notes.eleve_id) AND (c.site_id = u.site_id))))))))));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_acces ON public.notifications FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = notifications.site_id))))) OR ((u.role = 'chef_site'::text) AND (u.site_id = notifications.site_id)))))));


--
-- Name: paiements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements paiements_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_acces ON public.paiements USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM ((public.user_sites us
             JOIN public.eleves e ON ((e.id = paiements.eleve_id)))
             JOIN public.classes c ON ((c.id = e.classe_id)))
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = c.site_id))))))))));


--
-- Name: paiements_supprimes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.paiements_supprimes ENABLE ROW LEVEL SECURITY;

--
-- Name: paiements_supprimes paiements_supprimes_lecture; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY paiements_supprimes_lecture ON public.paiements_supprimes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text]))))));


--
-- Name: presences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.presences ENABLE ROW LEVEL SECURITY;

--
-- Name: presences presences_acces; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY presences_acces ON public.presences USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND ((u.role = ANY (ARRAY['coordonnateur'::text, 'comptable'::text])) OR ((u.role = 'superviseur'::text) AND (EXISTS ( SELECT 1
           FROM public.user_sites us
          WHERE ((us.user_id = auth.uid()) AND (us.site_id = presences.site_id))))) OR ((u.role = 'chef_site'::text) AND (u.site_id = presences.site_id)))))));


--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: sites sites_lecture_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_lecture_staff ON public.sites FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true)))));


--
-- Name: user_sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_sites ENABLE ROW LEVEL SECURITY;

--
-- Name: user_sites user_sites_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_sites_lecture_soi_meme ON public.user_sites FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_lecture_soi_meme; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_lecture_soi_meme ON public.users FOR SELECT USING ((id = auth.uid()));


--
-- Name: classes_td; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.classes_td ENABLE ROW LEVEL SECURITY;

--
-- Name: creneaux; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.creneaux ENABLE ROW LEVEL SECURITY;

--
-- Name: matieres_td; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.matieres_td ENABLE ROW LEVEL SECURITY;

--
-- Name: postulations; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.postulations ENABLE ROW LEVEL SECURITY;

--
-- Name: professeurs; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.professeurs ENABLE ROW LEVEL SECURITY;

--
-- Name: semaines; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.semaines ENABLE ROW LEVEL SECURITY;

--
-- Name: classes_td td_classes_td_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_classes_td_lecture_coordonnateur ON td.classes_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: creneaux td_creneaux_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_creneaux_lecture_coordonnateur ON td.creneaux FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: matieres_td td_matieres_td_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_matieres_td_lecture_coordonnateur ON td.matieres_td FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: postulations td_postulations_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_postulations_lecture_coordonnateur ON td.postulations FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: professeurs td_professeurs_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_professeurs_lecture_coordonnateur ON td.professeurs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: semaines td_semaines_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_semaines_lecture_coordonnateur ON td.semaines FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: zones td_zones_lecture_coordonnateur; Type: POLICY; Schema: td; Owner: -
--

CREATE POLICY td_zones_lecture_coordonnateur ON td.zones FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth.uid()) AND (u.actif = true) AND (u.role = 'coordonnateur'::text)))));


--
-- Name: zones; Type: ROW SECURITY; Schema: td; Owner: -
--

ALTER TABLE td.zones ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict m9pQybpele2TZmps7xIuSImG3z4qVVOS1SBAm2gsATTFuS8QDjqjNSYPn8QfRKG

